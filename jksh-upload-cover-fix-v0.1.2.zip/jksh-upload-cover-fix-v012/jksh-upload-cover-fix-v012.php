<?php
/**
 * Plugin Name: JKSH Upload Cover Fix v0.1.2
 * Description: Restores one separate video-only drag/drop cover uploader on JK Social Hub Social Upload. Hides cover UI for image posts and keeps the native cover input as the submission source.
 * Version: 0.1.2
 * Author: JustKalinga
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Upload_Cover_Fix_V012 {
    const VERSION = '0.1.2';

    public function __construct() {
        add_action( 'admin_footer', array( $this, 'render_fix' ), 9999 );
        add_action( 'rest_api_init', array( $this, 'register_rest' ) );
    }

    public function register_rest() {
        register_rest_route( 'jksh-upload-cover-fix/v1', '/status', array(
            'methods' => 'GET',
            'permission_callback' => function () { return current_user_can( 'manage_options' ) || current_user_can( 'jksh_view' ); },
            'callback' => function () {
                return rest_ensure_response( array(
                    'ok' => true,
                    'version' => self::VERSION,
                    'behavior' => array(
                        'single_post_cover' => 'hidden',
                        'carousel_cover' => 'hidden',
                        'reel_short_cover' => 'visible',
                        'long_video_cover' => 'visible',
                        'duplicate_native_cover_ui' => 'hidden',
                        'native_cover_input_preserved' => true,
                    ),
                ) );
            },
        ) );
    }

    public function render_fix() {
        if ( ! is_admin() ) { return; }
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( 'jksh-social-upload' !== $page ) { return; }
        ?>
        <style id="jksh-cover-fix-v012-css">
            .jksh-cover-fix-v012-card{display:none;margin:18px 0 0;background:#fff;border:1px solid #d9e1ec;border-radius:16px;padding:18px 20px;box-shadow:0 2px 10px rgba(15,23,42,.025)}
            .jksh-cover-fix-v012-card.is-visible{display:block}
            .jksh-cover-fix-v012-title{font-size:14px;font-weight:700;color:#101828;margin:0 0 10px}
            .jksh-cover-fix-v012-drop{min-height:150px;border:2px dashed #cbd5e1;border-radius:16px;background:#fbfdff;display:flex;align-items:center;justify-content:center;text-align:center;cursor:pointer;transition:border-color .16s ease,background .16s ease,box-shadow .16s ease;padding:18px}
            .jksh-cover-fix-v012-drop:hover,.jksh-cover-fix-v012-drop.is-over{border-color:#94a3b8;background:#f8fafc;box-shadow:0 0 0 3px rgba(148,163,184,.12)}
            .jksh-cover-fix-v012-drop strong{display:block;font-size:15px;color:#101828;margin-bottom:5px}
            .jksh-cover-fix-v012-drop small{display:block;color:#667085;font-size:12px}
            .jksh-cover-fix-v012-preview{display:none;gap:12px;align-items:center;margin-top:12px;padding:10px;border:1px solid #e5e7eb;border-radius:12px;background:#f8fafc}
            .jksh-cover-fix-v012-preview.is-visible{display:flex}
            .jksh-cover-fix-v012-preview img{width:66px;height:66px;object-fit:cover;border-radius:10px;border:1px solid #e5e7eb;background:#fff}
            .jksh-cover-fix-v012-preview span{font-size:12px;color:#475467;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:480px}
            .jksh-cover-fix-v012-note{margin:8px 0 0;font-size:11px;color:#667085}
        </style>
        <script id="jksh-cover-fix-v012-js">
        (()=>{
            'use strict';
            if (window.__jkshCoverFixV012) return;
            window.__jkshCoverFixV012 = true;

            const VIDEO_TYPES = new Set(['reel','short','reel_short','reel-short','video','long_video','long-video','longvideo']);
            let lastClickedType = '';
            let objectUrl = '';

            const norm = s => String(s || '').replace(/\s+/g,' ').trim().toLowerCase();

            function mapType(v){
                const s = norm(v).replace(/\s+/g,'_');
                if (!s) return '';
                if (s.includes('reel') || s.includes('short')) return 'reel';
                if (s.includes('long') && s.includes('video')) return 'long_video';
                if (s.includes('carousel')) return 'carousel';
                if (s.includes('single')) return 'single_post';
                if (s === 'image' || s.includes('single_image')) return 'single_post';
                return s;
            }

            function contentControls(){
                return Array.from(document.querySelectorAll('input[name*="content_type"], select[name*="content_type"], [data-content-type], [data-type]'));
            }

            function selectedFromInputs(){
                for (const el of contentControls()) {
                    let raw = '';
                    if (el.matches('input[type="radio"],input[type="checkbox"]')) {
                        if (!el.checked) continue;
                        raw = el.value || el.dataset.contentType || el.dataset.type || '';
                    } else if (el.tagName === 'SELECT') {
                        raw = el.value || '';
                    } else {
                        raw = el.dataset.contentType || el.dataset.type || '';
                    }
                    const mapped = mapType(raw);
                    if (mapped) return mapped;
                }
                return '';
            }

            function candidateCards(){
                const labels = ['Single post','Carousel','Reel / Short','Long video'];
                const out = [];
                for (const label of labels) {
                    const target = Array.from(document.querySelectorAll('button,label,[role="button"],div')).filter(el=>{
                        const t = String(el.innerText || '').replace(/\s+/g,' ').trim();
                        return t === label || t.startsWith(label + ' ');
                    }).sort((a,b)=>a.querySelectorAll('*').length-b.querySelectorAll('*').length)[0];
                    if (!target) continue;
                    let card = target;
                    for (let i=0;i<4 && card.parentElement;i++) {
                        const parent = card.parentElement;
                        const pt = String(parent.innerText || '').replace(/\s+/g,' ').trim();
                        if (pt.startsWith(label) && pt.length < 90) card = parent; else break;
                    }
                    out.push({label,type:mapType(label),el:card});
                }
                return out;
            }

            function selectedFromCards(){
                const cards = candidateCards();
                for (const c of cards) {
                    const el = c.el;
                    if (el.matches('.active,.selected,.is-active,.is-selected,[aria-selected="true"],[aria-pressed="true"]') || el.querySelector('input:checked')) return c.type;
                }
                // Fallback: chosen card usually has a unique red border/background compared with peers.
                const signatures = cards.map(c=>{
                    const s = getComputedStyle(c.el);
                    return {type:c.type, border:s.borderColor, bg:s.backgroundColor};
                });
                if (signatures.length >= 3) {
                    const score = sig => signatures.filter(x=>x.border===sig.border && x.bg===sig.bg).length;
                    const unique = signatures.filter(sig=>score(sig)===1);
                    if (unique.length === 1) return unique[0].type;
                }
                return '';
            }

            function currentType(){
                return lastClickedType || selectedFromInputs() || selectedFromCards() || '';
            }

            function nativeCoverInput(){
                const files = Array.from(document.querySelectorAll('input[type="file"]'));
                let best = null, bestScore = -1;
                for (const el of files) {
                    let score = 0;
                    const hay = norm((el.name||'')+' '+(el.id||'')+' '+(el.className||'')+' '+(el.accept||''));
                    const parentText = norm((el.closest('section,div,fieldset,label')||{}).innerText || '');
                    if (/cover|thumb/.test(hay)) score += 8;
                    if (/cover|thumbnail/.test(parentText)) score += 7;
                    if ((el.accept||'').toLowerCase().includes('image')) score += 4;
                    if ((el.accept||'').toLowerCase().includes('video')) score -= 5;
                    if (el.multiple) score -= 3;
                    if (score > bestScore) { best = el; bestScore = score; }
                }
                return bestScore >= 4 ? best : null;
            }

            function nativeCoverWrapper(input){
                if (!input) return null;
                let node = input.parentElement;
                for (let i=0;i<6 && node;i++, node=node.parentElement) {
                    const t = norm(node.innerText || '');
                    if (t.includes('cover / thumbnail') || t.includes('cover image') || t.includes('thumbnail')) return node;
                }
                return input.parentElement;
            }

            function diagnosticsAnchor(){
                const els = Array.from(document.querySelectorAll('details,section,div'));
                return els.find(el=>norm(el.innerText || '').startsWith('advanced / diagnostics')) || null;
            }

            function mediaSection(){
                const nodes = Array.from(document.querySelectorAll('section,div'));
                const matches = nodes.filter(el=>{
                    const t = norm(el.innerText || '');
                    return t.includes('drop media here or browse') && t.length < 400;
                }).sort((a,b)=>a.querySelectorAll('*').length-b.querySelectorAll('*').length);
                return matches[0] || null;
            }

            function ensureCard(){
                let card = document.getElementById('jksh-cover-fix-v012-card');
                if (card) return card;
                card = document.createElement('div');
                card.id = 'jksh-cover-fix-v012-card';
                card.className = 'jksh-cover-fix-v012-card';
                card.innerHTML = `
                    <div class="jksh-cover-fix-v012-title">Cover / thumbnail</div>
                    <div class="jksh-cover-fix-v012-drop" role="button" tabindex="0">
                        <div><strong>Drop cover image here or click to browse</strong><small>PNG, JPG or WebP</small></div>
                    </div>
                    <div class="jksh-cover-fix-v012-preview"><img alt="Cover preview"><span></span></div>
                    <p class="jksh-cover-fix-v012-note">Optional. If no cover is selected, the Studio can use a video frame where supported.</p>`;
                const diag = diagnosticsAnchor();
                const media = mediaSection();
                if (diag && diag.parentElement) diag.parentElement.insertBefore(card, diag);
                else if (media && media.parentElement) media.insertAdjacentElement('afterend', card);
                else document.querySelector('#wpbody-content')?.appendChild(card);

                const drop = card.querySelector('.jksh-cover-fix-v012-drop');
                const choose = ()=>{ const input = nativeCoverInput(); if (input) input.click(); };
                drop.addEventListener('click', choose);
                drop.addEventListener('keydown', e=>{ if (e.key==='Enter' || e.key===' ') { e.preventDefault(); choose(); } });
                ['dragenter','dragover'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault(); drop.classList.add('is-over');}));
                ['dragleave','drop'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault(); drop.classList.remove('is-over');}));
                drop.addEventListener('drop', e=>{
                    const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
                    if (!file) return;
                    if (!/^image\/(png|jpeg|webp)$/i.test(file.type)) { alert('Please use a PNG, JPG or WebP cover image.'); return; }
                    const input = nativeCoverInput();
                    if (!input) { alert('The native cover field was not found. Refresh the page and try again.'); return; }
                    try {
                        const dt = new DataTransfer(); dt.items.add(file); input.files = dt.files;
                        input.dispatchEvent(new Event('change',{bubbles:true}));
                    } catch(err) { input.click(); }
                });
                return card;
            }

            function updatePreview(input){
                const card = ensureCard();
                const preview = card.querySelector('.jksh-cover-fix-v012-preview');
                if (!input || !input.files || !input.files[0]) { preview.classList.remove('is-visible'); return; }
                const file = input.files[0];
                if (objectUrl) URL.revokeObjectURL(objectUrl);
                objectUrl = URL.createObjectURL(file);
                preview.querySelector('img').src = objectUrl;
                preview.querySelector('span').textContent = file.name;
                preview.classList.add('is-visible');
            }

            function hideLegacyCover(){
                const input = nativeCoverInput();
                if (!input) return;
                const wrap = nativeCoverWrapper(input);
                if (wrap && !wrap.contains(document.getElementById('jksh-cover-fix-v012-card'))) wrap.style.display = 'none';
                input.style.display = 'none';
                if (!input.dataset.jkshCoverFixBound) {
                    input.dataset.jkshCoverFixBound = '1';
                    input.addEventListener('change',()=>updatePreview(input));
                }
            }

            function sync(){
                hideLegacyCover();
                const card = ensureCard();
                const type = currentType();
                const isVideo = type === 'reel' || type === 'long_video' || VIDEO_TYPES.has(type);
                card.classList.toggle('is-visible', isVideo);
                if (!isVideo) card.querySelector('.jksh-cover-fix-v012-preview')?.classList.remove('is-visible');
            }

            document.addEventListener('click', e=>{
                let node = e.target;
                for (let i=0;i<5 && node;i++,node=node.parentElement) {
                    const t = norm(node.innerText || '');
                    if (t === 'single post' || t.startsWith('single post ')) { lastClickedType='single_post'; setTimeout(sync,20); return; }
                    if (t === 'carousel' || t.startsWith('carousel ')) { lastClickedType='carousel'; setTimeout(sync,20); return; }
                    if (t === 'reel / short' || t.startsWith('reel / short ')) { lastClickedType='reel'; setTimeout(sync,20); return; }
                    if (t === 'long video' || t.startsWith('long video ')) { lastClickedType='long_video'; setTimeout(sync,20); return; }
                }
            }, true);

            const observer = new MutationObserver(()=>{ clearTimeout(window.__jkshCoverFixTimer); window.__jkshCoverFixTimer=setTimeout(sync,60); });
            observer.observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['class','checked','aria-selected','aria-pressed']});
            setTimeout(sync,60);
            setTimeout(sync,400);
            setTimeout(sync,1200);
        })();
        </script>
        <?php
    }
}
new JKSH_Upload_Cover_Fix_V012();
