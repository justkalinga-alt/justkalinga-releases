<?php
/**
 * Plugin Name: JKSH Drive v1.0.1 Method Inspector
 * Description: Temporary read-only method-source inspector for selected non-secret v1.0.1 code paths.
 * Version: 1.0.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action( 'rest_api_init', function () {
  register_rest_route( 'jksh-drive-v101-methods/v1', '/inspect', array(
    'methods' => 'GET',
    'permission_callback' => function(){ return current_user_can('manage_options'); },
    'callback' => function(WP_REST_Request $req){
      $allowed=array('cfg','save','store_tokens','access','client','folder','ensure_folders');
      $name=sanitize_key((string)$req->get_param('method'));
      if(!in_array($name,$allowed,true)) return new WP_Error('bad_method','Method not allowed',array('status'=>400));
      if(!class_exists('JKSH_Drive_Storage_V101')) return new WP_Error('missing','Class missing',array('status'=>404));
      $r=new ReflectionMethod('JKSH_Drive_Storage_V101',$name);
      $file=$r->getFileName(); $lines=file($file,FILE_IGNORE_NEW_LINES);
      $start=$r->getStartLine(); $end=$r->getEndLine(); $out=array();
      for($i=$start;$i<=$end;$i++) $out[]=array('line'=>$i,'text'=>$lines[$i-1]);
      return rest_ensure_response(array('ok'=>true,'method'=>$name,'source'=>$out));
    }
  ));
});
