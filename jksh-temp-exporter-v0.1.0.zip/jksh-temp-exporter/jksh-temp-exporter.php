<?php
/**
 * Plugin Name: JKSH Temporary Bridge Exporter
 * Description: Temporary maintenance helper to export only the JK Social Supabase Bridge plugin as a ZIP.
 * Version: 0.1.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'rest_api_init', function() {
    register_rest_route( 'jksh-temp/v1', '/export-bridge', [
        'methods' => 'POST',
        'permission_callback' => function() { return current_user_can( 'manage_options' ); },
        'callback' => function( WP_REST_Request $request ) {
            if ( true !== rest_sanitize_boolean( $request->get_param( 'confirm' ) ) ) {
                return new WP_Error( 'jksh_confirm_required', 'confirm=true is required.', [ 'status' => 400 ] );
            }
            if ( ! class_exists( 'ZipArchive' ) ) {
                return new WP_Error( 'jksh_zip_missing', 'ZipArchive is unavailable.', [ 'status' => 500 ] );
            }
            $plugin_dir = WP_PLUGIN_DIR . '/jk-social-supabase-bridge';
            if ( ! is_dir( $plugin_dir ) ) {
                return new WP_Error( 'jksh_bridge_missing', 'JK Social Supabase Bridge directory not found.', [ 'status' => 404 ] );
            }
            $uploads = wp_upload_dir();
            if ( ! empty( $uploads['error'] ) ) {
                return new WP_Error( 'jksh_upload_dir', (string) $uploads['error'], [ 'status' => 500 ] );
            }
            $filename = 'jk-social-supabase-bridge-live-export-' . gmdate('Ymd-His') . '.zip';
            $zip_path = trailingslashit( $uploads['path'] ) . $filename;
            $zip = new ZipArchive();
            if ( true !== $zip->open( $zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
                return new WP_Error( 'jksh_zip_open', 'Could not create export ZIP.', [ 'status' => 500 ] );
            }
            $base_len = strlen( dirname( $plugin_dir ) ) + 1;
            $it = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator( $plugin_dir, FilesystemIterator::SKIP_DOTS ),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            $count = 0;
            foreach ( $it as $file ) {
                if ( ! $file->isFile() ) { continue; }
                $path = $file->getPathname();
                $local = str_replace('\\', '/', substr( $path, $base_len ) );
                if ( false !== strpos( $local, '../' ) ) { continue; }
                $zip->addFile( $path, $local );
                $count++;
            }
            $zip->close();
            if ( ! is_file( $zip_path ) ) {
                return new WP_Error( 'jksh_zip_failed', 'Export ZIP was not created.', [ 'status' => 500 ] );
            }
            $filetype = wp_check_filetype( $filename, null );
            $attachment_id = wp_insert_attachment( [
                'post_mime_type' => $filetype['type'] ?: 'application/zip',
                'post_title' => sanitize_text_field( pathinfo( $filename, PATHINFO_FILENAME ) ),
                'post_content' => 'Temporary maintenance export of live JK Social Supabase Bridge.',
                'post_status' => 'inherit',
            ], $zip_path );
            if ( is_wp_error( $attachment_id ) ) {
                @unlink( $zip_path );
                return $attachment_id;
            }
            return rest_ensure_response( [
                'ok' => true,
                'attachment_id' => (int) $attachment_id,
                'url' => wp_get_attachment_url( $attachment_id ),
                'filename' => $filename,
                'bytes' => filesize( $zip_path ),
                'sha256' => hash_file( 'sha256', $zip_path ),
                'file_count' => $count,
            ] );
        },
    ] );
} );
