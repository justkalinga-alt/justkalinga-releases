<?php
/**
 * Plugin Name: JKSH Manual Destination Mode
 * Description: Removes destination checkboxes from Social Upload. New uploads are stored without selected platforms so destinations can be chosen manually at publish/schedule time.
 * Version: 1.0.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Manual_Destination_Mode_V100 {
    public static function init(): void {
        add_action( 'wp_ajax_jkssb_ui_save_bundle', [ __CLASS__, 'neutralize_destinations' ], 0 );
        add_action( 'admin_footer', [ __CLASS__, 'clean_social_upload_ui' ], 999 );
    }

    public static function neutralize_destinations(): void {
        if ( empty( $_POST['payload'] ) ) { return; }
        $raw = wp_unslash( (string) $_POST['payload'] );
        $payload = json_decode( $raw, true );
        if ( ! is_array( $payload ) ) { return; }

        $payload['selected_platforms'] = [];
        $payload['destination_mode'] = 'manual';
        $_POST['payload'] = wp_json_encode( $payload );
    }

    public static function clean_social_upload_ui(): void {
        if ( ! is_admin() ) { return; }
        $page = sanitize_key( (string) ( $_GET['page'] ?? '' ) );
        if ( 'jksh-social-upload' !== $page ) { return; }
        ?>
        <style id="jksh-manual-destination-mode-css">
          .jkssb-platforms{display:none!important}
          .jksh-manual-destination-note{margin:4px 0 0;color:#667085;font-size:12px;font-weight:600}
        </style>
        <script id="jksh-manual-destination-mode-js">
        (()=>{
          const apply=()=>{
            document.querySelectorAll('.jkssb-platforms').forEach(grid=>{
              const section=grid.closest('.jkssb-section');
              if(section) section.remove(); else grid.remove();
            });
            const head=document.querySelector('.jkssb-card-head h2');
            if(head && head.textContent.trim()==='Media & destinations') head.textContent='Media';
            const body=document.querySelector('.jkssb-card-body');
            if(body && !document.querySelector('.jksh-manual-destination-note')){
              const note=document.createElement('p');
              note.className='jksh-manual-destination-note';
              note.textContent='Destinations are chosen manually when this upload is published or scheduled.';
              body.insertBefore(note, body.firstChild);
            }
          };
          apply();
          document.addEventListener('DOMContentLoaded',apply,{once:true});
          setTimeout(apply,250);
        })();
        </script>
        <?php
    }
}
JKSH_Manual_Destination_Mode_V100::init();
