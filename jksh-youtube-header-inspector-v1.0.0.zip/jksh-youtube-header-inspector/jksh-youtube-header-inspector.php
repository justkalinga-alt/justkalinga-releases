<?php
/**
 * Plugin Name: JKSH YouTube Header Inspector
 * Description: Temporary read-only inspector for YouTubeActions imports and declared connector class names.
 * Version: 1.0.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action( 'rest_api_init', function () {
    register_rest_route( 'jksh-youtube-header/v1', '/inspect', array(
        'methods' => 'GET',
        'permission_callback' => function () { return current_user_can( 'manage_options' ); },
        'callback' => function () {
            $out = array( 'header' => array(), 'declared' => array() );
            if ( class_exists( '\JKSH\Admin\YouTubeActions' ) ) {
                $r = new ReflectionClass( '\JKSH\Admin\YouTubeActions' );
                $file = $r->getFileName();
                if ( $file && is_readable( $file ) ) {
                    $lines = file( $file, FILE_IGNORE_NEW_LINES );
                    for ( $i = 1; $i <= min( 20, count( $lines ) ); $i++ ) {
                        $out['header'][] = array( 'line' => $i, 'text' => $lines[ $i - 1 ] );
                    }
                }
            }
            foreach ( get_declared_classes() as $class ) {
                if ( false !== stripos( $class, 'YouTube' ) || false !== stripos( $class, 'Google' ) ) {
                    $out['declared'][] = $class;
                }
            }
            sort( $out['declared'] );
            return rest_ensure_response( $out );
        },
    ) );
} );
