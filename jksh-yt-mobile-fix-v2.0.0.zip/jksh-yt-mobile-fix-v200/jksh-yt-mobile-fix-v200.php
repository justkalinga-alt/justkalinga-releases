<?php
/**
 * Plugin Name: JKSH YouTube Mobile Selection Fix
 * Description: Keeps YouTube selectable on Reel/Short and Long Video in Social Upload, including mobile tap handling.
 * Version: 2.0.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function jksh_yt_mobile_fix_v200_should_inject() {
    if ( is_admin() ) {
        return isset( $_GET['page'] ) && 'jksh-social-upload' === sanitize_key( wp_unslash( $_GET['page'] ) );
    }
    return is_user_logged_in();
}

function jksh_yt_mobile_fix_v200_inject() {
    if ( ! jksh_yt_mobile_fix_v200_should_inject() ) { return; }
    ?>
    <script id="jksh-yt-mobile-fix-v200">
    (() => {
      if (window.__JKSH_YT_MOBILE_FIX_V200__) return;
      window.__JKSH_YT_MOBILE_FIX_V200__ = true;

      const typeValue = () => {
        const active = document.querySelector('.jkssb-type-btn.is-active');
        return (active && active.dataset && active.dataset.type) || document.getElementById('jkssb-type')?.value || '';
      };
      const isVideoMode = () => ['reel','long_video'].includes(typeValue());
      const isImageMode = () => ['single_post','carousel'].includes(typeValue());

      const apply = () => {
        const yt = document.querySelector('.jkssb-platform[value="youtube"]');
        if (!yt) return;
        const card = yt.closest('.jkssb-platform-card');

        if (isVideoMode()) {
          yt.disabled = false;
          yt.removeAttribute('disabled');
          yt.style.pointerEvents = 'auto';
          yt.style.opacity = '1';
          yt.tabIndex = 0;
          if (card) {
            card.classList.remove('is-disabled');
            card.removeAttribute('aria-disabled');
            card.style.pointerEvents = 'auto';
            card.style.cursor = 'pointer';
            card.style.opacity = '1';
          }
        } else if (isImageMode()) {
          yt.checked = false;
          yt.disabled = true;
          yt.setAttribute('disabled', 'disabled');
          if (card) {
            card.classList.add('is-disabled');
            card.setAttribute('aria-disabled', 'true');
          }
        }
      };

      document.addEventListener('click', (event) => {
        const card = event.target.closest?.('.jkssb-platform-card');
        if (!card) return;
        const yt = card.querySelector('.jkssb-platform[value="youtube"]');
        if (!yt || !isVideoMode()) return;

        yt.disabled = false;
        yt.removeAttribute('disabled');
        card.classList.remove('is-disabled');
        card.removeAttribute('aria-disabled');

        if (event.target !== yt) {
          event.preventDefault();
          event.stopPropagation();
          yt.checked = !yt.checked;
          yt.dispatchEvent(new Event('change', { bubbles: true }));
        }
        requestAnimationFrame(apply);
      }, true);

      document.addEventListener('change', (event) => {
        if (event.target?.matches?.('.jkssb-platform[value="youtube"]') && isVideoMode()) {
          requestAnimationFrame(apply);
        }
      }, true);

      document.addEventListener('click', (event) => {
        if (event.target.closest?.('.jkssb-type-btn')) {
          requestAnimationFrame(() => setTimeout(apply, 0));
        }
      }, true);

      const observer = new MutationObserver(() => apply());
      observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class', 'disabled']
      });

      apply();
      setTimeout(apply, 100);
      setTimeout(apply, 500);
      setTimeout(apply, 1200);
    })();
    </script>
    <?php
}
add_action( 'admin_footer', 'jksh_yt_mobile_fix_v200_inject', PHP_INT_MAX );
add_action( 'wp_footer', 'jksh_yt_mobile_fix_v200_inject', PHP_INT_MAX );

add_action( 'rest_api_init', function () {
    register_rest_route( 'jksh-yt-mobile-fix/v2', '/status', array(
        'methods'  => 'GET',
        'permission_callback' => function () { return current_user_can( 'manage_options' ); },
        'callback' => function () {
            return rest_ensure_response( array(
                'ok'      => true,
                'version' => '2.0.0',
                'rule'    => 'YouTube enabled for reel and long_video; disabled for single_post and carousel.',
            ) );
        },
    ) );
} );
