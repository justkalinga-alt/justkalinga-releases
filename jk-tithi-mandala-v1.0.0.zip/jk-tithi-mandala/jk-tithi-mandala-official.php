<?php
/**
 * Plugin Name: JK Tithi Mandala - Official Shreemandira Calendar 2026-2027
 * Description: Lightweight Sun-Moon-Tithi-Nakshatra mandala with official Shreemandira festival dates from the 2026-2027 calendar. Shortcode: [jk_tithi_mandala]
 * Version: 1.0.0
 * Author: JustKalinga
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/*
 * SOURCE POLICY
 * Festival names and civil dates are transcribed from the supplied official
 * "Shreemandira Festivals 2026-2027" calendar issued by Shree Jagannatha
 * Temple Administration, Puri, Odisha.
 *
 * The astronomical Tithi, Moon illumination and Nakshatra shown by this
 * plugin are calculated independently for visualization. They are not a
 * replacement for the Temple Administration calendar or a local Panchanga.
 */

if ( ! function_exists( 'jk_tm_norm' ) ) {
    function jk_tm_norm( $v ) {
        $v = fmod( (float) $v, 360.0 );
        return ( $v < 0 ) ? $v + 360.0 : $v;
    }
}

if ( ! function_exists( 'jk_tm_sind' ) ) {
    function jk_tm_sind( $v ) {
        return sin( deg2rad( (float) $v ) );
    }
}

if ( ! function_exists( 'jk_tm_jd' ) ) {
    function jk_tm_jd( DateTimeInterface $dt ) {
        $utc = new DateTimeImmutable( $dt->format( 'Y-m-d H:i:s' ), $dt->getTimezone() );
        $utc = $utc->setTimezone( new DateTimeZone( 'UTC' ) );
        return 2440587.5 + ( (float) $utc->format( 'U' ) / 86400.0 );
    }
}

if ( ! function_exists( 'jk_tm_astro' ) ) {
    function jk_tm_astro( DateTimeInterface $dt ) {
        $jd = jk_tm_jd( $dt );
        $T  = ( $jd - 2451545.0 ) / 36525.0;

        // Apparent-enough solar ecliptic longitude for this visualization.
        $L0 = jk_tm_norm( 280.46646 + 36000.76983 * $T + 0.0003032 * $T * $T );
        $M  = jk_tm_norm( 357.52911 + 35999.05029 * $T - 0.0001537 * $T * $T );
        $C  = ( 1.914602 - 0.004817 * $T - 0.000014 * $T * $T ) * jk_tm_sind( $M )
            + ( 0.019993 - 0.000101 * $T ) * jk_tm_sind( 2 * $M )
            + 0.000289 * jk_tm_sind( 3 * $M );
        $sun_tropical = jk_tm_norm( $L0 + $C );

        // Truncated lunar longitude series (sufficient for visual Tithi display).
        $Lp = jk_tm_norm( 218.3164477 + 481267.88123421 * $T - 0.0015786 * $T * $T );
        $D  = jk_tm_norm( 297.8501921 + 445267.1114034 * $T - 0.0018819 * $T * $T );
        $Ms = jk_tm_norm( 357.5291092 + 35999.0502909 * $T - 0.0001536 * $T * $T );
        $Mp = jk_tm_norm( 134.9633964 + 477198.8675055 * $T + 0.0087414 * $T * $T );
        $F  = jk_tm_norm( 93.2720950 + 483202.0175233 * $T - 0.0036539 * $T * $T );

        $moon_tropical = $Lp
            + 6.289 * jk_tm_sind( $Mp )
            + 1.274 * jk_tm_sind( 2 * $D - $Mp )
            + 0.658 * jk_tm_sind( 2 * $D )
            + 0.214 * jk_tm_sind( 2 * $Mp )
            - 0.186 * jk_tm_sind( $Ms )
            - 0.114 * jk_tm_sind( 2 * $F )
            + 0.059 * jk_tm_sind( 2 * $D - 2 * $Mp )
            + 0.057 * jk_tm_sind( 2 * $D - $Ms - $Mp )
            + 0.053 * jk_tm_sind( 2 * $D + $Mp )
            + 0.046 * jk_tm_sind( 2 * $D - $Ms )
            + 0.041 * jk_tm_sind( $Ms - $Mp )
            - 0.035 * jk_tm_sind( $D )
            - 0.031 * jk_tm_sind( $Ms + $Mp )
            - 0.015 * jk_tm_sind( 2 * $F - 2 * $D )
            + 0.011 * jk_tm_sind( 2 * $D - 4 * $Mp );
        $moon_tropical = jk_tm_norm( $moon_tropical );

        // Approximate Lahiri ayanamsha; adequate for the 27-sector visual ring.
        $years_from_j2000 = ( $jd - 2451545.0 ) / 365.2425;
        $ayanamsha = 23.8531 + 0.0139688 * $years_from_j2000;

        $sun_sidereal  = jk_tm_norm( $sun_tropical - $ayanamsha );
        $moon_sidereal = jk_tm_norm( $moon_tropical - $ayanamsha );
        $elongation    = jk_tm_norm( $moon_tropical - $sun_tropical );

        $tithi_number = (int) floor( $elongation / 12.0 ) + 1;
        if ( $tithi_number > 30 ) {
            $tithi_number = 30;
        }

        $paksha_number = ( ( $tithi_number - 1 ) % 15 ) + 1;
        $tithi_names = array(
            1 => 'Pratipadā', 2 => 'Dvitīyā', 3 => 'Tṛtīyā', 4 => 'Caturthī',
            5 => 'Pañcamī', 6 => 'Ṣaṣṭhī', 7 => 'Saptamī', 8 => 'Aṣṭamī',
            9 => 'Navamī', 10 => 'Daśamī', 11 => 'Ekādaśī', 12 => 'Dvādaśī',
            13 => 'Trayodaśī', 14 => 'Caturdaśī'
        );

        if ( 15 === $tithi_number ) {
            $tithi_name = 'Pūrṇimā';
            $paksha = 'Śukla Pakṣa';
        } elseif ( 30 === $tithi_number ) {
            $tithi_name = 'Amāvasyā';
            $paksha = 'Kṛṣṇa Pakṣa';
        } else {
            $tithi_name = $tithi_names[ $paksha_number ];
            $paksha = ( $tithi_number <= 15 ) ? 'Śukla Pakṣa' : 'Kṛṣṇa Pakṣa';
        }

        $illumination = ( 1.0 - cos( deg2rad( $elongation ) ) ) * 50.0;
        $tithi_progress = fmod( $elongation, 12.0 ) / 12.0 * 100.0;

        $nak_names = array(
            'Aśvinī','Bharaṇī','Kṛttikā','Rohiṇī','Mṛgaśīrṣa','Ārdrā','Punarvasu',
            'Puṣya','Āśleṣā','Maghā','Pūrva Phālgunī','Uttara Phālgunī','Hasta',
            'Citrā','Svātī','Viśākhā','Anurādhā','Jyeṣṭhā','Mūla','Pūrva Āṣāḍhā',
            'Uttara Āṣāḍhā','Śravaṇa','Dhaniṣṭhā','Śatabhiṣā','Pūrva Bhādrapadā',
            'Uttara Bhādrapadā','Revatī'
        );
        $nak_index = (int) floor( $moon_sidereal / ( 360.0 / 27.0 ) );
        $nak_index = max( 0, min( 26, $nak_index ) );

        return array(
            'jd'             => $jd,
            'sun'            => $sun_sidereal,
            'moon'           => $moon_sidereal,
            'elongation'     => $elongation,
            'tithi_number'   => $tithi_number,
            'tithi_name'     => $tithi_name,
            'paksha'         => $paksha,
            'progress'       => $tithi_progress,
            'illumination'   => $illumination,
            'nak_index'      => $nak_index,
            'nakshatra'      => $nak_names[ $nak_index ],
        );
    }
}

if ( ! function_exists( 'jk_tm_events' ) ) {
    function jk_tm_events() {
        static $events = null;
        if ( null !== $events ) {
            return $events;
        }
        $json = <<<'JSON'
[{"date":"2026-04-14","title":"Mahabisuba Sankranti, Hanuman Jayanti","page":3},{"date":"2026-04-17","title":"Rukmini Amabasya","page":3},{"date":"2026-04-20","title":"Akshayatrutiya, Chandanyatra begins","page":3},{"date":"2026-04-24","title":"Neeladri Mahodayastami","page":3},{"date":"2026-04-27","title":"Mohini Ekadashi","page":3},{"date":"2026-04-30","title":"Nrusingha Janma","page":3},{"date":"2026-05-09","title":"Bhaunri Yatra","page":3},{"date":"2026-05-13","title":"Jalakrida Ekadashi","page":3},{"date":"2026-05-16","title":"Sabitri Amabasya & Jalakrida","page":3},{"date":"2026-05-22","title":"Malamasa Suklapaksha Sasthi & Jalakrida","page":3},{"date":"2026-05-27","title":"Malamasa Suklapaksha Ekadashi & Jalakrida","page":3},{"date":"2026-05-31","title":"Malamasa Purnima & Jalakrida","page":3},{"date":"2026-06-06","title":"Malamasa Krushnapaksha Sasthi & Jalakrida","page":3},{"date":"2026-06-11","title":"Malamasa Krushnapaksha Ekadashi & Jalakrida","page":3},{"date":"2026-06-15","title":"Malamasa Amabasya, Rajasankranti & Jalakrida","page":3},{"date":"2026-06-19","title":"Shiva Vivah","page":3},{"date":"2026-06-20","title":"Sitalasasthi & Jalakrida","page":3},{"date":"2026-06-24","title":"Rajendrabhiseka","page":3},{"date":"2026-06-25","title":"Rukminiharan Ekadashi, Vivah Mahotsava & Jalakrida","page":3},{"date":"2026-06-26","title":"Champaka Dwadashi","page":3},{"date":"2026-06-27","title":"Daitapati Prabesha","page":3},{"date":"2026-06-28","title":"Shreejew's Senapata Lagi & Chaturthi Homa","page":3},{"date":"2026-06-29","title":"Snanajatra, Gajanana Besha & Anabasara begins","page":3},{"date":"2026-07-10","title":"Anabasara Chakabije","page":3},{"date":"2026-07-11","title":"Anabasara Ekadashi & Khalilagi","page":3},{"date":"2026-07-12","title":"Anabasara Trayodashi, Rajaprasada Bije & Ghanalagi","page":3},{"date":"2026-07-13","title":"Anabasara Chaturdashi","page":3},{"date":"2026-07-14","title":"Amabasya, Shreejew's Netrotsava & Nabajaubana","page":3},{"date":"2026-07-15","title":"Shreejew's Ubhajatra & Ratha Ajnamala Bije","page":3},{"date":"2026-07-16","title":"Shreegundicha Yatra","page":5},{"date":"2026-07-17","title":"Dakshinayan Sankranti","page":5},{"date":"2026-07-20","title":"Herapanchami","page":5},{"date":"2026-07-23","title":"Shreejew's Sandhya Darshana","page":5},{"date":"2026-07-24","title":"Shreejew's Bahuda Yatra","page":5},{"date":"2026-07-25","title":"Shree Harisayan Ekadashi & Shreejew's Badatadhau Besha (Sunabesha)","page":5},{"date":"2026-07-26","title":"Shreejew's Adharapana & Garuda Sayana","page":5},{"date":"2026-07-27","title":"Shreejew's Neeladri Bije","page":5},{"date":"2026-08-09","title":"Kamada / Chakrabula Ekadashi","page":5},{"date":"2026-08-12","title":"Chitalagi Amabasya","page":5},{"date":"2026-08-21","title":"Badi Nrusingha Bije","page":5},{"date":"2026-08-23","title":"Putrada Ekadashi & Jhulanayatra begins","page":5},{"date":"2026-08-28","title":"Shree Balabhadra Janma, Rakshilagi & Shree Sudarshan Dev's Ashram Bije","page":5},{"date":"2026-08-29","title":"Jhulanayatra ends","page":5},{"date":"2026-09-02","title":"Rahurekha Lagi","page":5},{"date":"2026-09-03","title":"Garbhodaka Bandapana & Jeuta Bhoga","page":5},{"date":"2026-09-04","title":"Shree Krishna Janmastami","page":5},{"date":"2026-09-05","title":"Nandotsava","page":5},{"date":"2026-09-06","title":"Banabhoji Besha, Koli Bika, Bakasura Badha Prastaba & Arghasura Badha Prastaba","page":5},{"date":"2026-09-07","title":"Kaliyadalan Ekadashi & Dhenukasura Badha Prastaba","page":5},{"date":"2026-09-08","title":"Pralambasura Badha Besha Prastaba","page":5},{"date":"2026-09-09","title":"Krushnabalaram Besha & Annapratha","page":5},{"date":"2026-09-10","title":"Satapuri Tada Bije","page":5},{"date":"2026-09-11","title":"Satapuri Amabasya & Bastraharan Leela","page":5},{"date":"2026-09-12","title":"Dabagni Leela","page":5},{"date":"2026-09-13","title":"Nikunjaleela","page":5},{"date":"2026-09-14","title":"Shree Ganesha Chaturthi","page":5},{"date":"2026-09-15","title":"Andhaleela","page":5},{"date":"2026-09-16","title":"Rushipanchami & Dahaleela","page":5},{"date":"2026-09-17","title":"Bimbasura Badha, Lalita Saptami, Kukutibrata & Kanya Sankranti","page":5},{"date":"2026-09-18","title":"Kekeshi Badha & Durgasayana","page":7},{"date":"2026-09-19","title":"Shree Radhastami, Shree Sudarshan Dev's Ashrama Bije","page":7},{"date":"2026-09-21","title":"Kansabadha Prastaba, Labanikhia & Mathurahata Jura","page":7},{"date":"2026-09-22","title":"Parswa Parivartana Ekadashi","page":7},{"date":"2026-09-23","title":"Bamana Janma, Sunia, Indradhwaja Puja & Garuda Parswa Parivartana","page":7},{"date":"2026-09-24","title":"Shreejew's Balibamana Besha","page":7},{"date":"2026-09-25","title":"Ananta Brata","page":7},{"date":"2026-09-26","title":"Indra Gobinda Bandapana, Indrahati Prastaba","page":7},{"date":"2026-10-03","title":"Sahasrakumbhabhiseka, Devi Utthapana, Sodasadinatmaka Puja begins","page":7},{"date":"2026-10-06","title":"Indira Ekadashi","page":7},{"date":"2026-10-10","title":"Mahalaya Amabasya","page":7},{"date":"2026-10-11","title":"Durga Madhaba Bahara Bije","page":7},{"date":"2026-10-17","title":"Maha Saptami & Garvana Sankranti in Shreemandira","page":7},{"date":"2026-10-18","title":"Maha Astami in Shreemandira","page":7},{"date":"2026-10-19","title":"Maha Navami in Shreemandira","page":7},{"date":"2026-10-21","title":"Dashahara & Aayudha Puja","page":7},{"date":"2026-10-22","title":"Shreejew's Radhadamodar Besha & Baladhupa begins","page":7},{"date":"2026-10-26","title":"Kumar Purnima, Shree Sudarshan Dev's Ashrama Bije","page":7},{"date":"2026-11-05","title":"Rama Ekadashi","page":7},{"date":"2026-11-09","title":"Deepavali Amabasya Sagara Bije","page":7},{"date":"2026-11-18","title":"Anla Navami","page":7},{"date":"2026-11-21","title":"Shreehari Utthapana & Shreejew's Laxminarayana Besha","page":7},{"date":"2026-11-22","title":"Shreejew's Dalikia / Tribikrama Besha & Garuda Utthapana","page":7},{"date":"2026-11-23","title":"Shreejew's Laxmi Nrusingha Besha","page":7},{"date":"2026-11-24","title":"Kartika Purnima & Shreejew's Rajadhiraj Besha","page":7},{"date":"2026-12-01","title":"Prathamastami","page":7},{"date":"2026-12-04","title":"Utpanna Ekadashi","page":7},{"date":"2026-12-08","title":"Deva Deepavali begins","page":7},{"date":"2026-12-09","title":"Madhya Deva Deepavali & Amabasya Sagar Bije","page":7},{"date":"2026-12-10","title":"Deva Deepavali ends","page":9},{"date":"2026-12-15","title":"Prabarana / Odhana Sasthi","page":9},{"date":"2026-12-16","title":"Dhanu Sankranti & Pahili Bhoga begins in Shreemandira","page":9},{"date":"2026-12-20","title":"Gomati Ekadashi","page":9},{"date":"2026-12-23","title":"Pandu Nrusingha Bije","page":9},{"date":"2027-01-03","title":"Saphala Ekadashi","page":9},{"date":"2027-01-07","title":"Bakula Amabasya Sagara Bije","page":9},{"date":"2027-01-12","title":"Dudha Melana","page":9},{"date":"2027-01-13","title":"Shreejew's Nabanka Besha","page":9},{"date":"2027-01-14","title":"Makara Sankranti","page":9},{"date":"2027-01-18","title":"Samba Dashami","page":9},{"date":"2027-01-19","title":"Putrada Ekadashi","page":9},{"date":"2027-01-22","title":"Devabhiseka & Pusyabhiseka Purnima","page":9},{"date":"2027-02-02","title":"Sattila Ekadashi","page":9},{"date":"2027-02-10","title":"Shreejew's Padmabesha","page":9},{"date":"2027-02-11","title":"Basanta Panchami & Ratha Katha Anukula Puja","page":9},{"date":"2027-02-13","title":"Magha Saptami & Kumbha Sankranti","page":9},{"date":"2027-02-17","title":"Bhauma Ekadashi","page":9},{"date":"2027-02-20","title":"Shreejew's Gaja Uddharana Besha","page":9},{"date":"2027-03-04","title":"Pankoddhara Ekadashi","page":9},{"date":"2027-03-06","title":"Mahasivaratri","page":9},{"date":"2027-03-17","title":"Shreejew's Chacheri Besha, Dolajatra begins","page":9},{"date":"2027-03-18","title":"Papanashini Ekadashi in Shreemandira","page":9},{"date":"2027-03-21","title":"Rajagnyutsava in Shreemandira","page":9},{"date":"2027-03-22","title":"Dola Purnima & Rajabesha","page":9},{"date":"2027-03-23","title":"Holi","page":9},{"date":"2027-04-02","title":"Papamochani Ekadashi","page":9},{"date":"2027-04-10","title":"Badinrushingha Bije in Shreemandira (Chaitra Sukla Chaturthi)","page":9}]
JSON;
        $rows = json_decode( $json, true );
        $events = array();
        if ( is_array( $rows ) ) {
            foreach ( $rows as $row ) {
                if ( empty( $row['date'] ) || empty( $row['title'] ) ) {
                    continue;
                }
                $events[ $row['date'] ] = $row;
            }
        }
        ksort( $events );
        return $events;
    }
}

if ( ! function_exists( 'jk_tm_next_event' ) ) {
    function jk_tm_next_event( $date_key ) {
        foreach ( jk_tm_events() as $key => $event ) {
            if ( $key > $date_key ) {
                return $event;
            }
        }
        return null;
    }
}

if ( ! function_exists( 'jk_tm_day_diff' ) ) {
    function jk_tm_day_diff( $from, $to, DateTimeZone $tz ) {
        try {
            $a = new DateTimeImmutable( $from . ' 00:00:00', $tz );
            $b = new DateTimeImmutable( $to . ' 00:00:00', $tz );
            return (int) $a->diff( $b )->format( '%r%a' );
        } catch ( Exception $e ) {
            return 0;
        }
    }
}

if ( ! function_exists( 'jk_tm_arc' ) ) {
    function jk_tm_arc( $cx, $cy, $r, $start_deg, $end_deg ) {
        $start = deg2rad( $start_deg - 90.0 );
        $end   = deg2rad( $end_deg - 90.0 );
        $x1 = $cx + $r * cos( $start );
        $y1 = $cy + $r * sin( $start );
        $x2 = $cx + $r * cos( $end );
        $y2 = $cy + $r * sin( $end );
        $large = ( ( $end_deg - $start_deg ) > 180 ) ? 1 : 0;
        return sprintf( 'M %.3f %.3f A %.3f %.3f 0 %d 1 %.3f %.3f', $x1, $y1, $r, $r, $large, $x2, $y2 );
    }
}

if ( ! function_exists( 'jk_tithi_mandala_shortcode' ) ) {
    function jk_tithi_mandala_shortcode( $atts ) {
        static $assets_done = false;

        $atts = shortcode_atts(
            array(
                'size'       => '620',
                'date'       => '',
                'timezone'   => 'Asia/Kolkata',
                'show_next'  => 'yes',
                'show_source'=> 'yes',
            ),
            $atts,
            'jk_tithi_mandala'
        );

        try {
            $tz = new DateTimeZone( sanitize_text_field( $atts['timezone'] ) );
        } catch ( Exception $e ) {
            $tz = new DateTimeZone( 'Asia/Kolkata' );
        }

        $is_live = empty( trim( (string) $atts['date'] ) );
        try {
            if ( $is_live ) {
                $dt = new DateTimeImmutable( 'now', $tz );
            } else {
                $raw = sanitize_text_field( $atts['date'] );
                if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $raw ) ) {
                    $raw .= ' 12:00:00';
                }
                $dt = new DateTimeImmutable( $raw, $tz );
            }
        } catch ( Exception $e ) {
            $dt = new DateTimeImmutable( 'now', $tz );
            $is_live = true;
        }

        $astro = jk_tm_astro( $dt );
        $date_key = $dt->format( 'Y-m-d' );
        $events = jk_tm_events();
        $today_event = isset( $events[ $date_key ] ) ? $events[ $date_key ] : null;
        $next_event = jk_tm_next_event( $date_key );
        $next_days = $next_event ? jk_tm_day_diff( $date_key, $next_event['date'], $tz ) : 0;

        $size = max( 300, min( 900, (int) $atts['size'] ) );
        $show_next = strtolower( (string) $atts['show_next'] ) !== 'no';
        $show_source = strtolower( (string) $atts['show_source'] ) !== 'no';
        $uid = 'jk-tm-' . wp_rand( 100000, 999999 );

        $nak_span = 360.0 / 27.0;
        $stars = '';
        for ( $i = 0; $i < 27; $i++ ) {
            $a = deg2rad( $i * $nak_span - 90.0 );
            $x = 300 + 262 * cos( $a );
            $y = 300 + 262 * sin( $a );
            $active = ( $i === $astro['nak_index'] ) ? ' is-active' : '';
            $stars .= sprintf(
                '<g class="jk-tm-star-wrap%s" data-nak="%d"><circle cx="%.2f" cy="%.2f" r="%s" class="jk-tm-star"/><circle cx="%.2f" cy="%.2f" r="10" class="jk-tm-star-hit"/></g>',
                esc_attr( $active ),
                $i,
                $x, $y,
                ( $i === $astro['nak_index'] ? '5.5' : '3' ),
                $x, $y
            );
        }

        $tithi_arcs = '';
        for ( $i = 0; $i < 30; $i++ ) {
            $start = $i * 12.0 + 0.6;
            $end = ( $i + 1 ) * 12.0 - 0.6;
            $active = ( $i + 1 === $astro['tithi_number'] ) ? ' is-active' : '';
            $tithi_arcs .= sprintf(
                '<path d="%s" class="jk-tm-tithi-seg%s" data-tithi="%d"/>',
                esc_attr( jk_tm_arc( 300, 300, 195, $start, $end ) ),
                esc_attr( $active ),
                $i + 1
            );
        }

        $event_title = $today_event ? $today_event['title'] : 'No listed festival on this civil date';
        $event_page = $today_event ? (int) $today_event['page'] : 0;

        ob_start();
        if ( ! $assets_done ) {
            $assets_done = true;
            ?>
<style>
.jk-tm-wrap{width:100%;display:flex;justify-content:center;margin:18px auto;font-family:inherit}
.jk-tm-card{width:100%;box-sizing:border-box;position:relative;overflow:hidden;padding:18px;border-radius:26px;color:#fff;background:radial-gradient(circle at 50% 37%,#2a1741 0,#120a25 46%,#07040e 100%);box-shadow:0 18px 55px rgba(0,0,0,.25)}
.jk-tm-kicker{text-align:center;font-size:11px;letter-spacing:2.4px;text-transform:uppercase;color:#e4c16a;margin-top:2px}
.jk-tm-heading{text-align:center;font-size:clamp(21px,4vw,30px);line-height:1.15;font-weight:700;margin:4px 0 2px}
.jk-tm-sub{text-align:center;font-size:13px;color:#d7c9e8;margin-bottom:1px}
.jk-tm-svg{display:block;width:100%;height:auto;max-height:620px}
.jk-tm-ring{fill:none;stroke:rgba(255,255,255,.1);stroke-width:1.2}
.jk-tm-ring-gold{fill:none;stroke:rgba(218,178,79,.35);stroke-width:1.3}
.jk-tm-cardinal{stroke:rgba(255,255,255,.08);stroke-width:1}
.jk-tm-star{fill:rgba(255,255,255,.62);transition:.35s ease}
.jk-tm-star-hit{fill:transparent}
.jk-tm-star-wrap.is-active .jk-tm-star{fill:#ffe08a;filter:drop-shadow(0 0 7px #f4c650)}
.jk-tm-tithi-seg{fill:none;stroke:rgba(255,255,255,.12);stroke-width:8;stroke-linecap:round;transition:.35s ease}
.jk-tm-tithi-seg.is-active{stroke:#dcb34f;filter:drop-shadow(0 0 4px rgba(220,179,79,.8))}
.jk-tm-sun-halo{fill:rgba(255,185,53,.15);stroke:rgba(255,216,120,.5);stroke-width:1.2}
.jk-tm-sun{fill:#ffbd38;filter:drop-shadow(0 0 10px #ffae31)}
.jk-tm-moon-halo{fill:rgba(255,255,255,.08);stroke:rgba(255,255,255,.33);stroke-width:1}
.jk-tm-moon{fill:#f8f5ee;filter:drop-shadow(0 0 8px rgba(255,255,255,.75))}
.jk-tm-body-label{fill:#fff;font-size:10px;font-weight:700;letter-spacing:1.1px}
.jk-tm-center-disc{fill:#100820;stroke:#d7b35b;stroke-width:2}
.jk-tm-center-small{fill:#d9bb6c;font-size:10px;letter-spacing:1.8px}
.jk-tm-center-main{fill:#fff;font-size:22px;font-weight:700}
.jk-tm-center-sub{fill:#d7c9e8;font-size:12px}
.jk-tm-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:-2px}
.jk-tm-box{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.09);border-radius:14px;padding:10px 12px;min-width:0}
.jk-tm-label{display:block;font-size:9px;text-transform:uppercase;letter-spacing:1.2px;color:rgba(255,255,255,.53);margin-bottom:4px}
.jk-tm-value{display:block;font-size:13px;font-weight:650;line-height:1.3;overflow-wrap:anywhere}
.jk-tm-progress{height:4px;border-radius:99px;background:rgba(255,255,255,.1);overflow:hidden;margin-top:7px}
.jk-tm-progress>span{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#c89b36,#fff0ad)}
.jk-tm-official{margin-top:10px;border-radius:17px;padding:13px 14px;background:linear-gradient(135deg,rgba(199,149,43,.16),rgba(255,255,255,.055));border:1px solid rgba(225,186,88,.26)}
.jk-tm-official-title{font-size:9px;text-transform:uppercase;letter-spacing:1.5px;color:#e8c66d;margin-bottom:5px}
.jk-tm-event{font-size:16px;font-weight:700;line-height:1.35}
.jk-tm-event-meta{font-size:10px;color:rgba(255,255,255,.55);margin-top:5px}
.jk-tm-next{margin-top:8px;border-radius:14px;padding:10px 12px;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.08);display:flex;gap:10px;align-items:flex-start}
.jk-tm-next-badge{flex:0 0 auto;font-size:9px;text-transform:uppercase;letter-spacing:1.2px;color:#e8c66d;padding-top:2px}
.jk-tm-next-body{font-size:12px;line-height:1.4}
.jk-tm-next-body strong{font-size:13px;color:#fff}
.jk-tm-source{text-align:center;margin-top:10px;font-size:9.5px;line-height:1.45;color:rgba(255,255,255,.43)}
.jk-tm-source b{color:rgba(255,255,255,.62);font-weight:600}
@media(max-width:520px){.jk-tm-card{padding:13px;border-radius:20px}.jk-tm-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.jk-tm-grid .jk-tm-box:last-child{grid-column:1/-1}.jk-tm-event{font-size:14px}}
</style>
            <?php
        }
        ?>
<div class="jk-tm-wrap" id="<?php echo esc_attr( $uid ); ?>">
  <div class="jk-tm-card" style="max-width:<?php echo esc_attr( $size ); ?>px"
       data-live="<?php echo $is_live ? '1' : '0'; ?>"
       data-time="<?php echo esc_attr( $dt->format( DATE_ATOM ) ); ?>"
       data-sun="<?php echo esc_attr( $astro['sun'] ); ?>"
       data-moon="<?php echo esc_attr( $astro['moon'] ); ?>"
       data-tithi="<?php echo esc_attr( $astro['tithi_number'] ); ?>"
       data-nak="<?php echo esc_attr( $astro['nak_index'] ); ?>">

    <div class="jk-tm-kicker">Śrīmandira Celestial Mandala</div>
    <div class="jk-tm-heading jk-js-tithi-name"><?php echo esc_html( $astro['tithi_name'] ); ?></div>
    <div class="jk-tm-sub jk-js-paksha"><?php echo esc_html( $astro['paksha'] ); ?> · <?php echo esc_html( $dt->format( 'd M Y, h:i A' ) ); ?> IST</div>

    <svg class="jk-tm-svg" viewBox="0 0 600 600" role="img" aria-label="Sun Moon Tithi and Nakshatra Mandala">
      <circle cx="300" cy="300" r="270" class="jk-tm-ring-gold"/>
      <circle cx="300" cy="300" r="246" class="jk-tm-ring"/>
      <circle cx="300" cy="300" r="212" class="jk-tm-ring"/>
      <circle cx="300" cy="300" r="178" class="jk-tm-ring-gold"/>
      <line x1="300" y1="36" x2="300" y2="564" class="jk-tm-cardinal"/>
      <line x1="36" y1="300" x2="564" y2="300" class="jk-tm-cardinal"/>

      <g class="jk-tm-stars"><?php echo $stars; ?></g>

      <g class="jk-tm-tithi-band" transform="rotate(<?php echo esc_attr( $astro['sun'] ); ?> 300 300)">
        <?php echo $tithi_arcs; ?>
      </g>

      <g class="jk-tm-sun-group" transform="rotate(<?php echo esc_attr( $astro['sun'] ); ?> 300 300)">
        <circle cx="300" cy="122" r="26" class="jk-tm-sun-halo"/>
        <circle cx="300" cy="122" r="14" class="jk-tm-sun"/>
        <text x="300" y="91" text-anchor="middle" class="jk-tm-body-label">SUN</text>
      </g>

      <g class="jk-tm-moon-group" transform="rotate(<?php echo esc_attr( $astro['moon'] ); ?> 300 300)">
        <circle cx="300" cy="88" r="22" class="jk-tm-moon-halo"/>
        <circle cx="300" cy="88" r="11" class="jk-tm-moon"/>
        <text x="300" y="60" text-anchor="middle" class="jk-tm-body-label">MOON</text>
      </g>

      <circle cx="300" cy="300" r="78" class="jk-tm-center-disc"/>
      <text x="300" y="274" text-anchor="middle" class="jk-tm-center-small">TITHI</text>
      <text x="300" y="307" text-anchor="middle" class="jk-tm-center-main jk-js-center-tithi"><?php echo esc_html( $astro['tithi_name'] ); ?></text>
      <text x="300" y="333" text-anchor="middle" class="jk-tm-center-sub jk-js-center-paksha"><?php echo esc_html( $astro['paksha'] ); ?></text>
    </svg>

    <div class="jk-tm-grid">
      <div class="jk-tm-box">
        <span class="jk-tm-label">Nakṣatra · approx.</span>
        <span class="jk-tm-value jk-js-nak"><?php echo esc_html( $astro['nakshatra'] ); ?></span>
      </div>
      <div class="jk-tm-box">
        <span class="jk-tm-label">Moon illumination</span>
        <span class="jk-tm-value jk-js-light"><?php echo esc_html( round( $astro['illumination'] ) ); ?>%</span>
      </div>
      <div class="jk-tm-box">
        <span class="jk-tm-label">Tithi progress</span>
        <span class="jk-tm-value jk-js-progress-text"><?php echo esc_html( round( $astro['progress'] ) ); ?>%</span>
        <div class="jk-tm-progress"><span class="jk-js-progress" style="width:<?php echo esc_attr( $astro['progress'] ); ?>%"></span></div>
      </div>
    </div>

    <div class="jk-tm-official">
      <div class="jk-tm-official-title">Official Śrīmandira Calendar · <?php echo esc_html( $dt->format( 'd M Y' ) ); ?></div>
      <div class="jk-tm-event"><?php echo esc_html( $event_title ); ?></div>
      <?php if ( $today_event ) : ?>
        <div class="jk-tm-event-meta">Transcribed from calendar page <?php echo esc_html( $event_page ); ?>.</div>
      <?php endif; ?>
    </div>

    <?php if ( $show_next && $next_event ) : ?>
      <div class="jk-tm-next">
        <div class="jk-tm-next-badge">Next</div>
        <div class="jk-tm-next-body">
          <strong><?php echo esc_html( $next_event['title'] ); ?></strong><br>
          <?php echo esc_html( date_i18n( 'd M Y', strtotime( $next_event['date'] ) ) ); ?>
          <?php if ( $next_days > 0 ) : ?> · <?php echo esc_html( $next_days ); ?> day<?php echo ( 1 === $next_days ) ? '' : 's'; ?><?php endif; ?>
        </div>
      </div>
    <?php endif; ?>

    <?php if ( $show_source ) : ?>
      <div class="jk-tm-source"><b>Festival source:</b> Shreemandira Festivals 2026-2027 · Shree Jagannatha Temple Administration, Puri, Odisha. Festival dates/names are source-derived; Tithi/Nakṣatra are astronomical visual calculations.</div>
    <?php endif; ?>
  </div>
</div>
<script>
(function(){
  const root=document.getElementById(<?php echo wp_json_encode( $uid ); ?>);
  if(!root)return;
  const card=root.querySelector('.jk-tm-card');
  const sunG=root.querySelector('.jk-tm-sun-group');
  const moonG=root.querySelector('.jk-tm-moon-group');
  const band=root.querySelector('.jk-tm-tithi-band');
  const live=card.dataset.live==='1';
  if(!live)return;

  const tithiNames=['','Pratipadā','Dvitīyā','Tṛtīyā','Caturthī','Pañcamī','Ṣaṣṭhī','Saptamī','Aṣṭamī','Navamī','Daśamī','Ekādaśī','Dvādaśī','Trayodaśī','Caturdaśī'];
  const nakNames=['Aśvinī','Bharaṇī','Kṛttikā','Rohiṇī','Mṛgaśīrṣa','Ārdrā','Punarvasu','Puṣya','Āśleṣā','Maghā','Pūrva Phālgunī','Uttara Phālgunī','Hasta','Citrā','Svātī','Viśākhā','Anurādhā','Jyeṣṭhā','Mūla','Pūrva Āṣāḍhā','Uttara Āṣāḍhā','Śravaṇa','Dhaniṣṭhā','Śatabhiṣā','Pūrva Bhādrapadā','Uttara Bhādrapadā','Revatī'];
  const rad=Math.PI/180;
  const norm=v=>((v%360)+360)%360;
  const sind=v=>Math.sin(v*rad);

  function astro(date){
    const jd=2440587.5+date.getTime()/86400000;
    const T=(jd-2451545.0)/36525;
    const L0=norm(280.46646+36000.76983*T+0.0003032*T*T);
    const M=norm(357.52911+35999.05029*T-0.0001537*T*T);
    const C=(1.914602-0.004817*T-0.000014*T*T)*sind(M)+(0.019993-0.000101*T)*sind(2*M)+0.000289*sind(3*M);
    const sunT=norm(L0+C);
    const Lp=norm(218.3164477+481267.88123421*T-0.0015786*T*T);
    const D=norm(297.8501921+445267.1114034*T-0.0018819*T*T);
    const Ms=norm(357.5291092+35999.0502909*T-0.0001536*T*T);
    const Mp=norm(134.9633964+477198.8675055*T+0.0087414*T*T);
    const F=norm(93.2720950+483202.0175233*T-0.0036539*T*T);
    const moonT=norm(Lp+6.289*sind(Mp)+1.274*sind(2*D-Mp)+0.658*sind(2*D)+0.214*sind(2*Mp)-0.186*sind(Ms)-0.114*sind(2*F)+0.059*sind(2*D-2*Mp)+0.057*sind(2*D-Ms-Mp)+0.053*sind(2*D+Mp)+0.046*sind(2*D-Ms)+0.041*sind(Ms-Mp)-0.035*sind(D)-0.031*sind(Ms+Mp)-0.015*sind(2*F-2*D)+0.011*sind(2*D-4*Mp));
    const years=(jd-2451545.0)/365.2425;
    const aya=23.8531+0.0139688*years;
    const sun=norm(sunT-aya), moon=norm(moonT-aya), elong=norm(moonT-sunT);
    let t=Math.floor(elong/12)+1;if(t>30)t=30;
    const local=((t-1)%15)+1;
    const pak=t<=15?'Śukla Pakṣa':'Kṛṣṇa Pakṣa';
    const name=t===15?'Pūrṇimā':(t===30?'Amāvasyā':tithiNames[local]);
    const illum=(1-Math.cos(elong*rad))*50;
    const progress=((elong%12)/12)*100;
    const nak=Math.max(0,Math.min(26,Math.floor(moon/(360/27))));
    return {sun,moon,elong,t,name,pak,illum,progress,nak};
  }

  function update(){
    const a=astro(new Date());
    sunG.setAttribute('transform','rotate('+a.sun+' 300 300)');
    moonG.setAttribute('transform','rotate('+a.moon+' 300 300)');
    band.setAttribute('transform','rotate('+a.sun+' 300 300)');
    root.querySelectorAll('.jk-tm-tithi-seg').forEach(el=>el.classList.toggle('is-active',parseInt(el.dataset.tithi,10)===a.t));
    root.querySelectorAll('.jk-tm-star-wrap').forEach(el=>el.classList.toggle('is-active',parseInt(el.dataset.nak,10)===a.nak));
    root.querySelector('.jk-js-tithi-name').textContent=a.name;
    root.querySelector('.jk-js-center-tithi').textContent=a.name;
    root.querySelector('.jk-js-center-paksha').textContent=a.pak;
    root.querySelector('.jk-js-nak').textContent=nakNames[a.nak];
    root.querySelector('.jk-js-light').textContent=Math.round(a.illum)+'%';
    root.querySelector('.jk-js-progress-text').textContent=Math.round(a.progress)+'%';
    root.querySelector('.jk-js-progress').style.width=a.progress+'%';
  }
  update();
  setInterval(update,60000);
})();
</script>
        <?php
        return ob_get_clean();
    }
}

add_shortcode( 'jk_tithi_mandala', 'jk_tithi_mandala_shortcode' );
