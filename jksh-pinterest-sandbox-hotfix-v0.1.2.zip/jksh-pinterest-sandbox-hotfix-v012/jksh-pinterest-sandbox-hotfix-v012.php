<?php
/**
 * Plugin Name: JKSH Pinterest Sandbox Hotfix
 * Description: Sandbox-only Pinterest image proof lane for Social Upload and Content Library. Does not unlock production Standard Access.
 * Version: 0.1.2
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Pinterest_Sandbox_Hotfix_V010 {
    const VERSION = '0.1.2';
    const OPTION = 'jksh_pinterest_sandbox_hotfix_v012';
    private static $instance;

    public static function instance() {
        if ( ! self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action( 'rest_api_init', [ $this, 'routes' ] );
        add_action( 'admin_footer', [ $this, 'social_upload_ui' ], 99999 );
    }

    public function can_manage() { return current_user_can( 'manage_options' ); }

    public function routes() {
        register_rest_route( 'jksh-pinterest-sandbox-hotfix3/v1', '/status', [
            'methods' => 'GET', 'permission_callback' => [ $this, 'can_manage' ],
            'callback' => fn() => rest_ensure_response( $this->status() ),
        ] );
        register_rest_route( 'jksh-pinterest-sandbox-hotfix3/v1', '/apply', [
            'methods' => 'POST', 'permission_callback' => [ $this, 'can_manage' ],
            'callback' => function( WP_REST_Request $r ) {
                if ( ! $r->get_param( 'confirm' ) ) return new WP_Error( 'confirm_required', 'confirm=true is required.', [ 'status' => 400 ] );
                $res = $this->apply();
                return is_wp_error( $res ) ? $res : rest_ensure_response( $res );
            },
        ] );
    }

    private function files() {
        return [
            'sync12' => WP_PLUGIN_DIR . '/jk-social-hub/includes/class-jksh-content-library-v0912-upload-sync.php',
            'sync13' => WP_PLUGIN_DIR . '/jk-social-hub/includes/class-jksh-content-library-v0913-upload-sync.php',
            'bridge' => WP_PLUGIN_DIR . '/jk-social-supabase-bridge-disabled/jk-social-supabase-bridge.php',
            'pinterest' => WP_PLUGIN_DIR . '/jk-social-pinterest/jk-social-pinterest.php',
        ];
    }

    private function sandbox_ready() {
        if ( ! class_exists( 'JKSH_Pinterest_Sandbox_V0138' ) ) return false;
        $r = JKSH_Pinterest_Sandbox_V0138::instance()->readiness();
        return is_array( $r ) && ! empty( $r['connected'] ) && ! empty( $r['image_pins_supported'] );
    }

    public function status() {
        $state = get_option( self::OPTION, [] );
        $files = [];
        foreach ( $this->files() as $k => $file ) {
            $raw = is_readable( $file ) ? file_get_contents( $file ) : '';
            $files[$k] = [
                'exists' => is_file( $file ),
                'sha256' => $raw !== '' ? hash( 'sha256', $raw ) : '',
                'patched' => $raw !== '' && false !== strpos( $raw, 'JKSH_PINTEREST_SANDBOX_PROOF_V010' ),
            ];
        }
        return [
            'ok' => true,
            'version' => self::VERSION,
            'sandbox_ready' => $this->sandbox_ready(),
            'production_standard_access_changed' => false,
            'state' => is_array( $state ) ? $state : [],
            'files' => $files,
        ];
    }

    private function patch_file( $file, $old, $new, $tag, &$backups ) {
        if ( ! is_readable( $file ) || ! is_writable( $file ) ) return new WP_Error( 'file_unavailable', 'Required plugin file is not readable/writable: ' . basename( $file ) );
        $raw = file_get_contents( $file );
        if ( false === $raw ) return new WP_Error( 'file_read_failed', 'Could not read ' . basename( $file ) );
        if ( false !== strpos( $raw, $tag ) ) return [ 'already_patched' => true, 'sha256' => hash( 'sha256', $raw ) ];
        $count = substr_count( $raw, $old );
        if ( 1 !== $count ) return new WP_Error( 'source_mismatch', 'Expected exactly one patch target in ' . basename( $file ) . '; found ' . $count . '.' );
        $stamp = gmdate( 'YmdHis' );
        $backup = $file . '.jkshbak-pinsandbox-' . $stamp;
        if ( ! copy( $file, $backup ) ) return new WP_Error( 'backup_failed', 'Could not back up ' . basename( $file ) );
        $backups[$file] = $backup;
        $patched = str_replace( $old, $new, $raw, $replaced );
        if ( 1 !== $replaced ) return new WP_Error( 'replace_failed', 'Could not patch ' . basename( $file ) );
        $tmp = $file . '.jksh-tmp-' . wp_generate_password( 8, false, false );
        if ( false === file_put_contents( $tmp, $patched, LOCK_EX ) ) return new WP_Error( 'write_failed', 'Could not write temporary patch for ' . basename( $file ) );
        @chmod( $tmp, fileperms( $file ) & 0777 );
        if ( ! rename( $tmp, $file ) ) { @unlink( $tmp ); return new WP_Error( 'swap_failed', 'Could not atomically replace ' . basename( $file ) ); }
        return [ 'patched' => true, 'sha256' => hash( 'sha256', $patched ), 'backup' => $backup ];
    }

    private function rollback( array $backups ) {
        foreach ( $backups as $file => $backup ) {
            if ( is_file( $backup ) ) @copy( $backup, $file );
        }
    }

    public function apply() {
        $f = $this->files();
        $backups = [];
        $results = [];

        $old12 = "    private function is_test_upload( array \$draft ) {";
        $new12 = <<<'PHP'
    private function is_test_upload( array $draft ) {
        // JKSH_PINTEREST_SANDBOX_PROOF_V010
        $jksh_pin_platforms = array_values( array_map( 'sanitize_key', (array) ( $draft['selected_platforms'] ?? [] ) ) );
        $jksh_pin_type = sanitize_key( (string) ( $draft['content_type'] ?? '' ) );
        if ( in_array( 'pinterest', $jksh_pin_platforms, true ) && in_array( $jksh_pin_type, [ 'single_post', 'single_image' ], true ) && class_exists( 'JKSH_Pinterest_Sandbox_V0138' ) ) {
            $jksh_pin_ready = JKSH_Pinterest_Sandbox_V0138::instance()->readiness();
            if ( is_array( $jksh_pin_ready ) && ! empty( $jksh_pin_ready['connected'] ) && ! empty( $jksh_pin_ready['image_pins_supported'] ) ) return false;
        }
PHP;

        $old13 = "    private function is_testish( array \$draft ) {";
        $new13 = <<<'PHP'
    private function is_testish( array $draft ) {
        // JKSH_PINTEREST_SANDBOX_PROOF_V010
        $jksh_pin_platforms = array_values( array_map( 'sanitize_key', (array) ( $draft['selected_platforms'] ?? [] ) ) );
        $jksh_pin_type = sanitize_key( (string) ( $draft['content_type'] ?? '' ) );
        if ( in_array( 'pinterest', $jksh_pin_platforms, true ) && in_array( $jksh_pin_type, [ 'single_post', 'single_image' ], true ) && class_exists( 'JKSH_Pinterest_Sandbox_V0138' ) ) {
            $jksh_pin_ready = JKSH_Pinterest_Sandbox_V0138::instance()->readiness();
            if ( is_array( $jksh_pin_ready ) && ! empty( $jksh_pin_ready['connected'] ) && ! empty( $jksh_pin_ready['image_pins_supported'] ) ) return false;
        }
PHP;

        $oldBridge = "            if ( 'pinterest' === \$platform ) { if ( ! class_exists( 'JKSH_Pinterest_Connector' ) ) return new WP_Error( 'jkssb_live_account_unhealthy', 'Pinterest connector is not installed.', array( 'platform' => 'pinterest' ) ); \$pr = JKSH_Pinterest_Connector::instance()->readiness(); if ( empty( \$pr['live_publish_possible'] ) ) return new WP_Error( 'jkssb_live_account_unhealthy', 'Pinterest is not connected, verified, boarded and armed.', array( 'platform' => 'pinterest' ) ); continue; }";
        $newBridge = <<<'PHP'
            if ( 'pinterest' === $platform ) {
                // JKSH_PINTEREST_SANDBOX_PROOF_V010
                if ( ! class_exists( 'JKSH_Pinterest_Connector' ) ) return new WP_Error( 'jkssb_live_account_unhealthy', 'Pinterest connector is not installed.', array( 'platform' => 'pinterest' ) );
                $pr = JKSH_Pinterest_Connector::instance()->readiness();
                $sandbox_ok = false;
                if ( in_array( $content_type, array( 'single_image', 'single_post' ), true ) && class_exists( 'JKSH_Pinterest_Sandbox_V0138' ) ) {
                    $sr = JKSH_Pinterest_Sandbox_V0138::instance()->readiness();
                    $sandbox_ok = is_array( $sr ) && ! empty( $sr['connected'] ) && ! empty( $sr['image_pins_supported'] );
                }
                if ( empty( $pr['live_publish_possible'] ) && ! $sandbox_ok ) return new WP_Error( 'jkssb_live_account_unhealthy', 'Pinterest production is locked and the Sandbox image proof lane is not ready.', array( 'platform' => 'pinterest' ) );
                continue;
            }
PHP;

        $oldPin = "        \$c=\$this->config(); if(!\$c['live_publish_enabled']){\$jobs->update((int)\$job->id,['status'=>'blocked','last_error'=>'Pinterest live publishing master switch is OFF.','completed_at'=>\$now]);\$variants->update_status((int)\$v->id,'blocked');return;}";
        $newPin = <<<'PHP'
        // JKSH_PINTEREST_SANDBOX_PROOF_V010
        $c=$this->config();
        $sandbox_ok=false;
        $sandbox_ids=$this->media_ids($v);
        if(1===count($sandbox_ids)&&str_starts_with((string)get_post_mime_type($sandbox_ids[0]),'image/')&&class_exists('JKSH_Pinterest_Sandbox_V0138')){
            $sandbox_ready=JKSH_Pinterest_Sandbox_V0138::instance()->readiness();
            $sandbox_ok=is_array($sandbox_ready)&&!empty($sandbox_ready['connected'])&&!empty($sandbox_ready['image_pins_supported']);
        }
        if(!$c['live_publish_enabled']&&!$sandbox_ok){$jobs->update((int)$job->id,['status'=>'blocked','last_error'=>'Pinterest production publishing is locked and Sandbox image proof mode is unavailable.','completed_at'=>$now]);$variants->update_status((int)$v->id,'blocked');return;}
PHP;

        $patches = [
            [ 'key' => 'sync12', 'file' => $f['sync12'], 'old' => $old12, 'new' => $new12, 'tag' => 'JKSH_PINTEREST_SANDBOX_PROOF_V010' ],
            [ 'key' => 'sync13', 'file' => $f['sync13'], 'old' => $old13, 'new' => $new13, 'tag' => 'JKSH_PINTEREST_SANDBOX_PROOF_V010' ],
            [ 'key' => 'bridge', 'file' => $f['bridge'], 'old' => $oldBridge, 'new' => $newBridge, 'tag' => 'JKSH_PINTEREST_SANDBOX_PROOF_V010' ],
            [ 'key' => 'pinterest', 'file' => $f['pinterest'], 'old' => $oldPin, 'new' => $newPin, 'tag' => 'JKSH_PINTEREST_SANDBOX_PROOF_V010' ],
        ];

        foreach ( $patches as $p ) {
            $r = $this->patch_file( $p['file'], $p['old'], $p['new'], $p['tag'], $backups );
            if ( is_wp_error( $r ) ) {
                $this->rollback( $backups );
                return $r;
            }
            $results[$p['key']] = $r;
        }

        update_option( self::OPTION, [
            'applied' => true,
            'applied_at_utc' => current_time( 'mysql', true ),
            'backups' => $backups,
            'results' => $results,
            'production_standard_access_changed' => false,
        ], false );
        return $this->status();
    }

    public function social_upload_ui() {
        if ( ! is_admin() || 'jksh-social-upload' !== sanitize_key( (string) ( $_GET['page'] ?? '' ) ) ) return;
        $ready = $this->sandbox_ready();
        ?>
        <script id="jksh-pinterest-sandbox-ui-v010">
        (()=>{
          const sandboxReady=<?php echo $ready ? 'true' : 'false'; ?>;
          const apply=()=>{
            const pin=document.querySelector('.jkssb-platform[value="pinterest"]');
            if(!pin)return;
            const active=document.querySelector('.jkssb-type-btn.is-active');
            const hidden=document.querySelector('#jkssb-content-type');
            const type=(active&&active.dataset.type)||(hidden&&hidden.value)||'';
            const card=pin.closest('.jkssb-platform-card');
            const allowSandbox=sandboxReady&&type==='single_post';
            if(allowSandbox){
              pin.disabled=false;
              if(card){card.classList.remove('is-disabled');card.title='Pinterest Sandbox image proof mode · publishes to JustKalinga Sandbox Proof.';}
            }else if(!<?php echo $ready ? 'false' : 'true'; ?> && false){
              // reserved for future production Standard Access state
            }else if(type==='carousel'){
              pin.disabled=true; pin.checked=false;
              if(card){card.classList.add('is-disabled');card.title='Pinterest Sandbox proof mode currently accepts one image Pin. Use Single post.';}
            }else if(type==='reel'||type==='long_video'){
              pin.disabled=true; pin.checked=false;
              if(card){card.classList.add('is-disabled');card.title='Pinterest Sandbox does not support video Pins. Standard API access is required.';}
            }
          };
          document.addEventListener('DOMContentLoaded',()=>{apply();setTimeout(apply,100);setTimeout(apply,500);});
          document.addEventListener('click',e=>{if(e.target.closest('.jkssb-type-btn'))setTimeout(apply,0);});
          const obs=new MutationObserver(()=>apply());
          setTimeout(()=>{const root=document.querySelector('.jkssb-upload-shell')||document.body;obs.observe(root,{childList:true,subtree:true,attributes:true,attributeFilter:['class','disabled']});apply();},50);
        })();
        </script>
        <?php
    }
}
JKSH_Pinterest_Sandbox_Hotfix_V010::instance();
