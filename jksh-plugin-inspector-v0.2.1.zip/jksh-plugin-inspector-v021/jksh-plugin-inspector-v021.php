<?php
/**
 * Plugin Name: JKSH Plugin Inspector v0.2.0
 * Description: Temporary read-only inspector for selected JK Social plugin source files.
 * Version: 0.2.1
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'rest_api_init', function() {
    register_rest_route( 'jksh-plugin-inspect2/v1', '/search', [
        'methods' => 'GET',
        'permission_callback' => function() { return current_user_can( 'manage_options' ); },
        'args' => [ 'q' => [ 'required' => true ] ],
        'callback' => function( WP_REST_Request $r ) {
            $q = (string) $r->get_param( 'q' );
            if ( '' === trim( $q ) ) return new WP_Error( 'missing_q', 'q is required', [ 'status' => 400 ] );
            $files = [
                WP_PLUGIN_DIR . '/jk-social-pinterest/jk-social-pinterest.php',
                WP_PLUGIN_DIR . '/jk-social-supabase-bridge-disabled/jk-social-supabase-bridge.php',
                WP_PLUGIN_DIR . '/jk-social-hub/src/Queue/Dispatcher.php',
                WP_PLUGIN_DIR . '/jk-social-hub/includes/class-jksh-content-library-v0912-upload-sync.php',
                WP_PLUGIN_DIR . '/jk-social-hub/includes/class-jksh-content-library-v0913-upload-sync.php',
            ];
            $matches = [];
            foreach ( $files as $file ) {
                if ( ! is_readable( $file ) ) continue;
                $lines = file( $file, FILE_IGNORE_NEW_LINES );
                foreach ( $lines as $i => $line ) {
                    if ( false === stripos( $line, $q ) ) continue;
                    $start = max( 0, $i - 6 );
                    $end = min( count( $lines ) - 1, $i + 8 );
                    $excerpt = [];
                    for ( $j = $start; $j <= $end; $j++ ) $excerpt[] = [ 'line' => $j + 1, 'text' => $lines[$j] ];
                    $matches[] = [ 'file' => str_replace( WP_PLUGIN_DIR . '/', '', $file ), 'line' => $i + 1, 'excerpt' => $excerpt ];
                    if ( count( $matches ) >= 80 ) break 2;
                }
            }
            return rest_ensure_response( [ 'ok' => true, 'query' => $q, 'count' => count( $matches ), 'matches' => $matches ] );
        }
    ] );
} );
