<?php
/**
 * Plugin Name: JKSH YouTube Connector Inspector
 * Description: Temporary read-only source inspector for the YouTubeConnector class.
 * Version: 1.0.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action( 'rest_api_init', function () {
    register_rest_route( 'jksh-youtube-connector/v1', '/inspect', array(
        'methods' => 'GET',
        'permission_callback' => function () { return current_user_can( 'manage_options' ); },
        'callback' => function () {
            $class = '\JKSH\Services\YouTubeConnector';
            if ( ! class_exists( $class ) ) {
                return new WP_Error( 'missing', 'YouTubeConnector class could not be autoloaded.', array( 'status' => 404 ) );
            }
            $r = new ReflectionClass( $class );
            $file = $r->getFileName();
            $lines = ( $file && is_readable( $file ) ) ? file( $file, FILE_IGNORE_NEW_LINES ) : array();
            $out = array( 'file' => $file ? basename( $file ) : '', 'methods' => array(), 'source' => array() );
            foreach ( $r->getMethods() as $m ) {
                $out['methods'][] = array( 'name' => $m->getName(), 'public' => $m->isPublic(), 'static' => $m->isStatic() );
            }
            if ( $lines ) {
                $max = min( 260, count( $lines ) );
                for ( $i = 1; $i <= $max; $i++ ) {
                    $out['source'][] = array( 'line' => $i, 'text' => $lines[ $i - 1 ] );
                }
            }
            return rest_ensure_response( $out );
        },
    ) );
} );
