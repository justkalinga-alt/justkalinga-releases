<?php
/**
 * Plugin Name: JustKalinga Social Hub
 * Plugin URI:  https://social.justkalinga.com/
 * Description: Internal social-media operating system for JustKalinga. v0.13.13 renders Pinterest Sandbox directly from the Accounts renderer, eliminating footer-hook timing entirely.
 * Version:     0.13.13
 * Author:      JustKalinga
 * Text Domain: jk-social-hub
 * Requires at least: 6.5
 * Requires PHP: 8.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'JKSH_VERSION', '0.13.13' );
define( 'JKSH_DB_VERSION', '0.4.0' );
define( 'JKSH_FILE', __FILE__ );
define( 'JKSH_DIR', plugin_dir_path( __FILE__ ) );
define( 'JKSH_URL', plugin_dir_url( __FILE__ ) );

spl_autoload_register(
	static function ( $class ) {
		$prefix = 'JKSH\\';
		if ( 0 !== strpos( $class, $prefix ) ) {
			return;
		}

		$relative = substr( $class, strlen( $prefix ) );
		$path     = JKSH_DIR . 'src/' . str_replace( '\\', '/', $relative ) . '.php';
		if ( is_readable( $path ) ) {
			require_once $path;
		}
	}
);

register_activation_hook( __FILE__, array( 'JKSH\\Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'JKSH\Deactivator', 'deactivate' ) );

// Register MCP Ability hooks as early as possible. WordPress requires abilities to be
// registered from wp_abilities_api_* actions; waiting until plugins_loaded can be too late.
( new JKSH\Mcp\Abilities() )->register();

add_action(
	'plugins_loaded',
	static function () {
		JKSH\Plugin::instance()->boot();
	}
);


/* JKSH v0.9.3.4 unified content library */
if ( file_exists( __DIR__ . '/includes/class-jksh-content-library-v091.php' ) ) {
    require_once __DIR__ . '/includes/class-jksh-content-library-v091.php';
}

// JKSH_V0912_UPLOAD_SYNC_LOADER
$jksh_v0912_upload_sync = __DIR__ . '/includes/class-jksh-content-library-v0912-upload-sync.php';
if ( is_readable( $jksh_v0912_upload_sync ) ) { require_once $jksh_v0912_upload_sync; }
// JKSH_V0935_YOUTUBE_POSTS_MANUAL
$jksh_v0935_youtube_posts_manual = __DIR__ . '/includes/class-jksh-youtube-posts-manual-v0935.php';
if ( is_readable( $jksh_v0935_youtube_posts_manual ) ) { require_once $jksh_v0935_youtube_posts_manual; }
// JKSH_V0937_UI
$jksh_v0937_ui = __DIR__ . '/includes/class-jksh-ui-v0937.php';
if ( is_readable( $jksh_v0937_ui ) ) { require_once $jksh_v0937_ui; }
 // JKSH_V0938_TIME_RENDER
$jksh_v0938_time_render = __DIR__ . '/includes/class-jksh-time-render-v0938.php';
if ( is_readable( $jksh_v0938_time_render ) ) { require_once $jksh_v0938_time_render; }


// JKSH_V0130_GBP_FOUNDATION
$jksh_v0130_gbp_foundation = __DIR__ . '/includes/class-jksh-gbp-foundation-v0130.php';
if ( is_readable( $jksh_v0130_gbp_foundation ) ) { require_once $jksh_v0130_gbp_foundation; }

// JKSH_V0131_THREADS_FOUNDATION
$jksh_v0131_threads_foundation = __DIR__ . '/includes/class-jksh-threads-foundation-v0131.php';
if ( is_readable( $jksh_v0131_threads_foundation ) ) { require_once $jksh_v0131_threads_foundation; }

// JKSH_V0132_THREADS_CALLBACKS
$jksh_v0132_threads_callbacks = __DIR__ . '/includes/class-jksh-threads-callbacks-v0132.php';
if ( is_readable( $jksh_v0132_threads_callbacks ) ) { require_once $jksh_v0132_threads_callbacks; }

// JKSH_V0138_PINTEREST_SANDBOX
$jksh_v0138_pinterest_sandbox = __DIR__ . '/includes/class-jksh-pinterest-sandbox-v0138.php';
if ( is_readable( $jksh_v0138_pinterest_sandbox ) ) { require_once $jksh_v0138_pinterest_sandbox; }

// JKSH_V0133_ACCOUNTS_UI
$jksh_v0133_accounts_ui = __DIR__ . '/includes/class-jksh-accounts-ui-v0133.php';
if ( is_readable( $jksh_v0133_accounts_ui ) ) { require_once $jksh_v0133_accounts_ui; }
