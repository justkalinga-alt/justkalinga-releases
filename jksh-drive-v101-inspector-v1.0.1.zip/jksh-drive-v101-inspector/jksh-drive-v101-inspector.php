<?php
/**
 * Plugin Name: JKSH Drive v1.0.1 Inspector
 * Description: Temporary read-only structural inspector for the installed JKSH Drive v1.0.1 class. Never returns stored credentials or option values.
 * Version: 1.0.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action( 'rest_api_init', function () {
    register_rest_route( 'jksh-drive-v101-inspector/v1', '/structure', array(
        'methods' => 'GET',
        'permission_callback' => function () { return current_user_can( 'manage_options' ); },
        'callback' => function () {
            if ( ! class_exists( 'JKSH_Drive_Storage_V101' ) ) return new WP_Error( 'missing', 'JKSH_Drive_Storage_V101 is not loaded.', array( 'status' => 404 ) );
            $r = new ReflectionClass( 'JKSH_Drive_Storage_V101' );
            $file = $r->getFileName();
            if ( ! $file || ! is_readable( $file ) ) return new WP_Error( 'not_readable', 'v1.0.1 source is not readable.', array( 'status' => 404 ) );
            $src = file_get_contents( $file );
            $out = array('ok'=>true,'file'=>basename($file),'sha256'=>hash('sha256',$src),'constants'=>array(),'methods'=>array(),'option_keys'=>array(),'transient_keys'=>array(),'meta_keys'=>array(),'literals'=>array());
            foreach ( $r->getConstants() as $k => $v ) if ( is_scalar($v) && strlen((string)$v) < 200 ) $out['constants'][$k] = (string)$v;
            foreach ( $r->getMethods() as $m ) $out['methods'][] = $m->getName();
            $patterns = array(
              'option_keys' => '/(?:get_option|update_option|add_option|delete_option)\\s*\\(\\s*[\\\'\\\"]([^\\\'\\\"]+)[\\\'\\\"]/i',
              'transient_keys' => '/(?:get_transient|set_transient|delete_transient)\\s*\\(\\s*[\\\'\\\"]([^\\\'\\\"]+)[\\\'\\\"]/i',
              'meta_keys' => '/(?:get_post_meta|update_post_meta|add_post_meta|delete_post_meta)\\s*\\([^,]+,\\s*[\\\'\\\"]([^\\\'\\\"]+)[\\\'\\\"]/i'
            );
            foreach($patterns as $bucket=>$pattern) if(preg_match_all($pattern,$src,$m)) $out[$bucket]=array_values(array_unique(array_map('sanitize_text_field',$m[1])));
            if ( preg_match_all('/[\\\'\\\"]([A-Za-z0-9_:\/-]{4,120})[\\\'\\\"]/',$src,$m) ) {
                foreach(array_unique($m[1]) as $v) if(stripos($v,'drive')!==false || stripos($v,'google')!==false || stripos($v,'jksh')!==false) $out['literals'][]=sanitize_text_field($v);
            }
            return rest_ensure_response($out);
        }
    ));
});
