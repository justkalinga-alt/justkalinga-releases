<?php
/**
 * Plugin Name: JKSH Stable ID Scheduler
 * Description: Ensures scheduling an uploaded Social Hub item uses the v0.9.1.3 stable Content ID scheduler instead of the older duplicate-creating ability registration.
 * Version: 0.2.0
 * Author: JustKalinga
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Stable_ID_Scheduler_V020 {
    const VERSION = '0.2.0';
    const ABILITY = 'jk-social/queue-content-id';

    public static function boot(): void {
        add_action( 'wp_abilities_api_init', array( __CLASS__, 'replace_ability' ), 99999 );
        add_action( 'rest_api_init', array( __CLASS__, 'register_status_route' ) );
    }

    public static function replace_ability(): void {
        if ( ! function_exists( 'wp_register_ability' ) ) { return; }
        if ( ! class_exists( 'JKSH_Content_Library_V0913_Upload_Sync' ) ) { return; }

        if ( function_exists( 'wp_has_ability' ) && wp_has_ability( self::ABILITY ) ) {
            if ( ! function_exists( 'wp_unregister_ability' ) ) { return; }
            wp_unregister_ability( self::ABILITY );
        }

        $handler = JKSH_Content_Library_V0913_Upload_Sync::instance();
        if ( ! method_exists( $handler, 'ability_queue_content' ) ) { return; }

        wp_register_ability(
            self::ABILITY,
            array(
                'label' => 'Queue Content Library item by stable Content ID',
                'description' => 'Schedules an uploaded JK Social Hub Content Library item while preserving the same Content ID. Uses the v0.9.1.3 stable scheduler and adopts generated variants/jobs back into the original uploaded record.',
                'category' => 'jk-social',
                'input_schema' => array(
                    'type' => 'object',
                    'additionalProperties' => false,
                    'properties' => array(
                        'content_id' => array( 'type' => 'integer', 'minimum' => 1 ),
                        'scheduled_at_ist' => array( 'type' => 'string', 'minLength' => 1 ),
                        'platforms' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'minItems' => 1 ),
                        'title' => array( 'type' => 'string' ),
                        'body' => array( 'type' => 'string' ),
                        'platform_fields' => array( 'type' => 'object', 'additionalProperties' => true ),
                        'location' => array( 'type' => 'object', 'additionalProperties' => true ),
                        'products' => array( 'type' => 'array', 'items' => array( 'type' => 'object', 'additionalProperties' => true ) ),
                        'cta' => array( 'type' => 'string' ),
                        'confirm_live' => array( 'type' => 'boolean' ),
                    ),
                    'required' => array( 'content_id', 'scheduled_at_ist', 'confirm_live' ),
                ),
                'output_schema' => array( 'type' => 'object', 'additionalProperties' => true ),
                'execute_callback' => array( $handler, 'ability_queue_content' ),
                'permission_callback' => function () { return current_user_can( 'manage_options' ); },
                'meta' => array(
                    'public' => true,
                    'show_in_rest' => true,
                    'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => false ),
                ),
            )
        );
    }

    public static function register_status_route(): void {
        register_rest_route(
            'jksh-stable-id/v1',
            '/status',
            array(
                'methods' => WP_REST_Server::READABLE,
                'permission_callback' => function () { return current_user_can( 'manage_options' ); },
                'callback' => function () {
                    $ability = function_exists( 'wp_get_ability' ) ? wp_get_ability( self::ABILITY ) : null;
                    return rest_ensure_response( array(
                        'ok' => true,
                        'version' => self::VERSION,
                        'v0913_class_loaded' => class_exists( 'JKSH_Content_Library_V0913_Upload_Sync' ),
                        'ability_registered' => (bool) $ability,
                        'ability_label' => $ability && method_exists( $ability, 'get_label' ) ? $ability->get_label() : '',
                        'strategy' => 'v0913 stable Content ID scheduling',
                    ) );
                },
            )
        );
    }
}

JKSH_Stable_ID_Scheduler_V020::boot();
