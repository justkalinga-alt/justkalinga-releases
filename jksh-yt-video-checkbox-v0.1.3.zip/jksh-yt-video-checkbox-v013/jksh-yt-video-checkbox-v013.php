<?php
/**
 * Plugin Name: JKSH YT Video Checkbox Hotfix v0.1.3
 * Description: Enables the YouTube destination checkbox on JK Social Hub Social Upload for Reel/Short and Long video when the connected YouTube account is present. Does not enable YouTube for image/carousel posts.
 * Version: 0.1.3
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function jksh_yt013_connected() {
    global $wpdb;
    $table = $wpdb->prefix . 'jksh_accounts';
    if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
        return false;
    }
    return (bool) $wpdb->get_var( "SELECT id FROM {$table} WHERE platform='youtube' AND status='connected' ORDER BY id DESC LIMIT 1" );
}

add_action( 'rest_api_init', function () {
    register_rest_route( 'jksh-yt013/v1', '/status', array(
        'methods' => 'GET',
        'callback' => function () {
            return rest_ensure_response( array(
                'ok' => true,
                'version' => '0.1.3',
                'youtube_connected' => jksh_yt013_connected(),
                'rule' => 'enabled for reel/short and long video only',
            ) );
        },
        'permission_callback' => function () { return current_user_can( 'manage_options' ); },
    ) );
} );

add_action( 'admin_footer', function () {
    if ( ! is_admin() || sanitize_key( (string) ( $_GET['page'] ?? '' ) ) !== 'jksh-social-upload' || ! jksh_yt013_connected() ) {
        return;
    }
    ?>
<script id="jksh-yt013-video-checkbox">
(() => {
  'use strict';
  const norm = v => String(v || '').replace(/\s+/g,' ').trim().toLowerCase();

  function ytBox() {
    return Array.from(document.querySelectorAll('input[type="checkbox"]')).find(el => {
      const label = el.closest('label') || el.parentElement;
      return norm(el.value) === 'youtube' || /youtube/.test(norm(label && label.innerText));
    }) || null;
  }

  function selectedMode() {
    const selectors = ['[aria-selected="true"]','[aria-pressed="true"]','[aria-checked="true"]','.active','.selected','.is-active','.is-selected'];
    for (const sel of selectors) {
      for (const el of document.querySelectorAll(sel)) {
        const t = norm(el.innerText);
        if (/reel\s*\/\s*short|vertical video|long video|youtube landscape/.test(t)) return 'video';
        if (/single post|one image|carousel|ordered images/.test(t)) return 'image';
      }
    }
    const cards = Array.from(document.querySelectorAll('button,label,[role="button"],div')).filter(el => {
      const t = norm(el.innerText);
      return t.length > 0 && t.length < 90 && /(reel\s*\/\s*short|long video|single post|carousel)/.test(t);
    });
    for (const el of cards) {
      const cs = getComputedStyle(el);
      const border = cs.borderTopColor || cs.borderColor || '';
      const bg = cs.backgroundColor || '';
      const selected = /rgb\(2[0-9]{2},\s*[0-9]{1,2},\s*[0-9]{1,2}\)/.test(border) || /rgb\(25[0-5],\s*24[0-9],\s*24[0-9]\)/.test(bg);
      if (!selected) continue;
      const t = norm(el.innerText);
      if (/reel\s*\/\s*short|long video/.test(t)) return 'video';
      if (/single post|carousel/.test(t)) return 'image';
    }
    return window.jkshYt013LastMode || '';
  }

  function enableYT() {
    const yt = ytBox();
    if (!yt || selectedMode() !== 'video') return;
    yt.disabled = false;
    yt.removeAttribute('disabled');
    yt.setAttribute('aria-disabled','false');
    const label = yt.closest('label') || yt.parentElement;
    if (label) {
      label.style.opacity = '1';
      label.style.pointerEvents = 'auto';
      label.removeAttribute('aria-disabled');
      label.classList.remove('disabled','is-disabled','jksh-disabled');
      label.title = 'YouTube is available for Reel / Short and Long video.';
    }
  }

  document.addEventListener('click', e => {
    let el = e.target;
    for (let i=0; el && i<7; i++, el=el.parentElement) {
      const t = norm(el.innerText);
      if (t.length > 120) continue;
      if (/reel\s*\/\s*short|long video/.test(t)) {
        window.jkshYt013LastMode = 'video';
        setTimeout(enableYT,0); setTimeout(enableYT,100); setTimeout(enableYT,350);
        return;
      }
      if (/single post|carousel/.test(t)) {
        window.jkshYt013LastMode = 'image';
        return;
      }
    }
  }, true);

  const obs = new MutationObserver(() => {
    if (selectedMode() === 'video') requestAnimationFrame(enableYT);
  });
  obs.observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['disabled','class','aria-selected','aria-pressed','aria-checked']});
  setTimeout(enableYT,50); setTimeout(enableYT,500);
})();
</script>
    <?php
}, PHP_INT_MAX );
