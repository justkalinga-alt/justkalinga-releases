<?php
/**
 * Plugin Name: JKSH Manual Destination Mode
 * Description: Removes Social Upload destination controls, keeps native upload validation satisfied internally, and saves new uploads without selected platforms for manual publish/schedule destination choice.
 * Version: 1.0.2
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'admin_footer', function () {
    if ( ! is_admin() ) return;
    $page = sanitize_key( (string) ( $_GET['page'] ?? '' ) );
    if ( 'jksh-social-upload' !== $page ) return;
    ?>
    <style id="jksh-manual-destination-v102-css">
      .jksh-manual-destination-hidden{display:none!important}
    </style>
    <script id="jksh-manual-destination-v102-js">
    (()=>{
      if(window.__jkshManualDestinationV102)return;
      window.__jkshManualDestinationV102=true;

      const ensureHiddenValidatorPlatform=()=>{
        const boxes=[...document.querySelectorAll('.jkssb-platform')];
        if(!boxes.length)return;
        if(boxes.some(x=>x.checked && !x.disabled))return;
        const preferred=boxes.find(x=>x.value==='instagram' && !x.disabled) || boxes.find(x=>!x.disabled);
        if(preferred) preferred.checked=true;
      };

      const applyUI=()=>{
        document.querySelectorAll('.jkssb-platforms').forEach(box=>{
          const section=box.closest('.jkssb-section');
          if(section)section.classList.add('jksh-manual-destination-hidden');
        });
        document.querySelectorAll('.jkssb-storage-note span').forEach(span=>{
          const t=(span.textContent||'').trim();
          if(t.includes('>50 MB')) span.textContent='>50 MB · Google Drive';
        });
        ensureHiddenValidatorPlatform();
      };

      // Keep the hidden native validator satisfied immediately before its click handler runs.
      document.addEventListener('click',e=>{
        if(e.target && e.target.closest && e.target.closest('#jkssb-upload')){
          applyUI();
          ensureHiddenValidatorPlatform();
        }
      },true);

      // Destination-neutral persistence: native validation sees one internal checkbox,
      // but the saved bundle always receives an empty selected_platforms array.
      const priorFetch=window.fetch.bind(window);
      window.fetch=async function(input,init){
        try{
          if(init && init.body instanceof FormData){
            const action=init.body.get('action');
            if(action==='jkssb_ui_save_bundle'){
              const raw=init.body.get('payload');
              if(typeof raw==='string' && raw){
                const payload=JSON.parse(raw);
                payload.selected_platforms=[];
                init.body.set('payload',JSON.stringify(payload));
              }
            }
          }
        }catch(e){}
        return priorFetch(input,init);
      };

      applyUI();
      const mo=new MutationObserver(applyUI);
      mo.observe(document.documentElement,{childList:true,subtree:true});
    })();
    </script>
    <?php
}, 9999 );
