<?php
/**
 * Plugin Name: JKSH Pinterest Sandbox Dispatcher Fix
 * Description: One-time guarded patch allowing the connected Pinterest Sandbox image lane through JK Social Hub Dispatcher while production remains locked.
 * Version: 1.1.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) exit;

final class JKSH_Pin_Dispatcher_V110 {
    private static $i;
    static function instance(){ return self::$i ?: ( self::$i = new self() ); }
    private function __construct(){ add_action( 'rest_api_init', [ $this, 'routes' ] ); }
    public function can(){ return current_user_can( 'manage_options' ); }
    private function file(){ $f = WP_PLUGIN_DIR . '/jk-social-hub/src/Queue/Dispatcher.php'; return is_file($f) && is_readable($f) && is_writable($f) ? $f : ''; }
    public function routes(){
        register_rest_route( 'jksh-pin-dispatcher/v1', '/status', [ 'methods'=>'GET','permission_callback'=>[$this,'can'],'callback'=>fn()=>rest_ensure_response($this->status()) ] );
        register_rest_route( 'jksh-pin-dispatcher/v1', '/apply', [ 'methods'=>'POST','permission_callback'=>[$this,'can'],'callback'=>function(WP_REST_Request $r){ if(true!==(bool)$r->get_param('confirm')) return new WP_Error('confirm_required','confirm=true required',['status'=>400]); return rest_ensure_response($this->apply()); } ] );
    }
    public function status(){
        $f=$this->file(); $s=$f?file_get_contents($f):'';
        return [ 'ok'=>(bool)$f, 'version'=>'1.1.0', 'patched'=>$s && false!==strpos($s,'JKSH_PIN_SANDBOX_DISPATCHER_V110'), 'sha256'=>$f?hash_file('sha256',$f):'' ];
    }
    public function apply(){
        $f=$this->file(); if(!$f) return ['ok'=>false,'message'=>'Writable Dispatcher.php not found.'];
        $s=file_get_contents($f); if(false===$s) return ['ok'=>false,'message'=>'Could not read Dispatcher.php'];
        if(false!==strpos($s,'JKSH_PIN_SANDBOX_DISPATCHER_V110')) return array_merge(['ok'=>true,'message'=>'Already patched.'],$this->status());
        $orig=$s;

        $old1 = <<<'OLD'
					$pinterest_ready = \JKSH_Pinterest_Connector::instance()->readiness();
					$preflight = ! empty( $pinterest_ready['live_publish_possible'] )
						? array( 'ok' => true )
						: array( 'ok' => false, 'message' => (string) ( $pinterest_ready['message'] ?? $pinterest_ready['note'] ?? 'Pinterest live publishing is not ready.' ) );
OLD;
        $new1 = <<<'NEW'
					$pinterest_ready = \JKSH_Pinterest_Connector::instance()->readiness();
					/* JKSH_PIN_SANDBOX_DISPATCHER_V110 */
					$pinterest_sandbox = class_exists( '\\JKSH_Pinterest_Sandbox_V0138' ) ? \JKSH_Pinterest_Sandbox_V0138::instance()->readiness() : array();
					$pinterest_sandbox_ok = is_array( $pinterest_sandbox ) && ! empty( $pinterest_sandbox['connected'] ) && ! empty( $pinterest_sandbox['image_pins_supported'] );
					$preflight = ( ! empty( $pinterest_ready['live_publish_possible'] ) || $pinterest_sandbox_ok )
						? array( 'ok' => true )
						: array( 'ok' => false, 'message' => (string) ( $pinterest_ready['message'] ?? $pinterest_ready['note'] ?? 'Pinterest production and Sandbox publishing are not ready.' ) );
NEW;
        $s=str_replace($old1,$new1,$s,$c1);
        if(1!==$c1) return ['ok'=>false,'message'=>'Preflight anchor mismatch; no file changed.','count'=>$c1];

        $old2 = <<<'OLD'
			$pinterest = \JKSH_Pinterest_Connector::instance();
			$pinterest_ready = $pinterest->readiness();
			if ( empty( $pinterest_ready['live_publish_possible'] ) ) {
				$this->block_job( $jobs, $variants, $logs, $job, (string) ( $pinterest_ready['message'] ?? $pinterest_ready['note'] ?? 'Pinterest live publishing is not ready.' ) );
				return;
			}
OLD;
        $new2 = <<<'NEW'
			$pinterest = \JKSH_Pinterest_Connector::instance();
			$pinterest_ready = $pinterest->readiness();
			/* JKSH_PIN_SANDBOX_DISPATCHER_V110 */
			$pinterest_sandbox = class_exists( '\\JKSH_Pinterest_Sandbox_V0138' ) ? \JKSH_Pinterest_Sandbox_V0138::instance()->readiness() : array();
			$pinterest_sandbox_ok = is_array( $pinterest_sandbox ) && ! empty( $pinterest_sandbox['connected'] ) && ! empty( $pinterest_sandbox['image_pins_supported'] );
			if ( empty( $pinterest_ready['live_publish_possible'] ) && ! $pinterest_sandbox_ok ) {
				$this->block_job( $jobs, $variants, $logs, $job, (string) ( $pinterest_ready['message'] ?? $pinterest_ready['note'] ?? 'Pinterest production and Sandbox publishing are not ready.' ) );
				return;
			}
NEW;
        $s=str_replace($old2,$new2,$s,$c2);
        if(1!==$c2) return ['ok'=>false,'message'=>'Publish anchor mismatch; no file changed.','count'=>$c2];

        $backup=$f.'.jkshbak-pin-dispatcher-'.gmdate('YmdHis');
        if(!copy($f,$backup)) return ['ok'=>false,'message'=>'Could not create Dispatcher backup.'];
        if(false===file_put_contents($f,$s,LOCK_EX)) return ['ok'=>false,'message'=>'Could not write Dispatcher patch.'];
        clearstatcache(true,$f);
        return array_merge(['ok'=>true,'message'=>'Dispatcher patched for Sandbox image lane.','backup'=>basename($backup)],$this->status());
    }
}
JKSH_Pin_Dispatcher_V110::instance();
