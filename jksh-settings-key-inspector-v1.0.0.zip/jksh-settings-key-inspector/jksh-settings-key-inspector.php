<?php
/**
 * Plugin Name: JKSH Settings Key Inspector
 * Description: Temporary read-only inspector that exposes settings/property names only, never values.
 * Version: 1.0.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'rest_api_init', function () {
    register_rest_route( 'jksh-settings-keys/v1', '/list', array(
        'methods' => 'GET',
        'permission_callback' => function () { return current_user_can( 'manage_options' ); },
        'callback' => function () {
            $out = array( 'settings_keys' => array(), 'youtube_action_properties' => array(), 'youtube_action_methods' => array() );
            if ( class_exists( '\JKSH\Services\Settings' ) ) {
                $s = new \JKSH\Services\Settings();
                if ( method_exists( $s, 'all' ) ) {
                    $all = $s->all();
                    if ( is_array( $all ) ) {
                        $keys = array_keys( $all );
                        sort( $keys );
                        $out['settings_keys'] = array_values( array_filter( $keys, function ( $k ) {
                            return preg_match( '/youtube|google|oauth|client|secret|drive/i', (string) $k );
                        } ) );
                    }
                }
            }
            if ( class_exists( '\JKSH\Admin\YouTubeActions' ) ) {
                $r = new ReflectionClass( '\JKSH\Admin\YouTubeActions' );
                foreach ( $r->getProperties() as $p ) { $out['youtube_action_properties'][] = $p->getName(); }
                foreach ( $r->getMethods() as $m ) { $out['youtube_action_methods'][] = $m->getName(); }
                sort( $out['youtube_action_properties'] );
                sort( $out['youtube_action_methods'] );
            }
            return rest_ensure_response( $out );
        },
    ) );
} );
