<?php
/**
 * Plugin Name: JKSH YouTube Video Selector Fix
 * Description: Keeps YouTube selectable for Reel/Short and Long Video in JK Social Hub Social Upload when the YouTube account is connected. Leaves image-post YouTube rules unchanged.
 * Version: 0.1.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_YouTube_Video_Select_V010 {
    const VERSION = '0.1.0';

    public static function boot() {
        add_action( 'admin_footer', array( __CLASS__, 'admin_footer' ), PHP_INT_MAX );
        add_action( 'rest_api_init', array( __CLASS__, 'rest_routes' ) );
    }

    private static function youtube_connected() {
        if ( class_exists( '\\JKSH\\Repositories\\AccountRepository' ) ) {
            try {
                $accounts = ( new \\JKSH\\Repositories\\AccountRepository() )->connected( 'youtube' );
                return ! empty( $accounts );
            } catch ( Throwable $e ) {
                return false;
            }
        }
        global $wpdb;
        $table = $wpdb->prefix . 'jksh_accounts';
        $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
        if ( $exists !== $table ) return false;
        return (bool) $wpdb->get_var( "SELECT id FROM {$table} WHERE platform='youtube' AND status='connected' ORDER BY id DESC LIMIT 1" );
    }

    public static function rest_routes() {
        register_rest_route( 'jksh-youtube-video-select/v1', '/status', array(
            'methods' => 'GET',
            'callback' => function () {
                return rest_ensure_response( array(
                    'ok' => true,
                    'version' => self::VERSION,
                    'youtube_connected' => self::youtube_connected(),
                    'rule' => 'youtube enabled for reel/short and long video; image rules unchanged',
                ) );
            },
            'permission_callback' => function () { return current_user_can( 'manage_options' ); },
        ) );
    }

    public static function admin_footer() {
        if ( ! is_admin() ) return;
        $page = sanitize_key( (string) ( $_GET['page'] ?? '' ) );
        if ( 'jksh-social-upload' !== $page ) return;
        $connected = self::youtube_connected();
        ?>
<script id="jksh-youtube-video-select-v010">
(() => {
  'use strict';
  const youtubeConnected = <?php echo $connected ? 'true' : 'false'; ?>;
  if (!youtubeConnected) return;

  const norm = s => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const isVideoText = s => {
    s = norm(s);
    return s.includes('reel / short') || s.includes('vertical video') || s.includes('long video') || s.includes('youtube landscape');
  };
  const isImageText = s => {
    s = norm(s);
    return s.includes('single post') || s.includes('one image') || s.includes('carousel') || s.includes('2–10 ordered images') || s.includes('2-10 ordered images');
  };

  function youtubeInput() {
    const boxes = Array.from(document.querySelectorAll('input[type="checkbox"]'));
    return boxes.find(el => norm(el.value) === 'youtube') ||
      boxes.find(el => /youtube/i.test((el.closest('label') || el.parentElement || {}).innerText || '')) || null;
  }

  function typeFromCheckedInput() {
    const checked = Array.from(document.querySelectorAll('input[type="radio"]:checked, input[type="checkbox"]:checked'));
    for (const el of checked) {
      const v = norm(el.value || el.name);
      if (/reel|short|long.?video|video/.test(v) && v !== 'youtube') return 'video';
      if (/single|carousel|image/.test(v)) return 'image';
    }
    return '';
  }

  function cardCandidates() {
    const phrases = ['Reel / Short','Long video','Single post','Carousel'];
    const all = Array.from(document.querySelectorAll('button,label,[role="radio"],[role="button"],div'));
    return all.filter(el => {
      const t = String(el.innerText || '').trim();
      if (!t || t.length > 90) return false;
      return phrases.some(p => t.includes(p));
    });
  }

  function looksSelected(el) {
    if (!el) return false;
    if (el.getAttribute('aria-selected') === 'true' || el.getAttribute('aria-pressed') === 'true' || el.getAttribute('aria-checked') === 'true') return true;
    const cls = norm(el.className);
    if (/\b(active|selected|is-active|is-selected|checked)\b/.test(cls)) return true;
    const nested = el.querySelector && el.querySelector('input:checked');
    if (nested) return true;
    try {
      const cs = getComputedStyle(el);
      const m = String(cs.borderTopColor || '').match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
      const bg = String(cs.backgroundColor || '').match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
      if (m) {
        const r=+m[1], g=+m[2], b=+m[3];
        if (r > 190 && r > g * 1.25 && r > b * 1.15) return true;
      }
      if (bg) {
        const r=+bg[1], g=+bg[2], b=+bg[3];
        if (r > 235 && g < 245 && b < 245 && r > g && r > b) return true;
      }
    } catch(e) {}
    return false;
  }

  let lastMode = '';
  function detectMode() {
    const checked = typeFromCheckedInput();
    if (checked) return checked;
    const selected = cardCandidates().find(looksSelected);
    if (selected) {
      const t = selected.innerText || '';
      if (isVideoText(t)) return 'video';
      if (isImageText(t)) return 'image';
    }
    return lastMode;
  }

  function setVisualEnabled(input) {
    input.disabled = false;
    input.removeAttribute('disabled');
    input.setAttribute('aria-disabled','false');
    const label = input.closest('label') || input.parentElement;
    if (label) {
      label.style.opacity = '1';
      label.style.pointerEvents = 'auto';
      label.removeAttribute('aria-disabled');
      label.classList.remove('disabled','is-disabled','jksh-disabled');
      label.title = 'YouTube is available for Reel / Short and Long video.';
      Array.from(label.querySelectorAll('*')).forEach(el => {
        if (el !== input) el.style.opacity = '';
      });
    }
  }

  let applying = false;
  function apply() {
    if (applying) return;
    applying = true;
    try {
      const yt = youtubeInput();
      if (!yt) return;
      const mode = detectMode();
      if (mode === 'video') setVisualEnabled(yt);
      // Image modes intentionally remain governed by the native JKSH rule.
    } finally {
      applying = false;
    }
  }

  document.addEventListener('click', e => {
    let el = e.target;
    for (let i=0; el && i<7; i++, el=el.parentElement) {
      const t = String(el.innerText || '');
      if (isVideoText(t) && t.length < 120) { lastMode = 'video'; setTimeout(apply, 0); setTimeout(apply, 80); return; }
      if (isImageText(t) && t.length < 120) { lastMode = 'image'; return; }
    }
  }, true);

  document.addEventListener('change', e => {
    const v = norm(e.target && (e.target.value || e.target.name));
    if (/reel|short|long.?video|video/.test(v) && v !== 'youtube') lastMode = 'video';
    else if (/single|carousel|image/.test(v)) lastMode = 'image';
    setTimeout(apply, 0);
  }, true);

  const obs = new MutationObserver(() => {
    if (detectMode() === 'video') requestAnimationFrame(apply);
  });
  obs.observe(document.body, {subtree:true, childList:true, attributes:true, attributeFilter:['disabled','class','aria-selected','aria-pressed','aria-checked']});

  setTimeout(apply, 0);
  setTimeout(apply, 250);
  setTimeout(apply, 1000);
})();
</script>
        <?php
    }
}
JKSH_YouTube_Video_Select_V010::boot();
