<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Pinterest_Diagnostic_V0135 {
    public static function init(): void {
        add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
    }
    public static function routes(): void {
        register_rest_route(
            'jksh/v1',
            '/maintenance/pinterest-connector-method',
            [
                'methods' => 'GET',
                'permission_callback' => static fn() => current_user_can( 'manage_options' ),
                'callback' => [ __CLASS__, 'inspect' ],
            ]
        );
    }
    public static function inspect( WP_REST_Request $request ): WP_REST_Response {
        $method = sanitize_key( (string) ( $request->get_param( 'method' ) ?: 'process_job' ) );
        if ( ! class_exists( 'JKSH_Pinterest_Connector' ) ) {
            return new WP_REST_Response( [ 'ok' => false, 'message' => 'Pinterest connector class not loaded.' ], 404 );
        }
        if ( ! method_exists( 'JKSH_Pinterest_Connector', $method ) ) {
            return new WP_REST_Response( [ 'ok' => false, 'message' => 'Method not found.' ], 404 );
        }
        try {
            $ref = new ReflectionMethod( 'JKSH_Pinterest_Connector', $method );
            $file = $ref->getFileName();
            $lines = is_string( $file ) && is_readable( $file ) ? file( $file, FILE_IGNORE_NEW_LINES ) : [];
            $start = max( 1, $ref->getStartLine() - 8 );
            $end = min( count( $lines ), $ref->getEndLine() + 8 );
            $source = [];
            for ( $i = $start; $i <= $end; $i++ ) {
                $source[] = [ 'line' => $i, 'text' => (string) ( $lines[ $i - 1 ] ?? '' ) ];
            }
            return new WP_REST_Response(
                [
                    'ok' => true,
                    'class' => 'JKSH_Pinterest_Connector',
                    'method' => $method,
                    'file' => basename( (string) $file ),
                    'start' => $ref->getStartLine(),
                    'end' => $ref->getEndLine(),
                    'source' => $source,
                ],
                200
            );
        } catch ( Throwable $e ) {
            return new WP_REST_Response( [ 'ok' => false, 'message' => $e->getMessage() ], 500 );
        }
    }
}
JKSH_Pinterest_Diagnostic_V0135::init();
