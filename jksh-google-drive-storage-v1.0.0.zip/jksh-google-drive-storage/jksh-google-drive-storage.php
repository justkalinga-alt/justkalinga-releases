<?php
/**
 * Plugin Name: JKSH Google Drive Storage
 * Description: Google Drive storage backend for JK Social Hub large media. Files over 50 MB upload directly from the browser to Drive; WordPress stores metadata only.
 * Version: 1.0.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Google_Drive_Storage_V100 {
    const VERSION = '1.0.0';
    const PLATFORM = 'google_drive';
    const THRESHOLD = 52428800; // 50 MB
    const MAX_BYTES = 524288000; // preserve current Social Upload 500 MB contract
    const UPLOAD_PREFIX = 'jkdrv1:';
    const STATE_TTL = 900;
    const UPLOAD_TTL = 7200;
    const DELIVERY_TTL = 21600;
    const ACTION = 'jksh_process_job';

    private static $instance = null;
    private static $temp_files = array();
    private static $temp_map = array();

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_post_jksh_drive_oauth_start', array( $this, 'oauth_start' ) );
        add_action( 'admin_post_jksh_drive_oauth_callback', array( $this, 'oauth_callback' ) );
        add_action( 'admin_post_jksh_drive_test_account', array( $this, 'test_account' ) );
        add_action( 'admin_post_jksh_drive_disconnect_account', array( $this, 'disconnect_account' ) );
        add_action( 'admin_footer', array( $this, 'admin_footer' ), 9200 );
        add_action( 'wp_footer', array( $this, 'frontend_footer' ), 9200 );
        add_action( 'template_redirect', array( $this, 'redirect_old_upload_portal' ), 0 );

        add_action( 'wp_ajax_jkssb_ui_begin', array( $this, 'intercept_large_begin' ), 1 );
        add_action( 'wp_ajax_jksh_drive_finalize', array( $this, 'ajax_finalize' ), 1 );

        add_filter( 'wp_get_attachment_url', array( $this, 'attachment_url' ), 50, 2 );
        add_filter( 'get_attached_file', array( $this, 'attached_file' ), 50, 2 );
        add_action( 'delete_attachment', array( $this, 'delete_drive_file_for_attachment' ), 5, 1 );

        add_action( self::ACTION, array( $this, 'prepare_publish_job' ), 4, 1 );
        add_action( self::ACTION, array( $this, 'cleanup_publish_job' ), 20, 1 );

        add_action( 'rest_api_init', array( $this, 'rest_routes' ) );
    }

    private function deps_ready() {
        return class_exists( '\\JKSH\\Repositories\\AccountRepository' )
            && class_exists( '\\JKSH\\Security\\Crypto' )
            && class_exists( '\\JKSH\\Services\\YouTubeConnector' );
    }

    private function accounts() { return new \JKSH\Repositories\AccountRepository(); }
    private function crypto() { return new \JKSH\Security\Crypto(); }
    private function youtube_connector() { return new \JKSH\Services\YouTubeConnector(); }

    private function can_manage() {
        return current_user_can( 'jksh_manage_accounts' ) || current_user_can( 'manage_options' );
    }

    public function redirect_uri() {
        return admin_url( 'admin-post.php?action=jksh_drive_oauth_callback' );
    }

    public function scopes() {
        return array( 'https://www.googleapis.com/auth/drive.file' );
    }

    private function youtube_config() {
        if ( ! $this->deps_ready() ) return array( 'client_id' => '', 'client_secret_encrypted' => '' );
        $config = $this->youtube_connector()->config();
        return is_array( $config ) ? $config : array();
    }

    private function google_client() {
        $config = $this->youtube_config();
        $client_id = sanitize_text_field( (string) ( $config['client_id'] ?? '' ) );
        $secret = '';
        if ( ! empty( $config['client_secret_encrypted'] ) ) {
            $secret = (string) $this->crypto()->decrypt( (string) $config['client_secret_encrypted'] );
        }
        return array( 'client_id' => $client_id, 'client_secret' => $secret );
    }

    private function primary_account() {
        if ( ! $this->deps_ready() ) return null;
        $items = $this->accounts()->connected( self::PLATFORM );
        return $items ? $items[0] : null;
    }

    private function account_settings( $account ) {
        if ( ! $account ) return array();
        $s = $this->accounts()->settings( $account );
        return is_array( $s ) ? $s : array();
    }

    private function decode_response( $response ) {
        if ( is_wp_error( $response ) ) {
            return array( 'ok' => false, 'status' => 0, 'message' => $response->get_error_message(), 'data' => array() );
        }
        $status = (int) wp_remote_retrieve_response_code( $response );
        $raw = (string) wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );
        $data = is_array( $data ) ? $data : array();
        if ( $status >= 200 && $status < 300 ) return array( 'ok' => true, 'status' => $status, 'message' => '', 'data' => $data );
        $message = (string) ( $data['error']['message'] ?? $data['error_description'] ?? $data['error'] ?? 'Google Drive API request failed.' );
        return array( 'ok' => false, 'status' => $status, 'message' => sanitize_textarea_field( $message ), 'data' => $data );
    }

    private function access_token( $account ) {
        if ( ! $account ) return array( 'ok' => false, 'message' => 'Google Drive is not connected.' );
        $creds = $this->accounts()->credentials( $account );
        $access = (string) ( $creds['access_token'] ?? '' );
        $expires_at = ! empty( $account->token_expires_at ) ? strtotime( (string) $account->token_expires_at . ' UTC' ) : false;
        if ( '' !== $access && ( false === $expires_at || $expires_at > time() + 120 ) ) {
            return array( 'ok' => true, 'access_token' => $access );
        }
        $refresh = (string) ( $creds['refresh_token'] ?? '' );
        if ( '' === $refresh ) return array( 'ok' => false, 'message' => 'Google Drive refresh token is unavailable. Reconnect Drive.' );
        $client = $this->google_client();
        if ( '' === $client['client_id'] || '' === $client['client_secret'] ) return array( 'ok' => false, 'message' => 'The shared Google OAuth client is not configured.' );
        $response = wp_remote_post( 'https://oauth2.googleapis.com/token', array(
            'timeout' => 30,
            'body' => array(
                'client_id' => $client['client_id'],
                'client_secret' => $client['client_secret'],
                'refresh_token' => $refresh,
                'grant_type' => 'refresh_token',
            ),
        ) );
        $decoded = $this->decode_response( $response );
        if ( empty( $decoded['ok'] ) || empty( $decoded['data']['access_token'] ) ) {
            return array( 'ok' => false, 'message' => 'Google Drive token refresh failed: ' . ( $decoded['message'] ?? 'Unknown error.' ) );
        }
        $creds['access_token'] = sanitize_text_field( (string) $decoded['data']['access_token'] );
        $creds['token_type'] = sanitize_text_field( (string) ( $decoded['data']['token_type'] ?? 'Bearer' ) );
        $creds['scope'] = sanitize_text_field( (string) ( $decoded['data']['scope'] ?? ( $creds['scope'] ?? implode( ' ', $this->scopes() ) ) ) );
        $expires_in = max( 0, (int) ( $decoded['data']['expires_in'] ?? 0 ) );
        $expiry = $expires_in ? gmdate( 'Y-m-d H:i:s', time() + $expires_in ) : null;
        $this->accounts()->upsert( array(
            'platform' => self::PLATFORM,
            'account_name' => (string) $account->account_name,
            'external_account_id' => (string) $account->external_account_id,
            'status' => 'connected',
            'settings' => $this->account_settings( $account ),
            'credentials' => $creds,
            'token_expires_at' => $expiry,
            'last_checked_at' => current_time( 'mysql', true ),
            'last_error' => '',
        ) );
        return array( 'ok' => true, 'access_token' => (string) $creds['access_token'] );
    }

    private function api( $account, $method, $url, $query = array(), $body = null, $headers = array(), $timeout = 45 ) {
        $token = $this->access_token( $account );
        if ( empty( $token['ok'] ) ) return $token;
        if ( $query ) $url = add_query_arg( $query, $url );
        $h = array_merge( array( 'Authorization' => 'Bearer ' . $token['access_token'], 'Accept' => 'application/json' ), $headers );
        $args = array( 'method' => strtoupper( $method ), 'timeout' => $timeout, 'redirection' => 2, 'headers' => $h );
        if ( null !== $body ) {
            if ( is_array( $body ) ) {
                $args['headers']['Content-Type'] = 'application/json; charset=UTF-8';
                $args['body'] = wp_json_encode( $body );
            } else {
                $args['body'] = $body;
            }
        }
        return $this->decode_response( wp_remote_request( $url, $args ) );
    }

    private function about( $account ) {
        return $this->api( $account, 'GET', 'https://www.googleapis.com/drive/v3/about', array( 'fields' => 'user(displayName,emailAddress,photoLink),storageQuota(limit,usage)' ) );
    }

    private function create_folder( $account, $name, $parent = '' ) {
        $body = array( 'name' => sanitize_text_field( $name ), 'mimeType' => 'application/vnd.google-apps.folder' );
        if ( $parent ) $body['parents'] = array( sanitize_text_field( $parent ) );
        return $this->api( $account, 'POST', 'https://www.googleapis.com/drive/v3/files', array( 'fields' => 'id,name,mimeType,parents' ), $body );
    }

    private function file_meta( $account, $file_id ) {
        return $this->api( $account, 'GET', 'https://www.googleapis.com/drive/v3/files/' . rawurlencode( $file_id ), array( 'fields' => 'id,name,mimeType,size,md5Checksum,webViewLink,parents,createdTime,modifiedTime' ) );
    }

    private function ensure_large_folder( $account ) {
        $settings = $this->account_settings( $account );
        $folder_id = sanitize_text_field( (string) ( $settings['large_media_folder_id'] ?? '' ) );
        if ( $folder_id ) {
            $probe = $this->file_meta( $account, $folder_id );
            if ( ! empty( $probe['ok'] ) && 'application/vnd.google-apps.folder' === (string) ( $probe['data']['mimeType'] ?? '' ) ) return $folder_id;
        }
        $vault = $this->create_folder( $account, 'JK Social Hub Media Vault' );
        if ( empty( $vault['ok'] ) || empty( $vault['data']['id'] ) ) return new WP_Error( 'jksh_drive_vault', 'Could not create JK Social Hub Media Vault: ' . ( $vault['message'] ?? 'Unknown error.' ) );
        $large = $this->create_folder( $account, 'Large Media', (string) $vault['data']['id'] );
        if ( empty( $large['ok'] ) || empty( $large['data']['id'] ) ) return new WP_Error( 'jksh_drive_large_folder', 'Could not create Large Media folder: ' . ( $large['message'] ?? 'Unknown error.' ) );
        $settings['vault_folder_id'] = sanitize_text_field( (string) $vault['data']['id'] );
        $settings['large_media_folder_id'] = sanitize_text_field( (string) $large['data']['id'] );
        $settings['large_media_folder_name'] = 'Large Media';
        $creds = $this->accounts()->credentials( $account );
        $this->accounts()->upsert( array(
            'platform' => self::PLATFORM,
            'account_name' => (string) $account->account_name,
            'external_account_id' => (string) $account->external_account_id,
            'status' => 'connected',
            'settings' => $settings,
            'credentials' => $creds,
            'token_expires_at' => $account->token_expires_at,
            'last_checked_at' => current_time( 'mysql', true ),
            'last_error' => '',
        ) );
        return (string) $large['data']['id'];
    }

    public function readiness() {
        $client = $this->google_client();
        $account = $this->primary_account();
        $settings = $account ? $this->account_settings( $account ) : array();
        $healthy = false;
        $message = '';
        if ( $account ) {
            $about = $this->about( $account );
            $healthy = ! empty( $about['ok'] );
            if ( ! $healthy ) $message = (string) ( $about['message'] ?? 'Drive API check failed.' );
        }
        return array(
            'ok' => true,
            'version' => self::VERSION,
            'configured' => '' !== $client['client_id'] && '' !== $client['client_secret'],
            'connected' => (bool) $account,
            'healthy' => $healthy,
            'account_name' => $account ? sanitize_text_field( (string) $account->account_name ) : '',
            'token_expires_at' => $account && $account->token_expires_at ? sanitize_text_field( (string) $account->token_expires_at ) : null,
            'large_media_folder_id' => sanitize_text_field( (string) ( $settings['large_media_folder_id'] ?? '' ) ),
            'threshold_bytes' => self::THRESHOLD,
            'max_bytes' => self::MAX_BYTES,
            'small_storage' => 'supabase',
            'large_storage' => 'google_drive',
            'wordpress_media_bytes' => false,
            'redirect_uri' => $this->redirect_uri(),
            'scopes' => $this->scopes(),
            'last_error' => $message,
        );
    }

    private function guard( $action ) {
        if ( ! $this->can_manage() ) wp_die( esc_html__( 'You do not have permission to manage social accounts.', 'jk-social-hub' ) );
        check_admin_referer( $action );
    }

    private function redirect( $type, $message ) {
        $url = add_query_arg( array( 'page' => 'jksh-accounts', 'jksh_notice' => sanitize_key( $type ), 'jksh_msg' => $message ), admin_url( 'admin.php' ) );
        wp_safe_redirect( $url . '#jksh-drive-storage-v100' );
        exit;
    }

    public function oauth_start() {
        $this->guard( 'jksh_drive_oauth_start' );
        $client = $this->google_client();
        if ( '' === $client['client_id'] || '' === $client['client_secret'] ) $this->redirect( 'error', 'The shared Google OAuth client is not configured in YouTube settings.' );
        $state = wp_generate_password( 48, false, false );
        set_transient( 'jksh_drive_state_' . get_current_user_id(), hash( 'sha256', $state ), self::STATE_TTL );
        $url = add_query_arg( array(
            'client_id' => $client['client_id'],
            'redirect_uri' => $this->redirect_uri(),
            'response_type' => 'code',
            'scope' => implode( ' ', $this->scopes() ),
            'access_type' => 'offline',
            'include_granted_scopes' => 'true',
            'prompt' => 'consent',
            'state' => $state,
        ), 'https://accounts.google.com/o/oauth2/v2/auth' );
        wp_redirect( $url, 302, 'JK Social Google Drive' );
        exit;
    }

    public function oauth_callback() {
        if ( ! $this->can_manage() ) wp_die( esc_html__( 'You do not have permission to manage social accounts.', 'jk-social-hub' ) );
        if ( ! empty( $_GET['error'] ) ) $this->redirect( 'error', 'Google Drive authorization was not completed: ' . sanitize_text_field( wp_unslash( $_GET['error_description'] ?? $_GET['error'] ) ) );
        $code = sanitize_text_field( wp_unslash( $_GET['code'] ?? '' ) );
        $state = sanitize_text_field( wp_unslash( $_GET['state'] ?? '' ) );
        $expected = (string) get_transient( 'jksh_drive_state_' . get_current_user_id() );
        delete_transient( 'jksh_drive_state_' . get_current_user_id() );
        if ( '' === $code || '' === $state || '' === $expected || ! hash_equals( $expected, hash( 'sha256', $state ) ) ) $this->redirect( 'error', 'Google Drive OAuth state validation failed. Start the connection again.' );
        $client = $this->google_client();
        $response = wp_remote_post( 'https://oauth2.googleapis.com/token', array(
            'timeout' => 30,
            'body' => array(
                'code' => $code,
                'client_id' => $client['client_id'],
                'client_secret' => $client['client_secret'],
                'redirect_uri' => $this->redirect_uri(),
                'grant_type' => 'authorization_code',
            ),
        ) );
        $token = $this->decode_response( $response );
        if ( empty( $token['ok'] ) || empty( $token['data']['access_token'] ) ) $this->redirect( 'error', 'Google Drive token exchange failed: ' . ( $token['message'] ?? 'Unknown error.' ) );
        $access = sanitize_text_field( (string) $token['data']['access_token'] );
        $about_response = wp_remote_get( add_query_arg( array( 'fields' => 'user(displayName,emailAddress,photoLink),storageQuota(limit,usage)' ), 'https://www.googleapis.com/drive/v3/about' ), array(
            'timeout' => 30,
            'headers' => array( 'Authorization' => 'Bearer ' . $access, 'Accept' => 'application/json' ),
        ) );
        $about = $this->decode_response( $about_response );
        if ( empty( $about['ok'] ) ) $this->redirect( 'error', 'Google Drive account discovery failed: ' . ( $about['message'] ?? 'Unknown error.' ) );
        $user = (array) ( $about['data']['user'] ?? array() );
        $email = sanitize_email( (string) ( $user['emailAddress'] ?? '' ) );
        $raw_name = sanitize_text_field( (string) ( $user['displayName'] ?? '' ) );
        $name = '' !== $raw_name ? $raw_name : ( '' !== $email ? $email : 'Google Drive' );
        if ( '' === $email ) $this->redirect( 'error', 'Google Drive did not return an account email.' );
        $existing = $this->accounts()->find( self::PLATFORM, $email );
        $existing_creds = $existing ? $this->accounts()->credentials( $existing ) : array();
        $refresh = sanitize_text_field( (string) ( $token['data']['refresh_token'] ?? $existing_creds['refresh_token'] ?? '' ) );
        if ( '' === $refresh ) $this->redirect( 'error', 'Google did not return an offline Drive refresh token. Reconnect and approve access again.' );
        $expires_in = max( 0, (int) ( $token['data']['expires_in'] ?? 0 ) );
        $expiry = $expires_in ? gmdate( 'Y-m-d H:i:s', time() + $expires_in ) : null;
        $settings = $existing ? $this->account_settings( $existing ) : array();
        $settings['email'] = $email;
        $settings['display_name'] = $name;
        $settings['photo_link'] = esc_url_raw( (string) ( $user['photoLink'] ?? '' ) );
        $settings['storage_quota'] = (array) ( $about['data']['storageQuota'] ?? array() );
        $settings['required_scopes'] = $this->scopes();
        $settings['connector_version'] = self::VERSION;
        $account_id = $this->accounts()->upsert( array(
            'platform' => self::PLATFORM,
            'account_name' => $name . ' · ' . $email,
            'external_account_id' => $email,
            'status' => 'connected',
            'credentials' => array(
                'access_token' => $access,
                'refresh_token' => $refresh,
                'token_type' => sanitize_text_field( (string) ( $token['data']['token_type'] ?? 'Bearer' ) ),
                'scope' => sanitize_text_field( (string) ( $token['data']['scope'] ?? implode( ' ', $this->scopes() ) ) ),
            ),
            'settings' => $settings,
            'token_expires_at' => $expiry,
            'last_checked_at' => current_time( 'mysql', true ),
            'last_error' => '',
        ) );
        $account = $this->accounts()->get( $account_id );
        $folder = $this->ensure_large_folder( $account );
        if ( is_wp_error( $folder ) ) $this->redirect( 'error', $folder->get_error_message() );
        $this->redirect( 'success', 'Google Drive connected. Large Media folder is ready.' );
    }

    public function test_account() {
        $this->guard( 'jksh_drive_test_account' );
        $account = $this->primary_account();
        if ( ! $account ) $this->redirect( 'error', 'Google Drive is not connected.' );
        $about = $this->about( $account );
        if ( empty( $about['ok'] ) ) {
            $this->accounts()->update_status( (int) $account->id, 'attention', (string) ( $about['message'] ?? 'Drive API check failed.' ) );
            $this->redirect( 'error', 'Google Drive connection test failed: ' . ( $about['message'] ?? 'Unknown error.' ) );
        }
        $folder = $this->ensure_large_folder( $account );
        if ( is_wp_error( $folder ) ) $this->redirect( 'error', $folder->get_error_message() );
        $this->accounts()->update_status( (int) $account->id, 'connected', '' );
        $this->redirect( 'success', 'Google Drive connection and Large Media folder verified.' );
    }

    public function disconnect_account() {
        $this->guard( 'jksh_drive_disconnect_account' );
        $account = $this->primary_account();
        if ( $account ) $this->accounts()->disconnect( (int) $account->id );
        $this->redirect( 'success', 'Google Drive disconnected locally. Files in Drive were not deleted.' );
    }

    private function ui_check() {
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'Forbidden' ), 403 );
        check_ajax_referer( 'jkssb_social_upload', 'nonce' );
    }

    private function upload_key( $id ) { return 'jksh_drive_upload_' . md5( $id ); }

    public function intercept_large_begin() {
        $bytes = absint( $_POST['bytes'] ?? 0 );
        if ( $bytes <= self::THRESHOLD ) return;
        $this->ui_check();
        $filename = sanitize_file_name( $_POST['filename'] ?? '' );
        $mime = sanitize_mime_type( $_POST['mime_type'] ?? '' );
        $allowed = array( 'image/jpeg','image/png','image/webp','image/gif','video/mp4','video/quicktime','video/webm' );
        if ( ! $filename || ! in_array( $mime, $allowed, true ) || $bytes < 1 || $bytes > self::MAX_BYTES ) wp_send_json_error( array( 'message' => 'This file exceeds the current 500 MB Drive upload limit.' ), 422 );
        $account = $this->primary_account();
        if ( ! $account ) wp_send_json_error( array( 'message' => 'Connect Google Drive in Social Hub → Accounts before uploading files over 50 MB.' ), 409 );
        $folder = $this->ensure_large_folder( $account );
        if ( is_wp_error( $folder ) ) wp_send_json_error( array( 'message' => $folder->get_error_message() ), 500 );
        $token = $this->access_token( $account );
        if ( empty( $token['ok'] ) ) wp_send_json_error( array( 'message' => $token['message'] ), 409 );
        $id = wp_generate_uuid4();
        $url = add_query_arg( array( 'uploadType' => 'resumable', 'fields' => 'id,name,mimeType,size,md5Checksum,webViewLink,parents' ), 'https://www.googleapis.com/upload/drive/v3/files' );
        $init = wp_remote_post( $url, array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $token['access_token'],
                'Accept' => 'application/json',
                'Content-Type' => 'application/json; charset=UTF-8',
                'X-Upload-Content-Type' => $mime,
                'X-Upload-Content-Length' => (string) $bytes,
            ),
            'body' => wp_json_encode( array(
                'name' => $filename,
                'mimeType' => $mime,
                'parents' => array( $folder ),
                'appProperties' => array( 'jksh_upload_id' => $id, 'jksh_source' => 'social_upload' ),
            ) ),
        ) );
        $status = (int) wp_remote_retrieve_response_code( $init );
        $location = (string) wp_remote_retrieve_header( $init, 'location' );
        if ( $status < 200 || $status >= 300 || '' === $location ) {
            $decoded = $this->decode_response( $init );
            wp_send_json_error( array( 'message' => 'Could not start Google Drive resumable upload: ' . ( $decoded['message'] ?? 'No upload session URL returned.' ) ), 502 );
        }
        set_transient( $this->upload_key( $id ), array(
            'id' => $id,
            'user_id' => get_current_user_id(),
            'filename' => $filename,
            'mime_type' => $mime,
            'bytes' => $bytes,
            'width' => absint( $_POST['width'] ?? 0 ),
            'height' => absint( $_POST['height'] ?? 0 ),
            'duration_ms' => absint( $_POST['duration_ms'] ?? 0 ),
            'account_id' => (int) $account->id,
            'folder_id' => (string) $folder,
            'session_url' => esc_url_raw( $location ),
            'created_at' => time(),
        ), self::UPLOAD_TTL );
        wp_send_json_success( array(
            'upload_id' => self::UPLOAD_PREFIX . $id,
            'max_chunk_bytes' => 16 * 1024 * 1024,
            'storage_target' => 'google_drive',
            'direct_transport' => true,
            'drive_session_url' => esc_url_raw( $location ),
            'total_bytes' => $bytes,
            'mime_type' => $mime,
        ) );
    }

    private function parse_upload_id( $upload_id ) {
        $upload_id = sanitize_text_field( (string) $upload_id );
        if ( 0 !== strpos( $upload_id, self::UPLOAD_PREFIX ) ) return '';
        $id = substr( $upload_id, strlen( self::UPLOAD_PREFIX ) );
        return preg_match( '/^[a-f0-9-]{36}$/', $id ) ? $id : '';
    }

    public function ajax_finalize() {
        $this->ui_check();
        $id = $this->parse_upload_id( $_POST['upload_id'] ?? '' );
        $drive_file_id = sanitize_text_field( (string) ( $_POST['drive_file_id'] ?? '' ) );
        if ( ! $id || ! $drive_file_id ) wp_send_json_error( array( 'message' => 'Google Drive upload finalization data is missing.' ), 400 );
        $session = get_transient( $this->upload_key( $id ) );
        if ( ! is_array( $session ) ) wp_send_json_error( array( 'message' => 'Google Drive upload session expired.' ), 404 );
        if ( (int) ( $session['user_id'] ?? 0 ) !== get_current_user_id() ) wp_send_json_error( array( 'message' => 'Google Drive upload session owner mismatch.' ), 403 );
        $account = $this->primary_account();
        if ( ! $account || (int) $account->id !== (int) ( $session['account_id'] ?? 0 ) ) wp_send_json_error( array( 'message' => 'Google Drive account changed during upload.' ), 409 );
        $meta = $this->file_meta( $account, $drive_file_id );
        if ( empty( $meta['ok'] ) ) wp_send_json_error( array( 'message' => 'Could not verify uploaded Drive file: ' . ( $meta['message'] ?? 'Unknown error.' ) ), 502 );
        $data = $meta['data'];
        if ( isset( $data['size'] ) && (int) $data['size'] !== (int) $session['bytes'] ) wp_send_json_error( array( 'message' => 'Google Drive file size does not match the uploaded file.' ), 409 );
        if ( empty( $data['id'] ) || ! hash_equals( (string) $data['id'], $drive_file_id ) ) wp_send_json_error( array( 'message' => 'Google Drive file verification failed.' ), 409 );
        $attachment_id = wp_insert_attachment( array(
            'post_title' => sanitize_text_field( pathinfo( (string) $session['filename'], PATHINFO_FILENAME ) ),
            'post_status' => 'inherit',
            'post_mime_type' => sanitize_mime_type( (string) $session['mime_type'] ),
            'guid' => esc_url_raw( (string) ( $data['webViewLink'] ?? '' ) ),
        ), false, 0, true );
        if ( is_wp_error( $attachment_id ) ) wp_send_json_error( array( 'message' => $attachment_id->get_error_message() ), 500 );
        $attachment_meta = array( 'filesize' => (int) $session['bytes'] );
        if ( ! empty( $session['width'] ) ) $attachment_meta['width'] = (int) $session['width'];
        if ( ! empty( $session['height'] ) ) $attachment_meta['height'] = (int) $session['height'];
        if ( ! empty( $session['duration_ms'] ) ) {
            $seconds = (float) $session['duration_ms'] / 1000;
            $attachment_meta['length'] = $seconds;
            $attachment_meta['length_formatted'] = sprintf( '%02d:%02d', floor( $seconds / 60 ), round( fmod( $seconds, 60 ) ) );
        }
        wp_update_attachment_metadata( $attachment_id, $attachment_meta );
        update_post_meta( $attachment_id, '_jksh_storage_source', 'google_drive' );
        update_post_meta( $attachment_id, '_jkssb_storage_source', 'google_drive' );
        update_post_meta( $attachment_id, '_jksh_drive_file_id', $drive_file_id );
        update_post_meta( $attachment_id, '_jksh_drive_bytes', (int) $session['bytes'] );
        update_post_meta( $attachment_id, '_jksh_drive_md5', sanitize_text_field( (string) ( $data['md5Checksum'] ?? '' ) ) );
        update_post_meta( $attachment_id, '_jksh_drive_account_id', (int) $account->id );
        update_post_meta( $attachment_id, '_jksh_drive_web_view_link', esc_url_raw( (string) ( $data['webViewLink'] ?? '' ) ) );
        update_post_meta( $attachment_id, '_jksh_original_filename', sanitize_file_name( (string) $session['filename'] ) );
        delete_transient( $this->upload_key( $id ) );
        wp_send_json_success( array(
            'ok' => true,
            'attachment_id' => (int) $attachment_id,
            'storage' => 'google_drive',
            'drive_file_id' => $drive_file_id,
            'asset' => array( 'id' => $drive_file_id, 'storage' => 'google_drive' ),
            'url' => $this->signed_delivery_url( (int) $attachment_id ),
        ) );
    }

    private function signed_delivery_url( $attachment_id, $ttl = self::DELIVERY_TTL ) {
        $exp = time() + max( 60, min( self::DELIVERY_TTL, (int) $ttl ) );
        $payload = (int) $attachment_id . '|' . $exp;
        $sig = hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );
        return add_query_arg( array( 'exp' => $exp, 'sig' => $sig ), rest_url( 'jksh-drive/v1/media/' . (int) $attachment_id ) );
    }

    private function is_drive_attachment( $attachment_id ) {
        return 'google_drive' === (string) get_post_meta( (int) $attachment_id, '_jksh_storage_source', true )
            && '' !== (string) get_post_meta( (int) $attachment_id, '_jksh_drive_file_id', true );
    }

    public function attachment_url( $url, $attachment_id ) {
        if ( $this->is_drive_attachment( $attachment_id ) ) return $this->signed_delivery_url( (int) $attachment_id );
        return $url;
    }

    public function attached_file( $file, $attachment_id ) {
        $attachment_id = (int) $attachment_id;
        if ( isset( self::$temp_map[ $attachment_id ] ) && is_readable( self::$temp_map[ $attachment_id ] ) ) return self::$temp_map[ $attachment_id ];
        return $file;
    }

    private function stream_drive_file( $attachment_id ) {
        $exp = absint( $_GET['exp'] ?? 0 );
        $sig = sanitize_text_field( (string) ( $_GET['sig'] ?? '' ) );
        if ( $exp < time() || $exp > time() + self::DELIVERY_TTL + 300 ) return new WP_Error( 'jksh_drive_expired', 'Drive delivery link expired.', array( 'status' => 403 ) );
        $expected = hash_hmac( 'sha256', (int) $attachment_id . '|' . $exp, wp_salt( 'auth' ) );
        if ( ! $sig || ! hash_equals( $expected, $sig ) ) return new WP_Error( 'jksh_drive_signature', 'Drive delivery signature is invalid.', array( 'status' => 403 ) );
        if ( ! $this->is_drive_attachment( $attachment_id ) ) return new WP_Error( 'jksh_drive_missing', 'Drive-backed attachment not found.', array( 'status' => 404 ) );
        $file_id = (string) get_post_meta( $attachment_id, '_jksh_drive_file_id', true );
        $account = $this->primary_account();
        $token = $this->access_token( $account );
        if ( empty( $token['ok'] ) ) return new WP_Error( 'jksh_drive_token', $token['message'], array( 'status' => 503 ) );
        if ( ! function_exists( 'curl_init' ) ) return new WP_Error( 'jksh_drive_curl', 'PHP cURL is required for Drive delivery.', array( 'status' => 500 ) );
        @set_time_limit( 0 );
        ignore_user_abort( true );
        $url = 'https://www.googleapis.com/drive/v3/files/' . rawurlencode( $file_id ) . '?alt=media';
        $range = sanitize_text_field( (string) ( $_SERVER['HTTP_RANGE'] ?? '' ) );
        $method = strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) );
        $ch = curl_init( $url );
        $headers = array( 'Authorization: Bearer ' . $token['access_token'], 'Accept: */*' );
        if ( $range ) $headers[] = 'Range: ' . $range;
        curl_setopt_array( $ch, array(
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 30,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_NOBODY => ( 'HEAD' === $method ),
            CURLOPT_HEADERFUNCTION => function( $curl, $line ) {
                $len = strlen( $line );
                $trim = trim( $line );
                if ( preg_match( '#^HTTP/\\S+\\s+(\\d+)#', $trim, $m ) ) http_response_code( (int) $m[1] );
                foreach ( array( 'content-type:', 'content-length:', 'content-range:', 'accept-ranges:', 'etag:', 'last-modified:' ) as $prefix ) {
                    if ( 0 === stripos( $trim, $prefix ) ) header( $trim, true );
                }
                return $len;
            },
            CURLOPT_WRITEFUNCTION => function( $curl, $chunk ) {
                echo $chunk;
                if ( function_exists( 'fastcgi_finish_request' ) ) { /* do not finish early */ }
                flush();
                return strlen( $chunk );
            },
        ) );
        header( 'Cache-Control: private, max-age=300' );
        header( 'X-Robots-Tag: noindex, nofollow, noarchive' );
        $ok = curl_exec( $ch );
        $err = curl_error( $ch );
        curl_close( $ch );
        if ( false === $ok && ! headers_sent() ) return new WP_Error( 'jksh_drive_stream', sanitize_text_field( $err ?: 'Drive delivery failed.' ), array( 'status' => 502 ) );
        exit;
    }

    private function download_drive_to_temp( $attachment_id ) {
        $attachment_id = (int) $attachment_id;
        if ( isset( self::$temp_map[ $attachment_id ] ) && is_readable( self::$temp_map[ $attachment_id ] ) ) return self::$temp_map[ $attachment_id ];
        $file_id = (string) get_post_meta( $attachment_id, '_jksh_drive_file_id', true );
        $bytes = (int) get_post_meta( $attachment_id, '_jksh_drive_bytes', true );
        $account = $this->primary_account();
        $token = $this->access_token( $account );
        if ( empty( $token['ok'] ) || ! $file_id ) return new WP_Error( 'jksh_drive_download', $token['message'] ?? 'Drive file ID is missing.' );
        $dir = sys_get_temp_dir();
        $free = @disk_free_space( $dir );
        $required = max( 512 * 1024 * 1024, $bytes + 512 * 1024 * 1024 );
        if ( false !== $free && $free < $required ) return new WP_Error( 'jksh_drive_temp_space', 'Not enough temporary disk space to stage this Drive video safely for YouTube. Free at least ' . size_format( $required, 1 ) . '.' );
        $tmp = tempnam( $dir, 'jksh-drive-' );
        if ( ! $tmp ) return new WP_Error( 'jksh_drive_temp', 'Could not create a temporary file for Drive media.' );
        $fh = fopen( $tmp, 'wb' );
        if ( ! $fh ) { @unlink( $tmp ); return new WP_Error( 'jksh_drive_temp_open', 'Could not open the Drive temporary file.' ); }
        $ch = curl_init( 'https://www.googleapis.com/drive/v3/files/' . rawurlencode( $file_id ) . '?alt=media' );
        curl_setopt_array( $ch, array(
            CURLOPT_FILE => $fh,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 30,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_HTTPHEADER => array( 'Authorization: Bearer ' . $token['access_token'], 'Accept: */*' ),
        ) );
        $ok = curl_exec( $ch );
        $status = (int) curl_getinfo( $ch, CURLINFO_RESPONSE_CODE );
        $err = curl_error( $ch );
        curl_close( $ch );
        fclose( $fh );
        if ( false === $ok || $status < 200 || $status >= 300 || ! is_readable( $tmp ) || filesize( $tmp ) < 1 ) {
            @unlink( $tmp );
            return new WP_Error( 'jksh_drive_download_failed', sanitize_text_field( $err ?: 'Google Drive download failed with HTTP ' . $status . '.' ) );
        }
        self::$temp_files[] = $tmp;
        self::$temp_map[ $attachment_id ] = $tmp;
        return $tmp;
    }

    private function download_virtual_to_temp( $attachment_id ) {
        $attachment_id = (int) $attachment_id;
        if ( isset( self::$temp_map[ $attachment_id ] ) && is_readable( self::$temp_map[ $attachment_id ] ) ) return self::$temp_map[ $attachment_id ];
        if ( $this->is_drive_attachment( $attachment_id ) ) return $this->download_drive_to_temp( $attachment_id );
        $url = wp_get_attachment_url( $attachment_id );
        if ( ! $url ) return new WP_Error( 'jksh_virtual_url', 'Virtual media URL is unavailable.' );
        $dir = sys_get_temp_dir();
        $meta = wp_get_attachment_metadata( $attachment_id );
        $bytes = is_array( $meta ) ? (int) ( $meta['filesize'] ?? 0 ) : 0;
        $free = @disk_free_space( $dir );
        $required = max( 256 * 1024 * 1024, $bytes + 256 * 1024 * 1024 );
        if ( false !== $free && $free < $required ) return new WP_Error( 'jksh_virtual_temp_space', 'Not enough temporary disk space to stage this media safely.' );
        $tmp = tempnam( $dir, 'jksh-media-' );
        if ( ! $tmp ) return new WP_Error( 'jksh_virtual_temp', 'Could not create media temporary file.' );
        $response = wp_remote_get( $url, array( 'timeout' => 300, 'redirection' => 3, 'stream' => true, 'filename' => $tmp ) );
        if ( is_wp_error( $response ) || (int) wp_remote_retrieve_response_code( $response ) < 200 || (int) wp_remote_retrieve_response_code( $response ) >= 300 || ! is_readable( $tmp ) || filesize( $tmp ) < 1 ) {
            $msg = is_wp_error( $response ) ? $response->get_error_message() : 'Virtual media download failed.';
            @unlink( $tmp );
            return new WP_Error( 'jksh_virtual_download', $msg );
        }
        self::$temp_files[] = $tmp;
        self::$temp_map[ $attachment_id ] = $tmp;
        return $tmp;
    }

    private function compact_threads_text( $text ) {
        $text = trim( preg_replace( '/\\s+/u', ' ', wp_strip_all_tags( (string) $text ) ) );
        $len = function_exists( 'mb_strlen' ) ? mb_strlen( $text, 'UTF-8' ) : strlen( $text );
        if ( $len <= 500 ) return $text;
        $body = function_exists( 'mb_substr' ) ? mb_substr( $text, 0, 496, 'UTF-8' ) : substr( $text, 0, 496 );
        $space = function_exists( 'mb_strrpos' ) ? mb_strrpos( $body, ' ', 0, 'UTF-8' ) : strrpos( $body, ' ' );
        if ( false !== $space && $space > 400 ) $body = function_exists( 'mb_substr' ) ? mb_substr( $body, 0, $space, 'UTF-8' ) : substr( $body, 0, $space );
        return rtrim( $body, " \t\n\r\0\x0B,.;:-" ) . '…';
    }

    public function prepare_publish_job( $job_id ) {
        global $wpdb;
        $job_id = absint( $job_id );
        if ( ! $job_id ) return;
        $jobs = $wpdb->prefix . 'jksh_jobs';
        $variants = $wpdb->prefix . 'jksh_variants';
        $job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$jobs} WHERE id=%d LIMIT 1", $job_id ) );
        if ( ! $job || ! in_array( (string) $job->status, array( 'queued', 'scheduled', 'pending' ), true ) ) return;
        $variant = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$variants} WHERE id=%d LIMIT 1", (int) $job->variant_id ) );
        if ( ! $variant ) return;

        if ( 'threads' === (string) $job->platform ) {
            $fields = json_decode( (string) ( $variant->fields_json ?? '{}' ), true );
            $fields = is_array( $fields ) ? $fields : array();
            $text = (string) ( $fields['text'] ?? $variant->caption ?? $variant->description ?? '' );
            $compact = $this->compact_threads_text( $text );
            if ( $compact !== $text ) {
                $fields['text'] = $compact;
                $fields['_jksh_drive_guard'] = array( 'threads_compacted' => true, 'version' => self::VERSION, 'at_utc' => gmdate( 'c' ) );
                $wpdb->update( $variants, array( 'caption' => $compact, 'description' => $compact, 'fields_json' => wp_json_encode( $fields, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $variant->id ) );
            }
            return;
        }

        if ( 'youtube' !== (string) $job->platform ) return;
        $ids = json_decode( (string) ( $variant->media_json ?? '[]' ), true );
        $ids = is_array( $ids ) ? array_values( array_filter( array_map( 'absint', $ids ) ) ) : array();
        foreach ( $ids as $id ) {
            $file = get_attached_file( $id );
            if ( ! $file || ! is_readable( $file ) ) {
                $result = $this->download_virtual_to_temp( $id );
                if ( is_wp_error( $result ) ) {
                    $wpdb->update( $jobs, array( 'status' => 'failed', 'last_error' => $result->get_error_message(), 'completed_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $job_id ) );
                    return;
                }
            }
        }
        $fields = json_decode( (string) ( $variant->fields_json ?? '{}' ), true );
        $fields = is_array( $fields ) ? $fields : array();
        $thumb = absint( $fields['thumbnail_attachment_id'] ?? 0 );
        if ( $thumb ) {
            $file = get_attached_file( $thumb );
            if ( ! $file || ! is_readable( $file ) ) {
                $result = $this->download_virtual_to_temp( $thumb );
                if ( is_wp_error( $result ) ) {
                    $fields['thumbnail_attachment_id'] = 0;
                    $fields['_jksh_drive_guard_thumbnail_warning'] = $result->get_error_message();
                    $wpdb->update( $variants, array( 'fields_json' => wp_json_encode( $fields, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $variant->id ) );
                }
            }
        }
    }

    public function cleanup_publish_job( $job_id ) {
        foreach ( array_unique( self::$temp_files ) as $file ) if ( $file && is_file( $file ) ) @unlink( $file );
        self::$temp_files = array();
        self::$temp_map = array();
    }

    public function delete_drive_file_for_attachment( $attachment_id ) {
        $attachment_id = (int) $attachment_id;
        if ( ! $this->is_drive_attachment( $attachment_id ) ) return;
        $file_id = (string) get_post_meta( $attachment_id, '_jksh_drive_file_id', true );
        $account = $this->primary_account();
        if ( ! $file_id || ! $account ) return;
        $this->api( $account, 'DELETE', 'https://www.googleapis.com/drive/v3/files/' . rawurlencode( $file_id ) );
    }

    public function rest_routes() {
        register_rest_route( 'jksh-drive/v1', '/readiness', array(
            'methods' => 'GET',
            'permission_callback' => function() { return $this->can_manage(); },
            'callback' => function() { return rest_ensure_response( $this->readiness() ); },
        ) );
        register_rest_route( 'jksh-drive/v1', '/media/(?P<id>\\d+)', array(
            'methods' => array( 'GET', 'HEAD' ),
            'permission_callback' => '__return_true',
            'callback' => function( WP_REST_Request $request ) { return $this->stream_drive_file( absint( $request['id'] ) ); },
        ) );
    }

    public function admin_footer() {
        if ( ! is_admin() ) return;
        $page = sanitize_key( (string) ( $_GET['page'] ?? '' ) );
        if ( 'jksh-accounts' === $page ) $this->render_account_card();
        if ( 'jksh-social-upload' === $page ) $this->render_upload_router();
    }

    public function frontend_footer() {
        if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) return;
        if ( is_singular() ) {
            global $post;
            if ( $post instanceof WP_Post && has_shortcode( (string) $post->post_content, 'jk_social_upload' ) ) $this->render_upload_router();
        }
    }

    public function redirect_old_upload_portal() {
        if ( is_admin() || wp_doing_ajax() || ! is_user_logged_in() || ! current_user_can( 'manage_options' ) || ! is_singular() ) return;
        global $post;
        if ( $post instanceof WP_Post && has_shortcode( (string) $post->post_content, 'jk_social_upload' ) ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jksh-social-upload&view=upload' ), 302 );
            exit;
        }
    }

    private function render_account_card() {
        $r = $this->readiness();
        $account = $this->primary_account();
        ?>
        <section id="jksh-drive-storage-v100" class="jksh-card" style="margin-top:18px">
          <h2>Google Drive Storage <span class="jksh-badge <?php echo $r['healthy'] ? 'status-connected' : 'status-attention'; ?>"><?php echo esc_html( $r['healthy'] ? 'Connected' : ( $r['connected'] ? 'Attention' : 'Not connected' ) ); ?></span></h2>
          <p><strong>Large-media storage:</strong> files over 50 MB go directly from the browser to Google Drive. WordPress stores metadata only.</p>
          <p><strong>Small media:</strong> Supabase &nbsp; · &nbsp; <strong>Large media:</strong> Google Drive &nbsp; · &nbsp; <strong>WordPress media bytes:</strong> disabled for Social Upload</p>
          <p><strong>OAuth redirect URI</strong><br><code><?php echo esc_html( $this->redirect_uri() ); ?></code></p>
          <p><strong>Scope</strong><br><code><?php echo esc_html( implode( ' ', $this->scopes() ) ); ?></code></p>
          <?php if ( $r['account_name'] ) : ?><p><strong>Account:</strong> <?php echo esc_html( $r['account_name'] ); ?><br><strong>Large Media folder:</strong> <?php echo $r['large_media_folder_id'] ? esc_html( $r['large_media_folder_id'] ) : 'Will be created after connection'; ?></p><?php endif; ?>
          <?php if ( ! $r['configured'] ) : ?><p style="color:#b32d2e"><strong>Shared Google OAuth client is not configured in YouTube settings.</strong></p><?php else : ?>
            <form style="display:inline-block;margin-right:8px" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="jksh_drive_oauth_start"><?php wp_nonce_field( 'jksh_drive_oauth_start' ); ?><button class="button button-primary"><?php echo $r['connected'] ? 'Reconnect Google Drive' : 'Connect Google Drive'; ?></button></form>
          <?php endif; ?>
          <?php if ( $account ) : ?>
            <form style="display:inline-block;margin-right:8px" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="jksh_drive_test_account"><?php wp_nonce_field( 'jksh_drive_test_account' ); ?><button class="button">Test Drive</button></form>
            <form style="display:inline-block" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="jksh_drive_disconnect_account"><?php wp_nonce_field( 'jksh_drive_disconnect_account' ); ?><button class="button button-link-delete">Disconnect Drive</button></form>
          <?php endif; ?>
          <?php if ( $r['last_error'] ) : ?><p style="color:#b32d2e"><strong>Last check:</strong> <?php echo esc_html( $r['last_error'] ); ?></p><?php endif; ?>
        </section>
        <script>(()=>{const card=document.getElementById('jksh-drive-storage-v100');const wrap=document.querySelector('.wrap');if(card&&wrap&&card.parentElement!==wrap)wrap.appendChild(card);})();</script>
        <?php
    }

    private function render_upload_router() {
        ?>
        <script id="jksh-drive-upload-router-v100">
        (()=>{
          if(window.__jkshDriveUploadRouterV100)return;
          window.__jkshDriveUploadRouterV100=true;
          const nativeFetch=window.fetch.bind(window);
          const sessions=new Map();
          const prefix=<?php echo wp_json_encode( self::UPLOAD_PREFIX ); ?>;
          const sleep=ms=>new Promise(r=>setTimeout(r,ms));
          const jsonResponse=(success,data,status=200)=>new Response(JSON.stringify({success,data}),{status,headers:{'Content-Type':'application/json'}});
          window.fetch=async function(input,init){
            const body=init&&init.body;
            if(!(body instanceof FormData))return nativeFetch(input,init);
            const action=String(body.get('action')||'');
            if(action==='jkssb_ui_begin'){
              const resp=await nativeFetch(input,init);
              try{const j=await resp.clone().json();const d=j&&j.success?j.data:null;if(d&&d.direct_transport&&d.storage_target==='google_drive'&&String(d.upload_id||'').startsWith(prefix)){sessions.set(String(d.upload_id),{url:String(d.drive_session_url||''),total:Number(d.total_bytes||body.get('bytes')||0),mime:String(d.mime_type||body.get('mime_type')||'application/octet-stream'),file:null});}}catch(e){}
              return resp;
            }
            const uploadId=String(body.get('upload_id')||'');
            if(!uploadId.startsWith(prefix))return nativeFetch(input,init);
            const s=sessions.get(uploadId);
            if(!s||!s.url)return jsonResponse(false,{message:'Google Drive resumable session is missing. Restart the upload.'},409);
            if(action==='jkssb_ui_chunk'){
              const chunk=body.get('chunk');const offset=Number(body.get('offset')||0);if(!(chunk instanceof Blob))return jsonResponse(false,{message:'Drive upload chunk is missing.'},400);
              const end=offset+chunk.size-1;let lastErr='';
              for(let attempt=1;attempt<=3;attempt++){
                try{
                  const r=await nativeFetch(s.url,{method:'PUT',headers:{'Content-Range':`bytes ${offset}-${end}/${s.total}`,'Content-Type':s.mime},body:chunk,cache:'no-store'});
                  if(r.status===308){return jsonResponse(true,{next_offset:end+1,storage:'google_drive'});}
                  if(r.ok){let meta={};try{meta=await r.json();}catch(e){}s.file=meta;return jsonResponse(true,{next_offset:end+1,storage:'google_drive',drive_file_id:String(meta.id||'')});}
                  lastErr=`Google Drive upload returned HTTP ${r.status}`;if(r.status<500&&r.status!==429)break;
                }catch(e){lastErr=e&&e.message?e.message:'Network error while uploading to Google Drive.';}
                await sleep(attempt*1200);
              }
              return jsonResponse(false,{message:lastErr||'Google Drive chunk upload failed.'},502);
            }
            if(action==='jkssb_ui_finalize'){
              const driveId=s.file&&s.file.id?String(s.file.id):'';if(!driveId)return jsonResponse(false,{message:'Google Drive upload finished without a file ID. Restart the upload.'},409);
              body.set('action','jksh_drive_finalize');body.set('drive_file_id',driveId);
              const resp=await nativeFetch(input,Object.assign({},init,{body}));if(resp.ok)sessions.delete(uploadId);return resp;
            }
            return nativeFetch(input,init);
          };
        })();
        </script>
        <?php
    }
}

add_action( 'plugins_loaded', function() {
    if ( class_exists( '\\JKSH\\Plugin' ) ) JKSH_Google_Drive_Storage_V100::instance();
}, 35 );
