<?php
/**
 * Plugin Name: JKSH Temporary Bridge Exporter
 * Description: Temporary maintenance helper to inspect/export only the JK Social Supabase Bridge plugin.
 * Version: 0.2.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function jksh_temp_bridge_root() {
    return WP_PLUGIN_DIR . '/jk-social-supabase-bridge';
}
function jksh_temp_safe_rel_path( $rel ) {
    $rel = ltrim( str_replace('\\', '/', (string) $rel ), '/' );
    if ( '' === $rel || false !== strpos( $rel, '../' ) ) { return ''; }
    return $rel;
}

add_action( 'rest_api_init', function() {
    register_rest_route( 'jksh-temp/v1', '/bridge-manifest', [
        'methods' => 'GET',
        'permission_callback' => function() { return current_user_can( 'manage_options' ); },
        'callback' => function() {
            $root = jksh_temp_bridge_root();
            if ( ! is_dir( $root ) ) return new WP_Error( 'jksh_bridge_missing', 'Bridge directory not found.', [ 'status' => 404 ] );
            $base_len = strlen( $root ) + 1;
            $items = [];
            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::LEAVES_ONLY);
            foreach ( $it as $file ) {
                if ( ! $file->isFile() ) continue;
                $path = $file->getPathname();
                $rel = str_replace('\\', '/', substr($path, $base_len));
                $items[] = [ 'path' => $rel, 'bytes' => filesize($path), 'sha256' => hash_file('sha256',$path) ];
            }
            return rest_ensure_response([ 'ok'=>true, 'files'=>$items ]);
        },
    ] );
    register_rest_route( 'jksh-temp/v1', '/bridge-file', [
        'methods' => 'GET',
        'permission_callback' => function() { return current_user_can( 'manage_options' ); },
        'callback' => function( WP_REST_Request $request ) {
            $rel = jksh_temp_safe_rel_path( $request->get_param('path') );
            if ( '' === $rel ) return new WP_Error('jksh_bad_path','Invalid path.',[ 'status'=>400 ]);
            $root = realpath(jksh_temp_bridge_root());
            $path = realpath($root . '/' . $rel);
            if ( ! $root || ! $path || 0 !== strpos($path, $root . DIRECTORY_SEPARATOR) || ! is_file($path) ) return new WP_Error('jksh_file_missing','File not found.',[ 'status'=>404 ]);
            $bytes = filesize($path);
            if ( $bytes > 200000 ) return new WP_Error('jksh_file_large','File too large for text inspection.',[ 'status'=>413 ]);
            $content = file_get_contents($path);
            if ( false === $content ) return new WP_Error('jksh_read_failed','Read failed.',[ 'status'=>500 ]);
            return rest_ensure_response([ 'ok'=>true, 'path'=>$rel, 'bytes'=>$bytes, 'sha256'=>hash('sha256',$content), 'content'=>$content ]);
        },
    ] );
} );
