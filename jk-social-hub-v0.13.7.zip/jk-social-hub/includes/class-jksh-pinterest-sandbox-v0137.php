<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Pinterest_Sandbox_V0137 {
    public static function init(): void {
        add_filter( 'pre_http_request', [ __CLASS__, 'route_trial_api' ], 5, 3 );
    }

    public static function route_trial_api( $preempt, array $args, string $url ) {
        if ( false !== $preempt ) {
            return $preempt;
        }
        if ( ! class_exists( 'JKSH_Pinterest_Connector' ) ) {
            return $preempt;
        }
        if ( 0 !== strpos( $url, 'https://api.pinterest.com/' ) ) {
            return $preempt;
        }

        $readiness = JKSH_Pinterest_Connector::instance()->readiness();
        if ( empty( $readiness['configured'] ) || empty( $readiness['api_access_confirmed'] ) ) {
            return $preempt;
        }

        $method = strtoupper( (string) ( $args['method'] ?? 'GET' ) );
        if ( ! in_array( $method, [ 'POST', 'PUT', 'PATCH', 'DELETE' ], true ) ) {
            return $preempt;
        }

        $sandbox_url = preg_replace(
            '#^https://api\\.pinterest\\.com/#',
            'https://api-sandbox.pinterest.com/',
            $url,
            1
        );
        if ( ! is_string( $sandbox_url ) || $sandbox_url === $url ) {
            return $preempt;
        }

        remove_filter( 'pre_http_request', [ __CLASS__, 'route_trial_api' ], 5 );
        try {
            return wp_remote_request( $sandbox_url, $args );
        } finally {
            add_filter( 'pre_http_request', [ __CLASS__, 'route_trial_api' ], 5, 3 );
        }
    }
}

JKSH_Pinterest_Sandbox_V0137::init();
