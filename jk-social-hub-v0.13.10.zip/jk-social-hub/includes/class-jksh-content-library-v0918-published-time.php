<?php
// JKSH_V0923_MEDIA_CONTROL_LOADER
require_once __DIR__ . '/class-jksh-content-library-v0923-media-control.php';
if (!defined('ABSPATH')) { exit; }

final class JKSH_Content_Library_V0918_Published_Time {
    const VERSION = '0.9.2.1';
    private static $instance = null;

    public static function instance() {
        if (!self::$instance) { self::$instance = new self(); }
        return self::$instance;
    }

    private function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
        add_action('admin_footer', [$this, 'inject_ui']);
    }

    public function can_manage() {
        return current_user_can('manage_options');
    }

    private function tables() {
        global $wpdb;
        return [
            'jobs' => $wpdb->prefix . 'jksh_jobs',
            'logs' => $wpdb->prefix . 'jksh_publish_logs',
        ];
    }

    private function format_ist($utc) {
        if (!$utc) { return ''; }
        try {
            $dt = new DateTime($utc, new DateTimeZone('UTC'));
            $dt->setTimezone(new DateTimeZone('Asia/Kolkata'));
            return $dt->format('j M Y, g:i:s A') . ' IST';
        } catch (Throwable $e) {
            return '';
        }
    }

    private function build_map() {
        global $wpdb;
        $t = $this->tables();
        $map = [];

        $rows = $wpdb->get_results(
            "SELECT content_id, MAX(created_at) AS published_at
             FROM {$t['logs']}
             WHERE content_id > 0 AND action='publish' AND result='success'
             GROUP BY content_id",
            ARRAY_A
        );

        foreach ((array)$rows as $row) {
            $cid = (int)($row['content_id'] ?? 0);
            $utc = (string)($row['published_at'] ?? '');
            if ($cid > 0 && $utc) {
                $map[$cid] = [
                    'content_id' => $cid,
                    'source' => 'publish_log',
                    'published_at_utc' => $utc,
                    'published_at_ist' => $this->format_ist($utc),
                ];
            }
        }

        $rows = $wpdb->get_results(
            "SELECT content_id, MAX(completed_at) AS published_at
             FROM {$t['jobs']}
             WHERE content_id > 0 AND status='published' AND completed_at IS NOT NULL
             GROUP BY content_id",
            ARRAY_A
        );

        foreach ((array)$rows as $row) {
            $cid = (int)($row['content_id'] ?? 0);
            $utc = (string)($row['published_at'] ?? '');
            if ($cid > 0 && $utc && empty($map[$cid])) {
                $map[$cid] = [
                    'content_id' => $cid,
                    'source' => 'job_completed_at',
                    'published_at_utc' => $utc,
                    'published_at_ist' => $this->format_ist($utc),
                ];
            }
        }

        return $map;
    }

    public function register_routes() {
        register_rest_route('jksh/v1', '/content-library-published-time-map', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_map'],
            'permission_callback' => [$this, 'can_manage'],
        ]);

        register_rest_route('jksh/v1', '/maintenance/content-library-published-time-status', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_status'],
            'permission_callback' => [$this, 'can_manage'],
        ]);
    }

    public function rest_map() {
        return rest_ensure_response([
            'ok' => true,
            'patch' => self::VERSION,
            'timezone' => 'Asia/Kolkata',
            'items' => $this->build_map(),
        ]);
    }

    public function rest_status() {
        $map = $this->build_map();
        return rest_ensure_response([
            'ok' => true,
            'patch' => self::VERSION,
            'timezone' => 'Asia/Kolkata',
            'published_time_count' => count($map),
            'content_37' => $map[37] ?? null,
            'content_32' => $map[32] ?? null,
            'content_24' => $map[24] ?? null,
        ]);
    }

    public function inject_ui() {
        if (!isset($_GET['page']) || $_GET['page'] !== 'jksh-content') { return; }
        $nonce = wp_create_nonce('wp_rest');
        ?>
<style>
.jksh-published-time{
    margin-top:7px;
    font-size:11px;
    line-height:1.35;
    font-weight:700;
    color:#067647;
    white-space:normal;
}
</style>
<script>
(() => {
    const nonce = <?php echo wp_json_encode($nonce); ?>;

    const contentIdFromRow = row => {
        const text = row.innerText || '';
        let m = text.match(/Content\s*#?\s*(\d+)/i);
        if (!m) m = text.match(/Content\s*ID\s*#?\s*(\d+)/i);
        return m ? Number(m[1]) : 0;
    };

    const load = async () => {
        try {
            const r = await fetch('/wp-json/jksh/v1/content-library-published-time-map', {
                headers: {'X-WP-Nonce': nonce}
            });
            const d = await r.json();
            if (!d || !d.ok || !d.items) return;

            document.querySelectorAll('table.jksh-content-table tbody tr').forEach(row => {
                const cells = Array.from(row.querySelectorAll('td'));
                if (cells.length < 2) return;

                const workflowCell = cells[1];
                const workflowText = (workflowCell.innerText || '').trim();
                if (!/^Published$/i.test(workflowText)) return;

                const id = contentIdFromRow(row);
                if (!id || !d.items[id]) return;

                const value = d.items[id].published_at_ist || '';
                if (!value || workflowCell.querySelector('.jksh-published-time')) return;

                const meta = document.createElement('div');
                meta.className = 'jksh-published-time';
                meta.textContent = '✅ ' + value;
                workflowCell.appendChild(meta);
            });

            const state = (document.querySelector('.jksh-head-meta .badge')?.innerText || '').trim();
            if (/^Published$/i.test(state)) {
                const m = (document.body.innerText || '').match(/Content\s*ID\s*(\d+)/i);
                const id = m ? Number(m[1]) : 0;
                if (id && d.items[id]) {
                    document.querySelectorAll('.jksh-editor-summary > div').forEach(box => {
                        const label = box.querySelector('span');
                        const value = box.querySelector('strong');
                        if (label && value && /next\s+schedule/i.test(label.textContent || '')) {
                            label.textContent = 'Published time';
                            value.textContent = d.items[id].published_at_ist;
                        }
                    });
                }
            }
        } catch (e) {}
    };

    load();
})();
</script>
        <?php
    }
}

JKSH_Content_Library_V0918_Published_Time::instance();
