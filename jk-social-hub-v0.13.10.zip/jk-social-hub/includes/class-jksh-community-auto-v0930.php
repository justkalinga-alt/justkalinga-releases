<?php
if (!defined('ABSPATH')) { exit; }

final class JKSH_Community_Auto_V0930 {
    const VERSION = '0.9.3.4';
    const CRON_HOOK = 'jksh_community_auto_tick_v0930';
    const RETRY_OPTION = 'jksh_community_auto_retry_v0930';
    const RECEIPT_OPTION = 'jksh_community_auto_receipts_v0930';
    const LAST_RUN_OPTION = 'jksh_community_auto_last_run_v0930';
    const PULL_TOKEN_ENC_OPTION = 'jksh_community_pull_token_enc_v0931';
    const PULL_TOKEN_HASH_OPTION = 'jksh_community_pull_token_hash_v0931';
    const LEASE_OPTION = 'jksh_community_pull_leases_v0931';
    const REPOST_OPTION = 'jksh_community_repost_generation_v0934';
    private static $instance = null;

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        if (null === get_option('jksh_community_auto_enabled', null)) {
            add_option('jksh_community_auto_enabled', 1, '', false);
        }
        add_filter('cron_schedules', [$this, 'cron_schedules']);
        add_action('init', [$this, 'ensure_cron']);
        add_action(self::CRON_HOOK, [$this, 'tick']);
        add_action('rest_api_init', [$this, 'routes']);
    }

    public function cron_schedules($schedules) {
        if (!isset($schedules['jksh_community_every_minute'])) {
            $schedules['jksh_community_every_minute'] = [
                'interval' => 60,
                'display' => 'JKSH Community every minute',
            ];
        }
        return $schedules;
    }

    public function ensure_cron() {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 60, 'jksh_community_every_minute', self::CRON_HOOK);
        }
    }

    public function can_manage() {
        return current_user_can('manage_options') || current_user_can('jksh_publish');
    }

    private function tables() {
        global $wpdb;
        return [
            'jobs' => $wpdb->prefix . 'jksh_jobs',
            'content' => $wpdb->prefix . 'jksh_content',
        ];
    }

    private function push_worker_health() {
        $health = (new \JKSH\Services\LiveWorkerClient())->health();
        $data = is_array($health['data'] ?? null) ? $health['data'] : [];
        $cap = is_array($data['community_publish'] ?? null) ? $data['community_publish'] : [];
        return [
            'ok' => !empty($health['ok']),
            'status' => (int)($health['status'] ?? 0),
            'message' => sanitize_textarea_field((string)($health['message'] ?? '')),
            'community_publish_available' => !empty($cap['available']),
            'community_publish' => $cap,
        ];
    }

    private function due_job_ids($limit = 5) {
        global $wpdb;
        $t = $this->tables();
        $now = current_time('mysql', true);
        $sql = $wpdb->prepare(
            "SELECT id FROM {$t['jobs']}
             WHERE platform='youtube'
               AND job_type='community_handoff'
               AND status='community_ready'
               AND scheduled_at IS NOT NULL
               AND scheduled_at<=%s
             ORDER BY scheduled_at ASC, id ASC
             LIMIT %d",
            $now,
            max(1, min(20, (int)$limit))
        );
        return array_map('intval', (array)$wpdb->get_col($sql));
    }

    private function retry_map() {
        $map = get_option(self::RETRY_OPTION, []);
        return is_array($map) ? $map : [];
    }

    private function save_retry_map($map) {
        update_option(self::RETRY_OPTION, is_array($map) ? $map : [], false);
    }

    private function retry_blocked($job_id) {
        $map = $this->retry_map();
        return !empty($map[$job_id]['retry_at']) && (int)$map[$job_id]['retry_at'] > time();
    }

    private function set_retry($job_id, $status, $message, $safe_fast = false) {
        $map = $this->retry_map();
        $failures = max(0, (int)($map[$job_id]['failures'] ?? 0)) + 1;
        $minutes = $safe_fast ? 1 : ($failures <= 1 ? 5 : ($failures === 2 ? 15 : 30));
        $map[$job_id] = [
            'failures' => $failures,
            'retry_at' => time() + ($minutes * 60),
            'last_status' => (int)$status,
            'last_message' => sanitize_textarea_field((string)$message),
            'safe_fast_retry' => (bool)$safe_fast,
            'updated_at_utc' => gmdate('c'),
        ];
        $this->save_retry_map($map);
        $this->release_lease((int)$job_id);
        return $minutes;
    }

    private function clear_retry($job_id) {
        $map = $this->retry_map();
        unset($map[$job_id]);
        $this->save_retry_map($map);
    }

    private function receipt_tokens() {
        $map = get_option(self::RECEIPT_OPTION, []);
        return is_array($map) ? $map : [];
    }

    private function issue_receipt_token($job_id, $idempotency_key) {
        $plain = wp_generate_password(48, false, false);
        $map = $this->receipt_tokens();
        $map[$job_id] = [
            'token_hash' => hash('sha256', $plain),
            'idempotency_key' => $idempotency_key,
            'expires_at' => time() + DAY_IN_SECONDS,
            'created_at_utc' => gmdate('c'),
        ];
        update_option(self::RECEIPT_OPTION, $map, false);
        return $plain;
    }

    private function verify_receipt_token($job_id, $idempotency_key, $token) {
        $map = $this->receipt_tokens();
        $row = is_array($map[$job_id] ?? null) ? $map[$job_id] : [];
        if (!$row || (int)($row['expires_at'] ?? 0) < time()) return false;
        if (!hash_equals((string)($row['idempotency_key'] ?? ''), (string)$idempotency_key)) return false;
        return hash_equals((string)($row['token_hash'] ?? ''), hash('sha256', (string)$token));
    }

    private function clear_receipt_token($job_id) {
        $map = $this->receipt_tokens();
        unset($map[$job_id]);
        update_option(self::RECEIPT_OPTION, $map, false);
    }

    private function ensure_pull_token() {
        $crypto = new \JKSH\Security\Crypto();
        $enc = (string)get_option(self::PULL_TOKEN_ENC_OPTION, '');
        $plain = $enc ? $crypto->decrypt($enc) : '';
        if ($plain) return $plain;
        $plain = 'jkcp_' . wp_generate_password(64, false, false);
        update_option(self::PULL_TOKEN_ENC_OPTION, $crypto->encrypt($plain), false);
        update_option(self::PULL_TOKEN_HASH_OPTION, hash('sha256', $plain), false);
        return $plain;
    }

    private function pull_token_configured() {
        return '' !== (string)get_option(self::PULL_TOKEN_HASH_OPTION, '');
    }

    private function verify_pull_token($token) {
        $expected = (string)get_option(self::PULL_TOKEN_HASH_OPTION, '');
        if (!$expected || !$token) return false;
        return hash_equals($expected, hash('sha256', (string)$token));
    }

    private function request_worker_token($req) {
        $token = sanitize_text_field((string)$req->get_header('x-jksh-worker-token'));
        if ($token) return $token;
        $auth = trim((string)$req->get_header('authorization'));
        if (preg_match('/^Bearer\s+(.+)$/i', $auth, $m)) return trim($m[1]);
        return '';
    }

    private function lease_map() {
        $map = get_option(self::LEASE_OPTION, []);
        if (!is_array($map)) $map = [];
        $now = time();
        foreach ($map as $job_id => $row) {
            if ((int)($row['expires_at'] ?? 0) <= $now) unset($map[$job_id]);
        }
        update_option(self::LEASE_OPTION, $map, false);
        return $map;
    }

    private function save_lease_map($map) {
        update_option(self::LEASE_OPTION, is_array($map) ? $map : [], false);
    }

    private function release_lease($job_id) {
        $map = $this->lease_map();
        unset($map[$job_id]);
        $this->save_lease_map($map);
    }

    private function repost_generations() {
        $map = get_option(self::REPOST_OPTION, []);
        return is_array($map) ? $map : [];
    }

    private function repost_generation($job_id) {
        $map = $this->repost_generations();
        return max(0, (int)($map[(int)$job_id] ?? 0));
    }

    private function bump_repost_generation($job_id) {
        $map = $this->repost_generations();
        $job_id = (int)$job_id;
        $next = max(0, (int)($map[$job_id] ?? 0)) + 1;
        $map[$job_id] = $next;
        update_option(self::REPOST_OPTION, $map, false);
        return $next;
    }

    private function job_idempotency_key($job_id) {
        $job_id = (int)$job_id;
        $generation = $this->repost_generation($job_id);
        return 'jksh-community-' . $job_id . ($generation > 0 ? '-r' . $generation : '');
    }

    private function is_youtube_post_url($url) {
        $url = esc_url_raw((string)$url);
        if (!$url || !wp_http_validate_url($url)) return false;
        $host = strtolower((string)wp_parse_url($url, PHP_URL_HOST));
        $path = (string)wp_parse_url($url, PHP_URL_PATH);
        return in_array($host, ['youtube.com','www.youtube.com','m.youtube.com'], true)
            && str_starts_with($path, '/post/');
    }

    private function content_can_finish($content_id, $exclude_job_id) {
        global $wpdb;
        $t = $this->tables();
        $count = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$t['jobs']}
             WHERE content_id=%d AND id<>%d
               AND status NOT IN ('published','published_manual','cancelled')",
            (int)$content_id,
            (int)$exclude_job_id
        ));
        return $count === 0;
    }

    private function sync_published_variant($job, $external_url, $published_at_utc = '') {
        $variants = new \JKSH\Repositories\VariantRepository();
        $variant = $variants->get((int)$job->variant_id);
        if (!$variant) return;

        $fields = json_decode((string)$variant->fields_json, true);
        $fields = is_array($fields) ? $fields : [];
        $fields['community_handoff'] = true;
        $fields['manual_required'] = false;
        $fields['auto_published'] = true;
        $fields['auto_publish_pending'] = false;
        $fields['publish_mode'] = 'browser_worker_auto';
        $fields['target_surface'] = 'youtube_published_posts';
        $fields['worker_verified'] = true;
        $fields['youtube_post_url'] = esc_url_raw((string)$external_url);
        $fields['external_url'] = esc_url_raw((string)$external_url);
        $fields['published_at_utc'] = $published_at_utc ?: current_time('mysql', true);
        $fields['note'] = 'Published by the authenticated JK browser worker to the normal YouTube Posts surface and verified with a public YouTube post URL.';

        $variants->update_status(
            (int)$job->variant_id,
            'published',
            ['external_url' => esc_url_raw((string)$external_url)]
        );
        $variants->update_fields((int)$job->variant_id, [
            'status' => 'published',
            'fields_json' => wp_json_encode($fields),
        ]);
    }

    private function finalize($job_id, $external_url, $context = []) {
        $external_url = esc_url_raw((string)$external_url);
        if (!$this->is_youtube_post_url($external_url)) {
            return new \WP_Error('jksh_community_receipt_url', 'Worker receipt did not include a valid public YouTube Community post URL.');
        }

        $jobs = new \JKSH\Repositories\JobRepository();
        $job = $jobs->get((int)$job_id);
        if (!$job || 'youtube' !== sanitize_key((string)$job->platform) || 'community_handoff' !== sanitize_key((string)$job->job_type)) {
            return new \WP_Error('jksh_community_job_not_found', 'Community handoff job was not found.');
        }
        if (in_array((string)$job->status, ['published','published_manual'], true)) {
            $this->sync_published_variant(
                $job,
                $external_url,
                (string)($job->completed_at ?: current_time('mysql', true))
            );
            (new \JKSH\Repositories\ContentRepository())->update_status((int)$job->content_id, 'published');
            $this->release_lease((int)$job_id);
            return [
                'ok' => true,
                'already_published' => true,
                'reconciled' => true,
                'job_id' => (int)$job_id,
                'external_url' => $external_url,
            ];
        }

        $now = current_time('mysql', true);
        $response = array_merge([
            'publish_mode' => 'browser_worker_auto',
            'manual_required' => false,
            'external_url' => $external_url,
            'completed_at_utc' => $now,
            'idempotency_key' => $this->job_idempotency_key((int)$job_id),
            'worker_verified' => true,
        ], is_array($context) ? $context : []);

        $jobs->update((int)$job_id, [
            'status' => 'published',
            'last_error' => '',
            'last_response_json' => wp_json_encode($response),
            'completed_at' => $now,
        ]);

        $this->sync_published_variant($job, $external_url, $now);

        if ($this->content_can_finish((int)$job->content_id, (int)$job_id)) {
            (new \JKSH\Repositories\ContentRepository())->update_status((int)$job->content_id, 'published');
        }

        (new \JKSH\Repositories\LogRepository())->add([
            'job_id' => (int)$job_id,
            'content_id' => (int)$job->content_id,
            'variant_id' => (int)$job->variant_id,
            'action' => 'community_auto_published',
            'result' => 'success',
            'external_url' => $external_url,
            'message' => 'YouTube public creator post published by the authenticated browser worker and verified by public receipt URL.',
            'context' => [
                'publish_mode' => 'browser_worker_auto',
                'manual_required' => false,
                'idempotency_key' => $this->job_idempotency_key((int)$job_id),
                'patch' => self::VERSION,
            ],
        ]);

        $this->clear_retry((int)$job_id);
        $this->clear_receipt_token((int)$job_id);
        $this->release_lease((int)$job_id);

        return [
            'ok' => true,
            'job_id' => (int)$job_id,
            'content_id' => (int)$job->content_id,
            'variant_id' => (int)$job->variant_id,
            'status' => 'published',
            'external_url' => $external_url,
            'completed_at_utc' => $now,
        ];
    }

    private function mark_attention($job_id, $reason, $context = []) {
        $jobs = new \JKSH\Repositories\JobRepository();
        $job = $jobs->get((int)$job_id);
        if (!$job) return new \WP_Error('jksh_community_job_not_found', 'Community handoff job was not found.');
        $now = current_time('mysql', true);
        $reason = sanitize_textarea_field((string)$reason);
        $jobs->update((int)$job_id, [
            'status' => 'needs_attention',
            'last_error' => $reason,
            'last_response_json' => wp_json_encode(array_merge([
                'publish_mode' => 'browser_worker_auto',
                'uncertain_publication_state' => true,
                'completed_at_utc' => $now,
            ], is_array($context) ? $context : [])),
            'completed_at' => $now,
        ]);
        (new \JKSH\Repositories\VariantRepository())->update_status((int)$job->variant_id, 'needs_attention');
        (new \JKSH\Repositories\ContentRepository())->update_status((int)$job->content_id, 'needs_attention');
        (new \JKSH\Repositories\LogRepository())->add([
            'job_id' => (int)$job_id,
            'content_id' => (int)$job->content_id,
            'variant_id' => (int)$job->variant_id,
            'action' => 'community_auto_attention',
            'result' => 'failed',
            'message' => $reason,
            'context' => array_merge(['patch'=>self::VERSION], is_array($context) ? $context : []),
        ]);
        $this->clear_receipt_token((int)$job_id);
        $this->release_lease((int)$job_id);
        return ['ok'=>true,'job_id'=>(int)$job_id,'status'=>'needs_attention','message'=>$reason];
    }

    private function worker_payload($job_id) {
        $handoff = new \JKSH\Services\YouTubeCommunityHandoff();
        $payload = $handoff->payload_for_job((int)$job_id);
        if (is_wp_error($payload)) return $payload;

        $idempotency = $this->job_idempotency_key((int)$job_id);
        $token = $this->issue_receipt_token((int)$job_id, $idempotency);
        $payload['stop_before_publish'] = false;
        $payload['auto_publish'] = true;
        $payload['publish_mode'] = 'browser_worker_auto';
        $payload['worker_job_id'] = $idempotency;
        $payload['idempotency_key'] = $idempotency;
        $payload['receipt_callback_url'] = rest_url('jksh/v1/community-worker/receipt');
        $payload['receipt_callback_token'] = $token;
        $payload['receipt_contract'] = 'jksh-community-receipt-v1';
        return $payload;
    }

    private function dispatch_job($job_id) {
        if ($this->retry_blocked($job_id)) {
            return ['ok' => true, 'job_id' => $job_id, 'status' => 'retry_wait'];
        }
        $payload = $this->worker_payload((int)$job_id);
        if (is_wp_error($payload)) return $payload;

        $result = (new \JKSH\Services\LiveWorkerClient())->community_publish($payload);
        if (empty($result['ok'])) {
            $mins = $this->set_retry(
                (int)$job_id,
                (int)($result['status'] ?? 0),
                (string)($result['message'] ?? 'Community worker request failed.')
            );
            (new \JKSH\Repositories\LogRepository())->add([
                'job_id' => (int)$job_id,
                'action' => 'community_auto_dispatch',
                'result' => 'failed',
                'message' => 'Community browser-worker publish dispatch failed; retry scheduled.',
                'context' => [
                    'worker_status' => (int)($result['status'] ?? 0),
                    'retry_minutes' => $mins,
                    'patch' => self::VERSION,
                ],
            ]);
            return [
                'ok' => false,
                'job_id' => (int)$job_id,
                'status' => 'retry_scheduled',
                'retry_minutes' => $mins,
                'worker_status' => (int)($result['status'] ?? 0),
                'message' => sanitize_textarea_field((string)($result['message'] ?? 'Worker request failed.')),
            ];
        }

        $data = is_array($result['data'] ?? null) ? $result['data'] : [];
        $url = esc_url_raw((string)($data['external_url'] ?? $data['post_url'] ?? ''));
        if ($url && $this->is_youtube_post_url($url)) {
            return $this->finalize((int)$job_id, $url, [
                'worker_status' => (int)($result['status'] ?? 200),
                'receipt_source' => 'synchronous_worker_response',
            ]);
        }

        $this->set_retry((int)$job_id, (int)($result['status'] ?? 200), 'Worker accepted publish; awaiting callback receipt.');
        return [
            'ok' => true,
            'job_id' => (int)$job_id,
            'status' => 'awaiting_receipt',
            'worker_status' => (int)($result['status'] ?? 200),
        ];
    }

    public function claim_pull_job($worker_id) {
        $worker_id = sanitize_text_field((string)$worker_id);
        if (!$worker_id) $worker_id = 'jk-community-worker';

        $due = $this->due_job_ids(20);
        if (!$due) {
            return ['ok'=>true,'has_job'=>false,'poll_after_seconds'=>20,'patch'=>self::VERSION];
        }

        $job_id = (int)$due[0];
        if ($this->retry_blocked($job_id)) {
            return [
                'ok'=>true,
                'has_job'=>false,
                'poll_after_seconds'=>20,
                'blocked_job_id'=>$job_id,
                'reason'=>'oldest_job_retry_wait',
                'patch'=>self::VERSION,
            ];
        }

        $leases = $this->lease_map();
        if (!empty($leases[$job_id]) && (int)($leases[$job_id]['expires_at'] ?? 0) > time()) {
            return [
                'ok'=>true,
                'has_job'=>false,
                'poll_after_seconds'=>20,
                'blocked_job_id'=>$job_id,
                'reason'=>'oldest_job_leased',
                'patch'=>self::VERSION,
            ];
        }

        $payload = $this->worker_payload($job_id);
        if (is_wp_error($payload)) {
            return [
                'ok'=>true,
                'has_job'=>false,
                'poll_after_seconds'=>20,
                'blocked_job_id'=>$job_id,
                'reason'=>'oldest_job_payload_error',
                'message'=>$payload->get_error_message(),
                'patch'=>self::VERSION,
            ];
        }

        $leases[$job_id] = [
            'worker_id' => $worker_id,
            'claimed_at' => time(),
            'expires_at' => time() + 180,
            'idempotency_key' => (string)$payload['idempotency_key'],
        ];
        $this->save_lease_map($leases);
        $payload['lease_expires_at_utc'] = gmdate('c', time() + 180);
        $payload['poll_worker_id'] = $worker_id;
        return ['ok'=>true,'has_job'=>true,'job'=>$payload,'patch'=>self::VERSION];
    }

    public function tick($force = false) {
        $enabled = (bool)get_option('jksh_community_auto_enabled', 1);
        if (!$enabled) {
            $out = ['ok'=>true,'status'=>'disabled','processed'=>[],'patch'=>self::VERSION];
            update_option(self::LAST_RUN_OPTION, array_merge($out,['at_utc'=>gmdate('c')]), false);
            return $out;
        }

        $health = $this->push_worker_health();
        $due = $this->due_job_ids(10);
        if (empty($health['ok']) || empty($health['community_publish_available'])) {
            $out = [
                'ok' => true,
                'status' => 'armed_pull_worker',
                'push_worker' => $health,
                'pull_worker_ready' => $this->pull_token_configured(),
                'due_job_ids' => $due,
                'processed' => [],
                'patch' => self::VERSION,
            ];
            update_option(self::LAST_RUN_OPTION, array_merge($out,['at_utc'=>gmdate('c')]), false);
            return $out;
        }

        $processed = [];
        foreach ($due as $job_id) {
            $r = $this->dispatch_job($job_id);
            $processed[] = is_wp_error($r)
                ? ['ok'=>false,'job_id'=>$job_id,'error'=>$r->get_error_message()]
                : $r;
        }

        $out = [
            'ok' => true,
            'status' => 'push_worker_ready',
            'push_worker' => $health,
            'pull_worker_ready' => $this->pull_token_configured(),
            'due_job_ids' => $due,
            'processed' => $processed,
            'patch' => self::VERSION,
        ];
        update_option(self::LAST_RUN_OPTION, array_merge($out,['at_utc'=>gmdate('c')]), false);
        return $out;
    }

    public function status() {
        $this->ensure_pull_token();
        $last = get_option(self::LAST_RUN_OPTION, []);
        if (!is_array($last)) $last = [];
        $retry = $this->retry_map();
        $next = wp_next_scheduled(self::CRON_HOOK);
        $leases = $this->lease_map();
        return [
            'ok' => true,
            'patch' => self::VERSION,
            'enabled' => (bool)get_option('jksh_community_auto_enabled', 1),
            'cron_hook' => self::CRON_HOOK,
            'next_tick_utc' => $next ? gmdate('c', $next) : '',
            'push_worker' => $this->push_worker_health(),
            'pull_worker' => [
                'configured' => $this->pull_token_configured(),
                'pull_url' => rest_url('jksh/v1/community-worker/pull'),
                'receipt_url' => rest_url('jksh/v1/community-worker/receipt'),
                'poll_seconds' => 20,
                'active_leases' => count($leases),
                'inbound_tunnel_required' => false,
            ],
            'due_job_ids' => $this->due_job_ids(20),
            'retry_state' => $retry,
            'last_run' => $last,
            'receipt_contract' => 'jksh-community-receipt-v1',
            'publish_requires_public_post_url' => true,
            'youtube_api_used_for_community_creation' => false,
        ];
    }

    public function routes() {
        register_rest_route('jksh/v1', '/maintenance/community-auto-status', [
            'methods' => 'GET',
            'callback' => fn() => rest_ensure_response($this->status()),
            'permission_callback' => [$this, 'can_manage'],
        ]);

        register_rest_route('jksh/v1', '/maintenance/community-auto-run', [
            'methods' => 'POST',
            'callback' => function($req) {
                if (!$req->get_param('confirm')) {
                    return new \WP_Error('jksh_confirm_required','confirm=true is required.',['status'=>400]);
                }
                return rest_ensure_response($this->tick(true));
            },
            'permission_callback' => [$this, 'can_manage'],
        ]);

        register_rest_route('jksh/v1', '/maintenance/community-auto-clear-retry', [
            'methods' => 'POST',
            'callback' => function($req) {
                if (!$req->get_param('confirm')) {
                    return new \WP_Error('jksh_confirm_required','confirm=true is required.',['status'=>400]);
                }
                $job_id = absint($req->get_param('job_id'));
                if (!$job_id) {
                    return new \WP_Error('jksh_job_required','job_id is required.',['status'=>400]);
                }
                $this->clear_retry($job_id);
                $this->clear_receipt_token($job_id);
                $this->release_lease($job_id);
                return rest_ensure_response([
                    'ok' => true,
                    'job_id' => $job_id,
                    'retry_cleared' => true,
                    'patch' => self::VERSION,
                ]);
            },
            'permission_callback' => [$this, 'can_manage'],
        ]);

        register_rest_route('jksh/v1', '/maintenance/community-requeue-deleted-post', [
            'methods' => 'POST',
            'callback' => function($req) {
                if (!$req->get_param('confirm') || !$req->get_param('deleted_external_post_confirmed')) {
                    return new \WP_Error(
                        'jksh_requeue_confirmation_required',
                        'confirm=true and deleted_external_post_confirmed=true are required.',
                        ['status'=>400]
                    );
                }

                $job_id = absint($req->get_param('job_id'));
                if (!$job_id) {
                    return new \WP_Error('jksh_job_required','job_id is required.',['status'=>400]);
                }

                $jobs = new \JKSH\Repositories\JobRepository();
                $job = $jobs->get($job_id);
                if (!$job || 'youtube' !== sanitize_key((string)$job->platform) || 'community_handoff' !== sanitize_key((string)$job->job_type)) {
                    return new \WP_Error('jksh_community_job_not_found','Community handoff job was not found.',['status'=>404]);
                }

                if (!in_array((string)$job->status, ['published','published_manual','needs_attention'], true)) {
                    return new \WP_Error(
                        'jksh_requeue_state_invalid',
                        'Only a previously published or attention-state Community job can be requeued through this recovery endpoint.',
                        ['status'=>409]
                    );
                }

                $prior_response = json_decode((string)$job->last_response_json, true);
                $prior_response = is_array($prior_response) ? $prior_response : [];
                $generation = $this->bump_repost_generation($job_id);
                $idempotency = $this->job_idempotency_key($job_id);

                $jobs->update($job_id, [
                    'status' => 'community_ready',
                    'last_error' => '',
                    'last_response_json' => wp_json_encode([
                        'requeue_reason' => 'deleted_wrong_surface_post',
                        'repost_generation' => $generation,
                        'new_idempotency_key' => $idempotency,
                        'prior_response' => $prior_response,
                        'requeued_at_utc' => current_time('mysql', true),
                    ]),
                    'started_at' => null,
                    'completed_at' => null,
                ]);

                $variants = new \JKSH\Repositories\VariantRepository();
                $variant = $variants->get((int)$job->variant_id);
                if ($variant) {
                    $fields = json_decode((string)$variant->fields_json, true);
                    $fields = is_array($fields) ? $fields : [];
                    $media = json_decode((string)$variant->media_json, true);
                    $media = is_array($media) ? $media : [];

                    unset(
                        $fields['youtube_post_url'],
                        $fields['external_url'],
                        $fields['published_at_utc']
                    );

                    $fields['community_handoff'] = true;
                    $fields['manual_required'] = false;
                    $fields['auto_published'] = false;
                    $fields['auto_publish_pending'] = true;
                    $fields['publish_mode'] = 'browser_worker_auto';
                    $fields['target_surface'] = 'youtube_published_posts';
                    $fields['expected_media_count'] = count($media);
                    $fields['repost_generation'] = $generation;
                    $fields['note'] = 'Requeued after the prior Community-only test post was deleted. The corrected worker must publish to the normal YouTube Posts surface and verify the full media count.';

                    $variants->update_status((int)$job->variant_id, 'community_ready', ['external_url'=>'']);
                    $variants->update_fields((int)$job->variant_id, [
                        'status' => 'community_ready',
                        'fields_json' => wp_json_encode($fields),
                    ]);
                }

                (new \JKSH\Repositories\ContentRepository())->update_status((int)$job->content_id, 'community_ready');

                $this->clear_retry($job_id);
                $this->clear_receipt_token($job_id);
                $this->release_lease($job_id);

                (new \JKSH\Repositories\LogRepository())->add([
                    'job_id' => $job_id,
                    'content_id' => (int)$job->content_id,
                    'variant_id' => (int)$job->variant_id,
                    'action' => 'community_repost_requeued',
                    'result' => 'success',
                    'message' => 'Deleted wrong-surface YouTube test post requeued for corrected normal Posts publishing.',
                    'context' => [
                        'repost_generation' => $generation,
                        'idempotency_key' => $idempotency,
                        'target_surface' => 'youtube_published_posts',
                        'patch' => self::VERSION,
                    ],
                ]);

                return rest_ensure_response([
                    'ok' => true,
                    'job_id' => $job_id,
                    'status' => 'community_ready',
                    'repost_generation' => $generation,
                    'idempotency_key' => $idempotency,
                    'target_surface' => 'youtube_published_posts',
                    'patch' => self::VERSION,
                ]);
            },
            'permission_callback' => [$this, 'can_manage'],
        ]);

        register_rest_route('jksh/v1', '/maintenance/community-pull-pairing', [
            'methods' => 'GET',
            'callback' => function() {
                return rest_ensure_response([
                    'ok' => true,
                    'patch' => self::VERSION,
                    'hub_url' => home_url('/'),
                    'pull_url' => rest_url('jksh/v1/community-worker/pull'),
                    'receipt_url' => rest_url('jksh/v1/community-worker/receipt'),
                    'worker_token' => $this->ensure_pull_token(),
                    'poll_seconds' => 20,
                    'profile_hint' => 'D:\\Dev\\JKSocialHub\\jk-youtube-community-mcp\\.youtube-profile',
                    'inbound_tunnel_required' => false,
                ]);
            },
            'permission_callback' => [$this, 'can_manage'],
        ]);

        register_rest_route('jksh/v1', '/community-worker/pull', [
            'methods' => 'POST',
            'callback' => function($req) {
                $token = $this->request_worker_token($req);
                if (!$this->verify_pull_token($token)) {
                    return new \WP_Error('jksh_community_worker_auth','Invalid Community worker token.',['status'=>403]);
                }
                return rest_ensure_response($this->claim_pull_job((string)$req->get_param('worker_id')));
            },
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('jksh/v1', '/community-worker/receipt', [
            'methods' => 'POST',
            'callback' => [$this, 'receipt'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function receipt($req) {
        $job_id = absint($req->get_param('job_id'));
        $key = sanitize_text_field((string)$req->get_param('idempotency_key'));
        $token = sanitize_text_field((string)$req->get_param('token'));
        $status = sanitize_key((string)$req->get_param('status'));
        if (!$job_id || !$key || !$token || !$this->verify_receipt_token($job_id, $key, $token)) {
            return new \WP_Error('jksh_community_receipt_auth','Invalid or expired Community worker receipt token.',['status'=>403]);
        }

        if ('published' === $status) {
            return rest_ensure_response($this->finalize(
                $job_id,
                (string)$req->get_param('external_url'),
                [
                    'receipt_source' => 'worker_callback',
                    'worker_completed_at' => sanitize_text_field((string)$req->get_param('completed_at')),
                ]
            ));
        }

        $reason = sanitize_textarea_field((string)$req->get_param('error'));
        if ('uncertain' === $status || !$req->get_param('safe_to_retry')) {
            return rest_ensure_response($this->mark_attention(
                $job_id,
                $reason ?: 'Worker may have clicked Post but could not verify the public Community URL. Automatic retry is blocked to prevent duplicates.',
                ['receipt_status'=>$status,'safe_to_retry'=>false]
            ));
        }

        $mins = $this->set_retry($job_id, 0, $reason ?: 'Community worker reported a safe retryable failure.', true);
        $this->clear_receipt_token($job_id);
        return rest_ensure_response([
            'ok' => true,
            'job_id' => $job_id,
            'status' => 'retry_scheduled',
            'retry_minutes' => $mins,
        ]);
    }
}

JKSH_Community_Auto_V0930::instance();
