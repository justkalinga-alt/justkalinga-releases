<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Threads_Callbacks_V0132 {
    const VERSION = '0.13.2';
    const PLATFORM = 'threads';
    const OPTION = 'jksh_threads_config';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
        add_action( 'admin_footer', [ $this, 'admin_footer' ], 1120 );
    }

    private function accounts() {
        return new \JKSH\Repositories\AccountRepository();
    }

    private function logs() {
        return new \JKSH\Repositories\LogRepository();
    }

    private function crypto() {
        return new \JKSH\Security\Crypto();
    }

    private function app_secret() {
        $config = wp_parse_args(
            (array) get_option( self::OPTION, [] ),
            [
                'app_id' => '',
                'app_secret_encrypted' => '',
                'threads_use_case_confirmed' => 0,
            ]
        );

        $encrypted = (string) ( $config['app_secret_encrypted'] ?? '' );
        if ( '' === $encrypted ) {
            return '';
        }

        return (string) $this->crypto()->decrypt( $encrypted );
    }

    public function deauthorize_url() {
        return rest_url( 'jksh/v1/threads/deauthorize' );
    }

    public function data_deletion_url() {
        return rest_url( 'jksh/v1/threads/data-deletion' );
    }

    public function data_deletion_status_url() {
        return rest_url( 'jksh/v1/threads/data-deletion-status' );
    }

    public function register_routes() {
        register_rest_route(
            'jksh/v1',
            '/threads/deauthorize',
            [
                [
                    'methods' => [ 'GET', 'HEAD' ],
                    'callback' => fn() => rest_ensure_response( [
                        'ok' => true,
                        'service' => 'JK Social Hub Threads deauthorization callback',
                        'version' => self::VERSION,
                    ] ),
                    'permission_callback' => '__return_true',
                ],
                [
                    'methods' => 'POST',
                    'callback' => [ $this, 'handle_deauthorize' ],
                    'permission_callback' => '__return_true',
                ],
            ]
        );

        register_rest_route(
            'jksh/v1',
            '/threads/data-deletion',
            [
                [
                    'methods' => [ 'GET', 'HEAD' ],
                    'callback' => fn() => rest_ensure_response( [
                        'ok' => true,
                        'service' => 'JK Social Hub Threads data deletion callback',
                        'version' => self::VERSION,
                    ] ),
                    'permission_callback' => '__return_true',
                ],
                [
                    'methods' => 'POST',
                    'callback' => [ $this, 'handle_data_deletion' ],
                    'permission_callback' => '__return_true',
                ],
            ]
        );

        register_rest_route(
            'jksh/v1',
            '/threads/data-deletion-status',
            [
                'methods' => 'GET',
                'callback' => [ $this, 'handle_deletion_status' ],
                'permission_callback' => '__return_true',
            ]
        );

        register_rest_route(
            'jksh/v1',
            '/threads/callback-readiness',
            [
                'methods' => 'GET',
                'callback' => fn() => rest_ensure_response( [
                    'ok' => true,
                    'patch' => self::VERSION,
                    'deauthorize_url' => $this->deauthorize_url(),
                    'data_deletion_url' => $this->data_deletion_url(),
                    'data_deletion_status_url' => $this->data_deletion_status_url(),
                    'signed_request_validation' => 'HMAC-SHA256',
                    'app_secret_configured' => '' !== $this->app_secret(),
                ] ),
                'permission_callback' => fn() => current_user_can( 'jksh_manage_accounts' ),
            ]
        );
    }

    public function handle_deauthorize( \WP_REST_Request $request ) {
        $payload = $this->validate_signed_request( (string) $request->get_param( 'signed_request' ) );
        if ( is_wp_error( $payload ) ) {
            return $payload;
        }

        $user_id = sanitize_text_field( (string) ( $payload['user_id'] ?? '' ) );
        if ( '' === $user_id ) {
            return new \WP_Error( 'jksh_threads_user_missing', 'Threads signed request did not include a user ID.', [ 'status' => 400 ] );
        }

        $account = $this->accounts()->find( self::PLATFORM, $user_id );
        if ( $account ) {
            $this->accounts()->disconnect( (int) $account->id );
        }

        $this->logs()->add(
            [
                'action' => 'threads_deauthorize_callback',
                'result' => 'success',
                'message' => 'Threads deauthorization callback processed.',
                'context' => [
                    'threads_user_id' => $user_id,
                    'account_found' => (bool) $account,
                    'patch' => self::VERSION,
                ],
            ]
        );

        return rest_ensure_response( [
            'success' => true,
        ] );
    }

    public function handle_data_deletion( \WP_REST_Request $request ) {
        $payload = $this->validate_signed_request( (string) $request->get_param( 'signed_request' ) );
        if ( is_wp_error( $payload ) ) {
            return $payload;
        }

        $user_id = sanitize_text_field( (string) ( $payload['user_id'] ?? '' ) );
        if ( '' === $user_id ) {
            return new \WP_Error( 'jksh_threads_user_missing', 'Threads signed request did not include a user ID.', [ 'status' => 400 ] );
        }

        global $wpdb;

        $account = $this->accounts()->find( self::PLATFORM, $user_id );
        if ( $account ) {
            $accounts_table = $wpdb->prefix . 'jksh_accounts';
            $wpdb->delete( $accounts_table, [ 'id' => (int) $account->id ], [ '%d' ] );
        }

        $logs_table = $wpdb->prefix . 'jksh_logs';
        $logs_exists = $logs_table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $logs_table ) );
        if ( $logs_exists ) {
            $like = '%' . $wpdb->esc_like( $user_id ) . '%';
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$logs_table}
                     WHERE action LIKE %s
                     AND context_json LIKE %s",
                    'threads_%',
                    $like
                )
            );
        }

        $confirmation = wp_generate_password( 32, false, false );
        set_transient(
            'jksh_threads_delete_' . hash( 'sha256', $confirmation ),
            [
                'status' => 'completed',
                'threads_user_id' => $user_id,
                'completed_at_utc' => gmdate( 'c' ),
            ],
            7 * DAY_IN_SECONDS
        );

        $this->logs()->add(
            [
                'action' => 'threads_data_deletion_callback',
                'result' => 'success',
                'message' => 'Threads data deletion request processed.',
                'context' => [
                    'threads_user_id' => $user_id,
                    'account_deleted' => (bool) $account,
                    'patch' => self::VERSION,
                ],
            ]
        );

        return rest_ensure_response( [
            'url' => add_query_arg(
                [ 'confirmation_code' => rawurlencode( $confirmation ) ],
                $this->data_deletion_status_url()
            ),
            'confirmation_code' => $confirmation,
        ] );
    }

    public function handle_deletion_status( \WP_REST_Request $request ) {
        $code = sanitize_text_field( (string) $request->get_param( 'confirmation_code' ) );
        if ( '' === $code ) {
            return new \WP_Error( 'jksh_threads_confirmation_missing', 'Confirmation code is required.', [ 'status' => 400 ] );
        }

        $state = get_transient( 'jksh_threads_delete_' . hash( 'sha256', $code ) );
        if ( ! is_array( $state ) ) {
            return new \WP_Error( 'jksh_threads_confirmation_invalid', 'Deletion confirmation code was not found or has expired.', [ 'status' => 404 ] );
        }

        return rest_ensure_response( [
            'status' => (string) ( $state['status'] ?? 'completed' ),
            'completed_at_utc' => (string) ( $state['completed_at_utc'] ?? '' ),
        ] );
    }

    private function validate_signed_request( $signed_request ) {
        if ( '' === trim( $signed_request ) ) {
            return new \WP_Error( 'jksh_threads_signed_request_missing', 'signed_request is required.', [ 'status' => 400 ] );
        }

        $secret = $this->app_secret();
        if ( '' === $secret ) {
            return new \WP_Error( 'jksh_threads_secret_missing', 'Threads App Secret is not configured in JK Social Hub.', [ 'status' => 503 ] );
        }

        $parts = explode( '.', $signed_request, 2 );
        if ( 2 !== count( $parts ) ) {
            return new \WP_Error( 'jksh_threads_signed_request_invalid', 'Malformed Threads signed_request.', [ 'status' => 400 ] );
        }

        [ $encoded_sig, $encoded_payload ] = $parts;

        $signature = $this->base64url_decode( $encoded_sig );
        $payload_json = $this->base64url_decode( $encoded_payload );

        if ( false === $signature || false === $payload_json ) {
            return new \WP_Error( 'jksh_threads_signed_request_invalid', 'Threads signed_request could not be decoded.', [ 'status' => 400 ] );
        }

        $expected = hash_hmac( 'sha256', $encoded_payload, $secret, true );
        if ( ! hash_equals( $expected, $signature ) ) {
            return new \WP_Error( 'jksh_threads_signature_invalid', 'Threads signed_request signature validation failed.', [ 'status' => 403 ] );
        }

        $payload = json_decode( $payload_json, true );
        if ( ! is_array( $payload ) ) {
            return new \WP_Error( 'jksh_threads_payload_invalid', 'Threads signed_request payload was invalid.', [ 'status' => 400 ] );
        }

        $algorithm = strtoupper( (string) ( $payload['algorithm'] ?? 'HMAC-SHA256' ) );
        if ( 'HMAC-SHA256' !== $algorithm ) {
            return new \WP_Error( 'jksh_threads_algorithm_invalid', 'Unsupported Threads signed_request algorithm.', [ 'status' => 400 ] );
        }

        return $payload;
    }

    private function base64url_decode( $value ) {
        $value = strtr( (string) $value, '-_', '+/' );
        $padding = strlen( $value ) % 4;
        if ( $padding ) {
            $value .= str_repeat( '=', 4 - $padding );
        }
        return base64_decode( $value, true );
    }

    public function admin_footer() {
        if ( ! is_admin() || 'jksh-accounts' !== sanitize_key( (string) ( $_GET['page'] ?? '' ) ) ) {
            return;
        }
        ?>
        <section id="jksh-threads-callbacks-v0132" class="jksh-card" style="display:none">
            <h2>Threads callback URLs <span class="jksh-badge status-connected">Ready</span></h2>
            <p>Meta requires these URLs before the Threads settings form can be saved.</p>
            <h3>Uninstall / Deauthorize callback URL</h3>
            <code class="jksh-code-block"><?php echo esc_html( $this->deauthorize_url() ); ?></code>
            <h3>Data Deletion callback URL</h3>
            <code class="jksh-code-block"><?php echo esc_html( $this->data_deletion_url() ); ?></code>
            <p class="description">Both callbacks validate Meta signed_request payloads with HMAC-SHA256. The data-deletion endpoint removes the local Threads account/token/profile record and returns Meta's confirmation-code response.</p>
        </section>
        <script>
        (() => {
            const panel = document.getElementById('jksh-threads-callbacks-v0132');
            const threads = document.getElementById('jksh-threads-foundation-v0131');
            if (!panel || !threads) return;
            threads.insertAdjacentElement('afterend', panel);
            panel.style.display = '';
        })();
        </script>
        <?php
    }
}

JKSH_Threads_Callbacks_V0132::instance();
