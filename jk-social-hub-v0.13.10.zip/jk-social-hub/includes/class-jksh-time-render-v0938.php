<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Time_Render_V0938 {
    const VERSION = '0.9.3.8';
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_footer', [ $this, 'admin_footer' ], 1010 );
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route(
            'jksh/v1',
            '/maintenance/time-render-v0938-status',
            [
                'methods' => WP_REST_Server::READABLE,
                'permission_callback' => function () { return current_user_can( 'manage_options' ); },
                'callback' => function () {
                    return rest_ensure_response( [
                        'ok' => true,
                        'patch' => self::VERSION,
                        'filter_safe' => true,
                        'workflow_schedule_time' => true,
                        'workflow_published_time' => true,
                        'created_timezone' => 'Asia/Kolkata',
                        'strategy' => 'route_independent_table_decorator',
                    ] );
                },
            ]
        );
    }

    public function admin_footer() {
        if ( ! is_admin() ) return;
        $nonce = wp_create_nonce( 'wp_rest' );
        ?>
<style>
.jksh-time-v0938{margin-top:7px;font-size:11px;line-height:1.35;font-weight:700;white-space:normal}
.jksh-time-v0938.is-scheduled{color:#6d28d9}
.jksh-time-v0938.is-published{color:#067647}
.jksh-time-v0938.is-uploaded{color:#2563eb}
.jksh-time-v0938.is-community{color:#7c3aed}
.jksh-time-v0938.is-cancelled{color:#64748b}
.jksh-created-ist-v0938{white-space:normal}
</style>
<script>
(() => {
  const table = document.querySelector('table.jksh-content-table');
  if (!table) return;

  const nonce = <?php echo wp_json_encode( $nonce ); ?>;

  const idFromRow = row => {
    const text = row.innerText || '';
    let m = text.match(/Content\s*#?\s*(\d+)/i);
    if (!m) m = text.match(/Content\s*ID\s*#?\s*(\d+)/i);
    return m ? Number(m[1]) : 0;
  };

  const createdToIST = raw => {
    const s = String(raw || '').trim();
    if (!s || s === '—' || /\bIST\b/i.test(s)) return s;

    let date = null;
    if (/^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}$/.test(s)) {
      date = new Date(s.replace(/\s+/, 'T') + 'Z');
    } else if (/^\d{4}-\d{2}-\d{2}T/.test(s)) {
      date = new Date(s);
    }

    if (!date || Number.isNaN(date.getTime())) return s;

    const value = new Intl.DateTimeFormat('en-IN', {
      timeZone: 'Asia/Kolkata',
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(date).replace(/\bam\b/i, 'AM').replace(/\bpm\b/i, 'PM');

    return value + ' IST';
  };

  const fixCreated = () => {
    table.querySelectorAll('tbody tr').forEach(row => {
      const cell = row.querySelector('td[data-label="Created"]');
      if (!cell) return;
      const target = cell.querySelector('.muted') || cell;
      if (target.dataset.jkshIstFixed === '1') return;

      const before = (target.textContent || '').trim();
      const after = createdToIST(before);
      if (after && after !== before) {
        target.textContent = after;
        target.classList.add('jksh-created-ist-v0938');
      }
      target.dataset.jkshIstFixed = '1';
    });
  };

  const appendMeta = (workflowCell, kind, text) => {
    if (!workflowCell || !text) return;

    const selectors = kind === 'published'
      ? '.jksh-published-time,.jksh-published-time-inline,.jksh-time-v0938.is-published'
      : '.jksh-schedule-display,.jksh-time-v0938:not(.is-published)';

    if (workflowCell.querySelector(selectors)) return;

    const meta = document.createElement('div');
    meta.className = 'jksh-time-v0938 is-' + kind;
    meta.textContent = text;
    workflowCell.appendChild(meta);
  };

  const decorate = (scheduleMap, publishedMap) => {
    table.querySelectorAll('tbody tr').forEach(row => {
      const id = idFromRow(row);
      if (!id) return;

      const workflowCell = row.querySelector('td[data-label="Workflow"]') || row.querySelectorAll('td')[1];
      if (!workflowCell) return;

      const state = (workflowCell.querySelector('.badge')?.textContent || '').trim().toLowerCase();

      if (state === 'published') {
        const item = publishedMap && publishedMap[id];
        const value = item && item.published_at_ist ? item.published_at_ist : '';
        if (value) appendMeta(workflowCell, 'published', '✅ ' + value);
        return;
      }

      const item = scheduleMap && scheduleMap[id];
      if (!item) return;

      if (item.state === 'not_scheduled') {
        appendMeta(workflowCell, 'uploaded', '⏳ Not scheduled');
      } else if (item.state === 'community_ready') {
        appendMeta(workflowCell, 'community', '📌 Handoff: ' + (item.display || ''));
      } else if (item.state === 'cancelled') {
        appendMeta(workflowCell, 'cancelled', '🕓 Was scheduled: ' + (item.display || ''));
      } else {
        appendMeta(workflowCell, 'scheduled', '📅 ' + (item.display || ''));
      }
    });

    fixCreated();
  };

  const load = async () => {
    fixCreated();

    try {
      const [scheduleResponse, publishedResponse] = await Promise.all([
        fetch('/wp-json/jksh/v1/content-library-schedule-map', {
          headers: { 'X-WP-Nonce': nonce }
        }),
        fetch('/wp-json/jksh/v1/content-library-published-time-map', {
          headers: { 'X-WP-Nonce': nonce }
        })
      ]);

      const scheduleData = await scheduleResponse.json();
      const publishedData = await publishedResponse.json();

      decorate(
        scheduleData && scheduleData.ok ? (scheduleData.items || {}) : {},
        publishedData && publishedData.ok ? (publishedData.items || {}) : {}
      );
    } catch (e) {
      fixCreated();
    }
  };

  load();
})();
</script>
        <?php
    }
}

JKSH_Time_Render_V0938::instance();
