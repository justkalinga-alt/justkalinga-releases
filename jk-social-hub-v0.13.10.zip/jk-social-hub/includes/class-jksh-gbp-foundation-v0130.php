<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_GBP_Foundation_V0130 {
    const VERSION = '0.13.0';
    const OPTION = 'jksh_gbp_config';
    const PLATFORM = 'google_business_profile';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_post_jksh_save_gbp_config', [ $this, 'save_config' ] );
        add_action( 'admin_post_jksh_gbp_oauth_callback', [ $this, 'callback' ] );
        add_action( 'admin_post_jksh_gbp_test_account', [ $this, 'test_account' ] );
        add_action( 'admin_post_jksh_gbp_disconnect_account', [ $this, 'disconnect_account' ] );
        add_action( 'rest_api_init', [ $this, 'rest_routes' ] );
        add_action( 'admin_footer', [ $this, 'admin_footer' ], 1100 );
    }

    private function crypto() {
        return new \JKSH\Security\Crypto();
    }

    private function accounts() {
        return new \JKSH\Repositories\AccountRepository();
    }

    private function logs() {
        return new \JKSH\Repositories\LogRepository();
    }

    private function defaults() {
        return [
            'project_id' => '',
            'client_id' => '',
            'client_secret_encrypted' => '',
            'api_access_confirmed' => 0,
        ];
    }

    public function config() {
        return wp_parse_args( (array) get_option( self::OPTION, [] ), $this->defaults() );
    }

    public function has_secret() {
        return '' !== (string) ( $this->config()['client_secret_encrypted'] ?? '' );
    }

    public function is_configured() {
        $c = $this->config();
        return '' !== trim( (string) ( $c['project_id'] ?? '' ) )
            && '' !== trim( (string) ( $c['client_id'] ?? '' ) )
            && $this->has_secret();
    }

    public function access_confirmed() {
        return 1 === (int) ( $this->config()['api_access_confirmed'] ?? 0 );
    }

    public function redirect_uri() {
        return admin_url( 'admin-post.php?action=jksh_gbp_oauth_callback' );
    }

    public function scopes() {
        return [ 'https://www.googleapis.com/auth/business.manage' ];
    }

    public function readiness() {
        $rows = $this->accounts()->connected( self::PLATFORM );
        $eligible = 0;
        foreach ( $rows as $row ) {
            $settings = $this->accounts()->settings( $row );
            if ( ! empty( $settings['can_operate_local_post'] ) ) {
                $eligible++;
            }
        }

        return [
            'ok' => true,
            'phase' => 'v0.13.0-A',
            'platform' => self::PLATFORM,
            'configured' => $this->is_configured(),
            'api_access_confirmed' => $this->access_confirmed(),
            'connectable' => $this->is_configured() && $this->access_confirmed(),
            'connected_locations' => count( $rows ),
            'local_post_eligible_locations' => $eligible,
            'publisher_enabled' => false,
            'publisher_gate' => 'connect_and_verify_location_first',
            'redirect_uri' => $this->redirect_uri(),
            'scope' => $this->scopes(),
            'native_post_types_next' => [ 'UPDATE', 'EVENT', 'OFFER' ],
            'native_fields_next' => [
                'summary',
                'languageCode',
                'callToAction.actionType',
                'callToAction.url',
                'event.title',
                'event.schedule',
                'offer.couponCode',
                'offer.redeemOnlineUrl',
                'offer.termsConditions',
                'media.sourceUrl',
            ],
            'product_posts_supported' => false,
            'requirements' => [
                'Approved Google Business Profile API project',
                'Business Profile API family enabled in the approved Google Cloud project',
                'OAuth 2.0 Web application configured with the exact redirect URI',
                'Authorized Google user owns or manages a Business Profile location',
            ],
            'note' => 'OAuth/account/location foundation only. No GBP post will be created by this release.',
        ];
    }

    public function save_config() {
        $this->guard( 'jksh_gbp_config' );
        $current = $this->config();
        $project_id = sanitize_text_field( wp_unslash( $_POST['project_id'] ?? '' ) );
        $client_id = sanitize_text_field( wp_unslash( $_POST['client_id'] ?? '' ) );
        $secret = trim( (string) wp_unslash( $_POST['client_secret'] ?? '' ) );

        $next = [
            'project_id' => trim( $project_id ),
            'client_id' => trim( $client_id ),
            'client_secret_encrypted' => (string) ( $current['client_secret_encrypted'] ?? '' ),
            'api_access_confirmed' => ! empty( $_POST['api_access_confirmed'] ) ? 1 : 0,
        ];

        if ( '' !== $secret ) {
            $next['client_secret_encrypted'] = $this->crypto()->encrypt( $secret );
        }

        update_option( self::OPTION, $next, false );
        $this->redirect( 'success', 'Google Business Profile API settings saved securely.' );
    }

    public function auth_url() {
        if ( ! $this->is_configured() || ! $this->access_confirmed() ) {
            return '';
        }

        $state = wp_generate_password( 48, false, false );
        set_transient(
            'jksh_gbp_state_' . get_current_user_id(),
            hash( 'sha256', $state ),
            15 * MINUTE_IN_SECONDS
        );

        $c = $this->config();
        return add_query_arg(
            [
                'client_id' => (string) $c['client_id'],
                'redirect_uri' => $this->redirect_uri(),
                'response_type' => 'code',
                'scope' => implode( ' ', $this->scopes() ),
                'access_type' => 'offline',
                'include_granted_scopes' => 'true',
                'prompt' => 'consent',
                'state' => $state,
            ],
            'https://accounts.google.com/o/oauth2/v2/auth'
        );
    }

    public function callback() {
        if ( ! current_user_can( 'jksh_manage_accounts' ) ) {
            wp_die( esc_html__( 'You do not have permission to manage social accounts.', 'jk-social-hub' ) );
        }

        if ( ! empty( $_GET['error'] ) ) {
            $msg = sanitize_text_field( wp_unslash( $_GET['error_description'] ?? $_GET['error'] ) );
            $this->redirect( 'error', 'Google Business Profile authorization was not completed: ' . $msg );
        }

        $code = sanitize_text_field( wp_unslash( $_GET['code'] ?? '' ) );
        $state = sanitize_text_field( wp_unslash( $_GET['state'] ?? '' ) );
        if ( '' === $code || '' === $state ) {
            $this->redirect( 'error', 'Google Business Profile callback was missing authorization data.' );
        }

        $expected = (string) get_transient( 'jksh_gbp_state_' . get_current_user_id() );
        delete_transient( 'jksh_gbp_state_' . get_current_user_id() );
        if ( '' === $expected || ! hash_equals( $expected, hash( 'sha256', $state ) ) ) {
            $this->redirect( 'error', 'Google Business Profile OAuth state validation failed. Start the connection again.' );
        }

        $result = $this->connect_with_code( $code );
        $this->redirect( $result['ok'] ? 'success' : 'error', $result['message'] );
    }

    private function connect_with_code( $code ) {
        if ( ! $this->is_configured() || ! $this->access_confirmed() ) {
            return [ 'ok' => false, 'message' => 'Save approved GBP OAuth configuration before connecting.' ];
        }

        $c = $this->config();
        $secret = $this->crypto()->decrypt( (string) $c['client_secret_encrypted'] );
        if ( '' === $secret ) {
            return [ 'ok' => false, 'message' => 'Saved Google OAuth client secret could not be decrypted.' ];
        }

        $token_result = $this->decode_response(
            wp_remote_post(
                'https://oauth2.googleapis.com/token',
                [
                    'timeout' => 30,
                    'body' => [
                        'code' => $code,
                        'client_id' => (string) $c['client_id'],
                        'client_secret' => $secret,
                        'redirect_uri' => $this->redirect_uri(),
                        'grant_type' => 'authorization_code',
                    ],
                ]
            )
        );

        if ( ! $token_result['ok'] || empty( $token_result['data']['access_token'] ) ) {
            return [ 'ok' => false, 'message' => 'GBP token exchange failed: ' . $token_result['message'] ];
        }

        $access = sanitize_text_field( (string) $token_result['data']['access_token'] );
        $refresh = sanitize_text_field( (string) ( $token_result['data']['refresh_token'] ?? '' ) );

        if ( '' === $refresh ) {
            foreach ( $this->accounts()->connected( self::PLATFORM ) as $existing ) {
                $creds = $this->accounts()->credentials( $existing );
                if ( ! empty( $creds['refresh_token'] ) ) {
                    $refresh = sanitize_text_field( (string) $creds['refresh_token'] );
                    break;
                }
            }
        }

        if ( '' === $refresh ) {
            return [ 'ok' => false, 'message' => 'Google did not return an offline refresh token. Reconnect and approve access again.' ];
        }

        $account_result = $this->api_get(
            $access,
            'https://mybusinessaccountmanagement.googleapis.com/v1/accounts'
        );

        if ( ! $account_result['ok'] ) {
            return [ 'ok' => false, 'message' => 'GBP account discovery failed: ' . $account_result['message'] ];
        }

        $google_accounts = (array) ( $account_result['data']['accounts'] ?? [] );
        if ( ! $google_accounts ) {
            return [ 'ok' => false, 'message' => 'No Google Business Profile accounts were returned.' ];
        }

        $locations = $this->discover_locations( $access, $google_accounts );
        if ( is_wp_error( $locations ) ) {
            return [ 'ok' => false, 'message' => $locations->get_error_message() ];
        }

        if ( ! $locations ) {
            return [ 'ok' => false, 'message' => 'No Google Business Profile locations were found.' ];
        }

        $expires_in = max( 0, (int) ( $token_result['data']['expires_in'] ?? 0 ) );
        $expires_at = $expires_in ? gmdate( 'Y-m-d H:i:s', time() + $expires_in ) : null;

        $credentials = [
            'access_token' => $access,
            'refresh_token' => $refresh,
            'token_type' => sanitize_text_field( (string) ( $token_result['data']['token_type'] ?? 'Bearer' ) ),
            'scope' => sanitize_text_field( (string) ( $token_result['data']['scope'] ?? implode( ' ', $this->scopes() ) ) ),
        ];

        $imported = 0;
        $eligible = 0;

        foreach ( $locations as $location ) {
            $resource = sanitize_text_field( (string) ( $location['name'] ?? '' ) );
            if ( '' === $resource ) {
                continue;
            }

            $metadata = is_array( $location['metadata'] ?? null ) ? $location['metadata'] : [];
            $can_post = ! empty( $metadata['canOperateLocalPost'] );
            if ( $can_post ) {
                $eligible++;
            }

            $title = sanitize_text_field( (string) ( $location['title'] ?? $resource ) );
            $settings = [
                'google_account_resource' => sanitize_text_field( (string) ( $location['_jksh_account_resource'] ?? '' ) ),
                'google_account_name' => sanitize_text_field( (string) ( $location['_jksh_account_name'] ?? '' ) ),
                'google_account_type' => sanitize_key( (string) ( $location['_jksh_account_type'] ?? '' ) ),
                'location_resource' => $resource,
                'title' => $title,
                'store_code' => sanitize_text_field( (string) ( $location['storeCode'] ?? '' ) ),
                'website_uri' => esc_url_raw( (string) ( $location['websiteUri'] ?? '' ) ),
                'maps_uri' => esc_url_raw( (string) ( $metadata['mapsUri'] ?? '' ) ),
                'place_id' => sanitize_text_field( (string) ( $metadata['placeId'] ?? '' ) ),
                'can_operate_local_post' => $can_post,
                'has_voice_of_merchant' => ! empty( $metadata['hasVoiceOfMerchant'] ),
                'api_project_id' => sanitize_text_field( (string) $c['project_id'] ),
                'connector_phase' => 'v0.13.0-A',
            ];

            $this->accounts()->upsert(
                [
                    'platform' => self::PLATFORM,
                    'account_name' => $title,
                    'external_account_id' => $resource,
                    'status' => 'connected',
                    'settings' => $settings,
                    'credentials' => $credentials,
                    'token_expires_at' => $expires_at,
                    'last_checked_at' => current_time( 'mysql', true ),
                    'last_error' => '',
                ]
            );
            $imported++;
        }

        $this->logs()->add(
            [
                'action' => 'gbp_connect',
                'result' => 'success',
                'message' => 'Google Business Profile OAuth and location discovery completed.',
                'context' => [
                    'locations_imported' => $imported,
                    'local_post_eligible_locations' => $eligible,
                    'project_id' => sanitize_text_field( (string) $c['project_id'] ),
                    'scope' => $this->scopes(),
                ],
            ]
        );

        return [
            'ok' => true,
            'message' => sprintf(
                'Google Business Profile connected. %d location(s) discovered; %d report Local Post capability.',
                $imported,
                $eligible
            ),
        ];
    }

    private function discover_locations( $token, $google_accounts ) {
        $locations = [];

        foreach ( $google_accounts as $google_account ) {
            if ( ! is_array( $google_account ) ) {
                continue;
            }

            $account_resource = sanitize_text_field( (string) ( $google_account['name'] ?? '' ) );
            if ( ! preg_match( '#^accounts/[A-Za-z0-9_-]+$#', $account_resource ) ) {
                continue;
            }

            $page_token = '';
            for ( $page = 0; $page < 20; $page++ ) {
                $query = [
                    'readMask' => 'name,title,storeCode,websiteUri,metadata',
                    'pageSize' => 100,
                ];
                if ( '' !== $page_token ) {
                    $query['pageToken'] = $page_token;
                }

                $result = $this->api_get(
                    $token,
                    'https://mybusinessbusinessinformation.googleapis.com/v1/' . $account_resource . '/locations',
                    $query
                );

                if ( ! $result['ok'] ) {
                    return new \WP_Error(
                        'jksh_gbp_location_discovery_failed',
                        'GBP location discovery failed for ' . $account_resource . ': ' . $result['message']
                    );
                }

                foreach ( (array) ( $result['data']['locations'] ?? [] ) as $location ) {
                    if ( ! is_array( $location ) ) {
                        continue;
                    }
                    $name = sanitize_text_field( (string) ( $location['name'] ?? '' ) );
                    if ( '' === $name ) {
                        continue;
                    }
                    $location['_jksh_account_resource'] = $account_resource;
                    $location['_jksh_account_name'] = sanitize_text_field( (string) ( $google_account['accountName'] ?? '' ) );
                    $location['_jksh_account_type'] = sanitize_key( (string) ( $google_account['type'] ?? '' ) );
                    $locations[ $name ] = $location;
                }

                $page_token = sanitize_text_field( (string) ( $result['data']['nextPageToken'] ?? '' ) );
                if ( '' === $page_token ) {
                    break;
                }
            }
        }

        return array_values( $locations );
    }

    public function test_account() {
        $this->guard( 'jksh_gbp_test_account' );
        $account_id = absint( $_POST['account_id'] ?? 0 );
        $account = $this->accounts()->get( $account_id );

        if ( ! $account || self::PLATFORM !== (string) $account->platform ) {
            $this->redirect( 'error', 'Google Business Profile location was not found.' );
        }

        $token = $this->access_token_for_account( $account );
        if ( is_wp_error( $token ) ) {
            $message = 'GBP connection test failed: ' . $token->get_error_message();
            $this->accounts()->update_status( $account_id, 'attention', $message );
            $this->redirect( 'error', $message );
        }

        $settings = $this->accounts()->settings( $account );
        $resource = sanitize_text_field( (string) ( $settings['location_resource'] ?? $account->external_account_id ) );

        $result = $this->api_get(
            (string) $token,
            'https://mybusinessbusinessinformation.googleapis.com/v1/' . $resource,
            [ 'readMask' => 'name,title,storeCode,websiteUri,metadata' ]
        );

        if ( ! $result['ok'] ) {
            $message = 'GBP connection test failed: ' . $result['message'];
            $this->accounts()->update_status( $account_id, 'attention', $message );
            $this->redirect( 'error', $message );
        }

        $metadata = is_array( $result['data']['metadata'] ?? null ) ? $result['data']['metadata'] : [];
        $settings['can_operate_local_post'] = ! empty( $metadata['canOperateLocalPost'] );
        $settings['has_voice_of_merchant'] = ! empty( $metadata['hasVoiceOfMerchant'] );
        $settings['maps_uri'] = esc_url_raw( (string) ( $metadata['mapsUri'] ?? '' ) );
        $settings['place_id'] = sanitize_text_field( (string) ( $metadata['placeId'] ?? '' ) );

        $this->accounts()->upsert(
            [
                'platform' => self::PLATFORM,
                'account_name' => sanitize_text_field( (string) ( $result['data']['title'] ?? $account->account_name ) ),
                'external_account_id' => (string) $account->external_account_id,
                'status' => 'connected',
                'settings' => $settings,
                'token_expires_at' => $account->token_expires_at,
                'last_checked_at' => current_time( 'mysql', true ),
                'last_error' => '',
            ]
        );

        $this->logs()->add(
            [
                'action' => 'gbp_account_test',
                'result' => 'success',
                'message' => 'Google Business Profile location test succeeded.',
                'context' => [
                    'account_id' => $account_id,
                    'location_resource' => $resource,
                    'can_operate_local_post' => ! empty( $settings['can_operate_local_post'] ),
                ],
            ]
        );

        $this->redirect( 'success', 'Google Business Profile location test succeeded.' );
    }

    public function disconnect_account() {
        $this->guard( 'jksh_gbp_disconnect_account' );
        $account_id = absint( $_POST['account_id'] ?? 0 );
        $account = $this->accounts()->get( $account_id );

        if ( ! $account || self::PLATFORM !== (string) $account->platform ) {
            $this->redirect( 'error', 'Google Business Profile location was not found.' );
        }

        $this->accounts()->disconnect( $account_id );
        $this->logs()->add(
            [
                'action' => 'gbp_disconnect',
                'result' => 'success',
                'message' => 'Google Business Profile location disconnected locally.',
                'context' => [
                    'account_id' => $account_id,
                    'location_resource' => (string) $account->external_account_id,
                ],
            ]
        );

        $this->redirect( 'success', 'Google Business Profile location disconnected locally.' );
    }

    private function access_token_for_account( $account ) {
        $repo = $this->accounts();
        $credentials = $repo->credentials( $account );
        $access = sanitize_text_field( (string) ( $credentials['access_token'] ?? '' ) );
        $expires_at = strtotime( (string) ( $account->token_expires_at ?? '' ) . ' UTC' );

        if ( '' !== $access && $expires_at && $expires_at > time() + 120 ) {
            return $access;
        }

        $refresh = sanitize_text_field( (string) ( $credentials['refresh_token'] ?? '' ) );
        if ( '' === $refresh ) {
            return new \WP_Error( 'jksh_gbp_refresh_missing', 'No stored GBP refresh token is available.' );
        }

        $c = $this->config();
        $secret = $this->crypto()->decrypt( (string) ( $c['client_secret_encrypted'] ?? '' ) );
        if ( '' === $secret ) {
            return new \WP_Error( 'jksh_gbp_secret_unavailable', 'Saved Google OAuth client secret could not be decrypted.' );
        }

        $result = $this->decode_response(
            wp_remote_post(
                'https://oauth2.googleapis.com/token',
                [
                    'timeout' => 30,
                    'body' => [
                        'client_id' => (string) $c['client_id'],
                        'client_secret' => $secret,
                        'refresh_token' => $refresh,
                        'grant_type' => 'refresh_token',
                    ],
                ]
            )
        );

        if ( ! $result['ok'] || empty( $result['data']['access_token'] ) ) {
            return new \WP_Error( 'jksh_gbp_refresh_failed', 'Google token refresh failed: ' . $result['message'] );
        }

        $access = sanitize_text_field( (string) $result['data']['access_token'] );
        $expires_in = max( 0, (int) ( $result['data']['expires_in'] ?? 0 ) );
        $expires = $expires_in ? gmdate( 'Y-m-d H:i:s', time() + $expires_in ) : null;

        $repo->upsert(
            [
                'platform' => self::PLATFORM,
                'account_name' => (string) $account->account_name,
                'external_account_id' => (string) $account->external_account_id,
                'status' => 'connected',
                'settings' => $repo->settings( $account ),
                'credentials' => [
                    'access_token' => $access,
                    'refresh_token' => $refresh,
                    'token_type' => sanitize_text_field( (string) ( $result['data']['token_type'] ?? $credentials['token_type'] ?? 'Bearer' ) ),
                    'scope' => sanitize_text_field( (string) ( $result['data']['scope'] ?? $credentials['scope'] ?? implode( ' ', $this->scopes() ) ) ),
                ],
                'token_expires_at' => $expires,
                'last_checked_at' => current_time( 'mysql', true ),
                'last_error' => '',
            ]
        );

        return $access;
    }

    private function api_get( $token, $url, $query = [] ) {
        if ( $query ) {
            $url = add_query_arg( $query, $url );
        }

        return $this->decode_response(
            wp_remote_get(
                $url,
                [
                    'timeout' => 30,
                    'headers' => [
                        'Authorization' => 'Bearer ' . $token,
                        'Accept' => 'application/json',
                        'X-GOOG-API-FORMAT-VERSION' => '2',
                    ],
                ]
            )
        );
    }

    private function decode_response( $response ) {
        if ( is_wp_error( $response ) ) {
            return [ 'ok' => false, 'message' => $response->get_error_message(), 'data' => [] ];
        }

        $status = (int) wp_remote_retrieve_response_code( $response );
        $data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        $data = is_array( $data ) ? $data : [];

        if ( $status >= 200 && $status < 300 ) {
            return [ 'ok' => true, 'message' => '', 'data' => $data, 'status' => $status ];
        }

        $message = (string) (
            $data['error']['message']
            ?? $data['error_description']
            ?? $data['error']
            ?? 'Google Business Profile API request failed.'
        );

        return [
            'ok' => false,
            'message' => sanitize_textarea_field( $message ),
            'data' => $data,
            'status' => $status,
        ];
    }

    public function rest_routes() {
        register_rest_route(
            'jksh/v1',
            '/gbp/readiness',
            [
                'methods' => 'GET',
                'callback' => fn() => rest_ensure_response( $this->readiness() ),
                'permission_callback' => fn() => current_user_can( 'jksh_manage_accounts' ),
            ]
        );
    }

    private function guard( $nonce_action ) {
        if ( ! current_user_can( 'jksh_manage_accounts' ) ) {
            wp_die( esc_html__( 'You do not have permission to manage social accounts.', 'jk-social-hub' ) );
        }
        check_admin_referer( $nonce_action );
    }

    private function redirect( $type, $message ) {
        wp_safe_redirect(
            add_query_arg(
                [
                    'page' => 'jksh-accounts',
                    'jksh_notice' => sanitize_key( $type ),
                    'jksh_msg' => $message,
                ],
                admin_url( 'admin.php' )
            )
        );
        exit;
    }

    public function admin_footer() {
        if ( ! is_admin() || 'jksh-accounts' !== sanitize_key( (string) ( $_GET['page'] ?? '' ) ) ) {
            return;
        }

        $config = $this->config();
        $ready = $this->readiness();
        $accounts = $this->accounts()->connected( self::PLATFORM );
        ?>
        <section id="jksh-gbp-foundation-v0130" class="jksh-card" style="display:none">
            <h2>Google Business Profile <span class="jksh-badge status-<?php echo esc_attr( $ready['connected_locations'] ? 'connected' : ( $ready['connectable'] ? 'attention' : 'not_connected' ) ); ?>"><?php echo esc_html( $ready['connected_locations'] ? 'Connected' : 'Tier 2 foundation' ); ?></span></h2>
            <p><strong>v0.13.0-A:</strong> secure OAuth, Business Profile account discovery, location discovery and health verification. Publishing remains locked until a real location passes this gate.</p>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="jksh-form">
                <input type="hidden" name="action" value="jksh_save_gbp_config">
                <?php wp_nonce_field( 'jksh_gbp_config' ); ?>
                <label><span>Google Cloud Project ID</span><input type="text" name="project_id" value="<?php echo esc_attr( $config['project_id'] ); ?>" autocomplete="off" placeholder="Approved GBP API project"></label>
                <label><span>OAuth Client ID</span><input type="text" name="client_id" value="<?php echo esc_attr( $config['client_id'] ); ?>" autocomplete="off"></label>
                <label><span>OAuth Client Secret</span><input type="password" name="client_secret" value="" autocomplete="new-password" placeholder="<?php echo $this->has_secret() ? esc_attr__( 'Saved securely — leave blank to keep it', 'jk-social-hub' ) : esc_attr__( 'Enter Client Secret', 'jk-social-hub' ); ?>"></label>
                <label class="jksh-check"><input type="checkbox" name="api_access_confirmed" value="1" <?php checked( ! empty( $config['api_access_confirmed'] ) ); ?>> I confirm this Google Cloud project has approved Google Business Profile API access.</label>
                <p><button class="button button-primary">Save GBP settings</button></p>
            </form>

            <hr>
            <h3>OAuth redirect URI</h3>
            <code class="jksh-code-block"><?php echo esc_html( $this->redirect_uri() ); ?></code>
            <h3>Required OAuth scope</h3>
            <p><code><?php echo esc_html( implode( ' ', $this->scopes() ) ); ?></code></p>

            <div class="jksh-grid jksh-grid-3">
                <div><strong>Configured</strong><br><?php echo esc_html( $ready['configured'] ? 'Yes' : 'No' ); ?></div>
                <div><strong>Connected locations</strong><br><?php echo esc_html( (string) $ready['connected_locations'] ); ?></div>
                <div><strong>Local Post capable</strong><br><?php echo esc_html( (string) $ready['local_post_eligible_locations'] ); ?></div>
            </div>

            <?php if ( $ready['connectable'] ) : ?>
                <p><a class="button button-primary button-hero" href="<?php echo esc_url( $this->auth_url() ); ?>">Connect / Reconnect Google Business Profile</a></p>
            <?php else : ?>
                <p><button class="button button-primary" disabled>Connect Google Business Profile</button></p>
                <p class="description">Save the approved Google Cloud Project ID, OAuth Client ID and Client Secret, then confirm API approval.</p>
            <?php endif; ?>

            <p class="description"><strong>Safety:</strong> this release cannot publish a GBP post. It only connects and verifies. Google Business Profile has no sandbox, so the publisher stays locked until we verify the real location read-only first.</p>

            <hr>
            <h3>Connected GBP locations</h3>
            <table class="widefat striped">
                <thead><tr><th>Location</th><th>Resource</th><th>Local Post</th><th>Status</th><th>Last checked</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if ( ! $accounts ) : ?><tr><td colspan="6">No Google Business Profile locations connected yet.</td></tr><?php endif; ?>
                <?php foreach ( $accounts as $account ) : $settings = $this->accounts()->settings( $account ); ?>
                    <tr>
                        <td><strong><?php echo esc_html( $account->account_name ); ?></strong></td>
                        <td><code><?php echo esc_html( $account->external_account_id ); ?></code></td>
                        <td><?php echo ! empty( $settings['can_operate_local_post'] ) ? 'Eligible' : 'Not reported'; ?></td>
                        <td><?php echo esc_html( $account->status ); ?></td>
                        <td><?php echo esc_html( (string) $account->last_checked_at ); ?> UTC</td>
                        <td>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block">
                                <input type="hidden" name="action" value="jksh_gbp_test_account">
                                <input type="hidden" name="account_id" value="<?php echo esc_attr( (string) $account->id ); ?>">
                                <?php wp_nonce_field( 'jksh_gbp_test_account' ); ?>
                                <button class="button">Test</button>
                            </form>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block" onsubmit="return confirm('Disconnect this GBP location locally?');">
                                <input type="hidden" name="action" value="jksh_gbp_disconnect_account">
                                <input type="hidden" name="account_id" value="<?php echo esc_attr( (string) $account->id ); ?>">
                                <?php wp_nonce_field( 'jksh_gbp_disconnect_account' ); ?>
                                <button class="button button-link-delete">Disconnect</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <hr>
            <p><strong>Native publisher fields reserved for the next gate:</strong> UPDATE / EVENT / OFFER, summary, CTA, event schedule, offer coupon/terms and photo URL. Product Posts remain unsupported by Google's API.</p>
        </section>

        <script>
        (() => {
            const panel = document.getElementById('jksh-gbp-foundation-v0130');
            if (!panel) return;
            const cards = Array.from(document.querySelectorAll('.jksh-card'));
            const old = cards.find(card => /^Google Business Profile/i.test((card.querySelector('h2')?.textContent || '').trim()) && card !== panel);
            if (old) {
                old.replaceWith(panel);
                panel.style.display = '';
                return;
            }
            const wrap = document.querySelector('.jksh-wrap');
            if (wrap) {
                wrap.appendChild(panel);
                panel.style.display = '';
            }
        })();
        </script>
        <?php
    }
}

JKSH_GBP_Foundation_V0130::instance();
