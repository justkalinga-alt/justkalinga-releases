<?php
/**
 * JK Social Hub v0.9.1.2 upload-library sync.
 *
 * Adds persistent Content IDs for uploaded-but-not-scheduled Social Upload bundles,
 * reconciles canonical media rows from content.media_json, and exposes safe abilities
 * for listing/scheduling uploads by Content ID.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class JKSH_Content_Library_V0912_Upload_Sync {
    private const PATCH = '0.9.1.2';
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_init', [ $this, 'sync_now' ], 80 );
        add_action( 'wp_abilities_api_init', [ $this, 'register_abilities' ], 40 );
        add_action( 'rest_api_init', [ $this, 'register_rest_routes' ] );
    }

    private function tables() {
        global $wpdb;
        return [
            'content'  => $wpdb->prefix . 'jksh_content',
            'variants' => $wpdb->prefix . 'jksh_variants',
            'jobs'     => $wpdb->prefix . 'jksh_jobs',
            'media'    => $wpdb->prefix . 'jksh_media',
            'logs'     => $wpdb->prefix . 'jksh_publish_logs',
            'receipts' => $wpdb->prefix . 'jksh_queue_bridge_receipts',
        ];
    }

    private function table_exists( $table ) {
        global $wpdb;
        return $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
    }

    private function decode_json( $value ) {
        if ( is_array( $value ) ) {
            return $value;
        }
        if ( ! is_string( $value ) || '' === trim( $value ) ) {
            return [];
        }
        $decoded = json_decode( $value, true );
        return is_array( $decoded ) ? $decoded : [];
    }

    private function is_test_upload( array $draft ) {
        $haystack = implode(
            ' ',
            [
                (string) ( $draft['title'] ?? '' ),
                (string) ( $draft['content_type'] ?? '' ),
                (string) ( $draft['instructions'] ?? '' ),
            ]
        );
        return (bool) preg_match( '/(^|\\b)(qa|test|specimen)(\\b|$)|do not publish|internal qa|internal test|dry run|schema specimen|jk direct mcp/i', $haystack );
    }

    private function bundle_from_meta( array $meta ) {
        if ( ! empty( $meta['bundle_id'] ) && is_string( $meta['bundle_id'] ) ) {
            return $meta['bundle_id'];
        }
        if ( ! empty( $meta['upload_snapshot']['bundle_id'] ) && is_string( $meta['upload_snapshot']['bundle_id'] ) ) {
            return $meta['upload_snapshot']['bundle_id'];
        }
        $request_id = isset( $meta['request_id'] ) ? (string) $meta['request_id'] : '';
        if ( preg_match( '/^upload-([0-9a-f-]{36})-/i', $request_id, $m ) ) {
            return strtolower( $m[1] );
        }
        return '';
    }

    private function list_upload_drafts() {
        if ( ! function_exists( 'wp_get_ability' ) ) {
            return new WP_Error( 'jksh_abilities_unavailable', 'WordPress Abilities API is unavailable.' );
        }
        $ability = wp_get_ability( 'jk-social-supabase/list-upload-drafts' );
        if ( ! $ability ) {
            return new WP_Error( 'jksh_upload_ability_missing', 'Social Upload draft ability is unavailable.' );
        }
        $result = $ability->execute();
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        if ( ! is_array( $result ) || empty( $result['items'] ) || ! is_array( $result['items'] ) ) {
            return [];
        }
        return $result['items'];
    }

    private function mysql_datetime_from_utc( $value ) {
        if ( ! is_string( $value ) || '' === trim( $value ) ) {
            return current_time( 'mysql', true );
        }
        try {
            $dt = new DateTimeImmutable( $value );
            return $dt->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
        } catch ( Throwable $e ) {
            return current_time( 'mysql', true );
        }
    }

    private function normalize_content_type( $type ) {
        $type = sanitize_key( (string) $type );
        if ( 'long_video' === $type ) {
            return 'video';
        }
        return $type ?: 'post';
    }

    private function build_upload_meta( array $draft, array $existing_meta = [] ) {
        $content_type = sanitize_key( (string) ( $draft['content_type'] ?? '' ) );
        $selected_platforms = array_values( array_filter( array_map( 'sanitize_key', (array) ( $draft['selected_platforms'] ?? [] ) ) ) );
        $youtube_video_allowed = in_array( $content_type, [ 'mangal_arati', 'reel', 'video', 'short', 'long_video', 'sell_reel', 'knowledge_reel', 'long_knowledge_video' ], true ) || (bool) preg_match( '/(^|_)(reel|video|short)($|_)/', $content_type );
        if ( ! $youtube_video_allowed ) {
            $selected_platforms = array_values( array_diff( $selected_platforms, [ 'youtube' ] ) );
        }
        $snapshot = [
            'bundle_id'              => (string) ( $draft['bundle_id'] ?? '' ),
            'selected_platforms'     => $selected_platforms,
            'attachment_ids'         => array_values( array_map( 'absint', (array) ( $draft['attachment_ids'] ?? [] ) ) ),
            'asset_ids'              => array_values( (array) ( $draft['asset_ids'] ?? [] ) ),
            'storage_sources'        => array_values( (array) ( $draft['storage_sources'] ?? [] ) ),
            'filenames'              => array_values( (array) ( $draft['filenames'] ?? [] ) ),
            'media_meta'             => array_values( (array) ( $draft['media_meta'] ?? [] ) ),
            'cover_attachment_id'    => absint( $draft['cover_attachment_id'] ?? 0 ),
            'cover_asset_id'         => (string) ( $draft['cover_asset_id'] ?? '' ),
            'cover_storage_source'   => (string) ( $draft['cover_storage_source'] ?? '' ),
            'cover_filename'         => (string) ( $draft['cover_filename'] ?? '' ),
            'cover_meta'             => is_array( $draft['cover_meta'] ?? null ) ? $draft['cover_meta'] : [],
            'add_to_story'           => ! empty( $draft['add_to_story'] ),
            'highlight_name'         => (string) ( $draft['highlight_name'] ?? '' ),
            'location'               => $draft['location'] ?? '',
            'product_url'            => (string) ( $draft['product_url'] ?? '' ),
            'product_refs'           => array_values( (array) ( $draft['product_refs'] ?? [] ) ),
            'music_suggestion'       => (string) ( $draft['music_suggestion'] ?? '' ),
            'autopilot_native_fields'=> ! empty( $draft['autopilot_native_fields'] ),
            'created_at_utc'         => (string) ( $draft['created_at_utc'] ?? '' ),
            'status'                 => (string) ( $draft['status'] ?? 'uploaded' ),
        ];

        $existing_meta['source']          = $existing_meta['source'] ?? 'social_upload';
        $existing_meta['workflow']        = $existing_meta['workflow'] ?? 'uploaded_draft_v1';
        $existing_meta['bundle_id']       = $snapshot['bundle_id'];
        $existing_meta['upload_snapshot'] = $snapshot;
        $existing_meta['library_patch']   = self::PATCH;
        return $existing_meta;
    }

    private function current_bundle_map() {
        global $wpdb;
        $t = $this->tables();
        $rows = $wpdb->get_results( "SELECT id,status,meta_json FROM {$t['content']} ORDER BY id ASC", ARRAY_A );
        $map  = [];
        foreach ( (array) $rows as $row ) {
            $meta   = $this->decode_json( $row['meta_json'] ?? '' );
            $bundle = $this->bundle_from_meta( $meta );
            if ( '' === $bundle ) {
                continue;
            }
            if ( ! isset( $map[ $bundle ] ) ) {
                $map[ $bundle ] = [];
            }
            $map[ $bundle ][] = [
                'id'     => (int) $row['id'],
                'status' => (string) $row['status'],
                'meta'   => $meta,
            ];
        }
        return $map;
    }

    private function primary_existing_for_bundle( array $entries ) {
        foreach ( $entries as $entry ) {
            if ( 'uploaded' !== (string) $entry['status'] ) {
                return $entry;
            }
        }
        return $entries ? $entries[0] : null;
    }

    public function sync_now() {
        if ( is_admin() && ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $this->sync_upload_library();
    }

    public function sync_upload_library() {
        global $wpdb;
        $drafts = $this->list_upload_drafts();
        if ( is_wp_error( $drafts ) ) {
            return $drafts;
        }

        $t = $this->tables();
        $bundle_map = $this->current_bundle_map();
        $created = [];
        $updated = [];
        $skipped = [];

        foreach ( $drafts as $draft ) {
            if ( ! is_array( $draft ) ) {
                continue;
            }
            $bundle = strtolower( (string) ( $draft['bundle_id'] ?? '' ) );
            if ( '' === $bundle ) {
                continue;
            }
            if ( $this->is_test_upload( $draft ) ) {
                $skipped[] = [ 'bundle_id' => $bundle, 'reason' => 'test_qa' ];
                continue;
            }

            $attachments = array_values( array_filter( array_map( 'absint', (array) ( $draft['attachment_ids'] ?? [] ) ) ) );
            $created_at  = $this->mysql_datetime_from_utc( $draft['created_at_utc'] ?? '' );
            $title       = sanitize_text_field( (string) ( $draft['title'] ?? '' ) );
            if ( '' === $title ) {
                $title = ! empty( $draft['filenames'][0] ) ? sanitize_text_field( (string) $draft['filenames'][0] ) : 'Uploaded content';
            }
            $body = isset( $draft['instructions'] ) ? (string) $draft['instructions'] : '';

            if ( ! empty( $bundle_map[ $bundle ] ) ) {
                $existing = $this->primary_existing_for_bundle( $bundle_map[ $bundle ] );
                if ( $existing && 'uploaded' === (string) $existing['status'] ) {
                    $meta = $this->build_upload_meta( $draft, $existing['meta'] );
                    $wpdb->update(
                        $t['content'],
                        [
                            'title'        => $title,
                            'content_type' => $this->normalize_content_type( $draft['content_type'] ?? '' ),
                            'body'         => $body,
                            'media_json'   => wp_json_encode( $attachments ),
                            'meta_json'    => wp_json_encode( $meta ),
                            'updated_at'   => current_time( 'mysql', true ),
                        ],
                        [ 'id' => (int) $existing['id'] ]
                    );
                    $updated[] = (int) $existing['id'];
                }
                continue;
            }

            $meta = $this->build_upload_meta( $draft );
            $ok = $wpdb->insert(
                $t['content'],
                [
                    'uuid'         => wp_generate_uuid4(),
                    'title'        => $title,
                    'content_type' => $this->normalize_content_type( $draft['content_type'] ?? '' ),
                    'body'         => $body,
                    'status'       => 'uploaded',
                    'media_json'   => wp_json_encode( $attachments ),
                    'author_id'    => get_current_user_id() ?: 1,
                    'created_at'   => $created_at,
                    'updated_at'   => current_time( 'mysql', true ),
                    'meta_json'    => wp_json_encode( $meta ),
                ]
            );
            if ( false !== $ok ) {
                $id = (int) $wpdb->insert_id;
                $created[] = $id;
                $bundle_map[ $bundle ] = [ [ 'id' => $id, 'status' => 'uploaded', 'meta' => $meta ] ];
            }
        }

        $media_result = $this->sync_media_rows( $drafts );
        $result = [
            'ok'            => true,
            'patch'         => self::PATCH,
            'created_ids'   => $created,
            'updated_ids'   => array_values( array_unique( $updated ) ),
            'skipped'       => $skipped,
            'media_sync'    => $media_result,
            'uploaded_rows' => $this->uploaded_rows(),
        ];
        update_option( 'jksh_v0912_last_sync', [ 'at_utc' => gmdate( 'c' ), 'result' => $result ], false );
        return $result;
    }

    private function draft_by_bundle( array $drafts ) {
        $map = [];
        foreach ( $drafts as $draft ) {
            if ( is_array( $draft ) && ! empty( $draft['bundle_id'] ) ) {
                $map[ strtolower( (string) $draft['bundle_id'] ) ] = $draft;
            }
        }
        return $map;
    }

    private function sync_media_rows( array $drafts = [] ) {
        global $wpdb;
        $t = $this->tables();
        if ( ! $this->table_exists( $t['media'] ) ) {
            return [ 'ok' => false, 'reason' => 'media_table_missing', 'inserted' => 0 ];
        }
        $draft_map = $this->draft_by_bundle( $drafts );
        $rows = $wpdb->get_results( "SELECT id,media_json,meta_json,created_at FROM {$t['content']} ORDER BY id ASC", ARRAY_A );
        $inserted = 0;
        $seen = 0;

        foreach ( (array) $rows as $row ) {
            $content_id = (int) $row['id'];
            $attachments = array_values( array_filter( array_map( 'absint', $this->decode_json( $row['media_json'] ?? '' ) ) ) );
            if ( ! $attachments ) {
                continue;
            }
            $meta   = $this->decode_json( $row['meta_json'] ?? '' );
            $bundle = strtolower( $this->bundle_from_meta( $meta ) );
            $draft  = ( $bundle && isset( $draft_map[ $bundle ] ) ) ? $draft_map[ $bundle ] : null;

            foreach ( $attachments as $index => $attachment_id ) {
                $seen++;
                $exists = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT id FROM {$t['media']} WHERE content_id=%d AND attachment_id=%d LIMIT 1",
                        $content_id,
                        $attachment_id
                    )
                );
                if ( $exists ) {
                    continue;
                }

                $source_type = 'wordpress';
                $meta_row = [ 'origin' => 'content.media_json', 'patch' => self::PATCH ];
                if ( is_array( $draft ) ) {
                    $media_meta = isset( $draft['media_meta'][ $index ] ) && is_array( $draft['media_meta'][ $index ] ) ? $draft['media_meta'][ $index ] : [];
                    if ( ! empty( $media_meta['storage_source'] ) ) {
                        $source_type = sanitize_key( (string) $media_meta['storage_source'] );
                    } elseif ( ! empty( $draft['storage_sources'][ $index ] ) ) {
                        $source_type = sanitize_key( (string) $draft['storage_sources'][ $index ] );
                    }
                    $meta_row['upload_media_meta'] = $media_meta;
                }
                $url = wp_get_attachment_url( $attachment_id );
                $ok = $wpdb->insert(
                    $t['media'],
                    [
                        'content_id'    => $content_id,
                        'attachment_id' => $attachment_id,
                        'source_type'   => $source_type ?: 'wordpress',
                        'source_url'    => $url ? $url : '',
                        'meta_json'     => wp_json_encode( $meta_row ),
                        'sort_order'    => (int) $index,
                        'created_at'    => (string) ( $row['created_at'] ?: current_time( 'mysql', true ) ),
                    ]
                );
                if ( false !== $ok ) {
                    $inserted++;
                }
            }
        }
        return [ 'ok' => true, 'canonical_media_seen' => $seen, 'inserted' => $inserted ];
    }

    private function uploaded_rows() {
        global $wpdb;
        $t = $this->tables();
        $rows = $wpdb->get_results( "SELECT id,title,content_type,status,media_json,meta_json,created_at,updated_at FROM {$t['content']} WHERE status='uploaded' ORDER BY id DESC", ARRAY_A );
        $out = [];
        foreach ( (array) $rows as $row ) {
            $meta = $this->decode_json( $row['meta_json'] ?? '' );
            $snapshot = isset( $meta['upload_snapshot'] ) && is_array( $meta['upload_snapshot'] ) ? $meta['upload_snapshot'] : [];
            $out[] = [
                'content_id'         => (int) $row['id'],
                'title'              => (string) $row['title'],
                'content_type'       => (string) $row['content_type'],
                'status'             => (string) $row['status'],
                'bundle_id'          => $this->bundle_from_meta( $meta ),
                'selected_platforms' => array_values( (array) ( $snapshot['selected_platforms'] ?? [] ) ),
                'media_count'        => count( array_filter( array_map( 'absint', $this->decode_json( $row['media_json'] ?? '' ) ) ) ),
                'cover_attachment_id'=> absint( $snapshot['cover_attachment_id'] ?? 0 ),
                'created_at'         => (string) $row['created_at'],
                'updated_at'         => (string) $row['updated_at'],
            ];
        }
        return $out;
    }

    public function register_abilities() {
        if ( ! function_exists( 'wp_register_ability' ) ) {
            return;
        }
        wp_register_ability(
            'jk-social/list-uploaded-content',
            [
                'label'               => 'List uploaded Social Hub content',
                'description'         => 'Synchronizes Social Upload drafts into stable JK Social Hub Content IDs and returns uploaded-but-not-scheduled items.',
                'category'            => 'jk-social',
                'input_schema'        => [ 'type' => 'object', 'properties' => [], 'additionalProperties' => false ],
                'output_schema'       => [ 'type' => 'object', 'additionalProperties' => true ],
                'execute_callback'    => [ $this, 'ability_list_uploaded_content' ],
                'permission_callback' => [ $this, 'can_manage' ],
                'meta'                => [
                    'show_in_rest' => true,
                    'public'       => true,
                    'annotations'  => [ 'readonly' => false, 'destructive' => false, 'idempotent' => true ],
                ],
            ]
        );

        wp_register_ability(
            'jk-social/queue-content-id',
            [
                'label'               => 'Queue uploaded content by Content ID',
                'description'         => 'Queues one uploaded Social Hub Content ID using its linked Social Upload bundle, while preserving the same stable Content ID.',
                'category'            => 'jk-social',
                'input_schema'        => [
                    'type'                 => 'object',
                    'properties'           => [
                        'content_id'       => [ 'type' => 'integer', 'minimum' => 1 ],
                        'scheduled_at_ist' => [ 'type' => 'string', 'minLength' => 1 ],
                        'platforms'        => [ 'type' => 'array', 'items' => [ 'type' => 'string' ] ],
                        'confirm_live'     => [ 'type' => 'boolean', 'enum' => [ true ] ],
                    ],
                    'required'             => [ 'content_id', 'scheduled_at_ist', 'confirm_live' ],
                    'additionalProperties' => false,
                ],
                'output_schema'       => [ 'type' => 'object', 'additionalProperties' => true ],
                'execute_callback'    => [ $this, 'ability_queue_content_id' ],
                'permission_callback' => [ $this, 'can_manage' ],
                'meta'                => [
                    'show_in_rest' => true,
                    'public'       => true,
                    'annotations'  => [ 'readonly' => false, 'destructive' => false, 'idempotent' => false ],
                ],
            ]
        );
    }

    public function can_manage() {
        return current_user_can( 'manage_options' );
    }

    public function ability_list_uploaded_content() {
        $sync = $this->sync_upload_library();
        if ( is_wp_error( $sync ) ) {
            return $sync;
        }
        return [
            'ok'    => true,
            'patch' => self::PATCH,
            'items' => $this->uploaded_rows(),
            'sync'  => [
                'created_ids' => $sync['created_ids'],
                'updated_ids' => $sync['updated_ids'],
                'media_sync'  => $sync['media_sync'],
            ],
        ];
    }

    private function content_row( $content_id ) {
        global $wpdb;
        $t = $this->tables();
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['content']} WHERE id=%d", $content_id ), ARRAY_A );
    }

    private function products_from_snapshot( array $snapshot ) {
        $products = [];
        $refs = (array) ( $snapshot['product_refs'] ?? [] );
        if ( ! empty( $snapshot['product_url'] ) ) {
            array_unshift( $refs, $snapshot['product_url'] );
        }
        foreach ( array_unique( array_filter( array_map( 'strval', $refs ) ) ) as $ref ) {
            if ( filter_var( $ref, FILTER_VALIDATE_URL ) ) {
                $products[] = [ 'url' => $ref ];
            } else {
                $products[] = [ 'reference' => $ref ];
            }
        }
        return $products;
    }

    private function merge_queued_content_into_stable_id( $stable_id, $new_id, $bundle_id ) {
        global $wpdb;
        if ( $stable_id === $new_id ) {
            return true;
        }
        $t = $this->tables();
        $old = $this->content_row( $stable_id );
        $new = $this->content_row( $new_id );
        if ( ! $old || ! $new ) {
            return new WP_Error( 'jksh_merge_rows_missing', 'Could not reconcile the queued content with the stable Content ID.' );
        }
        if ( 'uploaded' !== (string) $old['status'] ) {
            return new WP_Error( 'jksh_merge_stable_not_uploaded', 'Stable Content ID is no longer in uploaded state.' );
        }

        $old_meta = $this->decode_json( $old['meta_json'] ?? '' );
        $new_meta = $this->decode_json( $new['meta_json'] ?? '' );
        if ( $bundle_id !== $this->bundle_from_meta( $old_meta ) ) {
            return new WP_Error( 'jksh_merge_bundle_mismatch', 'Stable Content ID does not match the queued upload bundle.' );
        }
        $new_meta['bundle_id'] = $bundle_id;
        $new_meta['stable_content_id'] = $stable_id;
        $new_meta['reconciled_from_content_id'] = $new_id;
        $new_meta['upload_snapshot'] = $old_meta['upload_snapshot'] ?? [];
        $new_meta['library_patch'] = self::PATCH;

        $wpdb->query( 'START TRANSACTION' );
        try {
            $ok = $wpdb->update(
                $t['content'],
                [
                    'title'        => $new['title'],
                    'content_type' => $new['content_type'],
                    'body'         => $new['body'],
                    'status'       => $new['status'],
                    'media_json'   => $new['media_json'],
                    'author_id'    => $new['author_id'],
                    'updated_at'   => $new['updated_at'],
                    'meta_json'    => wp_json_encode( $new_meta ),
                ],
                [ 'id' => $stable_id ]
            );
            if ( false === $ok ) {
                throw new RuntimeException( 'Stable content update failed.' );
            }

            foreach ( [ 'variants', 'jobs', 'media', 'logs' ] as $key ) {
                if ( $this->table_exists( $t[ $key ] ) ) {
                    $wpdb->update( $t[ $key ], [ 'content_id' => $stable_id ], [ 'content_id' => $new_id ] );
                }
            }
            if ( $this->table_exists( $t['receipts'] ) ) {
                $wpdb->update( $t['receipts'], [ 'content_id' => $stable_id ], [ 'content_id' => $new_id ] );
            }
            $wpdb->delete( $t['content'], [ 'id' => $new_id ] );
            $wpdb->query( 'COMMIT' );
        } catch ( Throwable $e ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'jksh_stable_id_merge_failed', $e->getMessage() );
        }
        return true;
    }

    public function ability_queue_content_id( $input ) {
        global $wpdb;
        $input = is_array( $input ) ? $input : [];
        $content_id = absint( $input['content_id'] ?? 0 );
        $scheduled  = isset( $input['scheduled_at_ist'] ) ? sanitize_text_field( (string) $input['scheduled_at_ist'] ) : '';
        if ( ! $content_id || '' === $scheduled || true !== (bool) ( $input['confirm_live'] ?? false ) ) {
            return new WP_Error( 'jksh_queue_input_invalid', 'content_id, scheduled_at_ist and confirm_live=true are required.' );
        }

        $this->sync_upload_library();
        $row = $this->content_row( $content_id );
        if ( ! $row ) {
            return new WP_Error( 'jksh_content_not_found', 'Content ID not found.' );
        }
        if ( 'uploaded' !== (string) $row['status'] ) {
            return new WP_Error( 'jksh_content_not_uploaded', 'Only uploaded-but-not-scheduled Content IDs can use this ability.' );
        }
        $meta = $this->decode_json( $row['meta_json'] ?? '' );
        $bundle = strtolower( $this->bundle_from_meta( $meta ) );
        if ( '' === $bundle ) {
            return new WP_Error( 'jksh_bundle_missing', 'This uploaded Content ID is not linked to a Social Upload bundle.' );
        }
        $snapshot = isset( $meta['upload_snapshot'] ) && is_array( $meta['upload_snapshot'] ) ? $meta['upload_snapshot'] : [];
        $platforms = isset( $input['platforms'] ) && is_array( $input['platforms'] )
            ? array_values( array_filter( array_map( 'sanitize_key', $input['platforms'] ) ) )
            : array_values( array_filter( array_map( 'sanitize_key', (array) ( $snapshot['selected_platforms'] ?? [] ) ) ) );

        if ( ! function_exists( 'wp_get_ability' ) ) {
            return new WP_Error( 'jksh_abilities_unavailable', 'WordPress Abilities API is unavailable.' );
        }
        $queue = wp_get_ability( 'jk-social-supabase/queue-upload-draft' );
        if ( ! $queue ) {
            return new WP_Error( 'jksh_queue_ability_missing', 'Social Upload queue ability is unavailable.' );
        }

        $before_max = (int) $wpdb->get_var( 'SELECT MAX(id) FROM ' . $this->tables()['content'] );
        $queue_input = [
            'bundle_id'        => $bundle,
            'title'            => (string) $row['title'],
            'body'             => (string) $row['body'],
            'scheduled_at_ist' => $scheduled,
            'platforms'        => $platforms,
            'products'         => $this->products_from_snapshot( $snapshot ),
            'confirm_live'     => true,
        ];
        $location = $snapshot['location'] ?? '';
        if ( is_string( $location ) && '' !== trim( $location ) ) {
            $queue_input['location'] = [ 'query' => $location, 'text' => $location ];
        } elseif ( is_array( $location ) && $location ) {
            $queue_input['location'] = $location;
        }

        $result = $queue->execute( $queue_input );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        $t = $this->tables();
        $candidates = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$t['content']} WHERE id>%d ORDER BY id DESC",
                $before_max
            ),
            ARRAY_A
        );
        $new_id = 0;
        foreach ( (array) $candidates as $candidate ) {
            $candidate_meta = $this->decode_json( $candidate['meta_json'] ?? '' );
            if ( $bundle === strtolower( $this->bundle_from_meta( $candidate_meta ) ) && 'youtube_community_handoff_v1' !== ( $candidate_meta['workflow'] ?? '' ) ) {
                $new_id = (int) $candidate['id'];
                break;
            }
        }
        if ( ! $new_id ) {
            return new WP_Error( 'jksh_queued_content_not_found', 'Queue completed but the newly created canonical content row could not be identified safely.' );
        }

        $merged = $this->merge_queued_content_into_stable_id( $content_id, $new_id, $bundle );
        if ( is_wp_error( $merged ) ) {
            return $merged;
        }

        $drafts = $this->list_upload_drafts();
        if ( ! is_wp_error( $drafts ) ) {
            $this->sync_media_rows( $drafts );
        }

        return [
            'ok'                 => true,
            'stable_content_id'  => $content_id,
            'bundle_id'          => $bundle,
            'scheduled_at_ist'   => $scheduled,
            'platforms'          => $platforms,
            'queue_result'       => $result,
            'reconciled_row_id'  => $new_id,
            'message'            => 'Queued successfully while preserving the original Content ID.',
        ];
    }

    public function register_rest_routes() {
        register_rest_route(
            'jksh/v1',
            '/maintenance/upload-library-status',
            [
                'methods'             => WP_REST_Server::READABLE,
                'permission_callback' => [ $this, 'can_manage' ],
                'callback'            => [ $this, 'rest_status' ],
            ]
        );
        register_rest_route(
            'jksh/v1',
            '/maintenance/upload-library-sync',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'permission_callback' => [ $this, 'can_manage' ],
                'callback'            => [ $this, 'rest_sync' ],
                'args'                 => [
                    'confirm' => [ 'type' => 'boolean', 'required' => true ],
                ],
            ]
        );
    }

    public function rest_sync( WP_REST_Request $request ) {
        if ( true !== (bool) $request->get_param( 'confirm' ) ) {
            return new WP_Error( 'jksh_confirm_required', 'confirm=true is required.', [ 'status' => 400 ] );
        }
        $result = $this->sync_upload_library();
        return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
    }

    public function rest_status() {
        global $wpdb;
        $t = $this->tables();
        $uploaded = $this->uploaded_rows();
        $media37 = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t['media']} WHERE content_id=%d", 37 ) );
        return rest_ensure_response(
            [
                'ok'             => true,
                'patch'          => self::PATCH,
                'uploaded_count' => count( $uploaded ),
                'uploaded_items' => $uploaded,
                'content_37_media_rows' => $media37,
                'last_sync'      => get_option( 'jksh_v0912_last_sync', [] ),
            ]
        );
    }
}

JKSH_Content_Library_V0912_Upload_Sync::instance();
