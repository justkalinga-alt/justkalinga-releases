<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_UI_V0937 {
    const VERSION = '0.9.3.7';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_footer', [ $this, 'admin_footer' ], 1002 );
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route(
            'jksh/v1',
            '/maintenance/ui-v0937-status',
            [
                'methods' => WP_REST_Server::READABLE,
                'permission_callback' => function () { return current_user_can( 'manage_options' ); },
                'callback' => function () {
                    return rest_ensure_response( [
                        'ok' => true,
                        'patch' => self::VERSION,
                        'youtube_posts_mode' => 'manual_only',
                        'youtube_reels_videos_ui' => 'enabled_by_content_type',
                        'content_library_default_date' => 'today_ist',
                        'content_library_date_modes' => [ 'single', 'range', 'all' ],
                        'content_library_date_ui' => 'compact_mode_switch',
                    ] );
                },
            ]
        );
    }

    public function admin_footer() {
        if ( ! is_admin() ) { return; }

        $page = sanitize_key( (string) ( $_GET['page'] ?? '' ) );
        if ( ! in_array( $page, [ 'jksh-social-upload', 'jksh-composer', 'jksh-content' ], true ) ) {
            return;
        }
        ?>
<style>
.jksh-youtube-manual-note{margin:7px 0 0;font-size:11px;line-height:1.4;font-weight:700;color:#667085}
.jksh-youtube-manual-disabled{opacity:.65}
.jksh-date-filter-v0937{display:flex;align-items:flex-end;gap:8px;flex-wrap:wrap}
.jksh-date-mode-switch{display:flex;align-items:center;gap:4px;padding:4px;border:1px solid #d0d5dd;border-radius:12px;background:#f8fafc}
.jksh-date-mode-switch button{height:32px;padding:0 10px;border:0;border-radius:8px;background:transparent;color:#475467;font-size:11px;font-weight:800;cursor:pointer;white-space:nowrap}
.jksh-date-mode-switch button.is-active{background:#2563eb;color:#fff;box-shadow:0 1px 2px rgba(16,24,40,.08)}
.jksh-date-single-v0937{display:flex;align-items:flex-end}
.jksh-date-single-v0937 label,.jksh-date-range label{display:flex;flex-direction:column;gap:3px;font-size:9px;line-height:1;font-weight:800;letter-spacing:.04em;text-transform:uppercase;color:#667085}
.jksh-date-single-v0937 input[type=date],.jksh-date-range input[type=date]{height:42px;min-width:138px;max-width:152px;padding:0 9px;border:1px solid #d0d5dd;border-radius:10px;background:#fff;color:#101828;box-sizing:border-box}
.jksh-date-range{display:flex;align-items:flex-end;gap:7px}
.jksh-date-all-note{height:42px;display:flex;align-items:center;padding:0 12px;border:1px dashed #cbd5e1;border-radius:10px;background:#f8fafc;color:#475467;font-size:11px;font-weight:800;white-space:nowrap}
@media(max-width:1180px){.jksh-date-filter-v0937{order:5}}
@media(max-width:782px){
  .jksh-date-filter-v0937{width:100%;order:5;align-items:stretch}
  .jksh-date-mode-switch{width:100%;display:grid;grid-template-columns:repeat(3,1fr)}
  .jksh-date-mode-switch button{width:100%;padding:0 6px}
  .jksh-date-single-v0937,.jksh-date-range{width:100%}
  .jksh-date-single-v0937 label,.jksh-date-range label{flex:1}
  .jksh-date-single-v0937 input[type=date],.jksh-date-range input[type=date]{width:100%;max-width:none;min-width:0}
  .jksh-date-all-note{width:100%;box-sizing:border-box}
}
</style>
<script>
(() => {
  const clean = value => String(value || '').toLowerCase().replace(/\s+/g, ' ').trim();

  const classify = raw => {
    const t = clean(raw);
    if (!t) return '';
    if (/reel\s*\/\s*short|long\s*video|\breel\b|\bshort\b|\bvideo\b/.test(t)) return 'video';
    if (/single\s*post|\bcarousel\b|\bimage\b/.test(t)) return 'post';
    return '';
  };

  let rememberedMode = '';

  const rememberCard = node => {
    let el = node && node.nodeType === 1 ? node : node?.parentElement;
    for (let i = 0; el && i < 7; i++, el = el.parentElement) {
      const values = [
        el.getAttribute?.('data-content-type'),
        el.getAttribute?.('data-type'),
        el.getAttribute?.('data-value'),
        el.value,
        (el.textContent || '').trim().slice(0, 120)
      ];
      for (const value of values) {
        const mode = classify(value);
        if (mode) {
          rememberedMode = mode;
          return mode;
        }
      }
    }
    return '';
  };

  const currentContentMode = () => {
    if (rememberedMode) return rememberedMode;

    const selectors = [
      'select[name="content_type"]',
      'input[name="content_type"]:checked',
      'input[type="hidden"][name="content_type"]',
      '[name="content_type"]',
      'select[name="type"]',
      'input[name="type"]:checked',
      'input[type="hidden"][name="type"]',
      '[data-content-type][aria-selected="true"]',
      '[data-content-type][aria-pressed="true"]',
      '[data-type][aria-selected="true"]',
      '[data-type][aria-pressed="true"]'
    ];

    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (!el) continue;
      const value = el.value || el.getAttribute('data-content-type') || el.getAttribute('data-type') || el.textContent || '';
      const mode = classify(value);
      if (mode) return mode;
    }

    const active = Array.from(document.querySelectorAll(
      '[aria-pressed="true"],[aria-selected="true"],[data-selected="true"],.active,.selected,.is-active,.is-selected'
    )).find(el => {
      const text = (el.textContent || '').trim();
      return text.length <= 140 && !!classify(text);
    });

    if (active) {
      const mode = classify(active.textContent || '');
      if (mode) return mode;
    }

    for (const input of Array.from(document.querySelectorAll('input[type="file"]'))) {
      for (const file of Array.from(input.files || [])) {
        if (String(file.type || '').toLowerCase().startsWith('video/')) return 'video';
      }
    }

    return 'post';
  };

  const youtubeBoxes = () => Array.from(document.querySelectorAll('input[type="checkbox"]')).filter(box => {
    if (String(box.value || '').toLowerCase() === 'youtube') return true;
    const label = box.closest('label');
    return !!label && /^\s*youtube\s*$/i.test(label.textContent || '');
  });

  const syncYouTube = () => {
    const video = currentContentMode() === 'video';

    youtubeBoxes().forEach(box => {
      const label = box.closest('label') || box.parentElement;

      if (video) {
        box.disabled = false;
        if (box.dataset.jkshMode !== 'video' && box.dataset.jkshUserTouched !== '1') {
          box.checked = true;
          box.dispatchEvent(new Event('change', { bubbles: true }));
        }
        box.dataset.jkshMode = 'video';
        label?.classList.remove('jksh-youtube-manual-disabled');
      } else {
        box.checked = false;
        box.disabled = true;
        box.dataset.jkshMode = 'post';
        label?.classList.add('jksh-youtube-manual-disabled');
      }

      if (!box.dataset.jkshTouchBound) {
        box.dataset.jkshTouchBound = '1';
        box.addEventListener('change', () => {
          if (!box.disabled) box.dataset.jkshUserTouched = '1';
        });
      }
    });
  };

  const todayIST = () => {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).formatToParts(new Date());
    const map = {};
    parts.forEach(part => { if (part.type !== 'literal') map[part.type] = part.value; });
    return map.year + '-' + map.month + '-' + map.day;
  };

  const setupDateModes = () => {
    const table = document.querySelector('.jksh-content-table');
    const range = document.querySelector('.jksh-date-range');
    if (!table || !range) return;
    if (range.dataset.jkshDateModes === '1') return;

    range.dataset.jkshDateModes = '1';

    const from = range.querySelector('input[name="date_from"]');
    const to = range.querySelector('input[name="date_to"]');
    if (!from || !to) return;

    const form = range.closest('form');
    const wrapper = document.createElement('div');
    wrapper.className = 'jksh-date-filter-v0937';

    const modes = document.createElement('div');
    modes.className = 'jksh-date-mode-switch';
    modes.setAttribute('role', 'group');
    modes.setAttribute('aria-label', 'Date filter mode');

    const singleButton = document.createElement('button');
    singleButton.type = 'button';
    singleButton.dataset.mode = 'single';
    singleButton.textContent = 'Single Date';

    const rangeButton = document.createElement('button');
    rangeButton.type = 'button';
    rangeButton.dataset.mode = 'range';
    rangeButton.textContent = 'From → To';

    const allButton = document.createElement('button');
    allButton.type = 'button';
    allButton.dataset.mode = 'all';
    allButton.textContent = 'All Time';

    modes.append(singleButton, rangeButton, allButton);

    const singleWrap = document.createElement('div');
    singleWrap.className = 'jksh-date-single-v0937';
    const singleLabel = document.createElement('label');
    const singleTitle = document.createElement('span');
    singleTitle.textContent = 'Date';
    const single = document.createElement('input');
    single.type = 'date';
    single.setAttribute('aria-label', 'Single content date');
    singleLabel.append(singleTitle, single);
    singleWrap.append(singleLabel);

    const allNote = document.createElement('div');
    allNote.className = 'jksh-date-all-note';
    allNote.textContent = 'Showing all dates';

    range.insertAdjacentElement('beforebegin', wrapper);
    wrapper.append(modes, singleWrap, range, allNote);

    let mode = (!from.value && !to.value)
      ? 'all'
      : (from.value && to.value && from.value === to.value ? 'single' : 'range');

    single.value = from.value || to.value || todayIST();

    const render = nextMode => {
      mode = nextMode;
      [singleButton, rangeButton, allButton].forEach(button => {
        const active = button.dataset.mode === mode;
        button.classList.toggle('is-active', active);
        button.setAttribute('aria-pressed', active ? 'true' : 'false');
      });

      singleWrap.style.display = mode === 'single' ? 'flex' : 'none';
      range.style.display = mode === 'range' ? 'flex' : 'none';
      allNote.style.display = mode === 'all' ? 'flex' : 'none';

      if (mode === 'single') {
        if (!single.value) single.value = from.value || to.value || todayIST();
        from.value = single.value;
        to.value = single.value;
      } else if (mode === 'range') {
        if (!from.value && !to.value) {
          from.value = todayIST();
          to.value = todayIST();
        } else {
          if (!from.value) from.value = to.value;
          if (!to.value) to.value = from.value;
        }
      } else {
        from.value = '';
        to.value = '';
      }
    };

    singleButton.addEventListener('click', () => render('single'));
    rangeButton.addEventListener('click', () => render('range'));
    allButton.addEventListener('click', () => render('all'));

    single.addEventListener('change', () => {
      if (mode === 'single') {
        from.value = single.value;
        to.value = single.value;
      }
    });

    if (form) {
      form.addEventListener('submit', () => {
        if (mode === 'single') {
          from.value = single.value;
          to.value = single.value;
        } else if (mode === 'all') {
          from.value = '';
          to.value = '';
        }
      });
    }

    render(mode);
  };

  const syncVisibleStats = () => {
    const table = document.querySelector('.jksh-content-table');
    if (!table) return;

    const rows = Array.from(table.querySelectorAll('tbody tr')).filter(row =>
      row.querySelector('td[data-label="Content"]')
    );

    const counts = { total: rows.length, uploaded: 0, scheduled: 0, published: 0, attention: 0 };

    rows.forEach(row => {
      const state = clean(row.querySelector('td[data-label="Workflow"] .badge')?.textContent || '');
      if (state === 'uploaded') counts.uploaded++;
      if (state === 'scheduled' || state === 'part published') counts.scheduled++;
      if (state === 'published') counts.published++;
      if (state === 'needs attention') counts.attention++;
    });

    Object.entries(counts).forEach(([key, value]) => {
      const target = document.querySelector('.jksh-stat-grid .jksh-stat.' + key + ' strong');
      if (target) target.textContent = String(value);
    });
  };

  let queued = false;
  const schedule = () => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      syncYouTube();
      setupDateModes();
      syncVisibleStats();
    });
  };

  document.addEventListener('pointerdown', event => {
    if (rememberCard(event.target)) schedule();
  }, true);

  document.addEventListener('click', event => {
    if (rememberCard(event.target)) schedule();
  }, true);

  document.addEventListener('change', event => {
    const target = event.target;
    if (!target) return;

    const raw = target.value || target.getAttribute?.('data-content-type') || target.getAttribute?.('data-type') || '';
    const mode = classify(raw);
    if (mode) rememberedMode = mode;

    if (
      target.matches?.('select,input[type="radio"],input[type="file"],input[type="hidden"]') ||
      target.name === 'content_type' ||
      target.name === 'type'
    ) {
      schedule();
    }
  }, true);

  syncYouTube();
  setupDateModes();
  syncVisibleStats();
  new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
})();
</script>
        <?php
    }
}

JKSH_UI_V0937::instance();
