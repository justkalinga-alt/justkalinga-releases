<?php
// JKSH_V0915_SCHEDULE_DISPLAY_LOADER
require_once __DIR__ . '/class-jksh-content-library-v0915-schedule-display.php';
if (!defined('ABSPATH')) { exit; }

final class JKSH_Content_Library_V0914_Media_Cleanup {
    const VERSION = '0.9.1.4';
    private static $i = null;
    public static function instance(){ return self::$i ?: (self::$i = new self()); }
    private function __construct(){
        add_action('rest_api_init', [$this,'routes']);
        add_action('admin_init', [$this,'reconcile']);
    }
    private function t(){
        global $wpdb;
        return [
            'c'=>$wpdb->prefix.'jksh_content',
            'j'=>$wpdb->prefix.'jksh_jobs',
            'm'=>$wpdb->prefix.'jksh_media',
            'l'=>$wpdb->prefix.'jksh_publish_logs'
        ];
    }
    public function can(){ return current_user_can('manage_options'); }
    public function routes(){
        register_rest_route('jksh/v1','/content/(?P<id>\\d+)/published-media-preview',[
            'methods'=>'GET','callback'=>[$this,'preview_rest'],'permission_callback'=>[$this,'can']
        ]);
        register_rest_route('jksh/v1','/content/(?P<id>\\d+)/published-media-delete',[
            'methods'=>'POST','callback'=>[$this,'delete_rest'],'permission_callback'=>[$this,'can'],
            'args'=>['confirm'=>['required'=>true,'type'=>'boolean']]
        ]);
        register_rest_route('jksh/v1','/maintenance/media-cleanup-status',[
            'methods'=>'GET','callback'=>[$this,'status_rest'],'permission_callback'=>[$this,'can']
        ]);
    }
    private function ids($raw){
        $v=is_array($raw)?$raw:json_decode((string)$raw,true); if(!is_array($v)) return [];
        $o=[]; array_walk_recursive($v,function($x)use(&$o){ if(is_numeric($x)&&(int)$x>0)$o[]=(int)$x; });
        return array_values(array_unique($o));
    }
    private function hasid($v,$id){
        if(is_array($v)){ foreach($v as $x) if($this->hasid($x,$id)) return true; return false; }
        return is_numeric($v)&&(int)$v===(int)$id;
    }
    private function row($id){
        global $wpdb; $t=$this->t();
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['c']} WHERE id=%d",(int)$id),ARRAY_A);
    }
    private function inspect($id){
        global $wpdb; $t=$this->t(); $id=(int)$id; $r=$this->row($id);
        if(!$r) return new WP_Error('jksh_not_found','Content not found.',['status'=>404]);
        $pub=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['j']} WHERE content_id=%d AND job_type='publish' AND status='published'",$id));
        $active=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['j']} WHERE content_id=%d AND status IN ('queued','processing','pending','retry','community_ready')",$id));
        $ids=$this->ids($r['media_json']??'[]');
        $mi=$wpdb->get_col($wpdb->prepare("SELECT attachment_id FROM {$t['m']} WHERE content_id=%d AND attachment_id>0",$id));
        $ids=array_values(array_unique(array_merge($ids,array_map('intval',$mi))));
        $others=$wpdb->get_results($wpdb->prepare("SELECT id,media_json FROM {$t['c']} WHERE id<>%d",$id),ARRAY_A);
        $jobs=$wpdb->get_results("SELECT id,payload_json FROM {$t['j']} WHERE status IN ('queued','processing','pending','retry','community_ready')",ARRAY_A);
        $ok=[];$blocked=[];
        foreach($ids as $aid){
            $why=[];
            foreach($others as $o) if(in_array($aid,$this->ids($o['media_json']??'[]'),true)) $why[]='shared_with_content_'.(int)$o['id'];
            $shared=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['m']} WHERE attachment_id=%d AND content_id<>%d",$aid,$id));
            if($shared>0)$why[]='shared_media_row';
            foreach($jobs as $j){$p=json_decode((string)($j['payload_json']??''),true);if(is_array($p)&&$this->hasid($p,$aid))$why[]='active_job_'.(int)$j['id'];}
            if(get_post_type($aid)!=='attachment')$why[]='not_wordpress_attachment';
            else{$f=get_attached_file($aid);if(!$f||!file_exists($f))$why[]='no_local_wordpress_file';}
            if($why)$blocked[$aid]=array_values(array_unique($why));else $ok[]=$aid;
        }
        return [
            'ok'=>true,'patch'=>self::VERSION,'content_id'=>$id,'content_status'=>$r['status']??'',
            'published_jobs'=>$pub,'active_jobs'=>$active,'eligible_attachment_ids'=>$ok,
            'blocked_attachment_ids'=>$blocked,'delete_allowed'=>($pub>0&&$active===0&&count($ok)>0),
            'history_preserved'=>true,'external_social_posts_deleted'=>false
        ];
    }
    public function preview_rest($req){ return rest_ensure_response($this->inspect((int)$req['id'])); }
    public function delete_rest($req){
        if(!$req->get_param('confirm')) return new WP_Error('jksh_confirm_required','confirm=true is required.',['status'=>400]);
        global $wpdb; $t=$this->t(); $id=(int)$req['id']; $p=$this->inspect($id);
        if(is_wp_error($p))return $p;
        if(empty($p['delete_allowed'])) return new WP_Error('jksh_delete_blocked','Cleanup blocked by safety checks.',['status'=>409,'preview'=>$p]);
        $deleted=[];$failed=[];
        foreach($p['eligible_attachment_ids'] as $aid){
            if(wp_delete_attachment((int)$aid,true)){
                $deleted[]=(int)$aid;
                $wpdb->delete($t['m'],['content_id'=>$id,'attachment_id'=>(int)$aid],['%d','%d']);
            } else $failed[(int)$aid]='wp_delete_attachment_failed';
        }
        $r=$this->row($id);
        if($r){
            $remain=array_values(array_diff($this->ids($r['media_json']??'[]'),$deleted));
            $meta=json_decode((string)($r['meta_json']??''),true); if(!is_array($meta))$meta=[];
            if(empty($meta['media_cleanup_history'])||!is_array($meta['media_cleanup_history']))$meta['media_cleanup_history']=[];
            $meta['media_cleanup_history'][]=['at_utc'=>gmdate('c'),'deleted_attachment_ids'=>$deleted,'failed'=>$failed,'blocked'=>$p['blocked_attachment_ids'],'actor_user_id'=>get_current_user_id(),'patch'=>self::VERSION];
            $wpdb->update($t['c'],['media_json'=>wp_json_encode($remain),'meta_json'=>wp_json_encode($meta),'updated_at'=>current_time('mysql',true)],['id'=>$id]);
        }
        $wpdb->insert($t['l'],[
            'job_id'=>0,'content_id'=>$id,'variant_id'=>0,'user_id'=>get_current_user_id(),
            'action'=>'delete_published_media','result'=>empty($failed)?'success':'partial',
            'external_id'=>'','external_url'=>'',
            'message'=>'Deleted eligible local WordPress media after publication; social history preserved.',
            'context_json'=>wp_json_encode(['deleted'=>$deleted,'failed'=>$failed,'blocked'=>$p['blocked_attachment_ids'],'patch'=>self::VERSION]),
            'created_at'=>current_time('mysql',true)
        ]);
        return rest_ensure_response(['ok'=>true,'patch'=>self::VERSION,'content_id'=>$id,'deleted_attachment_ids'=>$deleted,'failed'=>$failed,'blocked_attachment_ids'=>$p['blocked_attachment_ids'],'social_posts_deleted'=>false,'history_preserved'=>true]);
    }
    public function reconcile(){
        if(!current_user_can('manage_options'))return;
        global $wpdb;$t=$this->t();
        $ids=$wpdb->get_col("SELECT id FROM {$t['c']} WHERE status IN ('scheduled','queued','processing') ORDER BY id DESC LIMIT 100");
        foreach($ids as $id){
            $id=(int)$id;
            $all=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['j']} WHERE content_id=%d AND job_type='publish'",$id));
            if($all<1)continue;
            $done=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['j']} WHERE content_id=%d AND job_type='publish' AND status='published'",$id));
            $bad=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['j']} WHERE content_id=%d AND job_type='publish' AND status IN ('queued','processing','pending','retry','failed','cancelled')",$id));
            if($done===$all&&$bad===0)$wpdb->update($t['c'],['status'=>'published','updated_at'=>current_time('mysql',true)],['id'=>$id]);
        }
    }
    public function status_rest(){
        global $wpdb;$t=$this->t();
        return rest_ensure_response(['ok'=>true,'patch'=>self::VERSION,'routes'=>true,'ui'=>true,'published_count'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['c']} WHERE status='published'"),'content_32'=>$this->inspect(32)]);
    }
    public function ui(){ return; }

}
JKSH_Content_Library_V0914_Media_Cleanup::instance();
