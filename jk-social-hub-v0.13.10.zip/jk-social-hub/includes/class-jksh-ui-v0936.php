<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_UI_V0936 {
    const VERSION = '0.9.3.6';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_footer', [ $this, 'admin_footer' ], 1001 );
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route(
            'jksh/v1',
            '/maintenance/ui-v0936-status',
            [
                'methods' => WP_REST_Server::READABLE,
                'permission_callback' => function () { return current_user_can( 'manage_options' ); },
                'callback' => function () {
                    return rest_ensure_response( [
                        'ok' => true,
                        'patch' => self::VERSION,
                        'youtube_posts_mode' => 'manual_only',
                        'youtube_reels_videos_ui' => 'enabled_by_content_type',
                        'youtube_ui_detector' => 'content_card_click_v3',
                        'content_library_default_date' => 'today_ist',
                        'content_library_date_picker' => 'single',
                    ] );
                },
            ]
        );
    }

    public function admin_footer() {
        if ( ! is_admin() ) { return; }

        $page = sanitize_key( (string) ( $_GET['page'] ?? '' ) );
        if ( ! in_array( $page, [ 'jksh-social-upload', 'jksh-composer', 'jksh-content' ], true ) ) {
            return;
        }
        ?>
<style>
.jksh-youtube-manual-note{margin:7px 0 0;font-size:11px;line-height:1.4;font-weight:700;color:#667085}
.jksh-youtube-manual-disabled{opacity:.65}
.jksh-date-single{display:flex;align-items:flex-end}
.jksh-date-single label{display:flex;flex-direction:column;gap:3px;font-size:9px;line-height:1;font-weight:800;letter-spacing:.04em;text-transform:uppercase;color:#667085}
.jksh-date-single input[type=date]{height:42px;min-width:145px;max-width:160px;padding:0 9px;border:1px solid #d0d5dd;border-radius:10px;background:#fff;color:#101828;box-sizing:border-box}
@media(max-width:782px){.jksh-date-single{width:100%}.jksh-date-single label{width:100%}.jksh-date-single input[type=date]{width:100%;max-width:none;min-width:0}}
</style>
<script>
(() => {
  const clean = value => String(value || '').toLowerCase().replace(/\s+/g, ' ').trim();

  const classify = raw => {
    const t = clean(raw);
    if (!t) return '';
    if (/reel\s*\/\s*short|long\s*video|\breel\b|\bshort\b|\bvideo\b/.test(t)) return 'video';
    if (/single\s*post|\bcarousel\b|\bimage\b/.test(t)) return 'post';
    return '';
  };

  let rememberedMode = '';

  const rememberCard = node => {
    let el = node && node.nodeType === 1 ? node : node?.parentElement;
    for (let i = 0; el && i < 7; i++, el = el.parentElement) {
      const values = [
        el.getAttribute?.('data-content-type'),
        el.getAttribute?.('data-type'),
        el.getAttribute?.('data-value'),
        el.value,
        (el.textContent || '').trim().slice(0, 120)
      ];
      for (const value of values) {
        const mode = classify(value);
        if (mode) {
          rememberedMode = mode;
          return mode;
        }
      }
    }
    return '';
  };

  const currentMode = () => {
    if (rememberedMode) return rememberedMode;

    const selectors = [
      'select[name="content_type"]',
      'input[name="content_type"]:checked',
      'input[type="hidden"][name="content_type"]',
      '[name="content_type"]',
      'select[name="type"]',
      'input[name="type"]:checked',
      'input[type="hidden"][name="type"]',
      '[data-content-type][aria-selected="true"]',
      '[data-content-type][aria-pressed="true"]',
      '[data-type][aria-selected="true"]',
      '[data-type][aria-pressed="true"]'
    ];

    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (!el) continue;
      const value = el.value || el.getAttribute('data-content-type') || el.getAttribute('data-type') || el.textContent || '';
      const mode = classify(value);
      if (mode) return mode;
    }

    const active = Array.from(document.querySelectorAll(
      '[aria-pressed="true"],[aria-selected="true"],[data-selected="true"],.active,.selected,.is-active,.is-selected'
    )).find(el => {
      const text = (el.textContent || '').trim();
      return text.length <= 140 && !!classify(text);
    });
    if (active) {
      const mode = classify(active.textContent || '');
      if (mode) return mode;
    }

    for (const input of Array.from(document.querySelectorAll('input[type="file"]'))) {
      for (const file of Array.from(input.files || [])) {
        if (String(file.type || '').toLowerCase().startsWith('video/')) return 'video';
      }
    }

    return 'post';
  };

  const youtubeBoxes = () => Array.from(document.querySelectorAll('input[type="checkbox"]')).filter(box => {
    if (String(box.value || '').toLowerCase() === 'youtube') return true;
    const label = box.closest('label');
    return !!label && /^\s*youtube\s*$/i.test(label.textContent || '');
  });

  const syncYouTube = () => {
    const video = currentMode() === 'video';

    youtubeBoxes().forEach(box => {
      const label = box.closest('label') || box.parentElement;

      if (video) {
        box.disabled = false;
        if (box.dataset.jkshMode !== 'video' && box.dataset.jkshUserTouched !== '1') {
          box.checked = true;
          box.dispatchEvent(new Event('change', { bubbles: true }));
        }
        box.dataset.jkshMode = 'video';
        label?.classList.remove('jksh-youtube-manual-disabled');
      } else {
        box.checked = false;
        box.disabled = true;
        box.dataset.jkshMode = 'post';
        label?.classList.add('jksh-youtube-manual-disabled');
      }

      if (!box.dataset.jkshTouchBound) {
        box.dataset.jkshTouchBound = '1';
        box.addEventListener('change', () => {
          if (!box.disabled) box.dataset.jkshUserTouched = '1';
        });
      }
    });
  };

  const setupSingleDate = () => {
    const table = document.querySelector('.jksh-content-table');
    const range = document.querySelector('.jksh-date-range');
    if (!table || !range || range.dataset.jkshSingleDate === '1') return;

    range.dataset.jkshSingleDate = '1';
    const from = range.querySelector('input[name="date_from"]');
    const to = range.querySelector('input[name="date_to"]');
    if (!from || !to) return;

    const form = range.closest('form');
    const initial = (from.value && to.value && from.value === to.value) ? from.value : (from.value || to.value || '');

    from.type = 'hidden';
    to.type = 'hidden';
    from.parentElement.style.display = 'none';
    to.parentElement.style.display = 'none';

    const wrap = document.createElement('div');
    wrap.className = 'jksh-date-single';
    const label = document.createElement('label');
    const title = document.createElement('span');
    title.textContent = 'Date';
    const picker = document.createElement('input');
    picker.type = 'date';
    picker.value = initial;
    picker.setAttribute('aria-label', 'Content date');

    picker.addEventListener('change', () => {
      from.value = picker.value;
      to.value = picker.value;
    });

    label.appendChild(title);
    label.appendChild(picker);
    wrap.appendChild(label);
    range.insertAdjacentElement('beforebegin', wrap);
    range.style.display = 'none';

    if (form) {
      form.addEventListener('submit', () => {
        from.value = picker.value;
        to.value = picker.value;
      });
    }
  };

  const syncVisibleStats = () => {
    const table = document.querySelector('.jksh-content-table');
    if (!table) return;
    const rows = Array.from(table.querySelectorAll('tbody tr')).filter(row => row.querySelector('td[data-label="Content"]'));
    const counts = { total: rows.length, uploaded: 0, scheduled: 0, published: 0, attention: 0 };

    rows.forEach(row => {
      const state = clean(row.querySelector('td[data-label="Workflow"] .badge')?.textContent || '');
      if (state === 'uploaded') counts.uploaded++;
      if (state === 'scheduled' || state === 'part published') counts.scheduled++;
      if (state === 'published') counts.published++;
      if (state === 'needs attention') counts.attention++;
    });

    Object.entries(counts).forEach(([key, value]) => {
      const target = document.querySelector('.jksh-stat-grid .jksh-stat.' + key + ' strong');
      if (target) target.textContent = String(value);
    });
  };

  let queued = false;
  const schedule = () => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      syncYouTube();
      setupSingleDate();
      syncVisibleStats();
    });
  };

  document.addEventListener('pointerdown', event => {
    if (rememberCard(event.target)) schedule();
  }, true);

  document.addEventListener('click', event => {
    if (rememberCard(event.target)) schedule();
  }, true);

  document.addEventListener('change', event => {
    const target = event.target;
    if (!target) return;
    const raw = target.value || target.getAttribute?.('data-content-type') || target.getAttribute?.('data-type') || '';
    const mode = classify(raw);
    if (mode) rememberedMode = mode;
    if (target.matches?.('select,input[type="radio"],input[type="file"],input[type="hidden"]') || target.name === 'content_type' || target.name === 'type') {
      schedule();
    }
  }, true);

  syncYouTube();
  setupSingleDate();
  syncVisibleStats();
  new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
})();
</script>
        <?php
    }
}

JKSH_UI_V0936::instance();
