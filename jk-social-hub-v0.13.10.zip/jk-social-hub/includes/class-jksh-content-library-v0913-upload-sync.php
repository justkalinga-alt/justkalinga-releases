<?php
// JKSH_V0914_MEDIA_CLEANUP_LOADER
require_once __DIR__ . '/class-jksh-content-library-v0914-media-cleanup.php';
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class JKSH_Content_Library_V0913_Upload_Sync {
    private const PATCH = '0.9.1.3';
    private const REST_NS = 'jksh/v1';
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_init', [ $this, 'admin_sync' ], 25 );
        add_action( 'rest_api_init', [ $this, 'register_rest_routes' ] );
        add_action( 'wp_abilities_api_init', [ $this, 'register_abilities' ], 100 );
    }

    public function admin_sync() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( 'jksh-content' !== $page ) {
            return;
        }
        $this->sync_upload_drafts();
        $this->backfill_all_media();
    }

    public function register_rest_routes() {
        register_rest_route(
            self::REST_NS,
            '/library-upload-sync/status',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'rest_status' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ]
        );
        register_rest_route(
            self::REST_NS,
            '/library-upload-sync/run',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [ $this, 'rest_sync' ],
                'permission_callback' => [ $this, 'can_manage' ],
                'args'                => [
                    'confirm' => [ 'type' => 'boolean', 'required' => true ],
                ],
            ]
        );
        register_rest_route(
            self::REST_NS,
            '/content/(?P<id>\\d+)/queue-stable',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [ $this, 'rest_queue_content' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ]
        );
    }

    public function can_manage() {
        return current_user_can( 'manage_options' );
    }

    public function register_abilities() {
        if ( ! function_exists( 'wp_register_ability' ) || ( function_exists( 'wp_has_ability' ) && wp_has_ability( 'jk-social/queue-content-id' ) ) ) {
            return;
        }
        wp_register_ability(
            'jk-social/queue-content-id',
            [
                'label'               => 'Queue Content Library item by Content ID',
                'description'         => 'Schedules an uploaded JK Social Hub Content Library item while preserving the same Content ID. Reuses the existing upload-draft queue path and adopts the generated variants/jobs back into the uploaded record.',
                'category'            => 'jk-social',
                'input_schema'        => [
                    'type'                 => 'object',
                    'additionalProperties' => false,
                    'properties'           => [
                        'content_id'       => [ 'type' => 'integer', 'minimum' => 1 ],
                        'scheduled_at_ist' => [ 'type' => 'string', 'minLength' => 1 ],
                        'platforms'        => [ 'type' => 'array', 'items' => [ 'type' => 'string' ], 'minItems' => 1 ],
                        'title'            => [ 'type' => 'string' ],
                        'body'             => [ 'type' => 'string' ],
                        'platform_fields'  => [ 'type' => 'object', 'additionalProperties' => true ],
                        'location'         => [ 'type' => 'object', 'additionalProperties' => true ],
                        'products'         => [ 'type' => 'array', 'items' => [ 'type' => 'object', 'additionalProperties' => true ] ],
                        'cta'              => [ 'type' => 'string' ],
                        'confirm_live'     => [ 'type' => 'boolean' ],
                    ],
                    'required'             => [ 'content_id', 'scheduled_at_ist', 'confirm_live' ],
                ],
                'execute_callback'    => [ $this, 'ability_queue_content' ],
                'permission_callback' => function () { return current_user_can( 'manage_options' ); },
                'meta'                => [
                    'public'       => true,
                    'show_in_rest' => true,
                    'annotations'  => [
                        'readonly'    => false,
                        'destructive' => false,
                        'idempotent'  => true,
                    ],
                ],
            ]
        );
    }

    public function ability_queue_content( $input ) {
        $input = is_array( $input ) ? $input : [];
        return $this->queue_content_id( $input );
    }

    public function rest_queue_content( WP_REST_Request $request ) {
        $input = $request->get_json_params();
        if ( ! is_array( $input ) ) {
            $input = [];
        }
        $input['content_id'] = absint( $request['id'] );
        $result = $this->queue_content_id( $input );
        return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
    }

    public function rest_status() {
        global $wpdb;
        $t = $this->tables();
        $uploaded = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['content']} WHERE status='uploaded'" );
        $media = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['media']}" );
        return rest_ensure_response( [
            'ok'             => true,
            'patch'          => self::PATCH,
            'uploaded_count' => $uploaded,
            'media_rows'     => $media,
            'ability'        => function_exists( 'wp_has_ability' ) ? (bool) wp_has_ability( 'jk-social/queue-content-id' ) : false,
        ] );
    }

    public function rest_sync( WP_REST_Request $request ) {
        if ( true !== (bool) $request->get_param( 'confirm' ) ) {
            return new WP_Error( 'jksh_confirm_required', 'confirm=true is required.', [ 'status' => 400 ] );
        }
        $sync = $this->sync_upload_drafts();
        $media = $this->backfill_all_media();
        return rest_ensure_response( [ 'ok' => true, 'patch' => self::PATCH, 'sync' => $sync, 'media' => $media ] );
    }

    private function tables() {
        global $wpdb;
        return [
            'content'   => $wpdb->prefix . 'jksh_content',
            'variants'  => $wpdb->prefix . 'jksh_variants',
            'jobs'      => $wpdb->prefix . 'jksh_jobs',
            'media'     => $wpdb->prefix . 'jksh_media',
            'logs'      => $wpdb->prefix . 'jksh_publish_logs',
            'receipts'  => $wpdb->prefix . 'jksh_queue_bridge_receipts',
        ];
    }

    private function table_exists( $table ) {
        global $wpdb;
        return $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
    }

    private function columns( $table ) {
        global $wpdb;
        if ( ! $this->table_exists( $table ) ) {
            return [];
        }
        $rows = $wpdb->get_results( "SHOW COLUMNS FROM {$table}", ARRAY_A );
        return array_values( array_filter( array_map( static function ( $r ) { return isset( $r['Field'] ) ? (string) $r['Field'] : ''; }, (array) $rows ) ) );
    }

    private function json_array( $value ) {
        if ( is_array( $value ) ) {
            return $value;
        }
        if ( ! is_string( $value ) || '' === trim( $value ) ) {
            return [];
        }
        $decoded = json_decode( $value, true );
        return is_array( $decoded ) ? $decoded : [];
    }

    private function is_testish( array $draft ) {
        $hay = implode( ' ', [
            (string) ( $draft['title'] ?? '' ),
            (string) ( $draft['content_type'] ?? '' ),
            (string) ( $draft['instructions'] ?? '' ),
        ] );
        return (bool) preg_match( '/(^|\\b)(qa|test|specimen)(\\b|$)|dry[ -]?run|do not publish|internal qa|internal test/i', $hay );
    }

    private function normalized_type( $type ) {
        $type = sanitize_key( (string) $type );
        if ( 'long_video' === $type ) {
            return 'video';
        }
        return $type ?: 'single_post';
    }

    private function content_matches_bundle( $bundle_id, $exclude_id = 0 ) {
        global $wpdb;
        $t = $this->tables();
        if ( ! $this->table_exists( $t['content'] ) ) {
            return [];
        }
        $like = '%' . $wpdb->esc_like( (string) $bundle_id ) . '%';
        $sql = "SELECT * FROM {$t['content']} WHERE meta_json LIKE %s";
        $args = [ $like ];
        if ( $exclude_id ) {
            $sql .= ' AND id<>%d';
            $args[] = (int) $exclude_id;
        }
        $sql .= " ORDER BY CASE status WHEN 'published' THEN 1 WHEN 'scheduled' THEN 2 WHEN 'community_ready' THEN 3 WHEN 'uploaded' THEN 4 ELSE 5 END, id DESC";
        return (array) $wpdb->get_results( $wpdb->prepare( $sql, ...$args ), ARRAY_A );
    }

    private function call_ability( $name, array $input = [] ) {
        if ( ! function_exists( 'wp_get_ability' ) ) {
            return new WP_Error( 'jksh_abilities_unavailable', 'WordPress Abilities API is unavailable.' );
        }
        $ability = wp_get_ability( $name );
        if ( ! $ability ) {
            return new WP_Error( 'jksh_ability_missing', 'Required ability is not registered: ' . $name );
        }
        return $ability->execute( $input );
    }

    public function sync_upload_drafts() {
        global $wpdb;
        $t = $this->tables();
        if ( ! $this->table_exists( $t['content'] ) ) {
            return [ 'ok' => false, 'error' => 'content_table_missing' ];
        }
        $result = $this->call_ability( 'jk-social-supabase/list-upload-drafts', [] );
        if ( is_wp_error( $result ) ) {
            return [ 'ok' => false, 'error' => $result->get_error_message() ];
        }
        $items = isset( $result['items'] ) && is_array( $result['items'] ) ? $result['items'] : [];
        $created = [];
        $skipped = [];
        foreach ( $items as $draft ) {
            if ( ! is_array( $draft ) || 'uploaded' !== (string) ( $draft['status'] ?? '' ) ) {
                continue;
            }
            $bundle_id = sanitize_text_field( (string) ( $draft['bundle_id'] ?? '' ) );
            if ( '' === $bundle_id ) {
                continue;
            }
            if ( $this->is_testish( $draft ) ) {
                $skipped[] = [ 'bundle_id' => $bundle_id, 'reason' => 'test_or_qa' ];
                continue;
            }
            $existing = $this->content_matches_bundle( $bundle_id );
            if ( $existing ) {
                $skipped[] = [ 'bundle_id' => $bundle_id, 'content_id' => (int) $existing[0]['id'], 'reason' => 'already_represented' ];
                continue;
            }
            $media_ids = array_values( array_filter( array_map( 'absint', (array) ( $draft['attachment_ids'] ?? [] ) ) ) );
            $meta = [
                'source'          => 'social_upload',
                'workflow'        => 'uploaded_draft_v1',
                'bundle_id'       => $bundle_id,
                'upload_snapshot' => $draft,
                'library_patch'   => self::PATCH,
            ];
            $created_at = ! empty( $draft['created_at_utc'] ) ? gmdate( 'Y-m-d H:i:s', strtotime( (string) $draft['created_at_utc'] ) ) : current_time( 'mysql', true );
            $data = [
                'uuid'         => wp_generate_uuid4(),
                'title'        => sanitize_text_field( (string) ( $draft['title'] ?? 'Uploaded content' ) ),
                'content_type' => $this->normalized_type( $draft['content_type'] ?? '' ),
                'body'         => (string) ( $draft['instructions'] ?? '' ),
                'status'       => 'uploaded',
                'media_json'   => wp_json_encode( $media_ids ),
                'meta_json'    => wp_json_encode( $meta ),
                'created_at'   => $created_at,
                'updated_at'   => $created_at,
            ];
            $cols = $this->columns( $t['content'] );
            $data = array_intersect_key( $data, array_flip( $cols ) );
            if ( ! $wpdb->insert( $t['content'], $data ) ) {
                $skipped[] = [ 'bundle_id' => $bundle_id, 'reason' => 'insert_failed', 'error' => $wpdb->last_error ];
                continue;
            }
            $content_id = (int) $wpdb->insert_id;
            $this->backfill_media_for_content( $content_id );
            $created[] = [ 'bundle_id' => $bundle_id, 'content_id' => $content_id ];
        }
        return [ 'ok' => true, 'created' => $created, 'skipped' => $skipped, 'draft_count' => count( $items ) ];
    }

    public function backfill_all_media() {
        global $wpdb;
        $t = $this->tables();
        if ( ! $this->table_exists( $t['content'] ) || ! $this->table_exists( $t['media'] ) ) {
            return [ 'ok' => false, 'error' => 'required_table_missing' ];
        }
        $ids = array_map( 'intval', (array) $wpdb->get_col( "SELECT id FROM {$t['content']} ORDER BY id ASC" ) );
        $inserted = 0;
        foreach ( $ids as $id ) {
            $inserted += $this->backfill_media_for_content( $id );
        }
        return [ 'ok' => true, 'content_count' => count( $ids ), 'inserted' => $inserted ];
    }

    private function backfill_media_for_content( $content_id ) {
        global $wpdb;
        $t = $this->tables();
        if ( ! $this->table_exists( $t['media'] ) ) {
            return 0;
        }
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['content']} WHERE id=%d", $content_id ), ARRAY_A );
        if ( ! $row ) {
            return 0;
        }
        $ids = array_values( array_filter( array_map( 'absint', $this->json_array( $row['media_json'] ?? '[]' ) ) ) );
        if ( ! $ids && $this->table_exists( $t['variants'] ) ) {
            $variant_media = (array) $wpdb->get_col( $wpdb->prepare( "SELECT media_json FROM {$t['variants']} WHERE content_id=%d", $content_id ) );
            foreach ( $variant_media as $json ) {
                foreach ( $this->json_array( $json ) as $mid ) {
                    $mid = absint( $mid );
                    if ( $mid ) {
                        $ids[] = $mid;
                    }
                }
            }
            $ids = array_values( array_unique( $ids ) );
        }
        $meta = $this->json_array( $row['meta_json'] ?? '{}' );
        $snapshot = isset( $meta['upload_snapshot'] ) && is_array( $meta['upload_snapshot'] ) ? $meta['upload_snapshot'] : [];
        $media_meta = isset( $snapshot['media_meta'] ) && is_array( $snapshot['media_meta'] ) ? $snapshot['media_meta'] : [];
        $inserted = 0;
        foreach ( $ids as $order => $attachment_id ) {
            $exists = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t['media']} WHERE content_id=%d AND attachment_id=%d", $content_id, $attachment_id ) );
            if ( $exists ) {
                continue;
            }
            $source_type = 'wordpress_media';
            $upload_meta = [];
            foreach ( $media_meta as $candidate ) {
                if ( is_array( $candidate ) && absint( $candidate['attachment_id'] ?? 0 ) === $attachment_id ) {
                    $upload_meta = $candidate;
                    if ( ! empty( $candidate['storage_source'] ) ) {
                        $source_type = sanitize_key( (string) $candidate['storage_source'] );
                    }
                    break;
                }
            }
            $data = [
                'content_id'    => (int) $content_id,
                'attachment_id' => (int) $attachment_id,
                'source_type'   => $source_type,
                'source_url'    => (string) wp_get_attachment_url( $attachment_id ),
                'meta_json'     => wp_json_encode( [ 'origin' => 'content.media_json', 'patch' => self::PATCH, 'upload_media_meta' => $upload_meta ] ),
                'sort_order'    => (int) $order,
                'created_at'    => isset( $row['created_at'] ) ? $row['created_at'] : current_time( 'mysql', true ),
            ];
            $cols = $this->columns( $t['media'] );
            $data = array_intersect_key( $data, array_flip( $cols ) );
            if ( $wpdb->insert( $t['media'], $data ) ) {
                $inserted++;
            }
        }
        return $inserted;
    }

    private function current_queue_summary( $content_id ) {
        global $wpdb;
        $t = $this->tables();
        $variants = $this->table_exists( $t['variants'] ) ? (array) $wpdb->get_results( $wpdb->prepare( "SELECT id,platform,publication_type,status,publish_at FROM {$t['variants']} WHERE content_id=%d ORDER BY id ASC", $content_id ), ARRAY_A ) : [];
        $jobs = $this->table_exists( $t['jobs'] ) ? (array) $wpdb->get_results( $wpdb->prepare( "SELECT id,variant_id,platform,status,attempts,scheduled_at,last_error FROM {$t['jobs']} WHERE content_id=%d ORDER BY id ASC", $content_id ), ARRAY_A ) : [];
        return [
            'content_id'  => (int) $content_id,
            'variant_ids' => array_map( 'intval', wp_list_pluck( $variants, 'id' ) ),
            'job_ids'     => array_map( 'intval', wp_list_pluck( $jobs, 'id' ) ),
            'variants'    => $variants,
            'jobs'        => $jobs,
        ];
    }

    private function queue_content_id( array $input ) {
        global $wpdb;
        $content_id = absint( $input['content_id'] ?? 0 );
        if ( ! $content_id ) {
            return new WP_Error( 'jksh_missing_content_id', 'A valid content_id is required.' );
        }
        if ( true !== (bool) ( $input['confirm_live'] ?? false ) ) {
            return new WP_Error( 'jksh_confirm_live_required', 'confirm_live=true is required.' );
        }
        $t = $this->tables();
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['content']} WHERE id=%d", $content_id ), ARRAY_A );
        if ( ! $row ) {
            return new WP_Error( 'jksh_content_not_found', 'Content Library item not found.' );
        }
        $meta = $this->json_array( $row['meta_json'] ?? '{}' );
        $bundle_id = sanitize_text_field( (string) ( $meta['bundle_id'] ?? '' ) );
        if ( '' === $bundle_id ) {
            return new WP_Error( 'jksh_not_uploaded_bundle', 'This Content ID is not linked to a Social Upload bundle.' );
        }

        if ( 'uploaded' !== (string) $row['status'] ) {
            return array_merge( [ 'ok' => true, 'status' => (string) $row['status'], 'duplicate_detected' => true, 'message' => 'Content is already beyond uploaded state.' ], $this->current_queue_summary( $content_id ) );
        }

        foreach ( $this->content_matches_bundle( $bundle_id, $content_id ) as $match ) {
            if ( 'uploaded' === (string) $match['status'] ) {
                continue;
            }
            $summary = $this->current_queue_summary( (int) $match['id'] );
            if ( $summary['job_ids'] || $summary['variant_ids'] ) {
                return $this->adopt_scheduled_content( $content_id, (int) $match['id'], $bundle_id, [ 'recovered_existing' => true ] );
            }
        }

        $snapshot = isset( $meta['upload_snapshot'] ) && is_array( $meta['upload_snapshot'] ) ? $meta['upload_snapshot'] : [];
        $platforms = isset( $input['platforms'] ) && is_array( $input['platforms'] ) && $input['platforms'] ? array_values( array_map( 'sanitize_key', $input['platforms'] ) ) : array_values( array_map( 'sanitize_key', (array) ( $snapshot['selected_platforms'] ?? [] ) ) );
        $content_type = sanitize_key( (string) ( $row['content_type'] ?? '' ) );
        $youtube_video_allowed = in_array( $content_type, [ 'mangal_arati', 'reel', 'video', 'short', 'long_video', 'sell_reel', 'knowledge_reel', 'long_knowledge_video' ], true ) || (bool) preg_match( '/(^|_)(reel|video|short)($|_)/', $content_type );
        if ( ! $youtube_video_allowed ) {
            $platforms = array_values( array_diff( $platforms, [ 'youtube' ] ) );
        }
        if ( ! $platforms ) {
            return new WP_Error( 'jksh_missing_platforms', 'At least one platform is required.' );
        }
        $queue_input = [
            'bundle_id'        => $bundle_id,
            'title'            => isset( $input['title'] ) && '' !== (string) $input['title'] ? (string) $input['title'] : (string) $row['title'],
            'body'             => isset( $input['body'] ) ? (string) $input['body'] : (string) $row['body'],
            'scheduled_at_ist' => (string) ( $input['scheduled_at_ist'] ?? '' ),
            'platforms'        => $platforms,
            'confirm_live'     => true,
        ];
        foreach ( [ 'platform_fields', 'location', 'products', 'cta' ] as $optional ) {
            if ( array_key_exists( $optional, $input ) ) {
                $queue_input[ $optional ] = $input[ $optional ];
            }
        }
        if ( '' === $queue_input['scheduled_at_ist'] ) {
            return new WP_Error( 'jksh_missing_schedule', 'scheduled_at_ist is required.' );
        }
        $result = $this->call_ability( 'jk-social-supabase/queue-upload-draft', $queue_input );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        if ( empty( $result['content_id'] ) ) {
            return new WP_Error( 'jksh_queue_missing_content_id', 'Queue path returned no content_id.' );
        }
        $new_id = absint( $result['content_id'] );
        if ( $new_id === $content_id ) {
            return array_merge( [ 'ok' => true, 'content_id' => $content_id, 'stable_content_id' => true ], $result );
        }
        return $this->adopt_scheduled_content( $content_id, $new_id, $bundle_id, $result );
    }

    private function adopt_scheduled_content( $original_id, $generated_id, $bundle_id, array $queue_result ) {
        global $wpdb;
        $t = $this->tables();
        $original = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['content']} WHERE id=%d", $original_id ), ARRAY_A );
        $generated = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['content']} WHERE id=%d", $generated_id ), ARRAY_A );
        if ( ! $original || ! $generated ) {
            return new WP_Error( 'jksh_reconcile_missing_row', 'Unable to find both uploaded and generated scheduled content rows.' );
        }
        $old_meta = $this->json_array( $original['meta_json'] ?? '{}' );
        $new_meta = $this->json_array( $generated['meta_json'] ?? '{}' );
        $new_meta_blob = (string) ( $generated['meta_json'] ?? '' );
        $old_media = array_map( 'absint', $this->json_array( $original['media_json'] ?? '[]' ) );
        $new_media = array_map( 'absint', $this->json_array( $generated['media_json'] ?? '[]' ) );
        if ( false === strpos( $new_meta_blob, $bundle_id ) && ! array_intersect( $old_media, $new_media ) ) {
            return new WP_Error( 'jksh_reconcile_guard_failed', 'Generated scheduled record does not match the uploaded source bundle.' );
        }

        $merged_meta = $new_meta;
        $merged_meta['source'] = 'social_upload';
        $merged_meta['workflow'] = 'stable_content_queue_v1';
        $merged_meta['bundle_id'] = $bundle_id;
        $merged_meta['library_patch'] = self::PATCH;
        $merged_meta['stable_content_id'] = true;
        if ( isset( $old_meta['upload_snapshot'] ) ) {
            $merged_meta['upload_snapshot'] = $old_meta['upload_snapshot'];
        }

        $wpdb->query( 'START TRANSACTION' );
        try {
            if ( $this->table_exists( $t['media'] ) ) {
                $new_media_rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t['media']} WHERE content_id=%d", $generated_id ), ARRAY_A );
                foreach ( $new_media_rows as $mr ) {
                    $aid = absint( $mr['attachment_id'] ?? 0 );
                    if ( $aid && (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t['media']} WHERE content_id=%d AND attachment_id=%d", $original_id, $aid ) ) ) {
                        $wpdb->delete( $t['media'], [ 'id' => (int) $mr['id'] ] );
                    }
                }
                $wpdb->update( $t['media'], [ 'content_id' => $original_id ], [ 'content_id' => $generated_id ] );
            }
            foreach ( [ 'variants', 'jobs', 'logs' ] as $key ) {
                if ( $this->table_exists( $t[ $key ] ) ) {
                    $wpdb->update( $t[ $key ], [ 'content_id' => $original_id ], [ 'content_id' => $generated_id ] );
                }
            }
            if ( $this->table_exists( $t['receipts'] ) ) {
                $wpdb->update( $t['receipts'], [ 'content_id' => $original_id ], [ 'content_id' => $generated_id ] );
            }
            $update = [
                'title'        => (string) $generated['title'],
                'content_type' => (string) $generated['content_type'],
                'body'         => (string) $generated['body'],
                'status'       => (string) $generated['status'],
                'media_json'   => ! empty( $generated['media_json'] ) ? (string) $generated['media_json'] : (string) $original['media_json'],
                'meta_json'    => wp_json_encode( $merged_meta ),
                'updated_at'   => current_time( 'mysql', true ),
            ];
            $cols = $this->columns( $t['content'] );
            $update = array_intersect_key( $update, array_flip( $cols ) );
            if ( false === $wpdb->update( $t['content'], $update, [ 'id' => $original_id ] ) ) {
                throw new RuntimeException( 'Failed to update stable content row: ' . $wpdb->last_error );
            }
            if ( false === $wpdb->delete( $t['content'], [ 'id' => $generated_id ] ) ) {
                throw new RuntimeException( 'Failed to remove generated duplicate content row: ' . $wpdb->last_error );
            }
            $wpdb->query( 'COMMIT' );
        } catch ( Throwable $e ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'jksh_reconcile_failed', $e->getMessage() );
        }
        $this->backfill_media_for_content( $original_id );
        $summary = $this->current_queue_summary( $original_id );
        return array_merge(
            [
                'ok'                      => true,
                'status'                  => 'scheduled',
                'content_id'              => (int) $original_id,
                'stable_content_id'       => true,
                'adopted_from_content_id' => (int) $generated_id,
                'bundle_id'               => $bundle_id,
                'message'                 => 'Scheduled queue adopted into the original uploaded Content ID.',
            ],
            $queue_result,
            $summary,
            [ 'content_id' => (int) $original_id ]
        );
    }
}

JKSH_Content_Library_V0913_Upload_Sync::instance();
