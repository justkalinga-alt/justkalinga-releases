<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_YouTube_Posts_Manual_V0935 {
    const VERSION = '0.9.3.5';
    const MIGRATION_OPTION = 'jksh_youtube_posts_manual_v0935';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'init', [ $this, 'migrate_manual_only' ], 80 );
        add_action( 'admin_menu', [ $this, 'remove_handoff_menus' ], PHP_INT_MAX );
        // v0.9.3.6 owns the Social Upload UI state machine.
        // The v0.9.3.5 footer is intentionally disabled to avoid competing observers.
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    private function tables() {
        global $wpdb;
        return [
            'content'  => $wpdb->prefix . 'jksh_content',
            'variants' => $wpdb->prefix . 'jksh_variants',
            'jobs'     => $wpdb->prefix . 'jksh_jobs',
        ];
    }

    private function table_exists( $table ) {
        global $wpdb;
        return $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
    }

    public function migrate_manual_only() {
        if ( get_option( self::MIGRATION_OPTION ) ) {
            return;
        }

        global $wpdb;
        $t = $this->tables();
        $cancelled = [];

        if ( $this->table_exists( $t['jobs'] ) && $this->table_exists( $t['variants'] ) && $this->table_exists( $t['content'] ) ) {
            $rows = (array) $wpdb->get_results(
                "SELECT id,variant_id,content_id,status FROM {$t['jobs']}
                 WHERE platform='youtube' AND job_type='community_handoff'
                 AND status NOT IN ('published','published_manual','cancelled','failed_manual')
                 ORDER BY id ASC",
                ARRAY_A
            );

            foreach ( $rows as $row ) {
                $job_id = (int) $row['id'];
                $variant_id = (int) $row['variant_id'];
                $content_id = (int) $row['content_id'];
                $now = current_time( 'mysql', true );

                $wpdb->update(
                    $t['jobs'],
                    [
                        'status' => 'cancelled',
                        'last_error' => 'YouTube image/carousel Posts are manual-only from JK Social Hub v0.9.3.5.',
                        'last_response_json' => wp_json_encode( [
                            'reason' => 'youtube_posts_manual_only',
                            'manual_upload_required' => true,
                            'patch' => self::VERSION,
                            'cancelled_at_utc' => $now,
                        ] ),
                        'completed_at' => $now,
                    ],
                    [ 'id' => $job_id ]
                );

                $variant = $wpdb->get_row(
                    $wpdb->prepare( "SELECT fields_json FROM {$t['variants']} WHERE id=%d", $variant_id ),
                    ARRAY_A
                );
                $fields = $variant ? json_decode( (string) ( $variant['fields_json'] ?? '' ), true ) : [];
                $fields = is_array( $fields ) ? $fields : [];
                $fields['manual_required'] = true;
                $fields['manual_upload_required'] = true;
                $fields['auto_publish_pending'] = false;
                $fields['auto_published'] = false;
                $fields['publish_mode'] = 'manual_youtube_posts';
                $fields['target_surface'] = 'youtube_posts_manual';
                $fields['note'] = 'YouTube image/carousel Posts are uploaded manually outside JK Social Hub. Reels/videos remain supported.';

                $wpdb->update(
                    $t['variants'],
                    [
                        'status' => 'cancelled',
                        'fields_json' => wp_json_encode( $fields ),
                    ],
                    [ 'id' => $variant_id ]
                );

                $other_jobs = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$t['jobs']}
                         WHERE content_id=%d AND id<>%d
                         AND status NOT IN ('cancelled','failed_manual')",
                        $content_id,
                        $job_id
                    )
                );
                if ( 0 === $other_jobs ) {
                    $wpdb->update( $t['content'], [ 'status' => 'cancelled' ], [ 'id' => $content_id ] );
                }

                $cancelled[] = $job_id;
            }
        }

        wp_clear_scheduled_hook( 'jksh_community_auto_tick_v0930' );

        update_option(
            self::MIGRATION_OPTION,
            [
                'migrated_at_utc' => gmdate( 'c' ),
                'cancelled_job_ids' => $cancelled,
                'worker_disabled' => true,
                'youtube_posts_mode' => 'manual_only',
            ],
            false
        );
    }

    public function remove_handoff_menus() {
        global $submenu;
        foreach ( [ 'jksh-social-upload', 'jksh-dashboard' ] as $parent ) {
            if ( empty( $submenu[ $parent ] ) || ! is_array( $submenu[ $parent ] ) ) {
                continue;
            }
            foreach ( $submenu[ $parent ] as $index => $item ) {
                $label = isset( $item[0] ) ? wp_strip_all_tags( (string) $item[0] ) : '';
                if ( false !== stripos( $label, 'YouTube Community' ) || false !== stripos( $label, 'Community handoff' ) ) {
                    unset( $submenu[ $parent ][ $index ] );
                }
            }
        }
    }

    public function register_routes() {
        register_rest_route(
            'jksh/v1',
            '/maintenance/youtube-posts-manual-status',
            [
                'methods' => WP_REST_Server::READABLE,
                'permission_callback' => function () { return current_user_can( 'manage_options' ); },
                'callback' => [ $this, 'rest_status' ],
            ]
        );
    }

    public function rest_status() {
        global $wpdb;
        $t = $this->tables();
        $pending = 0;
        if ( $this->table_exists( $t['jobs'] ) ) {
            $pending = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$t['jobs']}
                 WHERE platform='youtube' AND job_type='community_handoff'
                 AND status NOT IN ('published','published_manual','cancelled','failed_manual')"
            );
        }
        return rest_ensure_response( [
            'ok' => true,
            'patch' => self::VERSION,
            'youtube_posts_mode' => 'manual_only',
            'youtube_reels_videos_enabled' => true,
            'community_worker_loaded' => class_exists( 'JKSH_Community_Auto_V0930', false ),
            'pending_community_jobs' => $pending,
            'migration' => get_option( self::MIGRATION_OPTION, [] ),
        ] );
    }

    public function admin_footer() {
        if ( ! is_admin() ) {
            return;
        }

        $page = sanitize_key( (string) ( $_GET['page'] ?? '' ) );
        if ( ! in_array( $page, [ 'jksh-social-upload', 'jksh-composer' ], true ) ) {
            return;
        }
        ?>
<style>
.jksh-youtube-manual-note{margin:7px 0 0;font-size:11px;line-height:1.4;font-weight:700;color:#667085}
.jksh-youtube-manual-disabled{opacity:.65}
</style>
<script>
(() => {
  const isVideoType = value => {
    const v = String(value || '').toLowerCase().replace(/\s+/g, '_');
    return /(^|_)(reel|video|short)($|_)/.test(v) || /mangal_?arati/.test(v);
  };

  const currentType = () => {
    const selectors = [
      'select[name="content_type"]',
      'input[name="content_type"]:checked',
      'select[name="type"]',
      'input[name="type"]:checked',
      '[data-content-type][aria-selected="true"]'
    ];
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (!el) continue;
      const value = el.value || el.getAttribute('data-content-type') || el.textContent || '';
      if (value) return value;
    }
    const files = Array.from(document.querySelectorAll('input[type="file"]'));
    for (const input of files) {
      for (const file of Array.from(input.files || [])) {
        if (String(file.type || '').toLowerCase().startsWith('video/')) return 'video';
      }
    }
    return '';
  };

  const youtubeBoxes = () => Array.from(document.querySelectorAll('input[type="checkbox"]')).filter(box => {
    const value = String(box.value || '').toLowerCase();
    if (value === 'youtube') return true;
    const label = box.closest('label');
    return !!label && /^\s*youtube\s*$/i.test(label.textContent || '');
  });

  const apply = () => {
    const video = isVideoType(currentType());
    const boxes = youtubeBoxes();

    boxes.forEach(box => {
      if (!box.dataset.jkshManualBound) {
        box.dataset.jkshManualBound = '1';
        box.addEventListener('change', () => {
          if (!box.disabled) box.dataset.jkshUserTouched = '1';
        });
      }

      const label = box.closest('label') || box.parentElement;
      if (video) {
        box.disabled = false;
        if (box.dataset.jkshLastMode !== 'video' && box.dataset.jkshUserTouched !== '1') {
          box.checked = true;
        }
        box.dataset.jkshLastMode = 'video';
        if (label) label.classList.remove('jksh-youtube-manual-disabled');
      } else {
        box.checked = false;
        box.disabled = true;
        box.dataset.jkshLastMode = 'manual';
        if (label) label.classList.add('jksh-youtube-manual-disabled');
      }

      if (label && !label.parentElement?.querySelector('.jksh-youtube-manual-note')) {
        const note = document.createElement('div');
        note.className = 'jksh-youtube-manual-note';
        note.textContent = 'YouTube image/carousel Posts are manual. YouTube remains enabled for Reels and videos.';
        label.insertAdjacentElement('afterend', note);
      }
    });

    document.querySelectorAll('#adminmenu a').forEach(link => {
      if (/youtube community|community handoff/i.test((link.textContent || '').trim())) {
        const li = link.closest('li');
        if (li) li.style.display = 'none';
      }
    });
  };

  let queued = false;
  const schedule = () => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      apply();
    });
  };

  document.addEventListener('change', event => {
    const target = event.target;
    if (target && (target.matches('select,input[type="radio"],input[type="file"]') || target.name === 'content_type')) {
      schedule();
    }
  });

  apply();
  new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
})();
</script>
        <?php
    }
}

JKSH_YouTube_Posts_Manual_V0935::instance();
