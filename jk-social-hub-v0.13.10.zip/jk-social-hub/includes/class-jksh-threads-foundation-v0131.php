<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Threads_Foundation_V0131 {
    const VERSION = '0.13.1';
    const OPTION = 'jksh_threads_config';
    const PLATFORM = 'threads';
    const API_HOST = 'https://graph.threads.net';
    const AUTH_HOST = 'https://threads.net/oauth/authorize';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_post_jksh_save_threads_config', [ $this, 'save_config' ] );
        add_action( 'admin_post_jksh_threads_oauth_callback', [ $this, 'callback' ] );
        add_action( 'admin_post_jksh_threads_test_account', [ $this, 'test_account' ] );
        add_action( 'admin_post_jksh_threads_disconnect_account', [ $this, 'disconnect_account' ] );
        add_action( 'rest_api_init', [ $this, 'rest_routes' ] );
        add_action( 'admin_footer', [ $this, 'admin_footer' ], 1110 );
    }

    private function crypto() {
        return new \JKSH\Security\Crypto();
    }

    private function accounts() {
        return new \JKSH\Repositories\AccountRepository();
    }

    private function logs() {
        return new \JKSH\Repositories\LogRepository();
    }

    private function defaults() {
        return [
            'app_id' => '',
            'app_secret_encrypted' => '',
            'threads_use_case_confirmed' => 0,
        ];
    }

    public function config() {
        return wp_parse_args( (array) get_option( self::OPTION, [] ), $this->defaults() );
    }

    public function has_secret() {
        return '' !== (string) ( $this->config()['app_secret_encrypted'] ?? '' );
    }

    public function is_configured() {
        $c = $this->config();
        return '' !== trim( (string) ( $c['app_id'] ?? '' ) )
            && $this->has_secret()
            && ! empty( $c['threads_use_case_confirmed'] );
    }

    public function redirect_uri() {
        return admin_url( 'admin-post.php?action=jksh_threads_oauth_callback' );
    }

    public function scopes() {
        return [ 'threads_basic', 'threads_content_publish' ];
    }

    public function readiness() {
        $rows = $this->accounts()->connected( self::PLATFORM );
        $verified = 0;

        foreach ( $rows as $row ) {
            $settings = $this->accounts()->settings( $row );
            if ( ! empty( $settings['profile_verified_by_api'] ) ) {
                $verified++;
            }
        }

        $settings = new \JKSH\Services\Settings();
        $adapter_ready = $this->is_configured() && $verified > 0;
        $live_possible = $adapter_ready && ! $settings->get( 'dry_run', 1 ) && $settings->get( 'threads_live_publish_enabled', 0 );
        $gate = ! $this->is_configured() ? 'configure_threads_app_first'
            : ( $verified < 1 ? 'connect_and_verify_threads_profile_first'
            : ( $settings->get( 'dry_run', 1 ) ? 'dry_run_is_on'
            : ( ! $settings->get( 'threads_live_publish_enabled', 0 ) ? 'enable_threads_live_publish_switch' : 'ready' ) ) );

        return [
            'ok' => true,
            'phase' => 'v0.13.3-B',
            'platform' => self::PLATFORM,
            'configured' => $this->is_configured(),
            'connected_accounts' => count( $rows ),
            'verified_accounts' => $verified,
            'publisher_enabled' => $adapter_ready,
            'live_publish_possible' => $live_possible,
            'threads_live_publish_enabled' => (bool) $settings->get( 'threads_live_publish_enabled', 0 ),
            'dry_run' => (bool) $settings->get( 'dry_run', 1 ),
            'publisher_gate' => $gate,
            'redirect_uri' => $this->redirect_uri(),
            'scope' => $this->scopes(),
            'api_host' => self::API_HOST,
            'auth_host' => self::AUTH_HOST,
            'supported_post_types' => [ 'TEXT', 'IMAGE', 'VIDEO', 'CAROUSEL' ],
            'native_post_types_next' => [ 'TEXT', 'IMAGE', 'VIDEO', 'CAROUSEL' ],
            'native_fields_next' => [
                'text',
                'image_url',
                'video_url',
                'alt_text',
                'reply_control',
                'topic_tag',
                'link_attachment',
                'quote_post_id',
                'location_id',
                'is_spoiler_media',
            ],
            'requirements' => [
                'Meta app created with the Threads use case',
                'Threads App ID and Threads App Secret saved in JK Social Hub',
                'OAuth redirect URI added exactly in the Meta app',
                'threads_basic and threads_content_publish permissions available to the authorizing account',
            ],
            'note' => $adapter_ready ? 'Native Threads publisher is installed. Live writes still require Dry Run OFF plus the dedicated Threads master switch.' : 'Connect and API-verify a real Threads profile before publishing.',
        ];
    }

    public function save_config() {
        $this->guard( 'jksh_threads_config' );

        $current = $this->config();
        $app_id = sanitize_text_field( wp_unslash( $_POST['app_id'] ?? '' ) );
        $secret = trim( (string) wp_unslash( $_POST['app_secret'] ?? '' ) );

        $next = [
            'app_id' => trim( $app_id ),
            'app_secret_encrypted' => (string) ( $current['app_secret_encrypted'] ?? '' ),
            'threads_use_case_confirmed' => ! empty( $_POST['threads_use_case_confirmed'] ) ? 1 : 0,
        ];

        if ( '' !== $secret ) {
            $next['app_secret_encrypted'] = $this->crypto()->encrypt( $secret );
        }

        update_option( self::OPTION, $next, false );
        $this->redirect( 'success', 'Threads API settings saved securely.' );
    }

    public function auth_url() {
        if ( ! $this->is_configured() ) {
            return '';
        }

        $state = wp_generate_password( 48, false, false );
        set_transient(
            'jksh_threads_state_' . get_current_user_id(),
            hash( 'sha256', $state ),
            15 * MINUTE_IN_SECONDS
        );

        $c = $this->config();

        return add_query_arg(
            [
                'client_id' => (string) $c['app_id'],
                'redirect_uri' => $this->redirect_uri(),
                'scope' => implode( ',', $this->scopes() ),
                'response_type' => 'code',
                'state' => $state,
            ],
            self::AUTH_HOST
        );
    }

    public function callback() {
        if ( ! current_user_can( 'jksh_manage_accounts' ) ) {
            wp_die( esc_html__( 'You do not have permission to manage social accounts.', 'jk-social-hub' ) );
        }

        if ( ! empty( $_GET['error'] ) ) {
            $msg = sanitize_text_field( wp_unslash( $_GET['error_description'] ?? $_GET['error'] ) );
            $this->redirect( 'error', 'Threads authorization was not completed: ' . $msg );
        }

        $code = sanitize_text_field( wp_unslash( $_GET['code'] ?? '' ) );
        $state = sanitize_text_field( wp_unslash( $_GET['state'] ?? '' ) );

        if ( '' === $code || '' === $state ) {
            $this->redirect( 'error', 'Threads OAuth callback was missing authorization data.' );
        }

        $expected = (string) get_transient( 'jksh_threads_state_' . get_current_user_id() );
        delete_transient( 'jksh_threads_state_' . get_current_user_id() );

        if ( '' === $expected || ! hash_equals( $expected, hash( 'sha256', $state ) ) ) {
            $this->redirect( 'error', 'Threads OAuth state validation failed. Start the connection again.' );
        }

        $result = $this->connect_with_code( $code );
        $this->redirect( $result['ok'] ? 'success' : 'error', $result['message'] );
    }

    private function connect_with_code( $code ) {
        if ( ! $this->is_configured() ) {
            return [ 'ok' => false, 'message' => 'Save the Threads App ID, App Secret and Threads-use-case confirmation before connecting.' ];
        }

        $c = $this->config();
        $secret = $this->crypto()->decrypt( (string) $c['app_secret_encrypted'] );

        if ( '' === $secret ) {
            return [ 'ok' => false, 'message' => 'Saved Threads App Secret could not be decrypted.' ];
        }

        $short = $this->decode_response(
            wp_remote_post(
                self::API_HOST . '/oauth/access_token',
                [
                    'timeout' => 30,
                    'body' => [
                        'client_id' => (string) $c['app_id'],
                        'client_secret' => $secret,
                        'code' => $code,
                        'grant_type' => 'authorization_code',
                        'redirect_uri' => $this->redirect_uri(),
                    ],
                ]
            )
        );

        if ( ! $short['ok'] || empty( $short['data']['access_token'] ) ) {
            return [ 'ok' => false, 'message' => 'Threads authorization-code exchange failed: ' . $short['message'] ];
        }

        $short_token = sanitize_text_field( (string) $short['data']['access_token'] );
        $user_id = sanitize_text_field( (string) ( $short['data']['user_id'] ?? '' ) );

        $long = $this->api_get(
            self::API_HOST . '/access_token',
            [
                'grant_type' => 'th_exchange_token',
                'client_secret' => $secret,
                'access_token' => $short_token,
            ]
        );

        if ( ! $long['ok'] || empty( $long['data']['access_token'] ) ) {
            return [ 'ok' => false, 'message' => 'Threads long-lived token exchange failed: ' . $long['message'] ];
        }

        $token = sanitize_text_field( (string) $long['data']['access_token'] );
        $expires_in = max( 0, (int) ( $long['data']['expires_in'] ?? 0 ) );
        $expires_at = $expires_in ? gmdate( 'Y-m-d H:i:s', time() + $expires_in ) : null;

        $profile = $this->api_get(
            self::API_HOST . '/me',
            [
                'fields' => 'id,username,name,threads_profile_picture_url,threads_biography',
                'access_token' => $token,
            ]
        );

        if ( ! $profile['ok'] || empty( $profile['data']['id'] ) ) {
            return [ 'ok' => false, 'message' => 'Threads profile discovery failed: ' . $profile['message'] ];
        }

        $profile_id = sanitize_text_field( (string) $profile['data']['id'] );
        if ( '' === $user_id ) {
            $user_id = $profile_id;
        }

        $username = sanitize_text_field( (string) ( $profile['data']['username'] ?? '' ) );
        $name = sanitize_text_field( (string) ( $profile['data']['name'] ?? $username ) );

        $settings = [
            'threads_user_id' => $profile_id,
            'username' => $username,
            'name' => $name,
            'profile_picture_url' => esc_url_raw( (string) ( $profile['data']['threads_profile_picture_url'] ?? '' ) ),
            'biography' => sanitize_textarea_field( (string) ( $profile['data']['threads_biography'] ?? '' ) ),
            'profile_verified_by_api' => true,
            'required_scopes' => $this->scopes(),
            'connector_phase' => 'v0.13.1-A',
        ];

        $this->accounts()->upsert(
            [
                'platform' => self::PLATFORM,
                'account_name' => $username ? '@' . $username : ( $name ?: 'Threads' ),
                'external_account_id' => $profile_id,
                'status' => 'connected',
                'settings' => $settings,
                'credentials' => [
                    'access_token' => $token,
                    'token_type' => sanitize_text_field( (string) ( $long['data']['token_type'] ?? 'bearer' ) ),
                    'scopes' => $this->scopes(),
                ],
                'token_expires_at' => $expires_at,
                'last_checked_at' => current_time( 'mysql', true ),
                'last_error' => '',
            ]
        );

        $this->logs()->add(
            [
                'action' => 'threads_connect',
                'result' => 'success',
                'message' => 'Threads OAuth and profile discovery completed.',
                'context' => [
                    'threads_user_id' => $profile_id,
                    'username' => $username,
                    'scope' => $this->scopes(),
                    'phase' => 'v0.13.1-A',
                ],
            ]
        );

        return [
            'ok' => true,
            'message' => 'Threads connected and profile verified: ' . ( $username ? '@' . $username : $profile_id ) . '.',
        ];
    }

    public function test_account() {
        $this->guard( 'jksh_threads_test_account' );

        $account_id = absint( $_POST['account_id'] ?? 0 );
        $account = $this->accounts()->get( $account_id );

        if ( ! $account || self::PLATFORM !== (string) $account->platform ) {
            $this->redirect( 'error', 'Threads account was not found.' );
        }

        $token = $this->token_for_account( $account );
        if ( is_wp_error( $token ) ) {
            $message = 'Threads connection test failed: ' . $token->get_error_message();
            $this->accounts()->update_status( $account_id, 'attention', $message );
            $this->redirect( 'error', $message );
        }

        $profile = $this->api_get(
            self::API_HOST . '/me',
            [
                'fields' => 'id,username,name,threads_profile_picture_url,threads_biography',
                'access_token' => (string) $token,
            ]
        );

        if ( ! $profile['ok'] || empty( $profile['data']['id'] ) ) {
            $message = 'Threads connection test failed: ' . $profile['message'];
            $this->accounts()->update_status( $account_id, 'attention', $message );
            $this->redirect( 'error', $message );
        }

        $settings = $this->accounts()->settings( $account );
        $settings['threads_user_id'] = sanitize_text_field( (string) $profile['data']['id'] );
        $settings['username'] = sanitize_text_field( (string) ( $profile['data']['username'] ?? '' ) );
        $settings['name'] = sanitize_text_field( (string) ( $profile['data']['name'] ?? '' ) );
        $settings['profile_picture_url'] = esc_url_raw( (string) ( $profile['data']['threads_profile_picture_url'] ?? '' ) );
        $settings['biography'] = sanitize_textarea_field( (string) ( $profile['data']['threads_biography'] ?? '' ) );
        $settings['profile_verified_by_api'] = true;

        $this->accounts()->upsert(
            [
                'platform' => self::PLATFORM,
                'account_name' => $settings['username'] ? '@' . $settings['username'] : (string) $account->account_name,
                'external_account_id' => (string) $account->external_account_id,
                'status' => 'connected',
                'settings' => $settings,
                'token_expires_at' => $account->token_expires_at,
                'last_checked_at' => current_time( 'mysql', true ),
                'last_error' => '',
            ]
        );

        $this->logs()->add(
            [
                'action' => 'threads_account_test',
                'result' => 'success',
                'message' => 'Threads profile read-only verification succeeded.',
                'context' => [
                    'account_id' => $account_id,
                    'threads_user_id' => (string) $account->external_account_id,
                ],
            ]
        );

        $this->redirect( 'success', 'Threads profile verification succeeded.' );
    }

    private function token_for_account( $account ) {
        $repo = $this->accounts();
        $credentials = $repo->credentials( $account );
        $token = sanitize_text_field( (string) ( $credentials['access_token'] ?? '' ) );

        if ( '' === $token ) {
            return new \WP_Error( 'jksh_threads_token_missing', 'No stored Threads access token is available.' );
        }

        $expires_at = strtotime( (string) ( $account->token_expires_at ?? '' ) . ' UTC' );

        if ( $expires_at && $expires_at > time() + 7 * DAY_IN_SECONDS ) {
            return $token;
        }

        $refreshed = $this->api_get(
            self::API_HOST . '/refresh_access_token',
            [
                'grant_type' => 'th_refresh_token',
                'access_token' => $token,
            ]
        );

        if ( ! $refreshed['ok'] ) {
            if ( $expires_at && $expires_at > time() + 120 ) {
                return $token;
            }
            return new \WP_Error( 'jksh_threads_refresh_failed', 'Threads token refresh failed: ' . $refreshed['message'] );
        }

        $new_token = sanitize_text_field( (string) ( $refreshed['data']['access_token'] ?? $token ) );
        $expires_in = max( 0, (int) ( $refreshed['data']['expires_in'] ?? 5184000 ) );
        $new_expires = gmdate( 'Y-m-d H:i:s', time() + $expires_in );

        $repo->upsert(
            [
                'platform' => self::PLATFORM,
                'account_name' => (string) $account->account_name,
                'external_account_id' => (string) $account->external_account_id,
                'status' => 'connected',
                'settings' => $repo->settings( $account ),
                'credentials' => [
                    'access_token' => $new_token,
                    'token_type' => sanitize_text_field( (string) ( $refreshed['data']['token_type'] ?? $credentials['token_type'] ?? 'bearer' ) ),
                    'scopes' => $credentials['scopes'] ?? $this->scopes(),
                ],
                'token_expires_at' => $new_expires,
                'last_checked_at' => current_time( 'mysql', true ),
                'last_error' => '',
            ]
        );

        return $new_token;
    }

    public function publisher_token_for_account( $account ) {
        return $this->token_for_account( $account );
    }

    public function disconnect_account() {
        $this->guard( 'jksh_threads_disconnect_account' );

        $account_id = absint( $_POST['account_id'] ?? 0 );
        $account = $this->accounts()->get( $account_id );

        if ( ! $account || self::PLATFORM !== (string) $account->platform ) {
            $this->redirect( 'error', 'Threads account was not found.' );
        }

        $this->accounts()->disconnect( $account_id );
        $this->logs()->add(
            [
                'action' => 'threads_disconnect',
                'result' => 'success',
                'message' => 'Threads account disconnected locally.',
                'context' => [
                    'account_id' => $account_id,
                    'threads_user_id' => (string) $account->external_account_id,
                ],
            ]
        );

        $this->redirect( 'success', 'Threads account disconnected locally from JK Social Hub.' );
    }

    private function api_get( $url, $query = [] ) {
        if ( $query ) {
            $url = add_query_arg( $query, $url );
        }

        return $this->decode_response(
            wp_remote_get(
                $url,
                [
                    'timeout' => 30,
                    'headers' => [ 'Accept' => 'application/json' ],
                ]
            )
        );
    }

    private function decode_response( $response ) {
        if ( is_wp_error( $response ) ) {
            return [ 'ok' => false, 'message' => $response->get_error_message(), 'data' => [] ];
        }

        $status = (int) wp_remote_retrieve_response_code( $response );
        $data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        $data = is_array( $data ) ? $data : [];

        if ( $status >= 200 && $status < 300 ) {
            return [ 'ok' => true, 'message' => '', 'data' => $data, 'status' => $status ];
        }

        $message = (string) (
            $data['error']['message']
            ?? $data['error_description']
            ?? $data['error']
            ?? 'Threads API request failed.'
        );

        return [
            'ok' => false,
            'message' => sanitize_textarea_field( $message ),
            'data' => $data,
            'status' => $status,
        ];
    }

    public function rest_routes() {
        register_rest_route(
            'jksh/v1',
            '/threads/readiness',
            [
                'methods' => 'GET',
                'callback' => fn() => rest_ensure_response( $this->readiness() ),
                'permission_callback' => fn() => current_user_can( 'jksh_manage_accounts' ),
            ]
        );

        register_rest_route(
            'jksh/v1',
            '/threads/publisher-switch',
            [
                'methods' => 'POST',
                'callback' => [ $this, 'publisher_switch' ],
                'permission_callback' => fn() => current_user_can( 'jksh_manage_settings' ),
            ]
        );

        register_rest_route(
            'jksh/v1',
            '/threads/publish-probe',
            [
                'methods' => 'POST',
                'callback' => [ $this, 'publish_probe' ],
                'permission_callback' => fn() => current_user_can( 'jksh_publish' ),
            ]
        );
    }

    public function publisher_switch( \WP_REST_Request $request ) {
        if ( true !== (bool) $request->get_param( 'confirm' ) ) {
            return new \WP_Error( 'jksh_threads_switch_confirm', 'confirm=true is required.', [ 'status' => 400 ] );
        }
        $enabled = (bool) $request->get_param( 'enabled' );
        $settings_service = new \JKSH\Services\Settings();
        $settings = $settings_service->all();
        $settings['threads_live_publish_enabled'] = $enabled ? 1 : 0;
        update_option( \JKSH\Services\Settings::OPTION, $settings_service->sanitize( $settings ), false );
        $this->logs()->add( [
            'action' => 'threads_publisher_switch',
            'result' => 'success',
            'message' => $enabled ? 'Threads live publishing master switch enabled.' : 'Threads live publishing master switch disabled.',
            'context' => [ 'enabled' => $enabled, 'release' => '0.13.3' ],
        ] );
        return rest_ensure_response( [ 'ok' => true, 'enabled' => $enabled, 'readiness' => $this->readiness() ] );
    }

    public function publish_probe( \WP_REST_Request $request ) {
        if ( true !== (bool) $request->get_param( 'confirm_live' ) ) {
            return new \WP_Error( 'jksh_threads_probe_confirm', 'confirm_live=true is required.', [ 'status' => 400 ] );
        }
        $settings = new \JKSH\Services\Settings();
        if ( $settings->get( 'dry_run', 1 ) ) {
            return new \WP_Error( 'jksh_threads_probe_dry_run', 'Dry Run is ON. No Threads write was attempted.', [ 'status' => 409 ] );
        }
        if ( ! $settings->get( 'threads_live_publish_enabled', 0 ) ) {
            return new \WP_Error( 'jksh_threads_probe_switch', 'Threads live publishing master switch is OFF.', [ 'status' => 409 ] );
        }
        $ready = $this->readiness();
        if ( empty( $ready['publisher_enabled'] ) ) {
            return new \WP_Error( 'jksh_threads_probe_not_ready', 'Threads publisher is not ready.', [ 'status' => 409 ] );
        }
        $text = sanitize_textarea_field( (string) $request->get_param( 'text' ) );
        if ( '' === trim( $text ) ) {
            return new \WP_Error( 'jksh_threads_probe_text', 'A non-empty Threads test message is required.', [ 'status' => 400 ] );
        }
        $length = function_exists( 'mb_strlen' ) ? mb_strlen( $text ) : strlen( $text );
        if ( $length > 500 ) {
            return new \WP_Error( 'jksh_threads_probe_text_long', 'Threads test message exceeds 500 characters.', [ 'status' => 400 ] );
        }
        $idempotency = sanitize_text_field( (string) $request->get_param( 'idempotency_key' ) );
        if ( '' === $idempotency ) {
            return new \WP_Error( 'jksh_threads_probe_idempotency', 'idempotency_key is required.', [ 'status' => 400 ] );
        }
        $transient_key = 'jksh_threads_probe_' . hash( 'sha256', $idempotency );
        $existing = get_transient( $transient_key );
        if ( is_array( $existing ) && ! empty( $existing['job_id'] ) ) {
            $job = ( new \JKSH\Repositories\JobRepository() )->get( (int) $existing['job_id'] );
            $variant = ( new \JKSH\Repositories\VariantRepository() )->get( (int) ( $existing['variant_id'] ?? 0 ) );
            return rest_ensure_response( [
                'ok' => true,
                'duplicate_safe' => true,
                'content_id' => (int) ( $existing['content_id'] ?? 0 ),
                'variant_id' => (int) ( $existing['variant_id'] ?? 0 ),
                'job_id' => (int) $existing['job_id'],
                'job_status' => $job ? (string) $job->status : 'unknown',
                'external_id' => $variant ? (string) $variant->external_id : '',
                'external_url' => $variant ? (string) $variant->external_url : '',
            ] );
        }

        $content_repo = new \JKSH\Repositories\ContentRepository();
        $variant_repo = new \JKSH\Repositories\VariantRepository();
        $job_repo = new \JKSH\Repositories\JobRepository();
        $content_id = $content_repo->create( [
            'title' => 'Threads publisher verification',
            'content_type' => 'threads_test',
            'body' => $text,
            'status' => 'scheduled',
            'media' => [],
            'meta' => [ 'source' => 'threads_publish_probe', 'release' => '0.13.3' ],
        ] );
        $variant_id = $variant_repo->create( [
            'content_id' => $content_id,
            'platform' => 'threads',
            'publication_type' => 'text',
            'title' => 'Threads publisher verification',
            'caption' => $text,
            'description' => '',
            'hashtags' => '',
            'cta' => '',
            'media' => [],
            'fields' => [ 'text' => $text ],
            'publish_at' => current_time( 'mysql', true ),
            'status' => 'scheduled',
        ] );
        $job_id = $job_repo->create( [
            'content_id' => $content_id,
            'variant_id' => $variant_id,
            'platform' => 'threads',
            'job_type' => 'publish',
            'status' => 'queued',
            'scheduled_at' => current_time( 'mysql', true ),
            'idempotency_key' => hash( 'sha256', 'jksh|threads_probe|' . $idempotency ),
            'payload' => [ 'variant_id' => $variant_id, 'publish_mode' => 'live', 'dry_run' => false, 'source' => 'threads_publish_probe' ],
        ] );
        set_transient( $transient_key, [ 'content_id' => $content_id, 'variant_id' => $variant_id, 'job_id' => $job_id ], DAY_IN_SECONDS );
        $this->logs()->add( [
            'job_id' => $job_id,
            'content_id' => $content_id,
            'variant_id' => $variant_id,
            'action' => 'schedule',
            'result' => 'success',
            'message' => 'Controlled Threads publisher probe queued for LIVE publishing.',
            'context' => [ 'platform' => 'threads', 'publish_mode' => 'live', 'release' => '0.13.3' ],
        ] );
        ( new \JKSH\Queue\Dispatcher() )->process( $job_id );
        $job = $job_repo->get( $job_id );
        $variant = $variant_repo->get( $variant_id );
        return rest_ensure_response( [
            'ok' => true,
            'content_id' => $content_id,
            'variant_id' => $variant_id,
            'job_id' => $job_id,
            'job_status' => $job ? (string) $job->status : 'unknown',
            'external_id' => $variant ? (string) $variant->external_id : '',
            'external_url' => $variant ? (string) $variant->external_url : '',
        ] );
    }

    private function guard( $nonce_action ) {
        if ( ! current_user_can( 'jksh_manage_accounts' ) ) {
            wp_die( esc_html__( 'You do not have permission to manage social accounts.', 'jk-social-hub' ) );
        }
        check_admin_referer( $nonce_action );
    }

    private function redirect( $type, $message ) {
        wp_safe_redirect(
            add_query_arg(
                [
                    'page' => 'jksh-accounts',
                    'jksh_notice' => sanitize_key( $type ),
                    'jksh_msg' => $message,
                ],
                admin_url( 'admin.php' )
            )
        );
        exit;
    }

    public function admin_footer() {
        if ( ! is_admin() || 'jksh-accounts' !== sanitize_key( (string) ( $_GET['page'] ?? '' ) ) ) {
            return;
        }

        $config = $this->config();
        $ready = $this->readiness();
        $accounts = $this->accounts()->connected( self::PLATFORM );
        ?>
        <section id="jksh-threads-foundation-v0131" class="jksh-card" style="display:none">
            <h2>Threads <span class="jksh-badge status-<?php echo esc_attr( $ready['connected_accounts'] ? 'connected' : ( $ready['configured'] ? 'attention' : 'not_connected' ) ); ?>"><?php echo esc_html( $ready['connected_accounts'] ? 'Connected' : 'Tier 2 foundation' ); ?></span></h2>
            <p><strong>v0.13.3:</strong> secure Threads OAuth plus native TEXT, IMAGE, VIDEO and CAROUSEL publishing through the shared JK queue with external read-back verification.</p>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="jksh-form">
                <input type="hidden" name="action" value="jksh_save_threads_config">
                <?php wp_nonce_field( 'jksh_threads_config' ); ?>

                <label><span>Threads App ID</span><input type="text" name="app_id" value="<?php echo esc_attr( $config['app_id'] ); ?>" autocomplete="off" placeholder="Meta App Dashboard → Threads App ID"></label>
                <label><span>Threads App Secret</span><input type="password" name="app_secret" value="" autocomplete="new-password" placeholder="<?php echo $this->has_secret() ? esc_attr__( 'Saved securely — leave blank to keep it', 'jk-social-hub' ) : esc_attr__( 'Enter Threads App Secret', 'jk-social-hub' ); ?>"></label>
                <label class="jksh-check"><input type="checkbox" name="threads_use_case_confirmed" value="1" <?php checked( ! empty( $config['threads_use_case_confirmed'] ) ); ?>> I confirm this Meta app was created/configured with the Threads use case.</label>
                <p><button class="button button-primary">Save Threads settings</button></p>
            </form>

            <hr>
            <h3>OAuth redirect URI</h3>
            <code class="jksh-code-block"><?php echo esc_html( $this->redirect_uri() ); ?></code>

            <h3>Required scopes</h3>
            <p><code><?php echo esc_html( implode( ',', $this->scopes() ) ); ?></code></p>

            <div class="jksh-grid jksh-grid-3">
                <div><strong>Configured</strong><br><?php echo esc_html( $ready['configured'] ? 'Yes' : 'No' ); ?></div>
                <div><strong>Connected profiles</strong><br><?php echo esc_html( (string) $ready['connected_accounts'] ); ?></div>
                <div><strong>API-verified</strong><br><?php echo esc_html( (string) $ready['verified_accounts'] ); ?></div>
            </div>

            <?php if ( $ready['configured'] ) : ?>
                <p><a class="button button-primary button-hero" href="<?php echo esc_url( $this->auth_url() ); ?>">Connect / Reconnect Threads</a></p>
            <?php else : ?>
                <p><button class="button button-primary" disabled>Connect Threads</button></p>
                <p class="description">Create/configure the Meta app with the Threads use case, then save the Threads App ID and App Secret here.</p>
            <?php endif; ?>

            <p class="description"><strong>Safety:</strong> Threads live writes require Dry Run OFF, a verified profile and the dedicated Threads live-publish switch ON. Queued jobs keep their captured publish mode and use duplicate-safe stateful processing.</p>

            <hr>
            <h3>Connected Threads profiles</h3>
            <table class="widefat striped">
                <thead><tr><th>Profile</th><th>User ID</th><th>Verified</th><th>Status</th><th>Token expiry</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if ( ! $accounts ) : ?><tr><td colspan="6">No Threads profile connected yet.</td></tr><?php endif; ?>
                <?php foreach ( $accounts as $account ) : $settings = $this->accounts()->settings( $account ); ?>
                    <tr>
                        <td><strong><?php echo esc_html( $account->account_name ); ?></strong><?php if ( ! empty( $settings['name'] ) ) : ?><br><small><?php echo esc_html( $settings['name'] ); ?></small><?php endif; ?></td>
                        <td><code><?php echo esc_html( $account->external_account_id ); ?></code></td>
                        <td><?php echo ! empty( $settings['profile_verified_by_api'] ) ? 'Yes' : 'No'; ?></td>
                        <td><?php echo esc_html( $account->status ); ?></td>
                        <td><?php echo esc_html( (string) $account->token_expires_at ); ?> UTC</td>
                        <td>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block">
                                <input type="hidden" name="action" value="jksh_threads_test_account">
                                <input type="hidden" name="account_id" value="<?php echo esc_attr( (string) $account->id ); ?>">
                                <?php wp_nonce_field( 'jksh_threads_test_account' ); ?>
                                <button class="button">Test</button>
                            </form>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block" onsubmit="return confirm('Disconnect this Threads profile locally?');">
                                <input type="hidden" name="action" value="jksh_threads_disconnect_account">
                                <input type="hidden" name="account_id" value="<?php echo esc_attr( (string) $account->id ); ?>">
                                <?php wp_nonce_field( 'jksh_threads_disconnect_account' ); ?>
                                <button class="button button-link-delete">Disconnect</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <hr>
            <p><strong>Native publisher:</strong> text, image, video, carousel and alt text are enabled in v0.13.3. Advanced API-backed fields remain available through platform field packs when supported by Meta.</p>
        </section>

        <script>
        (() => {
            const panel = document.getElementById('jksh-threads-foundation-v0131');
            if (!panel) return;

            const cards = Array.from(document.querySelectorAll('.jksh-card'));
            const old = cards.find(card => /Pinterest\s*\/\s*Threads/i.test((card.querySelector('h2')?.textContent || '').trim()));

            if (old) {
                const wrapper = document.createElement('div');
                wrapper.className = 'jksh-grid jksh-grid-2';

                const pinterest = document.createElement('section');
                pinterest.className = 'jksh-card';
                pinterest.innerHTML = '<h2>Pinterest</h2><p>Tier 2 · follows Threads using the same account / queue / verify architecture.</p><span class="jksh-badge status-not_connected">Not connected</span>';

                wrapper.append(panel, pinterest);
                old.replaceWith(wrapper);
                panel.style.display = '';
                return;
            }

            const wrap = document.querySelector('.jksh-wrap');
            if (wrap) {
                wrap.appendChild(panel);
                panel.style.display = '';
            }
        })();
        </script>
        <?php
    }
}

JKSH_Threads_Foundation_V0131::instance();
