<?php
if (!defined('ABSPATH')) { exit; }

final class JKSH_Content_Library_V0923_Media_Control {
    const VERSION = '0.9.2.4';
    private static $instance = null;

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('rest_api_init', [$this, 'routes']);
        add_action('admin_footer', [$this, 'ui']);
    }

    public function can_manage() { return current_user_can('manage_options'); }

    private function tables() {
        global $wpdb;
        return [
            'content' => $wpdb->prefix . 'jksh_content',
            'jobs'    => $wpdb->prefix . 'jksh_jobs',
            'logs'    => $wpdb->prefix . 'jksh_publish_logs',
        ];
    }

    private function j($raw) {
        $v = is_array($raw) ? $raw : json_decode((string)$raw, true);
        return is_array($v) ? $v : [];
    }

    private function contains($value, $needle) {
        if (is_array($value)) {
            foreach ($value as $v) if ($this->contains($v, $needle)) return true;
            return false;
        }
        return is_scalar($value) && (string)$value === (string)$needle;
    }

    private function refs(array $row) {
        $meta = $this->j($row['meta_json'] ?? '{}');
        $snap = isset($meta['upload_snapshot']) && is_array($meta['upload_snapshot']) ? $meta['upload_snapshot'] : [];
        $assets = [];
        foreach ((array)($snap['asset_ids'] ?? []) as $id) {
            $id = sanitize_text_field((string)$id);
            if ($id) $assets[] = $id;
        }
        $cover_asset = sanitize_text_field((string)($snap['cover_asset_id'] ?? ''));
        if ($cover_asset) $assets[] = $cover_asset;
        if (!empty($meta['supabase_asset']['id'])) $assets[] = sanitize_text_field((string)$meta['supabase_asset']['id']);

        return [
            'assets' => array_values(array_unique(array_filter($assets))),
            'cover_attachment_id' => absint($snap['cover_attachment_id'] ?? 0),
        ];
    }

    private function preview($content_id = 0) {
        global $wpdb;
        $t = $this->tables();
        $rows = (array)$wpdb->get_results("SELECT id,status,meta_json FROM {$t['content']} ORDER BY id ASC", ARRAY_A);

        $by_id = [];
        $refs = [];
        foreach ($rows as $row) {
            $id = (int)$row['id'];
            $by_id[$id] = $row;
            $refs[$id] = $this->refs($row);
        }

        $active = (array)$wpdb->get_results(
            "SELECT id,content_id,status,payload_json FROM {$t['jobs']}
             WHERE status IN ('queued','scheduled','processing','pending','retry','retrying','community_ready')",
            ARRAY_A
        );
        $active_by_content = [];
        foreach ($active as $job) {
            $cid = (int)$job['content_id'];
            $active_by_content[$cid] = ($active_by_content[$cid] ?? 0) + 1;
        }

        $targets = [];
        $blocked_contents = [];
        foreach ($rows as $row) {
            $id = (int)$row['id'];
            if ($content_id && $id !== (int)$content_id) continue;
            if (strtolower((string)$row['status']) !== 'published') {
                if ($content_id) $blocked_contents[$id] = 'Media deletion is available after publishing is complete.';
                continue;
            }
            if (!empty($active_by_content[$id])) {
                $blocked_contents[$id] = 'Active scheduled, processing, retry, or Community work still uses this content.';
                continue;
            }
            $targets[] = $id;
        }

        $assets = [];
        $covers = [];
        $blocked_assets = [];
        $blocked_covers = [];

        foreach ($targets as $cid) {
            foreach ($refs[$cid]['assets'] as $asset) {
                $reasons = [];
                foreach ($refs as $other => $r) {
                    if ($other === $cid) continue;
                    if (in_array($asset, $r['assets'], true)) $reasons[] = 'shared_with_content_' . $other;
                }
                foreach ($active as $job) {
                    if ($this->contains($this->j($job['payload_json'] ?? '{}'), $asset)) $reasons[] = 'active_job_' . (int)$job['id'];
                }
                if ($reasons) $blocked_assets[$asset] = array_values(array_unique($reasons));
                else $assets[] = $asset;
            }

            $cover = (int)$refs[$cid]['cover_attachment_id'];
            if ($cover && get_post_type($cover) === 'attachment') {
                $reasons = [];
                foreach ($refs as $other => $r) {
                    if ($other === $cid) continue;
                    if ((int)$r['cover_attachment_id'] === $cover) $reasons[] = 'shared_with_content_' . $other;
                }
                foreach ($active as $job) {
                    if ($this->contains($this->j($job['payload_json'] ?? '{}'), $cover)) $reasons[] = 'active_job_' . (int)$job['id'];
                }
                if ($reasons) $blocked_covers[$cover] = array_values(array_unique($reasons));
                else $covers[] = $cover;
            }
        }

        return [
            'ok' => true,
            'patch' => self::VERSION,
            'target_content_ids' => array_values(array_unique($targets)),
            'blocked_content_ids' => $blocked_contents,
            'eligible_supabase_asset_ids' => array_values(array_unique($assets)),
            'blocked_supabase_asset_ids' => $blocked_assets,
            'eligible_cover_attachment_ids' => array_values(array_unique($covers)),
            'blocked_cover_attachment_ids' => $blocked_covers,
            'external_social_posts_deleted' => false,
            'history_preserved' => true,
        ];
    }

    private function scrub($content_id, array $assets, array $covers) {
        global $wpdb;
        $t = $this->tables();
        $row = $wpdb->get_row($wpdb->prepare("SELECT meta_json FROM {$t['content']} WHERE id=%d", $content_id), ARRAY_A);
        if (!$row) return;

        $meta = $this->j($row['meta_json'] ?? '{}');
        $snap = isset($meta['upload_snapshot']) && is_array($meta['upload_snapshot']) ? $meta['upload_snapshot'] : [];

        if (!empty($snap['asset_ids'])) {
            $snap['asset_ids'] = array_values(array_filter((array)$snap['asset_ids'], fn($id) => $id && !in_array((string)$id, $assets, true)));
        }
        if (in_array((string)($snap['cover_asset_id'] ?? ''), $assets, true) ||
            in_array(absint($snap['cover_attachment_id'] ?? 0), $covers, true)) {
            $snap['cover_attachment_id'] = 0;
            $snap['cover_asset_id'] = '';
            $snap['cover_storage_source'] = '';
            $snap['cover_filename'] = '';
            $snap['cover_meta'] = [];
        }

        $meta['upload_snapshot'] = $snap;
        if (!isset($meta['media_cleanup_history']) || !is_array($meta['media_cleanup_history'])) $meta['media_cleanup_history'] = [];
        $meta['media_cleanup_history'][] = [
            'at_utc' => gmdate('c'),
            'deleted_supabase_asset_ids' => $assets,
            'deleted_cover_attachment_ids' => $covers,
            'actor_user_id' => get_current_user_id(),
            'patch' => self::VERSION,
        ];

        $wpdb->update(
            $t['content'],
            ['meta_json' => wp_json_encode($meta), 'updated_at' => current_time('mysql', true)],
            ['id' => $content_id]
        );
    }

    private function execute(array $preview) {
        global $wpdb;
        $t = $this->tables();

        $assets = (array)$preview['eligible_supabase_asset_ids'];
        $covers = (array)$preview['eligible_cover_attachment_ids'];

        if ($assets && (!class_exists('JKSSB_Bridge') || !is_callable([JKSSB_Bridge::instance(), 'ability_delete_asset']))) {
            return new WP_Error('jksh_supabase_delete_unavailable', 'Supabase deletion is unavailable. No media was deleted.', ['status' => 503]);
        }

        $deleted_assets = [];
        $failed_assets = [];
        foreach ($assets as $asset) {
            $res = JKSSB_Bridge::instance()->ability_delete_asset(['asset_id' => $asset, 'confirm' => true]);
            if (is_wp_error($res) || empty($res['ok'])) $failed_assets[$asset] = is_wp_error($res) ? $res->get_error_message() : 'Delete failed';
            else $deleted_assets[] = $asset;
        }

        if ($failed_assets) {
            return rest_ensure_response([
                'ok' => false,
                'partial' => true,
                'deleted_supabase_asset_ids' => $deleted_assets,
                'failed_supabase_assets' => $failed_assets,
                'deleted_cover_attachment_ids' => [],
                'message' => 'Supabase cleanup was partial, so cover deletion stopped for safety.',
            ]);
        }

        $deleted_covers = [];
        $failed_covers = [];
        foreach ($covers as $aid) {
            if (wp_delete_attachment((int)$aid, true)) $deleted_covers[] = (int)$aid;
            else $failed_covers[(int)$aid] = 'wp_delete_attachment_failed';
        }

        foreach ((array)$preview['target_content_ids'] as $cid) $this->scrub((int)$cid, $deleted_assets, $deleted_covers);

        $wpdb->insert($t['logs'], [
            'job_id' => 0,
            'content_id' => 0,
            'variant_id' => 0,
            'user_id' => get_current_user_id(),
            'action' => 'delete_published_supabase_media',
            'result' => ($failed_covers ? 'partial' : 'success'),
            'external_id' => '',
            'external_url' => '',
            'message' => 'Deleted eligible Supabase assets and cover attachments for fully published content. Social posts and history were preserved.',
            'context_json' => wp_json_encode([
                'target_content_ids' => $preview['target_content_ids'],
                'deleted_supabase_asset_ids' => $deleted_assets,
                'deleted_cover_attachment_ids' => $deleted_covers,
                'failed_covers' => $failed_covers,
                'blocked_assets' => $preview['blocked_supabase_asset_ids'],
                'blocked_covers' => $preview['blocked_cover_attachment_ids'],
                'patch' => self::VERSION,
            ]),
            'created_at' => current_time('mysql', true),
        ]);

        return rest_ensure_response([
            'ok' => !$failed_covers,
            'partial' => (bool)$failed_covers,
            'deleted_supabase_asset_ids' => $deleted_assets,
            'deleted_cover_attachment_ids' => $deleted_covers,
            'failed_cover_attachments' => $failed_covers,
            'external_social_posts_deleted' => false,
            'history_preserved' => true,
        ]);
    }

    public function routes() {
        register_rest_route('jksh/v1', '/published-storage-cleanup-preview', [
            'methods' => 'GET',
            'callback' => fn() => rest_ensure_response($this->preview()),
            'permission_callback' => [$this, 'can_manage'],
        ]);
        register_rest_route('jksh/v1', '/published-storage-cleanup', [
            'methods' => 'POST',
            'callback' => function($req) {
                if (!$req->get_param('confirm')) return new WP_Error('jksh_confirm_required', 'confirm=true is required.', ['status' => 400]);
                return $this->execute($this->preview());
            },
            'permission_callback' => [$this, 'can_manage'],
        ]);
        register_rest_route('jksh/v1', '/content/(?P<id>\d+)/storage-cleanup-preview', [
            'methods' => 'GET',
            'callback' => fn($req) => rest_ensure_response($this->preview((int)$req['id'])),
            'permission_callback' => [$this, 'can_manage'],
        ]);
        register_rest_route('jksh/v1', '/content/(?P<id>\d+)/storage-cleanup', [
            'methods' => 'POST',
            'callback' => function($req) {
                if (!$req->get_param('confirm')) return new WP_Error('jksh_confirm_required', 'confirm=true is required.', ['status' => 400]);
                $p = $this->preview((int)$req['id']);
                if (empty($p['target_content_ids'])) return new WP_Error('jksh_media_locked', 'This task media is locked until publishing is complete.', ['status' => 409, 'preview' => $p]);
                return $this->execute($p);
            },
            'permission_callback' => [$this, 'can_manage'],
        ]);
    }

    public function ui() {
        if (!isset($_GET['page']) || $_GET['page'] !== 'jksh-content') return;
        $nonce = wp_create_nonce('wp_rest');
        ?>
<style>
#jksh-delete-published-media{background:#fff!important;color:#b42318!important;border-color:#fecaca!important}
#jksh-delete-published-media:hover{background:#fff1f2!important;color:#991b1b!important}
.jksh-task-media-delete{border-color:#fda29b!important;color:#b42318!important;background:#fff!important}
.jksh-media-progress{display:none;align-items:center;gap:9px;margin:10px 0 14px;padding:8px 10px;background:#fff;border:1px solid #e4e7ec;border-radius:10px;box-shadow:0 2px 8px rgba(16,24,40,.04)}
.jksh-media-progress.is-visible{display:flex}
.jksh-media-progress-track{position:relative;flex:1;height:5px;overflow:hidden;border-radius:999px;background:#eef2f7;min-width:100px}
.jksh-media-progress-fill{position:absolute;inset:0 auto 0 0;width:0;border-radius:999px;background:linear-gradient(90deg,#2563eb,#60a5fa);transition:width .28s cubic-bezier(.2,.8,.2,1)}
.jksh-media-progress-label{font-size:11px;font-weight:700;color:#475467;white-space:nowrap}
.jksh-media-progress.is-done .jksh-media-progress-fill{background:linear-gradient(90deg,#059669,#34d399)}
@media(max-width:600px){.jksh-media-progress{gap:7px}.jksh-media-progress-label{font-size:10px;max-width:42%;overflow:hidden;text-overflow:ellipsis}.jksh-media-progress-track{height:4px}}
</style>
<script>
(() => {
    const nonce = <?php echo wp_json_encode($nonce); ?>;

    const req = async (url, options={}) => {
        options.headers = Object.assign({'X-WP-Nonce':nonce}, options.headers||{});
        const r = await fetch(url, options);
        let d={}; try{d=await r.json();}catch(e){}
        if(!r.ok) throw new Error(d.message||'Request failed');
        return d;
    };

    const getProgress = () => {
        let box = document.getElementById('jksh-media-progress');
        if (box) return box;
        box = document.createElement('div');
        box.id = 'jksh-media-progress';
        box.className = 'jksh-media-progress';
        box.innerHTML = '<span class="jksh-media-progress-label">Working…</span><span class="jksh-media-progress-track"><span class="jksh-media-progress-fill"></span></span>';
        const mediaGrid = document.querySelector('#jksh-media .media-grid');
        if (mediaGrid && mediaGrid.parentNode) mediaGrid.parentNode.insertBefore(box, mediaGrid);
        else {
            const hero = document.querySelector('.jksh-hero');
            if (hero && hero.parentNode) hero.parentNode.insertBefore(box, hero.nextSibling);
            else document.querySelector('.jkshclm')?.prepend(box);
        }
        return box;
    };

    let hideTimer = null;
    const progress = (label, pct, done=false) => {
        const box = getProgress();
        if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
        box.classList.add('is-visible');
        box.classList.toggle('is-done', !!done);
        box.querySelector('.jksh-media-progress-label').textContent = label;
        box.querySelector('.jksh-media-progress-fill').style.width = Math.max(0,Math.min(100,pct)) + '%';
        if(done) hideTimer=setTimeout(()=>box.classList.remove('is-visible','is-done'),700);
    };

    const failProgress = label => {
        const box=getProgress();
        box.classList.add('is-visible');
        box.classList.remove('is-done');
        box.querySelector('.jksh-media-progress-label').textContent=label;
        box.querySelector('.jksh-media-progress-fill').style.width='100%';
        box.querySelector('.jksh-media-progress-fill').style.background='linear-gradient(90deg,#dc2626,#fb7185)';
        setTimeout(()=>{box.classList.remove('is-visible');box.querySelector('.jksh-media-progress-fill').style.background='';},1400);
    };

    const wireMediaLoading = () => {
        const grid = document.querySelector('#jksh-media .media-grid');
        if(!grid) return;
        const nodes = [...grid.querySelectorAll('img,video')];
        if(!nodes.length) return;
        let done=0;
        const seen=new WeakSet();
        const mark=node=>{
            if(seen.has(node))return;
            seen.add(node);done++;
            const pct=Math.round((done/nodes.length)*100);
            progress(done>=nodes.length?'Media ready':'Loading media '+done+'/'+nodes.length,pct,done>=nodes.length);
        };
        progress('Loading media 0/'+nodes.length,4,false);
        nodes.forEach(node=>{
            if(node.tagName==='IMG'){
                if(node.complete) mark(node);
                else {node.addEventListener('load',()=>mark(node),{once:true});node.addEventListener('error',()=>mark(node),{once:true});}
            }else{
                if(node.readyState>=1) mark(node);
                else {node.addEventListener('loadedmetadata',()=>mark(node),{once:true});node.addEventListener('error',()=>mark(node),{once:true});}
            }
        });
    };

    const wpPreview = id => req('/wp-json/jksh/v1/content/'+id+'/published-media-preview');
    const wpDelete = id => req('/wp-json/jksh/v1/content/'+id+'/published-media-delete',{
        method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirm:true})
    });

    const globalBtn=document.getElementById('jksh-delete-published-media');
    if(globalBtn) globalBtn.onclick=async()=>{
        globalBtn.disabled=true;
        try{
            progress('Checking protected media…',8,false);
            const sp=await req('/wp-json/jksh/v1/published-storage-cleanup-preview');
            const ids=sp.target_content_ids||[];
            let mainCount=0;
            for(let i=0;i<ids.length;i++){
                const p=await wpPreview(ids[i]);
                mainCount+=(p.eligible_attachment_ids||[]).length;
                progress('Checking published media…',8+Math.round(((i+1)/Math.max(1,ids.length))*18),false);
            }
            const supa=(sp.eligible_supabase_asset_ids||[]).length;
            const covers=(sp.eligible_cover_attachment_ids||[]).length;
            const blocked=Object.keys(sp.blocked_supabase_asset_ids||{}).length+Object.keys(sp.blocked_cover_attachment_ids||{}).length;
            if(!mainCount&&!supa&&!covers){progress('Nothing safe to delete',100,true);alert('No published media is currently safe to delete.');return;}
            if(!confirm('Delete all safe media for fully published content?\n\nWordPress source files: '+mainCount+'\nWordPress cover files: '+covers+'\nSupabase assets: '+supa+'\nProtected/shared items skipped: '+blocked+'\n\nPublished social posts and history stay online.')){progress('Cancelled',100,true);return;}
            progress('Deleting Supabase media & covers…',38,false);
            const sr=await req('/wp-json/jksh/v1/published-storage-cleanup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirm:true})});
            let wpDeleted=0;
            progress('Deleting WordPress media…',62,false);
            for(let i=0;i<ids.length;i++){
                const p=await wpPreview(ids[i]);
                if(p.delete_allowed){const d=await wpDelete(ids[i]);wpDeleted+=(d.deleted_attachment_ids||[]).length;}
                progress('Deleting WordPress media…',62+Math.round(((i+1)/Math.max(1,ids.length))*30),false);
            }
            progress('Cleanup complete',100,true);
            setTimeout(()=>{alert('Cleanup finished. WordPress source files: '+wpDeleted+' · Covers: '+((sr.deleted_cover_attachment_ids||[]).length)+' · Supabase assets: '+((sr.deleted_supabase_asset_ids||[]).length)+'.');location.reload();},520);
        }catch(e){failProgress('Cleanup failed');alert(e.message||'Media cleanup failed.');}
        finally{globalBtn.disabled=false;}
    };

    document.querySelectorAll('.jksh-task-media-delete').forEach(btn=>{
        btn.onclick=async()=>{
            const id=Number(btn.dataset.contentId||0);if(!id)return;
            btn.disabled=true;
            try{
                progress('Checking task media…',10,false);
                const sp=await req('/wp-json/jksh/v1/content/'+id+'/storage-cleanup-preview');
                if(!(sp.target_content_ids||[]).length){progress('Media still protected',100,true);alert('Media is locked until this task finishes publishing.');return;}
                const wp=await wpPreview(id);
                const main=(wp.eligible_attachment_ids||[]).length,supa=(sp.eligible_supabase_asset_ids||[]).length,covers=(sp.eligible_cover_attachment_ids||[]).length;
                if(!main&&!supa&&!covers){progress('Nothing left to delete',100,true);alert('No deletable media remains for this task.');return;}
                if(!confirm('Delete this task media?\n\nWordPress source files: '+main+'\nCover files: '+covers+'\nSupabase assets: '+supa+'\n\nExternal posts/history stay online.')){progress('Cancelled',100,true);return;}
                progress('Deleting task storage…',42,false);
                const sr=await req('/wp-json/jksh/v1/content/'+id+'/storage-cleanup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirm:true})});
                progress('Deleting WordPress media…',76,false);
                let wpDeleted=0;const now=await wpPreview(id);if(now.delete_allowed){const d=await wpDelete(id);wpDeleted=(d.deleted_attachment_ids||[]).length;}
                progress('Task cleanup complete',100,true);
                setTimeout(()=>{alert('Task cleanup finished. WordPress source files: '+wpDeleted+' · Covers: '+((sr.deleted_cover_attachment_ids||[]).length)+' · Supabase assets: '+((sr.deleted_supabase_asset_ids||[]).length)+'.');location.reload();},520);
            }catch(e){failProgress('Task cleanup failed');alert(e.message||'Task media cleanup failed.');}
            finally{btn.disabled=false;}
        };
    });

    wireMediaLoading();
})();
</script>
        <?php
    }
}

JKSH_Content_Library_V0923_Media_Control::instance();
