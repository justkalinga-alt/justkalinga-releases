<?php
// JKSH_V0916_ROW_DELETE_MOBILE_LOADER
require_once __DIR__ . '/class-jksh-content-library-v0916-row-delete-mobile.php';
if (!defined('ABSPATH')) { exit; }

final class JKSH_Content_Library_V0915_Schedule_Display {
    const VERSION = '0.9.1.5';
    private static $instance = null;
    public static function instance(){ if(!self::$instance){ self::$instance=new self(); } return self::$instance; }
    private function __construct(){ add_action('rest_api_init',[$this,'register_routes']); add_action('admin_footer',[$this,'inject_ui']); }
    public function can_manage(){ return current_user_can('manage_options'); }
    private function tables(){ global $wpdb; return ['content'=>$wpdb->prefix.'jksh_content','jobs'=>$wpdb->prefix.'jksh_jobs']; }
    private function format_ist($utc){
        if(!$utc) return '';
        try{$dt=new DateTime($utc,new DateTimeZone('UTC'));$dt->setTimezone(new DateTimeZone('Asia/Kolkata'));return $dt->format('j M Y, g:i A').' IST';}
        catch(Throwable $e){return '';}
    }
    private function build_map(){
        global $wpdb; $t=$this->tables();
        $contents=$wpdb->get_results("SELECT id,status FROM {$t['content']} ORDER BY id DESC LIMIT 300",ARRAY_A);
        $jobs=$wpdb->get_results("SELECT id,content_id,platform,job_type,status,scheduled_at FROM {$t['jobs']} WHERE scheduled_at IS NOT NULL ORDER BY scheduled_at ASC,id ASC",ARRAY_A);
        $by=[]; foreach($jobs as $j){$cid=(int)$j['content_id']; if(!isset($by[$cid]))$by[$cid]=[]; $by[$cid][]=$j;}
        $active=['queued','processing','pending','retry']; $map=[];
        foreach($contents as $c){
            $cid=(int)$c['id']; $status=(string)$c['status']; $items=$by[$cid]??[];
            if($status==='uploaded'){ $map[$cid]=['content_id'=>$cid,'status'=>$status,'state'=>'not_scheduled','scheduled_at_utc'=>'','scheduled_at_ist'=>'','display'=>'Not scheduled']; continue; }
            $chosen=null;
            foreach($items as $j){ if($j['job_type']==='publish'&&in_array($j['status'],$active,true)){ $chosen=$j; break; } }
            if(!$chosen&&$status==='community_ready'){ foreach($items as $j){ if($j['job_type']==='community_handoff'&&$j['status']==='community_ready'){ $chosen=$j; break; } } }
            if(!$chosen&&$status==='cancelled'){ foreach($items as $j){ if($j['status']==='cancelled'){ $chosen=$j; break; } } }
            if(!$chosen&&$status==='scheduled'){ foreach($items as $j){ if($j['job_type']==='publish'){ $chosen=$j; break; } } }
            if(!$chosen) continue;
            $ist=$this->format_ist($chosen['scheduled_at']); if(!$ist)continue;
            $state='scheduled'; if($status==='community_ready')$state='community_ready'; elseif($status==='cancelled')$state='cancelled';
            $map[$cid]=['content_id'=>$cid,'status'=>$status,'state'=>$state,'scheduled_at_utc'=>(string)$chosen['scheduled_at'],'scheduled_at_ist'=>$ist,'display'=>$ist,'platform'=>(string)$chosen['platform'],'job_id'=>(int)$chosen['id']];
        }
        return $map;
    }
    public function register_routes(){
        register_rest_route('jksh/v1','/content-library-schedule-map',['methods'=>'GET','callback'=>[$this,'rest_map'],'permission_callback'=>[$this,'can_manage']]);
        register_rest_route('jksh/v1','/maintenance/content-library-schedule-status',['methods'=>'GET','callback'=>[$this,'rest_status'],'permission_callback'=>[$this,'can_manage']]);
    }
    public function rest_map(){ return rest_ensure_response(['ok'=>true,'patch'=>self::VERSION,'timezone'=>'Asia/Kolkata','items'=>$this->build_map()]); }
    public function rest_status(){
        global $wpdb;$t=$this->tables();$map=$this->build_map();
        $uploaded=array_map('intval',$wpdb->get_col("SELECT id FROM {$t['content']} WHERE status='uploaded' ORDER BY id DESC"));
        $scheduled=array_map('intval',$wpdb->get_col("SELECT id FROM {$t['content']} WHERE status='scheduled' ORDER BY id DESC"));
        return rest_ensure_response(['ok'=>true,'patch'=>self::VERSION,'timezone'=>'Asia/Kolkata','uploaded_ids'=>$uploaded,'uploaded_count'=>count($uploaded),'scheduled_ids'=>$scheduled,'scheduled_count'=>count($scheduled),'mapped_ids'=>array_map('intval',array_keys($map)),'content_38'=>$map[38]??null,'content_39'=>$map[39]??null,'content_40'=>$map[40]??null]);
    }
    public function inject_ui(){
        if(!isset($_GET['page'])||$_GET['page']!=='jksh-content')return;
        $nonce=wp_create_nonce('wp_rest');?>
<style>
.jksh-schedule-display{margin-top:7px;font-size:11px;line-height:1.35;font-weight:650;color:#475569;white-space:normal}
.jksh-schedule-display.is-scheduled{color:#6d28d9}.jksh-schedule-display.is-uploaded{color:#2563eb}.jksh-schedule-display.is-community{color:#7c3aed}.jksh-schedule-display.is-cancelled{color:#64748b}
</style>
<script>
(()=>{const nonce=<?php echo wp_json_encode($nonce); ?>;let scheduleMap=null,fetching=false;
const idFromRow=row=>{const t=row.innerText||'';let m=t.match(/Content\s*#?\s*(\d+)/i);if(!m)m=t.match(/Content\s*ID\s*#?\s*(\d+)/i);return m?Number(m[1]):0;};
const decorate=()=>{if(!scheduleMap)return;document.querySelectorAll('tr').forEach(row=>{if(row.querySelector('.jksh-schedule-display'))return;const id=idFromRow(row);if(!id||!scheduleMap[id])return;const item=scheduleMap[id],cells=row.querySelectorAll('td');if(cells.length<2)return;const n=document.createElement('div');n.className='jksh-schedule-display';if(item.state==='not_scheduled'){n.classList.add('is-uploaded');n.textContent='⏳ Not scheduled';}else if(item.state==='community_ready'){n.classList.add('is-community');n.textContent='📌 Handoff: '+item.display;}else if(item.state==='cancelled'){n.classList.add('is-cancelled');n.textContent='🕓 Was scheduled: '+item.display;}else{n.classList.add('is-scheduled');n.textContent='📅 '+item.display;}cells[1].appendChild(n);});};
const load=async()=>{if(fetching||scheduleMap)return;fetching=true;try{const r=await fetch('/wp-json/jksh/v1/content-library-schedule-map',{headers:{'X-WP-Nonce':nonce}}),d=await r.json();if(d&&d.ok&&d.items){scheduleMap=d.items;decorate();}}catch(e){}finally{fetching=false;}};
load();new MutationObserver(()=>scheduleMap?decorate():load()).observe(document.body,{childList:true,subtree:true});})();
</script><?php
    }
}
JKSH_Content_Library_V0915_Schedule_Display::instance();
