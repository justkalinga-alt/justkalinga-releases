<?php
// JKSH_V0918_PUBLISHED_TIME_LOADER
require_once __DIR__ . '/class-jksh-content-library-v0918-published-time.php';
if (!defined('ABSPATH')) { exit; }

final class JKSH_Content_Library_V0916_Row_Delete_Mobile {
    const VERSION = '0.9.2.6';
    private static $instance = null;

    public static function instance(){
        if(!self::$instance){ self::$instance = new self(); }
        return self::$instance;
    }

    private function __construct(){
        add_action('rest_api_init', [$this,'register_routes']);
        add_action('admin_footer', [$this,'inject_ui']);
    }

    public function can_manage(){ return current_user_can('manage_options'); }

    private function tables(){
        global $wpdb;
        return [
            'content'=>$wpdb->prefix.'jksh_content',
            'variants'=>$wpdb->prefix.'jksh_variants',
            'jobs'=>$wpdb->prefix.'jksh_jobs',
            'media'=>$wpdb->prefix.'jksh_media',
            'logs'=>$wpdb->prefix.'jksh_publish_logs',
            'receipts'=>$wpdb->prefix.'jksh_queue_bridge_receipts',
        ];
    }

    private function json_array($raw){
        $v=is_array($raw)?$raw:json_decode((string)$raw,true);
        return is_array($v)?$v:[];
    }

    private function bundle_ids_for_content($id,$row=[]){
        global $wpdb; $t=$this->tables(); $ids=[];
        $meta=$this->json_array($row['meta_json']??'');
        foreach([
            $meta['bundle_id']??'',
            $meta['upload_snapshot']['bundle_id']??'',
        ] as $bid){
            $bid=sanitize_text_field((string)$bid);
            if($bid!=='')$ids[]=$bid;
        }
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$t['receipts']))===$t['receipts']){
            $rids=$wpdb->get_col($wpdb->prepare("SELECT bundle_id FROM {$t['receipts']} WHERE content_id=%d AND bundle_id<>''",$id));
            foreach((array)$rids as $bid){
                $bid=sanitize_text_field((string)$bid);
                if($bid!=='')$ids[]=$bid;
            }
        }
        return array_values(array_unique(array_filter($ids)));
    }

    private function mark_tombstone($id,$bundle_ids,$row){
        $hidden=get_option('jksh_clm_hidden_bundles',[]);
        if(!is_array($hidden))$hidden=[];
        foreach($bundle_ids as $bid) if(!in_array($bid,$hidden,true))$hidden[]=$bid;
        update_option('jksh_clm_hidden_bundles',array_values(array_unique($hidden)),false);

        $archived=get_option('jksh_clm_archived_content',[]);
        if(!is_array($archived))$archived=[];
        if(!in_array((string)$id,array_map('strval',$archived),true))$archived[]=$id;
        update_option('jksh_clm_archived_content',array_values(array_unique($archived)),false);

        $tomb=get_option('jksh_clm_row_tombstones',[]);
        if(!is_array($tomb))$tomb=[];
        if(!isset($tomb['contents'])||!is_array($tomb['contents']))$tomb['contents']=[];
        if(!isset($tomb['bundles'])||!is_array($tomb['bundles']))$tomb['bundles']=[];
        $stamp=[
            'deleted_at_utc'=>gmdate('c'),
            'deleted_by'=>get_current_user_id(),
            'title'=>(string)($row['title']??''),
            'status'=>(string)($row['status']??''),
        ];
        $tomb['contents'][(string)$id]=$stamp;
        foreach($bundle_ids as $bid)$tomb['bundles'][(string)$bid]=array_merge($stamp,['content_id'=>$id]);
        update_option('jksh_clm_row_tombstones',$tomb,false);
    }

    private function preview($content_id){
        global $wpdb; $t=$this->tables(); $id=(int)$content_id;
        $row=$wpdb->get_row($wpdb->prepare("SELECT id,title,status,content_type,meta_json FROM {$t['content']} WHERE id=%d",$id),ARRAY_A);
        if(!$row) return new WP_Error('jksh_not_found','Content row not found.',['status'=>404]);

        $processing=(int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$t['jobs']} WHERE content_id=%d AND status='processing'",
            $id
        ));
        $cancelable=(int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$t['jobs']} WHERE content_id=%d AND status IN ('queued','scheduled','pending','retry','retrying','community_ready')",
            $id
        ));
        $published=(int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$t['jobs']} WHERE content_id=%d AND status='published'",
            $id
        ));
        $bundle_ids=$this->bundle_ids_for_content($id,$row);

        return [
            'ok'=>true,
            'patch'=>self::VERSION,
            'content_id'=>$id,
            'title'=>(string)$row['title'],
            'status'=>(string)$row['status'],
            'content_type'=>(string)$row['content_type'],
            'processing_jobs'=>$processing,
            'cancelable_future_jobs'=>$cancelable,
            'published_jobs'=>$published,
            'bundle_ids'=>$bundle_ids,
            'delete_allowed'=>($processing===0),
            'future_jobs_will_be_cancelled'=>($cancelable>0),
            'external_social_posts_deleted'=>false,
            'wordpress_media_deleted'=>false,
            'permanent_library_tombstone'=>true,
            'warning'=>$processing>0?'A publish job is actively processing. Wait for it to finish before deleting this row.':'',
        ];
    }

    public function register_routes(){
        register_rest_route('jksh/v1','/content/(?P<id>\d+)/library-row-delete-preview',[
            'methods'=>'GET',
            'callback'=>[$this,'preview_rest'],
            'permission_callback'=>[$this,'can_manage']
        ]);
        register_rest_route('jksh/v1','/content/(?P<id>\d+)/library-row-delete',[
            'methods'=>'POST',
            'callback'=>[$this,'delete_rest'],
            'permission_callback'=>[$this,'can_manage'],
            'args'=>['confirm'=>['required'=>true,'type'=>'boolean']]
        ]);
        register_rest_route('jksh/v1','/maintenance/content-library-row-ui-status',[
            'methods'=>'GET',
            'callback'=>[$this,'status_rest'],
            'permission_callback'=>[$this,'can_manage']
        ]);
    }

    public function preview_rest($req){
        return rest_ensure_response($this->preview((int)$req['id']));
    }

    public function delete_rest($req){
        if(!$req->get_param('confirm')){
            return new WP_Error('jksh_confirm_required','confirm=true is required.',['status'=>400]);
        }

        global $wpdb; $t=$this->tables(); $id=(int)$req['id'];
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['content']} WHERE id=%d",$id),ARRAY_A);
        if(!$row)return new WP_Error('jksh_not_found','Content row not found.',['status'=>404]);

        $p=$this->preview($id);
        if(is_wp_error($p))return $p;
        if(empty($p['delete_allowed'])){
            return new WP_Error(
                'jksh_row_delete_processing',
                'This content is actively publishing right now. Wait for the processing job to finish, then delete the row.',
                ['status'=>409,'preview'=>$p]
            );
        }

        $bundle_ids=$this->bundle_ids_for_content($id,$row);
        $this->mark_tombstone($id,$bundle_ids,$row);

        $cancelled_future=(int)$p['cancelable_future_jobs'];
        $deleted=[
            'media_relations'=>0,
            'jobs'=>0,
            'variants'=>0,
            'content'=>0,
        ];

        $wpdb->query('START TRANSACTION');
        try{
            $deleted['media_relations']=(int)$wpdb->delete($t['media'],['content_id'=>$id],['%d']);
            $deleted['jobs']=(int)$wpdb->delete($t['jobs'],['content_id'=>$id],['%d']);
            $deleted['variants']=(int)$wpdb->delete($t['variants'],['content_id'=>$id],['%d']);
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$t['receipts'])) === $t['receipts']) {
                $deleted['receipts']=(int)$wpdb->delete($t['receipts'],['content_id'=>$id],['%d']);
            } else {
                $deleted['receipts']=0;
            }
            $deleted['content']=(int)$wpdb->delete($t['content'],['id'=>$id],['%d']);
            $wpdb->query('COMMIT');
        }catch(Throwable $e){
            $wpdb->query('ROLLBACK');
            return new WP_Error('jksh_row_delete_failed',$e->getMessage(),['status'=>500]);
        }

        $wpdb->insert($t['logs'],[
            'job_id'=>0,
            'content_id'=>0,
            'variant_id'=>0,
            'user_id'=>get_current_user_id(),
            'action'=>'delete_content_library_row',
            'result'=>$deleted['content']===1?'success':'partial',
            'external_id'=>'',
            'external_url'=>'',
            'message'=>'Permanently tombstoned and deleted a JK Social Hub Content Library row. Pending future work was cancelled by removing its jobs. External published social posts and WordPress media files were not deleted.',
            'context_json'=>wp_json_encode([
                'deleted_content_id'=>$id,
                'title'=>$p['title'],
                'status'=>$p['status'],
                'published_jobs_before_delete'=>$p['published_jobs'],
                'future_jobs_cancelled'=>$cancelled_future,
                'bundle_tombstones'=>$bundle_ids,
                'content_tombstone'=>true,
                'deleted'=>$deleted,
                'external_social_posts_deleted'=>false,
                'wordpress_media_deleted'=>false,
                'patch'=>self::VERSION
            ]),
            'created_at'=>current_time('mysql',true)
        ]);

        return rest_ensure_response([
            'ok'=>$deleted['content']===1,
            'patch'=>self::VERSION,
            'content_id'=>$id,
            'deleted'=>$deleted,
            'future_jobs_cancelled'=>$cancelled_future,
            'bundle_tombstones'=>$bundle_ids,
            'permanent_library_tombstone'=>true,
            'external_social_posts_deleted'=>false,
            'wordpress_media_deleted'=>false,
        ]);
    }

    public function status_rest(){
        global $wpdb; $t=$this->tables();
        $tomb=get_option('jksh_clm_row_tombstones',[]);
        if(!is_array($tomb))$tomb=[];
        return rest_ensure_response([
            'ok'=>true,
            'patch'=>self::VERSION,
            'mobile_cards'=>true,
            'delete_row'=>true,
            'uploaded_rows_delete'=>true,
            'scheduled_rows_delete'=>true,
            'community_rows_delete'=>true,
            'published_rows_delete'=>true,
            'processing_rows_protected'=>true,
            'permanent_tombstones'=>true,
            'bundle_lineage_guard'=>true,
            'date_range_filter'=>true,
            'stale_receipts_removed_on_delete'=>true,
            'tombstoned_content_count'=>count((array)($tomb['contents']??[])),
            'tombstoned_bundle_count'=>count((array)($tomb['bundles']??[])),
            'content_count'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['content']}")
        ]);
    }

    public function inject_ui(){
        if(!isset($_GET['page'])||$_GET['page']!=='jksh-content') return;
        $nonce=wp_create_nonce('wp_rest');
        ?>
<style>
.jksh-row-delete{
    margin-left:8px!important;
    border-color:#ef4444!important;
    color:#b91c1c!important;
    background:#fff!important;
}
.jksh-row-delete:hover{background:#fff1f2!important;color:#991b1b!important;border-color:#dc2626!important}

@media (max-width: 782px){
    body.toplevel_page_jksh-content #wpcontent,
    body[class*="jksh-content"] #wpcontent{padding-left:0!important}
    table.jksh-mobile-library-table{display:block!important;width:100%!important;border:0!important;background:transparent!important}
    table.jksh-mobile-library-table thead{display:none!important}
    table.jksh-mobile-library-table tbody{display:flex!important;flex-direction:column!important;gap:12px!important;width:100%!important}
    table.jksh-mobile-library-table tr{display:block!important;width:100%!important;box-sizing:border-box!important;padding:14px!important;margin:0!important;border:1px solid #e5e7eb!important;border-radius:14px!important;background:#fff!important;box-shadow:0 1px 2px rgba(15,23,42,.05)!important}
    table.jksh-mobile-library-table td{display:grid!important;grid-template-columns:92px minmax(0,1fr)!important;gap:10px!important;align-items:start!important;width:100%!important;box-sizing:border-box!important;padding:7px 0!important;border:0!important;white-space:normal!important;text-align:left!important}
    table.jksh-mobile-library-table td::before{content:attr(data-jksh-label);display:block;font-size:10px!important;line-height:1.3!important;font-weight:800!important;letter-spacing:.04em!important;text-transform:uppercase!important;color:#64748b!important}
    table.jksh-mobile-library-table td:first-child{display:block!important;padding-top:0!important;padding-bottom:10px!important;border-bottom:1px solid #eef2f7!important}
    table.jksh-mobile-library-table td:first-child::before{display:none!important}
    table.jksh-mobile-library-table td:last-child{display:flex!important;grid-template-columns:none!important;gap:8px!important;flex-wrap:wrap!important;padding-top:12px!important;border-top:1px solid #eef2f7!important}
    table.jksh-mobile-library-table td:last-child::before{display:none!important}
    table.jksh-mobile-library-table td:last-child .button,
    table.jksh-mobile-library-table td:last-child a.button{flex:1 1 130px!important;min-height:40px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;margin:0!important}
    .jksh-schedule-display{margin-top:4px!important}
}
</style>
<script>
(() => {
    const nonce=<?php echo wp_json_encode($nonce); ?>;

    const contentIdFromRow = row => {
        const text=row.innerText||'';
        let m=text.match(/Content\s*#?\s*(\d+)/i);
        if(!m)m=text.match(/Content\s*ID\s*#?\s*(\d+)/i);
        return m?Number(m[1]):0;
    };

    const enhanceTable = () => {
        document.querySelectorAll('table').forEach(table => {
            const head=(table.querySelector('thead')?.innerText||'').toLowerCase();
            if(!(head.includes('content')&&head.includes('workflow')&&head.includes('platform')&&head.includes('media')&&head.includes('created'))) return;

            table.classList.add('jksh-mobile-library-table');
            const headers=Array.from(table.querySelectorAll('thead th')).map(th=>(th.innerText||'').trim());

            table.querySelectorAll('tbody tr').forEach(row => {
                const cells=Array.from(row.querySelectorAll('td'));
                cells.forEach((td,i)=>td.setAttribute('data-jksh-label',headers[i]||''));

                const id=contentIdFromRow(row);
                if(!id || row.querySelector('.jksh-row-delete')) return;

                const actionCell=cells[cells.length-1]||row;
                const btn=document.createElement('button');
                btn.type='button';
                btn.className='button jksh-row-delete';
                btn.textContent='Delete Row';
                btn.title='Permanently remove this Content Library row';

                btn.onclick=async()=>{
                    btn.disabled=true;
                    try{
                        let r=await fetch('/wp-json/jksh/v1/content/'+id+'/library-row-delete-preview',{headers:{'X-WP-Nonce':nonce}});
                        let p=await r.json();
                        if(!r.ok||!p.ok){alert(p?.message||'Could not check this row.');return;}
                        if(!p.delete_allowed){
                            alert('This row is actively publishing right now. Wait until processing finishes, then delete it.');
                            return;
                        }

                        let details='';
                        if(p.cancelable_future_jobs>0) details+='\n\nThis will cancel '+p.cancelable_future_jobs+' pending scheduled/queued/Community job(s).';
                        if(p.published_jobs>0) details+='\n\nAlready published social posts will stay online.';
                        if(!confirm('Permanently remove this row from the Content Library?\n\nIt will not come back after refresh. WordPress media files are kept.'+details))return;

                        r=await fetch('/wp-json/jksh/v1/content/'+id+'/library-row-delete',{
                            method:'POST',
                            headers:{'Content-Type':'application/json','X-WP-Nonce':nonce},
                            body:JSON.stringify({confirm:true})
                        });
                        p=await r.json();
                        if(!r.ok||!p.ok){alert(p?.message||'Delete Row failed.');return;}

                        row.style.opacity='.25';
                        row.style.transform='scale(.985)';
                        setTimeout(()=>row.remove(),180);
                    }catch(e){
                        alert('Delete Row request failed.');
                    }finally{
                        btn.disabled=false;
                    }
                };

                actionCell.appendChild(btn);
            });
        });
    };

    enhanceTable();
    new MutationObserver(enhanceTable).observe(document.body,{childList:true,subtree:true});
})();
</script>
        <?php
    }
}

JKSH_Content_Library_V0916_Row_Delete_Mobile::instance();
