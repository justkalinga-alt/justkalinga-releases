<?php
/**
 * JK Social Hub uninstall policy.
 *
 * Data is preserved by default. To permit destructive cleanup, define:
 * define( 'JKSH_ALLOW_DATA_PURGE', true );
 * before deleting the plugin.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( ! defined( 'JKSH_ALLOW_DATA_PURGE' ) || true !== JKSH_ALLOW_DATA_PURGE ) {
	return;
}

global $wpdb;

$tables = array(
	'jksh_accounts',
	'jksh_content',
	'jksh_variants',
	'jksh_media',
	'jksh_jobs',
	'jksh_publish_logs',
	'jksh_analytics',
	'jksh_templates',
	'jksh_campaigns',
	'jksh_live_streams',
);

foreach ( $tables as $table ) {
	$wpdb->query( 'DROP TABLE IF EXISTS `' . esc_sql( $wpdb->prefix . $table ) . '`' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared
}

delete_option( 'jksh_db_version' );
delete_option( 'jksh_settings' );
delete_option( 'jksh_meta_config' );

delete_option( 'jksh_live_secrets' );
delete_option( 'jksh_live_worker_private_key' );
delete_option( 'jksh_live_worker_public_key' );
