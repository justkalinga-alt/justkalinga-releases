<?php
namespace JKSH\Security;

final class Crypto {
	private const PREFIX = 'jksh1:';

	public function available(): bool {
		return function_exists( 'openssl_encrypt' ) && function_exists( 'openssl_decrypt' );
	}

	public function encrypt( string $plaintext ): string {
		if ( '' === $plaintext ) {
			return '';
		}
		if ( ! $this->available() ) {
			throw new \RuntimeException( 'OpenSSL is required to encrypt JK Social Hub credentials.' );
		}

		$key = $this->key();
		$iv  = random_bytes( 12 );
		$tag = '';
		$ciphertext = openssl_encrypt(
			$plaintext,
			'aes-256-gcm',
			$key,
			OPENSSL_RAW_DATA,
			$iv,
			$tag,
			'jk-social-hub',
			16
		);
		if ( false === $ciphertext ) {
			throw new \RuntimeException( 'Unable to encrypt JK Social Hub credentials.' );
		}

		return self::PREFIX . base64_encode( $iv . $tag . $ciphertext );
	}

	public function decrypt( string $payload ): string {
		if ( '' === $payload ) {
			return '';
		}
		if ( 0 !== strpos( $payload, self::PREFIX ) || ! $this->available() ) {
			return '';
		}

		$raw = base64_decode( substr( $payload, strlen( self::PREFIX ) ), true );
		if ( false === $raw || strlen( $raw ) < 29 ) {
			return '';
		}
		$iv         = substr( $raw, 0, 12 );
		$tag        = substr( $raw, 12, 16 );
		$ciphertext = substr( $raw, 28 );
		$plaintext  = openssl_decrypt(
			$ciphertext,
			'aes-256-gcm',
			$this->key(),
			OPENSSL_RAW_DATA,
			$iv,
			$tag,
			'jk-social-hub'
		);

		return false === $plaintext ? '' : $plaintext;
	}

	private function key(): string {
		$parts = array(
			defined( 'AUTH_KEY' ) ? AUTH_KEY : '',
			defined( 'SECURE_AUTH_KEY' ) ? SECURE_AUTH_KEY : '',
			defined( 'LOGGED_IN_KEY' ) ? LOGGED_IN_KEY : '',
			defined( 'NONCE_KEY' ) ? NONCE_KEY : '',
		);
		return hash( 'sha256', implode( '|', $parts ) . '|jk-social-hub-credentials-v1', true );
	}
}
