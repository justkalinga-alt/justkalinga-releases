<?php
namespace JKSH;

final class Deactivator {
	public static function deactivate(): void {
		wp_clear_scheduled_hook( 'jksh_process_due_jobs' );
		flush_rewrite_rules( false );
	}
}
