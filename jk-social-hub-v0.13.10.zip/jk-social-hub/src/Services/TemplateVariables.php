<?php
namespace JKSH\Services;

final class TemplateVariables {
	public function replace( string $text, array $context = array() ): string {
		$settings = ( new Settings() )->all();
		$defaults = array(
			'website'         => $settings['website'],
			'coupon'          => $settings['coupon_code'],
			'phone_primary'   => $settings['phone_primary'],
			'phone_secondary' => $settings['phone_secondary'],
			'whatsapp'        => $settings['whatsapp'],
			'today'           => wp_date( 'Y-m-d', null, new \DateTimeZone( $settings['timezone'] ) ),
			'platform'        => '',
			'product_name'    => '',
			'product_url'     => '',
			'festival'        => '',
		);
		$vars = wp_parse_args( $context, $defaults );
		foreach ( $vars as $key => $value ) {
			$text = str_replace( '{{' . $key . '}}', (string) $value, $text );
		}
		return $text;
	}
}
