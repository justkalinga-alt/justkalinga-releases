<?php
namespace JKSH\Services;

use JKSH\Repositories\AccountRepository;
use JKSH\Repositories\LogRepository;
use JKSH\Security\Crypto;

final class YouTubeConnector {
	public const OPTION = 'jksh_youtube_config';

	private Crypto $crypto;
	private AccountRepository $accounts;
	private LogRepository $logs;

	public function __construct() {
		$this->crypto   = new Crypto();
		$this->accounts = new AccountRepository();
		$this->logs     = new LogRepository();
	}

	public function defaults(): array {
		return array(
			'client_id'               => '',
			'client_secret_encrypted' => '',
		);
	}

	public function config(): array {
		return wp_parse_args( (array) get_option( self::OPTION, array() ), $this->defaults() );
	}

	public function has_secret(): bool {
		return '' !== (string) ( $this->config()['client_secret_encrypted'] ?? '' );
	}

	public function is_configured(): bool {
		$config = $this->config();
		return '' !== (string) ( $config['client_id'] ?? '' ) && $this->has_secret();
	}

	public function save_config( string $client_id, string $client_secret ): void {
		$current = $this->config();
		$next = array(
			'client_id'               => sanitize_text_field( trim( $client_id ) ),
			'client_secret_encrypted' => (string) ( $current['client_secret_encrypted'] ?? '' ),
		);
		if ( '' !== trim( $client_secret ) ) {
			$next['client_secret_encrypted'] = $this->crypto->encrypt( trim( $client_secret ) );
		}
		update_option( self::OPTION, $next, false );
	}

	public function redirect_uri(): string {
		return admin_url( 'admin-post.php?action=jksh_youtube_oauth_callback' );
	}

	public function scopes(): array {
		return array( 'https://www.googleapis.com/auth/youtube' );
	}

	public function auth_url(): string {
		if ( ! $this->is_configured() ) {
			return '';
		}
		$state = wp_generate_password( 48, false, false );
		set_transient( 'jksh_youtube_state_' . get_current_user_id(), hash( 'sha256', $state ), 15 * MINUTE_IN_SECONDS );
		$config = $this->config();
		return add_query_arg(
			array(
				'client_id'                  => (string) $config['client_id'],
				'redirect_uri'               => $this->redirect_uri(),
				'response_type'              => 'code',
				'scope'                      => implode( ' ', $this->scopes() ),
				'access_type'                => 'offline',
				'include_granted_scopes'     => 'true',
				'prompt'                     => 'consent',
				'state'                      => $state,
			),
			'https://accounts.google.com/o/oauth2/v2/auth'
		);
	}

	public function handle_callback( string $code, string $state ): array {
		if ( ! $this->is_configured() ) {
			return array( 'ok' => false, 'message' => 'YouTube OAuth credentials are not configured.' );
		}
		$expected = (string) get_transient( 'jksh_youtube_state_' . get_current_user_id() );
		delete_transient( 'jksh_youtube_state_' . get_current_user_id() );
		if ( '' === $expected || ! hash_equals( $expected, hash( 'sha256', $state ) ) ) {
			return array( 'ok' => false, 'message' => 'YouTube OAuth state validation failed. Start the connection again.' );
		}

		$config = $this->config();
		$secret = $this->crypto->decrypt( (string) $config['client_secret_encrypted'] );
		if ( '' === $secret ) {
			return array( 'ok' => false, 'message' => 'Saved YouTube OAuth client secret could not be decrypted.' );
		}
		$response = wp_remote_post(
			'https://oauth2.googleapis.com/token',
			array(
				'timeout' => 30,
				'body' => array(
					'code'          => $code,
					'client_id'     => (string) $config['client_id'],
					'client_secret' => $secret,
					'redirect_uri'  => $this->redirect_uri(),
					'grant_type'    => 'authorization_code',
				),
			)
		);
		$token = $this->decode_response( $response );
		if ( ! $token['ok'] || empty( $token['data']['access_token'] ) ) {
			return array( 'ok' => false, 'message' => 'YouTube token exchange failed: ' . $token['message'] );
		}

		$access = sanitize_text_field( (string) $token['data']['access_token'] );
		$channel = $this->request_with_token(
			$access,
			'https://www.googleapis.com/youtube/v3/channels',
			array( 'part' => 'snippet,contentDetails,statistics,status', 'mine' => 'true' )
		);
		if ( ! $channel['ok'] ) {
			return array( 'ok' => false, 'message' => 'YouTube channel discovery failed: ' . $channel['message'] );
		}
		$item = (array) ( $channel['data']['items'][0] ?? array() );
		$channel_id = sanitize_text_field( (string) ( $item['id'] ?? '' ) );
		$title      = sanitize_text_field( (string) ( $item['snippet']['title'] ?? '' ) );
		if ( '' === $channel_id || '' === $title ) {
			return array( 'ok' => false, 'message' => 'No YouTube channel was returned for the authorized Google account.' );
		}

		$existing = $this->accounts->find( 'youtube', $channel_id );
		$existing_credentials = $existing ? $this->accounts->credentials( $existing ) : array();
		$refresh = sanitize_text_field( (string) ( $token['data']['refresh_token'] ?? $existing_credentials['refresh_token'] ?? '' ) );
		if ( '' === $refresh ) {
			return array( 'ok' => false, 'message' => 'Google did not return an offline refresh token. Reconnect and approve access again.' );
		}
		$expires_in = max( 0, (int) ( $token['data']['expires_in'] ?? 0 ) );
		$expires_at = $expires_in ? gmdate( 'Y-m-d H:i:s', time() + $expires_in ) : null;
		$credentials = array(
			'access_token'  => $access,
			'refresh_token' => $refresh,
			'token_type'    => sanitize_text_field( (string) ( $token['data']['token_type'] ?? 'Bearer' ) ),
			'scope'         => sanitize_text_field( (string) ( $token['data']['scope'] ?? implode( ' ', $this->scopes() ) ) ),
		);
		$settings = array(
			'channel_id'           => $channel_id,
			'custom_url'           => sanitize_text_field( (string) ( $item['snippet']['customUrl'] ?? '' ) ),
			'published_at'         => sanitize_text_field( (string) ( $item['snippet']['publishedAt'] ?? '' ) ),
			'uploads_playlist_id'  => sanitize_text_field( (string) ( $item['contentDetails']['relatedPlaylists']['uploads'] ?? '' ) ),
			'subscriber_count'     => isset( $item['statistics']['subscriberCount'] ) ? (int) $item['statistics']['subscriberCount'] : null,
			'video_count'          => isset( $item['statistics']['videoCount'] ) ? (int) $item['statistics']['videoCount'] : null,
			'view_count'           => isset( $item['statistics']['viewCount'] ) ? (int) $item['statistics']['viewCount'] : null,
			'privacy_status'       => sanitize_key( (string) ( $item['status']['privacyStatus'] ?? '' ) ),
		);
		$account_id = $this->accounts->upsert(
			array(
				'platform'            => 'youtube',
				'account_name'        => $title,
				'external_account_id' => $channel_id,
				'status'              => 'connected',
				'settings'            => $settings,
				'credentials'         => $credentials,
				'token_expires_at'    => $expires_at,
				'last_checked_at'     => current_time( 'mysql', true ),
				'last_error'          => '',
			)
		);
		$this->logs->add(
			array(
				'action'  => 'youtube_connect',
				'result'  => 'success',
				'message' => 'YouTube channel connected successfully.',
				'context' => array( 'account_id' => $account_id, 'channel_id' => $channel_id, 'channel_title' => $title, 'scopes' => $this->scopes() ),
			)
		);
		return array( 'ok' => true, 'message' => 'YouTube connected: ' . $title . '.' );
	}

	public function test_account( int $account_id ): array {
		$account = $this->accounts->get( $account_id );
		if ( ! $account || 'youtube' !== (string) $account->platform ) {
			return array( 'ok' => false, 'message' => 'YouTube account was not found.' );
		}
		$result = ( new YouTubeClient() )->channel( $account );
		if ( ! $result['ok'] || empty( $result['data']['items'][0]['id'] ) ) {
			$message = 'YouTube connection test failed: ' . ( $result['message'] ?? 'Channel lookup returned no channel.' );
			$this->accounts->update_status( $account_id, 'attention', $message );
			$this->logs->add( array( 'action' => 'youtube_account_test', 'result' => 'failed', 'message' => $message, 'context' => array( 'account_id' => $account_id, 'platform' => 'youtube' ) ) );
			return array( 'ok' => false, 'message' => $message );
		}
		$this->accounts->update_status( $account_id, 'connected', '' );
		$this->logs->add( array( 'action' => 'youtube_account_test', 'result' => 'success', 'message' => 'YouTube connection test succeeded.', 'context' => array( 'account_id' => $account_id, 'platform' => 'youtube' ) ) );
		return array( 'ok' => true, 'message' => 'YouTube connection test succeeded.' );
	}

	public function disconnect_account( int $account_id ): array {
		$account = $this->accounts->get( $account_id );
		if ( ! $account || 'youtube' !== (string) $account->platform ) {
			return array( 'ok' => false, 'message' => 'YouTube account was not found.' );
		}
		$this->accounts->disconnect( $account_id );
		$this->logs->add( array( 'action' => 'youtube_disconnect', 'result' => 'success', 'message' => 'YouTube account disconnected locally.', 'context' => array( 'account_id' => $account_id, 'channel_id' => (string) $account->external_account_id ) ) );
		return array( 'ok' => true, 'message' => 'YouTube disconnected locally from JK Social Hub.' );
	}

	private function request_with_token( string $token, string $url, array $query ): array {
		$response = wp_remote_get(
			add_query_arg( $query, $url ),
			array(
				'timeout' => 30,
				'headers' => array( 'Authorization' => 'Bearer ' . $token, 'Accept' => 'application/json' ),
			)
		);
		return $this->decode_response( $response );
	}

	private function decode_response( $response ): array {
		if ( is_wp_error( $response ) ) {
			return array( 'ok' => false, 'message' => $response->get_error_message(), 'data' => array() );
		}
		$status = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$data = is_array( $data ) ? $data : array();
		if ( $status >= 200 && $status < 300 ) {
			return array( 'ok' => true, 'message' => '', 'data' => $data );
		}
		$message = (string) ( $data['error']['message'] ?? $data['error_description'] ?? $data['error'] ?? 'Google OAuth request failed.' );
		return array( 'ok' => false, 'message' => sanitize_textarea_field( $message ), 'data' => $data );
	}
}
