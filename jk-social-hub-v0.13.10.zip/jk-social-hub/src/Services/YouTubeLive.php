<?php
namespace JKSH\Services;

use JKSH\Repositories\AccountRepository;
use JKSH\Repositories\LiveStreamRepository;
use JKSH\Repositories\LogRepository;

final class YouTubeLive {
	private AccountRepository $accounts;
	private LiveStreamRepository $streams;
	private YouTubeClient $client;
	private Settings $settings;
	private LiveSecretStore $secrets;

	public function __construct() {
		$this->accounts = new AccountRepository();
		$this->streams  = new LiveStreamRepository();
		$this->client   = new YouTubeClient();
		$this->settings = new Settings();
		$this->secrets  = new LiveSecretStore();
	}

	public function readiness(): array {
		$account = $this->primary_account();
		return array(
			'connected' => (bool) $account,
			'channel' => $account ? array(
				'name' => sanitize_text_field( (string) $account->account_name ),
				'external_account_id' => sanitize_text_field( (string) $account->external_account_id ),
			) : null,
			'dry_run' => (bool) $this->settings->get( 'dry_run', 1 ),
			'youtube_live_stream_enabled' => (bool) $this->settings->get( 'youtube_live_stream_enabled', 0 ),
			'provisioning_possible' => (bool) $account && ! $this->settings->get( 'dry_run', 1 ) && $this->settings->get( 'youtube_live_stream_enabled', 0 ),
			'api' => array(
				'broadcast_create' => 'liveBroadcasts.insert',
				'stream_create' => 'liveStreams.insert',
				'bind' => 'liveBroadcasts.bind',
				'transitions' => array( 'testing', 'live', 'complete' ),
			),
			'safety' => 'Provisioning is blocked while global Dry Run is ON or the separate YouTube Live Stream switch is OFF. Stream keys are encrypted and never returned by MCP.',
		);
	}

	public function probe(): array {
		$account = $this->primary_account();
		if ( ! $account ) {
			return array( 'ok' => false, 'message' => 'No connected YouTube channel.', 'readiness' => $this->readiness() );
		}
		$broadcasts = $this->client->list_live_broadcasts( $account, 1 );
		$streams = $this->client->list_live_streams( $account, 1 );
		$ok = ! empty( $broadcasts['ok'] ) && ! empty( $streams['ok'] );
		$result = array(
			'ok' => $ok,
			'broadcasts_list' => array(
				'ok' => ! empty( $broadcasts['ok'] ),
				'status' => (int) ( $broadcasts['status'] ?? 0 ),
				'count' => is_array( $broadcasts['data']['items'] ?? null ) ? count( $broadcasts['data']['items'] ) : 0,
				'message' => sanitize_textarea_field( (string) ( $broadcasts['message'] ?? '' ) ),
			),
			'streams_list' => array(
				'ok' => ! empty( $streams['ok'] ),
				'status' => (int) ( $streams['status'] ?? 0 ),
				'count' => is_array( $streams['data']['items'] ?? null ) ? count( $streams['data']['items'] ) : 0,
				'message' => sanitize_textarea_field( (string) ( $streams['message'] ?? '' ) ),
			),
			'note' => 'Read-only YouTube Live API probe. No broadcast or stream was created or modified.',
		);
		( new LogRepository() )->add( array(
			'action' => 'youtube_live_probe',
			'result' => $ok ? 'success' : 'failed',
			'message' => $ok ? 'YouTube Live API read probe succeeded.' : 'YouTube Live API read probe failed.',
			'context' => array( 'broadcast_status' => (int) ( $broadcasts['status'] ?? 0 ), 'stream_status' => (int) ( $streams['status'] ?? 0 ) ),
		) );
		return $result;
	}

	public function preflight( int $live_stream_id ): array|\WP_Error {
		$row = $this->streams->get( $live_stream_id );
		if ( ! $row ) {
			return new \WP_Error( 'jksh_live_missing', 'Live stream draft not found.' );
		}
		$destinations = json_decode( (string) $row->destinations_json, true );
		if ( ! is_array( $destinations ) || ! in_array( 'youtube', $destinations, true ) ) {
			return new \WP_Error( 'jksh_live_youtube_missing', 'This live stream draft does not target YouTube.' );
		}
		$metadata = json_decode( (string) $row->metadata_json, true );
		$metadata = is_array( $metadata ) ? $metadata : array();
		if ( ! empty( $metadata['youtube']['broadcast_id'] ) || ! empty( $metadata['youtube']['stream_id'] ) ) {
			return new \WP_Error( 'jksh_live_already_provisioned', 'This draft already contains YouTube provisioning IDs.' );
		}
		$title = sanitize_text_field( (string) $row->title );
		if ( '' === $title || $this->strlen( $title ) > 100 ) {
			return new \WP_Error( 'jksh_live_title', 'YouTube Live title must be between 1 and 100 characters.' );
		}
		$scheduled = (string) $row->scheduled_start_at;
		$scheduled_ts = $scheduled ? strtotime( $scheduled . ' UTC' ) : false;
		if ( false === $scheduled_ts || $scheduled_ts <= time() + 60 ) {
			return new \WP_Error( 'jksh_live_schedule', 'YouTube Live scheduled start must be at least one minute in the future.' );
		}
		$fields = $this->youtube_fields( $metadata );
		$privacy = sanitize_key( (string) ( $fields['privacy_status'] ?? 'private' ) );
		if ( ! in_array( $privacy, array( 'private', 'unlisted', 'public' ), true ) ) {
			return new \WP_Error( 'jksh_live_privacy', 'YouTube Live privacy_status must be private, unlisted or public.' );
		}
		$resolution = sanitize_key( (string) ( $fields['resolution'] ?? '1080p' ) );
		$frame_rate = sanitize_key( (string) ( $fields['frame_rate'] ?? '30fps' ) );
		if ( ! in_array( $resolution, array( '240p', '360p', '480p', '720p', '1080p', '1440p', '2160p', 'variable' ), true ) ) {
			return new \WP_Error( 'jksh_live_resolution', 'Unsupported YouTube Live resolution.' );
		}
		if ( ! in_array( $frame_rate, array( '30fps', '60fps', 'variable' ), true ) ) {
			return new \WP_Error( 'jksh_live_framerate', 'Unsupported YouTube Live frame rate.' );
		}
		return array(
			'ok' => true,
			'live_stream_id' => (int) $row->id,
			'platform' => 'youtube',
			'title' => $title,
			'scheduled_start_at_utc' => gmdate( 'c', $scheduled_ts ),
			'privacy_status' => $privacy,
			'resolution' => $resolution,
			'frame_rate' => $frame_rate,
			'ingestion_type' => 'rtmp',
			'made_for_kids' => (bool) ( $fields['made_for_kids'] ?? false ),
			'note' => 'Local preflight only. No YouTube resource was created.',
		);
	}

	public function provision( array $input ): array|\WP_Error {
		$id = absint( $input['live_stream_id'] ?? 0 );
		if ( empty( $input['confirm'] ) ) {
			return new \WP_Error( 'jksh_live_confirm', 'confirm=true is required before provisioning YouTube Live resources.' );
		}
		if ( $this->settings->get( 'dry_run', 1 ) ) {
			return new \WP_Error( 'jksh_live_dry_run', 'YouTube Live provisioning is blocked while global Dry Run is ON.' );
		}
		if ( ! $this->settings->get( 'youtube_live_stream_enabled', 0 ) ) {
			return new \WP_Error( 'jksh_live_switch', 'YouTube Live Stream provisioning master switch is OFF.' );
		}
		$preflight = $this->preflight( $id );
		if ( is_wp_error( $preflight ) ) {
			return $preflight;
		}
		$row = $this->streams->get( $id );
		$metadata = json_decode( (string) $row->metadata_json, true );
		$metadata = is_array( $metadata ) ? $metadata : array();
		$fields = $this->youtube_fields( $metadata );
		$account = $this->primary_account();
		if ( ! $account ) {
			return new \WP_Error( 'jksh_live_account', 'No connected YouTube channel.' );
		}

		$broadcast_body = array(
			'snippet' => array(
				'title' => sanitize_text_field( (string) $row->title ),
				'description' => sanitize_textarea_field( (string) $row->description ),
				'scheduledStartTime' => (string) $preflight['scheduled_start_at_utc'],
			),
			'status' => array(
				'privacyStatus' => (string) $preflight['privacy_status'],
				'selfDeclaredMadeForKids' => (bool) $preflight['made_for_kids'],
			),
			'contentDetails' => array(
				'enableAutoStart' => false,
				'enableAutoStop' => false,
				'enableDvr' => true,
				'enableEmbed' => true,
				'recordFromStart' => true,
				'monitorStream' => array( 'enableMonitorStream' => true, 'broadcastStreamDelayMs' => 0 ),
			),
		);
		if ( ! empty( $fields['category_id'] ) ) {
			$broadcast_body['snippet']['categoryId'] = sanitize_text_field( (string) $fields['category_id'] );
		}
		$broadcast = $this->client->create_live_broadcast( $account, $broadcast_body );
		if ( empty( $broadcast['ok'] ) || empty( $broadcast['data']['id'] ) ) {
			return $this->provision_failure( 'YouTube liveBroadcasts.insert failed.', $broadcast );
		}
		$broadcast_id = sanitize_text_field( (string) $broadcast['data']['id'] );

		$stream = $this->client->create_live_stream(
			$account,
			array(
				'snippet' => array(
					'title' => sanitize_text_field( (string) $row->title ) . ' ingest',
					'description' => 'JK Social Hub managed RTMP ingest stream.',
				),
				'cdn' => array(
					'frameRate' => (string) $preflight['frame_rate'],
					'ingestionType' => 'rtmp',
					'resolution' => (string) $preflight['resolution'],
				),
				'contentDetails' => array( 'isReusable' => false ),
			)
		);
		if ( empty( $stream['ok'] ) || empty( $stream['data']['id'] ) ) {
			$this->client->delete_live_broadcast( $account, $broadcast_id );
			return $this->provision_failure( 'YouTube liveStreams.insert failed. Broadcast creation was rolled back.', $stream );
		}
		$stream_id = sanitize_text_field( (string) $stream['data']['id'] );
		$bind = $this->client->bind_live_broadcast( $account, $broadcast_id, $stream_id );
		if ( empty( $bind['ok'] ) ) {
			$this->client->delete_live_stream( $account, $stream_id );
			$this->client->delete_live_broadcast( $account, $broadcast_id );
			return $this->provision_failure( 'YouTube liveBroadcasts.bind failed. Created resources were rolled back.', $bind );
		}

		$ingestion = (array) ( $stream['data']['cdn']['ingestionInfo'] ?? array() );
		$stream_name = sanitize_text_field( (string) ( $ingestion['streamName'] ?? '' ) );
		if ( '' === $stream_name ) {
			$this->client->delete_live_stream( $account, $stream_id );
			$this->client->delete_live_broadcast( $account, $broadcast_id );
			return new \WP_Error( 'jksh_live_no_stream_key', 'YouTube did not return a stream name/key. Created resources were rolled back.' );
		}
		$this->secrets->put( $id, 'youtube', array( 'stream_name' => $stream_name ) );
		$metadata['youtube'] = array(
			'broadcast_id' => $broadcast_id,
			'stream_id' => $stream_id,
			'watch_url' => 'https://www.youtube.com/watch?v=' . rawurlencode( $broadcast_id ),
			'ingestion_address' => sanitize_text_field( (string) ( $ingestion['ingestionAddress'] ?? '' ) ),
			'backup_ingestion_address' => sanitize_text_field( (string) ( $ingestion['backupIngestionAddress'] ?? '' ) ),
			'rtmps_ingestion_address' => sanitize_text_field( (string) ( $ingestion['rtmpsIngestionAddress'] ?? '' ) ),
			'rtmps_backup_ingestion_address' => sanitize_text_field( (string) ( $ingestion['rtmpsBackupIngestionAddress'] ?? '' ) ),
			'life_cycle_status' => sanitize_key( (string) ( $bind['data']['status']['lifeCycleStatus'] ?? 'ready' ) ),
			'stream_status' => sanitize_key( (string) ( $stream['data']['status']['streamStatus'] ?? 'inactive' ) ),
			'provisioned_at_utc' => gmdate( 'c' ),
			'stream_key_encrypted' => true,
		);
		$this->streams->update( $id, array( 'metadata' => $metadata, 'status' => 'provisioned', 'last_error' => '' ) );
		( new LogRepository() )->add( array(
			'action' => 'youtube_live_provision',
			'result' => 'success',
			'external_id' => $broadcast_id,
			'external_url' => 'https://www.youtube.com/watch?v=' . rawurlencode( $broadcast_id ),
			'message' => 'YouTube live broadcast and RTMP stream were created and bound.',
			'context' => array( 'live_stream_id' => $id, 'broadcast_id' => $broadcast_id, 'stream_id' => $stream_id, 'stream_key_encrypted' => true ),
		) );
		return array(
			'ok' => true,
			'live_stream_id' => $id,
			'broadcast_id' => $broadcast_id,
			'stream_id' => $stream_id,
			'watch_url' => 'https://www.youtube.com/watch?v=' . rawurlencode( $broadcast_id ),
			'status' => 'provisioned',
			'stream_key_returned' => false,
			'note' => 'YouTube resources were provisioned and bound. The RTMP stream key is encrypted for the future worker and is never returned by MCP.',
		);
	}

	private function youtube_fields( array $metadata ): array {
		$fields = (array) ( $metadata['platform_fields']['youtube'] ?? array() );
		return $fields;
	}
	private function primary_account(): ?object {
		$items = $this->accounts->connected( 'youtube' );
		return $items ? $items[0] : null;
	}
	private function strlen( string $value ): int {
		return function_exists( 'mb_strlen' ) ? mb_strlen( $value, 'UTF-8' ) : strlen( $value );
	}
	private function provision_failure( string $prefix, array $response ): \WP_Error {
		$message = sanitize_textarea_field( (string) ( $response['message'] ?? 'Unknown YouTube Live API error.' ) );
		return new \WP_Error( 'jksh_youtube_live_api', $prefix . ' ' . $message, array( 'status' => (int) ( $response['status'] ?? 0 ) ) );
	}
}
