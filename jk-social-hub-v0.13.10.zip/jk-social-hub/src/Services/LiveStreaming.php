<?php
namespace JKSH\Services;

use JKSH\Repositories\AccountRepository;
use JKSH\Repositories\LiveStreamRepository;
use JKSH\Repositories\LogRepository;

final class LiveStreaming {
	public function readiness(): array {
		$settings = new Settings();
		$accounts = new AccountRepository();
		$facebook = $accounts->connected( 'facebook' );
		$instagram = $accounts->connected( 'instagram' );
		$youtube   = $accounts->connected( 'youtube' );
		$youtube_live = ( new YouTubeLive() )->readiness();
		$granted = $this->latest_granted_permissions();
		$fb_required = array( 'publish_video', 'pages_manage_posts', 'pages_show_list', 'pages_read_engagement' );
		$fb_missing = array_values( array_diff( $fb_required, $granted ) );
		$youtube_probe = ! empty( $youtube ) ? ( new YouTubeLive() )->probe() : array( 'ok' => false, 'message' => 'YouTube is not connected.' );
		$worker = ( new LiveWorker() )->readiness( true );
		return array(
			'control_plane_ready' => true,
			'worker' => $worker,
			'destinations' => array(
				'facebook' => array(
					'account_connected' => ! empty( $facebook ),
					'api_path' => 'Facebook Live Video API',
					'additional_permissions_required' => $fb_missing,
					'api_prerequisites_present' => ! empty( $facebook ) && ! $fb_missing,
					'ready' => false,
					'note' => ! empty( $facebook ) && ! $fb_missing ? 'OAuth prerequisites are present. A non-publishing API eligibility/provisioning check is still required before the first Facebook Live.' : 'Connection or required permissions are incomplete.',
				),
				'instagram' => array(
					'account_connected' => ! empty( $instagram ),
					'api_path' => 'Instagram Live Producer / RTMP destination',
					'per_session_stream_key_required' => true,
					'ready' => false,
					'note' => 'The current connector can publish Instagram media, but the live RTMP key is a separate per-broadcast credential and must be supplied when Instagram Live Producer issues it.',
				),
				'youtube' => array(
					'account_connected' => ! empty( $youtube ),
					'api_probe' => $youtube_probe,
					'api_path' => 'YouTube Live Streaming API',
					'oauth_connector_installed' => true,
					'provisioning_adapter_installed' => true,
					'dry_run' => (bool) ( $youtube_live['dry_run'] ?? true ),
					'provisioning_switch_enabled' => (bool) ( $youtube_live['youtube_live_stream_enabled'] ?? false ),
					'provisioning_possible' => (bool) ( $youtube_live['provisioning_possible'] ?? false ),
					'ready' => ! empty( $youtube ) && ! empty( $youtube_live['provisioning_possible'] ),
					'note' => ! empty( $youtube ) ? 'YouTube OAuth and live provisioning adapter are installed. External provisioning remains guarded by Dry Run plus the dedicated YouTube Live switch.' : 'YouTube OAuth connector is installed, but no channel is connected yet.',
				),
			),
		);
	}

	public function create_draft( array $input ): array|\WP_Error {
		$title = sanitize_text_field( (string) ( $input['title'] ?? '' ) );
		if ( '' === $title ) {
			return new \WP_Error( 'jksh_live_title', 'A live stream title is required.' );
		}
		$destinations = array_values( array_intersect( array( 'facebook', 'instagram', 'youtube' ), array_map( 'sanitize_key', (array) ( $input['destinations'] ?? array( 'facebook', 'instagram', 'youtube' ) ) ) ) );
		if ( ! $destinations ) {
			return new \WP_Error( 'jksh_live_destination', 'At least one live destination is required.' );
		}
		$scheduled = sanitize_text_field( (string) ( $input['scheduled_start_at_utc'] ?? '' ) );
		if ( $scheduled && ! strtotime( $scheduled . ' UTC' ) ) {
			return new \WP_Error( 'jksh_live_schedule', 'scheduled_start_at_utc is invalid.' );
		}
		$metadata = array(
			'platform_fields' => $this->sanitize_nested( (array) ( $input['platform_fields'] ?? array() ) ),
			'orientation' => sanitize_key( (string) ( $input['orientation'] ?? 'adaptive' ) ),
			'products' => $this->sanitize_nested( (array) ( $input['products'] ?? array() ) ),
			'location' => $this->sanitize_nested( (array) ( $input['location'] ?? array() ) ),
			'publish_mode' => 'draft_only',
		);
		$id = ( new LiveStreamRepository() )->create(
			array(
				'title' => $title,
				'description' => sanitize_textarea_field( (string) ( $input['description'] ?? '' ) ),
				'source_type' => sanitize_key( (string) ( $input['source_type'] ?? 'rtmp_input' ) ),
				'source' => array( 'reference' => sanitize_text_field( (string) ( $input['source_reference'] ?? '' ) ) ),
				'destinations' => $destinations,
				'metadata' => $metadata,
				'status' => 'draft',
				'scheduled_start_at' => $scheduled ?: null,
			)
		);
		$youtube_preflight = null;
		if ( in_array( 'youtube', $destinations, true ) ) {
			$preflight = ( new YouTubeLive() )->preflight( $id );
			$youtube_preflight = is_wp_error( $preflight ) ? array( 'ok' => false, 'message' => $preflight->get_error_message() ) : $preflight;
		}
		return array( 'live_stream_id' => $id, 'status' => 'draft', 'destinations' => $destinations, 'youtube_preflight' => $youtube_preflight, 'readiness' => $this->readiness(), 'note' => 'No live platform was created or modified. Read-only YouTube Live API checks may run in readiness diagnostics.' );
	}

	public function recent( int $limit = 25 ): array {
		$rows = ( new LiveStreamRepository() )->recent( $limit );
		return array( 'count' => count( $rows ), 'streams' => array_map( array( $this, 'safe_stream' ), $rows ) );
	}

	private function latest_granted_permissions(): array {
		$logs = ( new LogRepository() )->recent_by_actions( array( 'meta_connect' ), 10 );
		foreach ( $logs as $log ) {
			$context = json_decode( (string) $log->context_json, true );
			if ( is_array( $context ) && ! empty( $context['granted_permissions'] ) && is_array( $context['granted_permissions'] ) ) {
				return array_values( array_map( 'sanitize_key', $context['granted_permissions'] ) );
			}
		}
		return array();
	}
	private function sanitize_nested( array $value ): array {
		$out = array();
		foreach ( $value as $key => $item ) {
			$key = is_string( $key ) ? sanitize_key( $key ) : $key;
			$out[ $key ] = is_array( $item ) ? $this->sanitize_nested( $item ) : ( is_bool( $item ) || is_int( $item ) || is_float( $item ) || null === $item ? $item : sanitize_textarea_field( (string) $item ) );
		}
		return $out;
	}
	private function safe_stream( object $row ): array {
		return array(
			'id' => (int) $row->id,
			'title' => sanitize_text_field( (string) $row->title ),
			'description' => sanitize_textarea_field( (string) $row->description ),
			'source_type' => sanitize_key( (string) $row->source_type ),
			'destinations' => json_decode( (string) $row->destinations_json, true ) ?: array(),
			'metadata' => json_decode( (string) $row->metadata_json, true ) ?: array(),
			'status' => sanitize_key( (string) $row->status ),
			'scheduled_start_at' => $row->scheduled_start_at ? sanitize_text_field( (string) $row->scheduled_start_at ) : null,
			'worker_job_id' => sanitize_text_field( (string) $row->worker_job_id ),
			'last_error' => sanitize_textarea_field( (string) $row->last_error ),
		);
	}
}
