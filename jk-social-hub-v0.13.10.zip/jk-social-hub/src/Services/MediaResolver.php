<?php
namespace JKSH\Services;

final class MediaResolver {
	public function resolve_ids( array $ids ): array {
		$ids = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
		$items = array();
		$errors = array();

		foreach ( $ids as $id ) {
			if ( 'attachment' !== get_post_type( $id ) ) {
				$errors[] = 'Media attachment #' . $id . ' does not exist.';
				continue;
			}

			$url = wp_get_attachment_url( $id );
			$mime = (string) get_post_mime_type( $id );
			if ( ! $url || ! $this->is_http_url( (string) $url ) ) {
				$errors[] = 'Media attachment #' . $id . ' does not have a public HTTP(S) URL.';
				continue;
			}

			$type = str_starts_with( $mime, 'image/' ) ? 'image' : ( str_starts_with( $mime, 'video/' ) ? 'video' : 'other' );
			if ( 'other' === $type ) {
				$errors[] = 'Media attachment #' . $id . ' is not an image or video.';
				continue;
			}

			$file = get_attached_file( $id );
			$items[] = array(
				'id'       => $id,
				'url'      => esc_url_raw( (string) $url ),
				'mime'     => sanitize_text_field( $mime ),
				'type'     => $type,
				'filename' => sanitize_file_name( wp_basename( (string) $url ) ),
				'bytes'    => ( $file && is_readable( $file ) ) ? (int) filesize( $file ) : 0,
			);
		}

		return array(
			'ok'     => empty( $errors ),
			'items'  => $items,
			'errors' => $errors,
		);
	}

	private function is_http_url( string $url ): bool {
		$parts = wp_parse_url( $url );
		return is_array( $parts )
			&& in_array( strtolower( (string) ( $parts['scheme'] ?? '' ) ), array( 'http', 'https' ), true )
			&& '' !== (string) ( $parts['host'] ?? '' );
	}
}
