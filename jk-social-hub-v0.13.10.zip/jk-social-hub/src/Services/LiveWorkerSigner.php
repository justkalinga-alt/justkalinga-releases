<?php
namespace JKSH\Services;

use JKSH\Security\Crypto;

final class LiveWorkerSigner {
	private const PRIVATE_OPTION = 'jksh_live_worker_private_key';
	private const PUBLIC_OPTION  = 'jksh_live_worker_public_key';
	private Crypto $crypto;

	public function __construct() {
		$this->crypto = new Crypto();
	}

	public function available(): bool {
		return function_exists( 'openssl_pkey_new' ) && function_exists( 'openssl_sign' ) && $this->crypto->available();
	}

	public function configured(): bool {
		return '' !== (string) get_option( self::PRIVATE_OPTION, '' ) && '' !== (string) get_option( self::PUBLIC_OPTION, '' );
	}

	public function ensure(): array|\WP_Error {
		if ( ! $this->available() ) {
			return new \WP_Error( 'jksh_worker_crypto', 'OpenSSL signing support is required for the live relay worker.' );
		}
		if ( $this->configured() ) {
			return $this->public_bundle();
		}
		$config = array(
			'private_key_bits' => 2048,
			'private_key_type' => OPENSSL_KEYTYPE_RSA,
			'digest_alg'       => 'sha256',
		);
		$key = openssl_pkey_new( $config );
		if ( false === $key ) {
			return new \WP_Error( 'jksh_worker_keygen', 'Unable to generate a relay-worker signing key.' );
		}
		$private = '';
		if ( ! openssl_pkey_export( $key, $private ) || '' === $private ) {
			return new \WP_Error( 'jksh_worker_keyexport', 'Unable to export the relay-worker signing key.' );
		}
		$details = openssl_pkey_get_details( $key );
		$public = is_array( $details ) ? (string) ( $details['key'] ?? '' ) : '';
		if ( '' === $public ) {
			return new \WP_Error( 'jksh_worker_pubkey', 'Unable to derive the relay-worker public key.' );
		}
		update_option( self::PRIVATE_OPTION, $this->crypto->encrypt( $private ), false );
		update_option( self::PUBLIC_OPTION, $public, false );
		return $this->public_bundle();
	}

	public function public_bundle(): array {
		$public = (string) get_option( self::PUBLIC_OPTION, '' );
		return array(
			'configured' => $this->configured(),
			'algorithm'  => 'RSA-SHA256',
			'key_id'     => $public ? substr( hash( 'sha256', $public ), 0, 24 ) : '',
			'public_key_pem' => $public,
			'contract_version' => 'jksh-relay-v1',
		);
	}

	public function sign( string $timestamp, string $nonce, string $body ): array|\WP_Error {
		$ensured = $this->ensure();
		if ( is_wp_error( $ensured ) ) {
			return $ensured;
		}
		$encrypted = (string) get_option( self::PRIVATE_OPTION, '' );
		$private = $this->crypto->decrypt( $encrypted );
		if ( '' === $private ) {
			return new \WP_Error( 'jksh_worker_private_key', 'Relay-worker signing key could not be decrypted.' );
		}
		$payload = "jksh-relay-v1\n{$timestamp}\n{$nonce}\n" . hash( 'sha256', $body );
		$signature = '';
		if ( ! openssl_sign( $payload, $signature, $private, OPENSSL_ALGO_SHA256 ) ) {
			return new \WP_Error( 'jksh_worker_sign', 'Unable to sign relay-worker request.' );
		}
		return array(
			'key_id' => (string) ( $ensured['key_id'] ?? '' ),
			'signature' => base64_encode( $signature ),
			'payload_hash' => hash( 'sha256', $body ),
		);
	}
}
