<?php
namespace JKSH\Services;

use JKSH\Repositories\AccountRepository;

final class ThreadsPublisher {
	private const API_HOST = 'https://graph.threads.net';
	private const MAX_TEXT = 500;
	private AccountRepository $accounts;
	private MediaResolver $media;

	public function __construct() {
		$this->accounts = new AccountRepository();
		$this->media = new MediaResolver();
	}

	public function readiness(): array {
		$settings = new Settings();
		$account = $this->primary_account();
		$issues = array();
		if ( ! $account ) {
			$issues[] = 'No API-verified Threads profile is connected.';
		} else {
			if ( 'connected' !== (string) $account->status ) {
				$issues[] = 'Stored Threads account status is ' . sanitize_key( (string) $account->status ) . '.';
			}
			$credentials = $this->accounts->credentials( $account );
			if ( empty( $credentials['access_token'] ) ) {
				$issues[] = 'Encrypted Threads access token is missing.';
			}
			$account_settings = $this->accounts->settings( $account );
			if ( empty( $account_settings['profile_verified_by_api'] ) ) {
				$issues[] = 'Threads profile has not passed API verification.';
			}
		}
		$healthy = empty( $issues );
		return array(
			'configured' => class_exists( '\\JKSH_Threads_Foundation_V0131' ) ? \JKSH_Threads_Foundation_V0131::instance()->is_configured() : false,
			'connected' => (bool) $account,
			'healthy' => $healthy,
			'name' => $account ? sanitize_text_field( (string) $account->account_name ) : '',
			'external_account_id' => $account ? sanitize_text_field( (string) $account->external_account_id ) : '',
			'token_expires_at' => $account && $account->token_expires_at ? sanitize_text_field( (string) $account->token_expires_at ) : null,
			'issues' => $issues,
			'dry_run' => (bool) $settings->get( 'dry_run', 1 ),
			'threads_live_publish_enabled' => (bool) $settings->get( 'threads_live_publish_enabled', 0 ),
			'live_publish_possible' => $healthy && ! $settings->get( 'dry_run', 1 ) && $settings->get( 'threads_live_publish_enabled', 0 ),
			'supported' => array( 'text', 'single_image', 'video', 'carousel' ),
			'safety' => 'Threads live writes require Dry Run OFF plus the dedicated Threads live-publish switch. Jobs permanently capture publish_mode when scheduled.',
		);
	}

	public function preflight( object $variant ): array {
		if ( 'threads' !== sanitize_key( (string) $variant->platform ) ) {
			return array( 'ok' => true, 'message' => 'No Threads preflight required.', 'details' => array() );
		}
		$account = $this->primary_account();
		if ( ! $account ) {
			return array( 'ok' => false, 'message' => 'No API-verified Threads profile is connected.', 'details' => array( 'platform' => 'threads' ) );
		}
		$token = $this->token_for_account( $account );
		if ( is_wp_error( $token ) ) {
			return array( 'ok' => false, 'message' => $token->get_error_message(), 'details' => array( 'platform' => 'threads' ) );
		}
		$media_ids = $this->media_ids( $variant );
		$resolved = $this->media->resolve_ids( $media_ids );
		if ( ! $resolved['ok'] ) {
			return array( 'ok' => false, 'message' => implode( ' ', $resolved['errors'] ), 'details' => array( 'platform' => 'threads' ) );
		}
		$media = $resolved['items'];
		if ( count( $media ) > 20 ) {
			return array( 'ok' => false, 'message' => 'Threads carousel publishing supports at most 20 media items.', 'details' => array( 'media_count' => count( $media ) ) );
		}
		$text = $this->compose_text( $variant );
		if ( '' === $text && ! $media ) {
			return array( 'ok' => false, 'message' => 'A Threads text-only post requires text.', 'details' => array() );
		}
		$length = function_exists( 'mb_strlen' ) ? mb_strlen( $text ) : strlen( $text );
		if ( $length > self::MAX_TEXT ) {
			return array( 'ok' => false, 'message' => 'Threads post text exceeds 500 characters. Prepare a Threads-native variant before publishing.', 'details' => array( 'text_length' => $length ) );
		}
		return array(
			'ok' => true,
			'message' => 'Threads variant passed local publishing preflight.',
			'details' => array(
				'platform' => 'threads',
				'publication_type' => $this->publication_type( $media ),
				'media_count' => count( $media ),
				'media_types' => array_values( array_unique( array_map( static fn( array $item ): string => (string) $item['type'], $media ) ) ),
				'text_length' => $length,
				'field_mapping' => ( new PlatformSchema() )->summarize_fields( 'threads', $this->platform_fields( $variant ) ),
			),
		);
	}

	public function publish( object $variant, array $payload = array() ): array {
		if ( 'threads' !== sanitize_key( (string) $variant->platform ) ) {
			return $this->failure( 'ThreadsPublisher received a non-Threads variant.', false );
		}
		$account = $this->primary_account();
		if ( ! $account ) {
			return $this->failure( 'No API-verified Threads profile is connected.', false );
		}
		$token = $this->token_for_account( $account );
		if ( is_wp_error( $token ) ) {
			return $this->failure( $token->get_error_message(), false );
		}

		$state = isset( $payload['threads_state'] ) && is_array( $payload['threads_state'] ) ? $payload['threads_state'] : array();
		if ( $state ) {
			return $this->continue_state( $variant, $payload, $state, (string) $token );
		}

		$preflight = $this->preflight( $variant );
		if ( empty( $preflight['ok'] ) ) {
			return $this->failure( (string) ( $preflight['message'] ?? 'Threads preflight failed.' ), false, $preflight['details'] ?? array() );
		}
		$resolved = $this->media->resolve_ids( $this->media_ids( $variant ) );
		$media = $resolved['items'];
		$type = $this->publication_type( $media );
		$text = $this->compose_text( $variant );
		$fields = $this->platform_fields( $variant );

		if ( 'carousel' === $type ) {
			$children = array();
			foreach ( $media as $index => $item ) {
				$params = array(
					'media_type' => 'image' === $item['type'] ? 'IMAGE' : 'VIDEO',
					'is_carousel_item' => 'true',
				);
				$params[ 'image' === $item['type'] ? 'image_url' : 'video_url' ] = (string) $item['url'];
				$alt = $this->alt_text_for( $fields, $item, $index );
				if ( '' !== $alt ) {
					$params['alt_text'] = $alt;
				}
				$created = $this->api_post( '/me/threads', $token, $params );
				if ( ! $created['ok'] || empty( $created['data']['id'] ) ) {
					return $this->api_failure( 'Threads carousel item container creation failed.', $created );
				}
				$children[] = sanitize_text_field( (string) $created['data']['id'] );
			}
			return $this->pending( $payload, array( 'phase' => 'carousel_items', 'child_ids' => $children, 'text' => $text, 'fields' => $fields ), 12, 'Threads carousel items created. Waiting for media processing.' );
		}

		$params = $this->common_params( $fields );
		$params['media_type'] = strtoupper( $type );
		if ( '' !== $text ) {
			$params['text'] = $text;
		}
		if ( 'image' === $type ) {
			$params['image_url'] = (string) $media[0]['url'];
			$alt = $this->alt_text_for( $fields, $media[0], 0 );
			if ( '' !== $alt ) { $params['alt_text'] = $alt; }
		} elseif ( 'video' === $type ) {
			$params['video_url'] = (string) $media[0]['url'];
			$alt = $this->alt_text_for( $fields, $media[0], 0 );
			if ( '' !== $alt ) { $params['alt_text'] = $alt; }
		} elseif ( 'text' === $type && ! empty( $fields['link_attachment'] ) ) {
			$params['link_attachment'] = esc_url_raw( (string) $fields['link_attachment'] );
		}

		$created = $this->api_post( '/me/threads', $token, $params );
		if ( ! $created['ok'] || empty( $created['data']['id'] ) ) {
			return $this->api_failure( 'Threads media container creation failed.', $created );
		}
		$container_id = sanitize_text_field( (string) $created['data']['id'] );
		return $this->pending( $payload, array( 'phase' => 'single_container', 'container_id' => $container_id, 'publication_type' => $type ), 'text' === $type ? 3 : 10, 'Threads container created. Waiting for publishing readiness.' );
	}

	private function continue_state( object $variant, array $payload, array $state, string $token ): array {
		$phase = sanitize_key( (string) ( $state['phase'] ?? '' ) );
		if ( 'published_verify' === $phase ) {
			return $this->verify_published( $payload, $state, $token );
		}
		if ( 'single_container' === $phase || 'carousel_container' === $phase ) {
			$container_id = sanitize_text_field( (string) ( $state['container_id'] ?? '' ) );
			$status = $this->container_status( $container_id, $token );
			if ( ! $status['ok'] ) {
				return $this->api_failure( 'Threads container status check failed.', $status );
			}
			$container_status = strtoupper( (string) ( $status['data']['status'] ?? '' ) );
			if ( in_array( $container_status, array( 'IN_PROGRESS', '' ), true ) ) {
				return $this->pending( $payload, $state, 10, 'Threads media is still processing.' );
			}
			if ( in_array( $container_status, array( 'ERROR', 'EXPIRED' ), true ) ) {
				return $this->failure( 'Threads media container entered status ' . $container_status . '.', false, $status['data'] );
			}
			if ( 'PUBLISHED' === $container_status && ! empty( $state['published_id'] ) ) {
				$state['phase'] = 'published_verify';
				return $this->verify_published( $payload, $state, $token );
			}
			if ( 'FINISHED' !== $container_status ) {
				return $this->pending( $payload, $state, 10, 'Threads media is not ready yet.' );
			}
			return $this->publish_container( $payload, $state, $token );
		}
		if ( 'carousel_items' === $phase ) {
			$children = array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $state['child_ids'] ?? array() ) ) ) );
			if ( count( $children ) < 2 ) {
				return $this->failure( 'Threads carousel state is missing child containers.', false );
			}
			foreach ( $children as $child_id ) {
				$status = $this->container_status( $child_id, $token );
				if ( ! $status['ok'] ) {
					return $this->api_failure( 'Threads carousel item status check failed.', $status );
				}
				$child_status = strtoupper( (string) ( $status['data']['status'] ?? '' ) );
				if ( in_array( $child_status, array( 'ERROR', 'EXPIRED' ), true ) ) {
					return $this->failure( 'A Threads carousel item entered status ' . $child_status . '.', false, $status['data'] );
				}
				if ( ! in_array( $child_status, array( 'FINISHED', 'PUBLISHED' ), true ) ) {
					return $this->pending( $payload, $state, 12, 'Threads carousel items are still processing.' );
				}
			}
			$params = $this->common_params( is_array( $state['fields'] ?? null ) ? $state['fields'] : array() );
			$params['media_type'] = 'CAROUSEL';
			$params['children'] = implode( ',', $children );
			if ( '' !== (string) ( $state['text'] ?? '' ) ) {
				$params['text'] = sanitize_textarea_field( (string) $state['text'] );
			}
			$created = $this->api_post( '/me/threads', $token, $params );
			if ( ! $created['ok'] || empty( $created['data']['id'] ) ) {
				return $this->api_failure( 'Threads carousel container creation failed.', $created );
			}
			$next = array( 'phase' => 'carousel_container', 'container_id' => sanitize_text_field( (string) $created['data']['id'] ) );
			return $this->pending( $payload, $next, 10, 'Threads carousel container created. Waiting for final processing.' );
		}
		return $this->failure( 'Unknown Threads publishing state. Refusing to guess or restart externally.', false, $state );
	}

	private function publish_container( array $payload, array $state, string $token ): array {
		$container_id = sanitize_text_field( (string) ( $state['container_id'] ?? '' ) );
		$result = $this->api_post( '/me/threads_publish', $token, array( 'creation_id' => $container_id ) );
		if ( ! $result['ok'] || empty( $result['data']['id'] ) ) {
			// Once threads_publish is attempted, an error can be ambiguous at the network/API edge.
			// Never blind-retry the external write because that can create a duplicate post.
			return $this->failure( 'Threads publish request failed and was not automatically retried: ' . (string) $result['message'], false, $result['data'] ?? array() );
		}
		$next = array(
			'phase' => 'published_verify',
			'container_id' => $container_id,
			'published_id' => sanitize_text_field( (string) $result['data']['id'] ),
		);
		return $this->verify_published( $payload, $next, $token );
	}

	private function verify_published( array $payload, array $state, string $token ): array {
		$published_id = sanitize_text_field( (string) ( $state['published_id'] ?? '' ) );
		if ( '' === $published_id ) {
			return $this->failure( 'Threads verification state is missing the published media ID.', false );
		}
		$details = $this->api_get(
			'/' . rawurlencode( $published_id ),
			$token,
			array( 'fields' => 'id,media_product_type,media_type,permalink,username,text,timestamp,shortcode,alt_text,topic_tag,location_id' )
		);
		if ( ! $details['ok'] ) {
			if ( ! empty( $details['retryable'] ) ) {
				return $this->pending( $payload, $state, 10, 'Threads post was published; waiting for read-back verification.' );
			}
			return $this->success( $published_id, '', 'Threads post published; API read-back was unavailable.', array( 'publish_verified' => false, 'details' => $details['data'] ?? array() ), $payload );
		}
		$permalink = esc_url_raw( (string) ( $details['data']['permalink'] ?? '' ) );
		return $this->success( $published_id, $permalink, 'Threads post published and externally verified.', array( 'publish_verified' => true, 'details' => $details['data'] ), $payload );
	}

	private function container_status( string $container_id, string $token ): array {
		if ( '' === $container_id ) {
			return array( 'ok' => false, 'message' => 'Missing Threads container ID.', 'data' => array(), 'retryable' => false );
		}
		return $this->api_get( '/' . rawurlencode( $container_id ) . '/', $token, array( 'fields' => 'id,status,error_message' ) );
	}

	private function common_params( array $fields ): array {
		$out = array();
		if ( ! empty( $fields['reply_control'] ) ) { $out['reply_control'] = sanitize_key( (string) $fields['reply_control'] ); }
		if ( ! empty( $fields['topic_tag'] ) ) { $out['topic_tag'] = sanitize_text_field( (string) $fields['topic_tag'] ); }
		if ( ! empty( $fields['quote_post_id'] ) ) { $out['quote_post_id'] = sanitize_text_field( (string) $fields['quote_post_id'] ); }
		if ( ! empty( $fields['location_id'] ) ) { $out['location_id'] = sanitize_text_field( (string) $fields['location_id'] ); }
		if ( ! empty( $fields['is_spoiler_media'] ) ) { $out['is_spoiler_media'] = 'true'; }
		if ( ! empty( $fields['enable_reply_approvals'] ) ) { $out['enable_reply_approvals'] = 'true'; }
		return $out;
	}

	private function alt_text_for( array $fields, array $item, int $index ): string {
		$media_fields = is_array( $fields['media_fields'] ?? null ) ? $fields['media_fields'] : array();
		$candidates = array(
			$media_fields[ (string) ( $item['id'] ?? '' ) ]['alt_text'] ?? '',
			$media_fields[ $index ]['alt_text'] ?? '',
			$fields['alt_text'] ?? '',
			get_post_meta( (int) ( $item['id'] ?? 0 ), '_wp_attachment_image_alt', true ),
		);
		foreach ( $candidates as $candidate ) {
			$candidate = sanitize_text_field( (string) $candidate );
			if ( '' !== $candidate ) { return $candidate; }
		}
		return '';
	}

	private function compose_text( object $variant ): string {
		$fields = $this->platform_fields( $variant );
		if ( isset( $fields['text'] ) && '' !== trim( (string) $fields['text'] ) ) {
			return sanitize_textarea_field( (string) $fields['text'] );
		}
		$parts = array();
		$caption = trim( sanitize_textarea_field( (string) ( $variant->caption ?? '' ) ) );
		$hashtags = trim( sanitize_text_field( (string) ( $variant->hashtags ?? '' ) ) );
		$cta = trim( sanitize_textarea_field( (string) ( $variant->cta ?? '' ) ) );
		if ( '' !== $caption ) { $parts[] = $caption; }
		if ( '' !== $hashtags && false === strpos( $caption, $hashtags ) ) { $parts[] = $hashtags; }
		if ( '' !== $cta && false === strpos( $caption, $cta ) ) { $parts[] = $cta; }
		return trim( implode( "\n\n", $parts ) );
	}

	private function publication_type( array $media ): string {
		if ( ! $media ) { return 'text'; }
		if ( count( $media ) > 1 ) { return 'carousel'; }
		return 'video' === (string) ( $media[0]['type'] ?? '' ) ? 'video' : 'image';
	}

	private function media_ids( object $variant ): array {
		$ids = json_decode( (string) ( $variant->media_json ?? '[]' ), true );
		return is_array( $ids ) ? array_values( array_filter( array_map( 'absint', $ids ) ) ) : array();
	}

	private function platform_fields( object $variant ): array {
		$fields = json_decode( (string) ( $variant->fields_json ?? '{}' ), true );
		return is_array( $fields ) ? $fields : array();
	}

	private function primary_account(): ?object {
		foreach ( $this->accounts->connected( 'threads' ) as $account ) {
			$settings = $this->accounts->settings( $account );
			if ( ! empty( $settings['profile_verified_by_api'] ) ) { return $account; }
		}
		return null;
	}

	private function token_for_account( object $account ): string|\WP_Error {
		if ( class_exists( '\\JKSH_Threads_Foundation_V0131' ) && method_exists( \JKSH_Threads_Foundation_V0131::instance(), 'publisher_token_for_account' ) ) {
			return \JKSH_Threads_Foundation_V0131::instance()->publisher_token_for_account( $account );
		}
		$credentials = $this->accounts->credentials( $account );
		$token = sanitize_text_field( (string) ( $credentials['access_token'] ?? '' ) );
		return '' !== $token ? $token : new \WP_Error( 'jksh_threads_token_missing', 'No stored Threads access token is available.' );
	}

	private function api_post( string $path, string $token, array $body ): array {
		$response = wp_remote_post(
			self::API_HOST . $path,
			array(
				'timeout' => 45,
				'headers' => array( 'Accept' => 'application/json', 'Authorization' => 'Bearer ' . $token ),
				'body' => $body,
			)
		);
		return $this->decode_response( $response, true );
	}

	private function api_get( string $path, string $token, array $query = array() ): array {
		$url = self::API_HOST . $path;
		if ( $query ) { $url = add_query_arg( $query, $url ); }
		$response = wp_remote_get( $url, array( 'timeout' => 30, 'headers' => array( 'Accept' => 'application/json', 'Authorization' => 'Bearer ' . $token ) ) );
		return $this->decode_response( $response, false );
	}

	private function decode_response( $response, bool $write ): array {
		if ( is_wp_error( $response ) ) {
			return array( 'ok' => false, 'message' => $response->get_error_message(), 'data' => array(), 'status' => 0, 'retryable' => ! $write, 'ambiguous_write' => $write );
		}
		$status = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$data = is_array( $data ) ? $data : array();
		if ( $status >= 200 && $status < 300 ) {
			return array( 'ok' => true, 'message' => '', 'data' => $data, 'status' => $status, 'retryable' => false, 'ambiguous_write' => false );
		}
		$message = (string) ( $data['error']['message'] ?? $data['error_description'] ?? $data['error'] ?? 'Threads API request failed.' );
		$retryable = 429 === $status || $status >= 500;
		return array( 'ok' => false, 'message' => sanitize_textarea_field( $message ), 'data' => $data, 'status' => $status, 'retryable' => $retryable, 'ambiguous_write' => false );
	}

	private function api_failure( string $prefix, array $result ): array {
		return $this->failure( $prefix . ' ' . sanitize_textarea_field( (string) ( $result['message'] ?? '' ) ), ! empty( $result['retryable'] ) && empty( $result['ambiguous_write'] ), $result['data'] ?? array() );
	}

	private function pending( array $payload, array $state, int $delay, string $message ): array {
		$payload['threads_state'] = $state;
		return array( 'ok' => true, 'pending' => true, 'delay' => max( 3, $delay ), 'message' => $message, 'payload' => $payload, 'response' => array( 'threads_state' => $state ), 'external_id' => '', 'external_url' => '' );
	}

	private function success( string $external_id, string $external_url, string $message, array $response, array $payload ): array {
		unset( $payload['threads_state'] );
		return array( 'ok' => true, 'pending' => false, 'external_id' => sanitize_text_field( $external_id ), 'external_url' => esc_url_raw( $external_url ), 'message' => $message, 'response' => $response, 'payload' => $payload );
	}

	private function failure( string $message, bool $retryable, array $response = array() ): array {
		return array( 'ok' => false, 'pending' => false, 'message' => sanitize_textarea_field( $message ), 'retryable' => $retryable, 'response' => $response );
	}
}
