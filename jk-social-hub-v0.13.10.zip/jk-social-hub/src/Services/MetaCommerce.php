<?php
namespace JKSH\Services;

use JKSH\Repositories\AccountRepository;

final class MetaCommerce {
	private AccountRepository $accounts;

	public function __construct() {
		$this->accounts = new AccountRepository();
	}

	public function readiness(): array {
		$facebook  = $this->primary_facebook();
		$instagram = $this->primary_instagram( $facebook );

		if ( ! $facebook || ! $instagram ) {
			return array(
				'ok'                     => false,
				'connected'              => false,
				'product_tagging_ready'  => false,
				'issues'                 => array( 'A connected Facebook Page and linked Instagram professional account are required.' ),
			);
		}

		$fb_credentials = $this->accounts->credentials( $facebook );
		$ig_credentials = $this->accounts->credentials( $instagram );
		$user_token      = (string) ( $fb_credentials['user_access_token'] ?? '' );
		$page_token      = (string) ( $ig_credentials['access_token'] ?? $fb_credentials['access_token'] ?? '' );
		$ig_settings     = $this->accounts->settings( $instagram );
		$fb_settings     = $this->accounts->settings( $facebook );
		$version         = (string) ( $ig_settings['graph_version'] ?? $fb_settings['graph_version'] ?? 'v25.0' );
		$client          = new MetaClient( $version );

		$required_permissions = array(
			'instagram_basic',
			'instagram_content_publish',
			'catalog_management',
			'instagram_shopping_tag_products',
		);
		$granted_permissions = $this->granted_permissions( $client, $user_token );
		$missing_permissions = array_values( array_diff( $required_permissions, $granted_permissions ) );
		$issues = array();

		if ( '' === $page_token ) {
			$issues[] = 'Saved Meta Page access token is unavailable.';
		}
		if ( '' === $user_token ) {
			$issues[] = 'Saved Meta user access token is unavailable, so granted commerce permissions cannot be verified.';
		}
		if ( $missing_permissions ) {
			$issues[] = 'Meta has not granted all Instagram Shopping permissions required by the product-tagging API.';
		}

		$eligibility = array(
			'ok'        => false,
			'eligible'  => false,
			'review_status' => '',
			'error_code' => 0,
			'message'   => '',
		);
		$catalogs = array(
			'ok'         => false,
			'items'      => array(),
			'error_code' => 0,
			'message'    => '',
		);

		if ( '' !== $page_token ) {
			$eligibility_result = $client->get(
				(string) $instagram->external_account_id,
				$page_token,
				array( 'fields' => 'id,username,shopping_product_tag_eligibility,shopping_review_status' )
			);
			if ( ! empty( $eligibility_result['ok'] ) ) {
				$data = (array) ( $eligibility_result['data'] ?? array() );
				$eligibility['ok'] = true;
				$eligibility['eligible'] = ! empty( $data['shopping_product_tag_eligibility'] );
				$eligibility['review_status'] = sanitize_text_field( (string) ( $data['shopping_review_status'] ?? '' ) );
			} else {
				$eligibility['error_code'] = (int) ( $eligibility_result['code'] ?? 0 );
				$eligibility['message'] = sanitize_text_field( (string) ( $eligibility_result['message'] ?? 'Meta eligibility check failed.' ) );
				$issues[] = 'Meta could not confirm Instagram Shopping product-tag eligibility.';
			}

			$catalog_result = $client->get(
				(string) $instagram->external_account_id . '/available_catalogs',
				$page_token,
				array( 'limit' => 100 )
			);
			if ( ! empty( $catalog_result['ok'] ) ) {
				$catalogs['ok'] = true;
				$catalogs['items'] = $this->sanitize_catalogs( (array) ( $catalog_result['data']['data'] ?? array() ) );
				if ( empty( $catalogs['items'] ) ) {
					$issues[] = 'Meta returned no Instagram Shopping catalogs for this account.';
				}
			} else {
				$catalogs['error_code'] = (int) ( $catalog_result['code'] ?? 0 );
				$catalogs['message'] = sanitize_text_field( (string) ( $catalog_result['message'] ?? 'Meta catalog lookup failed.' ) );
				$issues[] = 'Meta could not return available Instagram Shopping catalogs.';
			}
		}

		if ( $eligibility['ok'] && ! $eligibility['eligible'] ) {
			$issues[] = 'Instagram reports this account is not currently eligible for product tagging.';
		}

		$ready = empty( $missing_permissions )
			&& ! empty( $eligibility['ok'] )
			&& ! empty( $eligibility['eligible'] )
			&& ! empty( $catalogs['ok'] )
			&& ! empty( $catalogs['items'] );

		return array(
			'ok'                    => true,
			'connected'             => true,
			'instagram_account'     => array(
				'id'       => sanitize_text_field( (string) $instagram->external_account_id ),
				'username' => sanitize_text_field( (string) $instagram->account_name ),
			),
			'facebook_page'         => array(
				'id'   => sanitize_text_field( (string) $facebook->external_account_id ),
				'name' => sanitize_text_field( (string) $facebook->account_name ),
			),
			'graph_version'         => sanitize_text_field( $version ),
			'required_permissions'  => $required_permissions,
			'granted_permissions'   => $granted_permissions,
			'missing_permissions'   => $missing_permissions,
			'eligibility'           => $eligibility,
			'catalogs'              => $catalogs,
			'product_tagging_ready' => $ready,
			'issues'                => array_values( array_unique( array_map( 'sanitize_text_field', $issues ) ) ),
			'note'                  => 'Read-only Meta Graph probe. No catalog, product, shop, post or account setting is created or changed.',
		);
	}

	public function search_product( array $input ): array|\WP_Error {
		$catalog_id = preg_replace( '/\D+/', '', (string) ( $input['catalog_id'] ?? '' ) );
		$query      = trim( sanitize_text_field( (string) ( $input['query'] ?? '' ) ) );
		if ( '' === $catalog_id || '' === $query ) {
			return new \WP_Error( 'jksh_invalid_catalog_search', 'catalog_id and query are required.' );
		}

		$facebook  = $this->primary_facebook();
		$instagram = $this->primary_instagram( $facebook );
		if ( ! $facebook || ! $instagram ) {
			return new \WP_Error( 'jksh_instagram_not_connected', 'A connected Instagram professional account is required.' );
		}
		$credentials = $this->accounts->credentials( $instagram );
		$token = (string) ( $credentials['access_token'] ?? '' );
		if ( '' === $token ) {
			return new \WP_Error( 'jksh_meta_token_missing', 'Saved Meta Page access token is unavailable.' );
		}
		$settings = $this->accounts->settings( $instagram );
		$client = new MetaClient( (string) ( $settings['graph_version'] ?? 'v25.0' ) );
		$result = $client->get(
			(string) $instagram->external_account_id . '/catalog_product_search',
			$token,
			array(
				'catalog_id' => $catalog_id,
				'q'          => $query,
				'limit'      => 25,
			)
		);
		if ( empty( $result['ok'] ) ) {
			return array(
				'ok'         => false,
				'catalog_id' => $catalog_id,
				'query'      => $query,
				'error_code' => (int) ( $result['code'] ?? 0 ),
				'message'    => sanitize_text_field( (string) ( $result['message'] ?? 'Meta catalog product search failed.' ) ),
				'items'      => array(),
			);
		}

		return array(
			'ok'         => true,
			'catalog_id' => $catalog_id,
			'query'      => $query,
			'items'      => $this->sanitize_products( (array) ( $result['data']['data'] ?? array() ) ),
			'note'       => 'Read-only Meta catalog product search. No catalog item is created or changed.',
		);
	}

	private function granted_permissions( MetaClient $client, string $user_token ): array {
		if ( '' === $user_token ) {
			return array();
		}
		$result = $client->get( 'me/permissions', $user_token );
		if ( empty( $result['ok'] ) ) {
			return array();
		}
		$granted = array();
		foreach ( (array) ( $result['data']['data'] ?? array() ) as $row ) {
			if ( 'granted' !== (string) ( $row['status'] ?? '' ) ) {
				continue;
			}
			$permission = sanitize_key( (string) ( $row['permission'] ?? '' ) );
			if ( '' !== $permission ) {
				$granted[] = $permission;
			}
		}
		return array_values( array_unique( $granted ) );
	}

	private function primary_facebook(): ?object {
		$rows = $this->accounts->connected( 'facebook' );
		if ( ! $rows ) {
			return null;
		}
		$preferred = ( new MetaConnector() )->preferred_page_id();
		if ( '' !== $preferred ) {
			foreach ( $rows as $row ) {
				if ( $preferred === (string) $row->external_account_id ) {
					return $row;
				}
			}
		}
		return $rows[0];
	}

	private function primary_instagram( ?object $facebook ): ?object {
		$rows = $this->accounts->connected( 'instagram' );
		if ( ! $rows ) {
			return null;
		}
		if ( $facebook ) {
			foreach ( $rows as $row ) {
				if ( (int) $row->parent_account_id === (int) $facebook->id ) {
					return $row;
				}
			}
		}
		return $rows[0];
	}

	private function sanitize_catalogs( array $rows ): array {
		$out = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$item = array(
				'catalog_id'    => sanitize_text_field( (string) ( $row['catalog_id'] ?? $row['id'] ?? '' ) ),
				'catalog_name'  => sanitize_text_field( (string) ( $row['catalog_name'] ?? $row['name'] ?? '' ) ),
				'shop_name'     => sanitize_text_field( (string) ( $row['shop_name'] ?? '' ) ),
				'product_count' => (int) ( $row['product_count'] ?? 0 ),
			);
			if ( '' !== $item['catalog_id'] ) {
				$out[] = $item;
			}
		}
		return $out;
	}

	private function sanitize_products( array $rows ): array {
		$out = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$item = array(
				'product_id'  => sanitize_text_field( (string) ( $row['product_id'] ?? $row['id'] ?? '' ) ),
				'retailer_id' => sanitize_text_field( (string) ( $row['retailer_id'] ?? '' ) ),
				'name'        => sanitize_text_field( (string) ( $row['name'] ?? '' ) ),
				'price'       => sanitize_text_field( (string) ( $row['price'] ?? '' ) ),
				'availability'=> sanitize_text_field( (string) ( $row['availability'] ?? '' ) ),
				'image_url'   => esc_url_raw( (string) ( $row['image_url'] ?? '' ) ),
				'url'         => esc_url_raw( (string) ( $row['url'] ?? '' ) ),
			);
			if ( '' !== $item['product_id'] || '' !== $item['retailer_id'] ) {
				$out[] = $item;
			}
		}
		return $out;
	}
}
