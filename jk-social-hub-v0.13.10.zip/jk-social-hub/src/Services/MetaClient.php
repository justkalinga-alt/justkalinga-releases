<?php
namespace JKSH\Services;

final class MetaClient {
	private string $version;

	public function __construct( string $version = 'v25.0' ) {
		$version = preg_replace( '/[^v0-9.]/', '', $version );
		$this->version = $version ?: 'v25.0';
	}

	public function get( string $path, string $access_token, array $params = array() ): array {
		$params['access_token'] = $access_token;
		$url = add_query_arg( $params, $this->graph_url( $path ) );
		return $this->request(
			$url,
			array(
				'method'      => 'GET',
				'timeout'     => 20,
				'redirection' => 3,
				'headers'     => array( 'Accept' => 'application/json' ),
			)
		);
	}

	public function post( string $path, string $access_token, array $params = array() ): array {
		$params['access_token'] = $access_token;
		return $this->request(
			$this->graph_url( $path ),
			array(
				'method'      => 'POST',
				'timeout'     => 30,
				'redirection' => 3,
				'headers'     => array( 'Accept' => 'application/json' ),
				'body'        => $params,
			)
		);
	}

	public function post_absolute( string $url, array $headers = array(), $body = null ): array {
		$args = array(
			'method'      => 'POST',
			'timeout'     => 60,
			'redirection' => 3,
			'headers'     => $headers,
		);
		if ( null !== $body ) {
			$args['body'] = $body;
		}
		return $this->request( $url, $args );
	}

	public function exchange_code( string $app_id, string $app_secret, string $redirect_uri, string $code ): array {
		$url = add_query_arg(
			array(
				'client_id'     => $app_id,
				'client_secret' => $app_secret,
				'redirect_uri'  => $redirect_uri,
				'code'          => $code,
			),
			$this->graph_url( 'oauth/access_token' )
		);
		return $this->request(
			$url,
			array(
				'method'      => 'GET',
				'timeout'     => 20,
				'redirection' => 3,
				'headers'     => array( 'Accept' => 'application/json' ),
			)
		);
	}

	public function exchange_long_lived( string $app_id, string $app_secret, string $short_token ): array {
		$url = add_query_arg(
			array(
				'grant_type'        => 'fb_exchange_token',
				'client_id'         => $app_id,
				'client_secret'     => $app_secret,
				'fb_exchange_token' => $short_token,
			),
			$this->graph_url( 'oauth/access_token' )
		);
		return $this->request(
			$url,
			array(
				'method'      => 'GET',
				'timeout'     => 20,
				'redirection' => 3,
				'headers'     => array( 'Accept' => 'application/json' ),
			)
		);
	}

	private function graph_url( string $path ): string {
		return 'https://graph.facebook.com/' . rawurlencode( $this->version ) . '/' . ltrim( $path, '/' );
	}

	private function request( string $url, array $args ): array {
		$response = wp_remote_request( $url, $args );
		if ( is_wp_error( $response ) ) {
			return array(
				'ok'      => false,
				'code'    => 0,
				'message' => $response->get_error_message(),
				'data'    => array(),
			);
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$raw    = (string) wp_remote_retrieve_body( $response );
		$body   = json_decode( $raw, true );
		$body   = is_array( $body ) ? $body : array();
		if ( $status >= 200 && $status < 300 && empty( $body['error'] ) ) {
			return array( 'ok' => true, 'code' => $status, 'message' => '', 'data' => $body );
		}

		$error = isset( $body['error'] ) && is_array( $body['error'] ) ? $body['error'] : array();
		$message = sanitize_text_field( $error['message'] ?? '' );
		if ( '' === $message ) {
			$message = 'Meta API request failed with HTTP ' . $status;
		}
		return array(
			'ok'            => false,
			'code'          => (int) ( $error['code'] ?? $status ),
			'error_subcode' => (int) ( $error['error_subcode'] ?? 0 ),
			'message'       => $message,
			'data'          => $body,
		);
	}
}
