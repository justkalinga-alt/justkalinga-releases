<?php
namespace JKSH\Services;

use JKSH\Security\Crypto;

final class LiveSecretStore {
	private const OPTION = 'jksh_live_secrets';
	private Crypto $crypto;

	public function __construct() {
		$this->crypto = new Crypto();
	}

	public function put( int $live_stream_id, string $platform, array $secret ): void {
		if ( $live_stream_id < 1 || '' === $platform ) {
			throw new \InvalidArgumentException( 'A live stream ID and platform are required.' );
		}
		$current = (array) get_option( self::OPTION, array() );
		$key = $live_stream_id . ':' . sanitize_key( $platform );
		$current[ $key ] = $this->crypto->encrypt( wp_json_encode( $secret ) );
		if ( false === get_option( self::OPTION, false ) ) {
			add_option( self::OPTION, $current, '', false );
		} else {
			update_option( self::OPTION, $current, false );
		}
	}

	public function get( int $live_stream_id, string $platform ): array {
		$current = (array) get_option( self::OPTION, array() );
		$key = $live_stream_id . ':' . sanitize_key( $platform );
		$encrypted = (string) ( $current[ $key ] ?? '' );
		if ( '' === $encrypted ) {
			return array();
		}
		$plain = $this->crypto->decrypt( $encrypted );
		$data = json_decode( $plain, true );
		return is_array( $data ) ? $data : array();
	}

	public function delete( int $live_stream_id, string $platform ): void {
		$current = (array) get_option( self::OPTION, array() );
		$key = $live_stream_id . ':' . sanitize_key( $platform );
		if ( isset( $current[ $key ] ) ) {
			unset( $current[ $key ] );
			update_option( self::OPTION, $current, false );
		}
	}
}
