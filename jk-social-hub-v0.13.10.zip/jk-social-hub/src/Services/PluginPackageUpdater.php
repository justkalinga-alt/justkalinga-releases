<?php
namespace JKSH\Services;

use JKSH\Repositories\LogRepository;

final class PluginPackageUpdater {
	private const PLUGIN_BASENAME   = 'jk-social-hub/jk-social-hub.php';
	private const PLUGIN_ROOT       = 'jk-social-hub/';
	private const PLUGIN_NAME       = 'JustKalinga Social Hub';
	private const TEXT_DOMAIN       = 'jk-social-hub';
	private const MAX_PACKAGE_BYTES = 20971520; // 20 MiB.
	private const MAX_FILES         = 1500;
	private const MAX_UNPACKED      = 52428800; // 50 MiB.
	private const LOCK_OPTION       = 'jksh_plugin_update_lock';
	private const LOCK_TTL          = 600;

	public function readiness(): array {
		$this->load_admin_helpers();
		$plugin_file = plugin_basename( JKSH_FILE );
		$archive_inspector = $this->archive_inspector();
		return array(
			'plugin'                  => self::PLUGIN_BASENAME,
			'current_version'         => defined( 'JKSH_VERSION' ) ? JKSH_VERSION : '',
			'active'                  => function_exists( 'is_plugin_active' ) ? is_plugin_active( $plugin_file ) : null,
			'zip_supported'           => 'unavailable' !== $archive_inspector,
			'archive_inspector'       => $archive_inspector,
			'filesystem_method'       => function_exists( 'get_filesystem_method' ) ? sanitize_key( (string) get_filesystem_method() ) : '',
			'can_install_plugins'     => current_user_can( 'install_plugins' ),
			'can_update_plugins'      => current_user_can( 'update_plugins' ),
			'max_package_bytes'       => self::MAX_PACKAGE_BYTES,
			'source'                  => 'WordPress media attachment ZIP only',
			'accepted_plugin_identity'=> self::PLUGIN_BASENAME,
			'note'                    => 'The updater is intentionally restricted to verified JK Social Hub packages. It cannot install arbitrary plugins.',
		);
	}

	public function preflight( mixed $input ): array|\WP_Error {
		$data = $this->normalize_input( $input );
		$attachment_id   = absint( $data['attachment_id'] ?? 0 );
		$expected_sha256 = strtolower( sanitize_text_field( (string) ( $data['expected_sha256'] ?? '' ) ) );

		$result = $this->inspect_package( $attachment_id, $expected_sha256 );
		if ( is_wp_error( $result ) ) {
			$this->audit( 'plugin_update_preflight', 'error', $result->get_error_message(), array( 'attachment_id' => $attachment_id ) );
			return $result;
		}

		$current = defined( 'JKSH_VERSION' ) ? JKSH_VERSION : '';
		$relation = version_compare( (string) $result['package_version'], $current, '>' ) ? 'newer' : ( version_compare( (string) $result['package_version'], $current, '<' ) ? 'older' : 'same' );
		$result['current_version']  = $current;
		$result['version_relation'] = $relation;
		$result['can_apply']        = 'newer' === $relation;
		$result['active']           = $this->plugin_is_active();

		$this->audit(
			'plugin_update_preflight',
			'success',
			'JK Social Hub package preflight succeeded.',
			array(
				'attachment_id'   => $attachment_id,
				'package_version' => $result['package_version'],
				'current_version' => $current,
				'version_relation'=> $relation,
			)
		);
		return $result;
	}

	public function install_update( mixed $input ): array|\WP_Error {
		$data = $this->normalize_input( $input );
		$attachment_id           = absint( $data['attachment_id'] ?? 0 );
		$expected_sha256         = strtolower( sanitize_text_field( (string) ( $data['expected_sha256'] ?? '' ) ) );
		$expected_current_version= sanitize_text_field( (string) ( $data['expected_current_version'] ?? '' ) );
		$confirm                 = ! empty( $data['confirm'] );
		$allow_reinstall         = ! empty( $data['allow_reinstall'] );
		$allow_downgrade         = ! empty( $data['allow_downgrade'] );
		$delete_package_after    = ! array_key_exists( 'delete_package_after', $data ) || ! empty( $data['delete_package_after'] );

		if ( ! $confirm ) {
			return new \WP_Error( 'jksh_update_confirmation_required', 'confirm=true is required to replace the installed JK Social Hub plugin.' );
		}
		if ( ! current_user_can( 'update_plugins' ) || ! current_user_can( 'install_plugins' ) || ! current_user_can( 'jksh_manage_settings' ) ) {
			return new \WP_Error( 'jksh_update_forbidden', 'The current user is not permitted to install/update JK Social Hub.' );
		}

		$current = defined( 'JKSH_VERSION' ) ? JKSH_VERSION : '';
		if ( '' === $expected_current_version || ! hash_equals( $current, $expected_current_version ) ) {
			return new \WP_Error(
				'jksh_update_version_conflict',
				'Installed plugin version changed since the update was prepared. Refresh readiness/preflight before retrying.',
				array( 'current_version' => $current )
			);
		}

		$package = $this->inspect_package( $attachment_id, $expected_sha256 );
		if ( is_wp_error( $package ) ) {
			$this->audit( 'plugin_update', 'error', $package->get_error_message(), array( 'attachment_id' => $attachment_id, 'phase' => 'preflight' ) );
			return $package;
		}

		$new_version = (string) $package['package_version'];
		if ( version_compare( $new_version, $current, '<' ) && ! $allow_downgrade ) {
			return new \WP_Error( 'jksh_update_downgrade_blocked', 'The package is older than the installed version. Downgrades are blocked by default.' );
		}
		if ( 0 === version_compare( $new_version, $current ) && ! $allow_reinstall ) {
			return new \WP_Error( 'jksh_update_reinstall_blocked', 'The package version matches the installed version. Same-version reinstalls are blocked by default.' );
		}

		$lock = $this->acquire_lock();
		if ( is_wp_error( $lock ) ) {
			return $lock;
		}

		$backup_dir = '';
		$was_active = $this->plugin_is_active();
		try {
			$backup_dir = $this->backup_current_plugin();
			if ( is_wp_error( $backup_dir ) ) {
				$this->audit( 'plugin_update', 'error', $backup_dir->get_error_message(), array( 'attachment_id' => $attachment_id, 'phase' => 'backup' ) );
				return $backup_dir;
			}

			$this->audit(
				'plugin_update',
				'info',
				'JK Social Hub self-update started.',
				array(
					'attachment_id'   => $attachment_id,
					'from_version'    => $current,
					'to_version'      => $new_version,
					'was_active'      => $was_active,
				)
			);

			$result = $this->run_upgrader( (string) $package['file_path'] );
			if ( is_wp_error( $result ) || true !== $result ) {
				$message = is_wp_error( $result ) ? $result->get_error_message() : 'WordPress upgrader could not complete the plugin replacement.';
				$rollback = $this->restore_backup( $backup_dir );
				$this->audit( 'plugin_update', 'error', $message, array( 'phase' => 'install', 'rollback' => $rollback ) );
				return new \WP_Error( 'jksh_update_install_failed', $message, array( 'rollback' => $rollback ) );
			}

			$verification = $this->verify_installed_package( $new_version, $was_active );
			if ( is_wp_error( $verification ) ) {
				$rollback = $this->restore_backup( $backup_dir );
				$this->audit( 'plugin_update', 'error', $verification->get_error_message(), array( 'phase' => 'verify', 'rollback' => $rollback ) );
				return new \WP_Error( 'jksh_update_verify_failed', $verification->get_error_message(), array( 'rollback' => $rollback ) );
			}

			$this->cleanup_directory( $backup_dir );
			if ( $delete_package_after ) {
				wp_delete_attachment( $attachment_id, true );
			}

			$this->audit(
				'plugin_update',
				'success',
				'JK Social Hub plugin update completed and verified.',
				array(
					'from_version' => $current,
					'to_version'   => $new_version,
					'active'       => $was_active,
				)
			);

			return array(
				'success'          => true,
				'plugin'           => self::PLUGIN_BASENAME,
				'previous_version' => $current,
				'installed_version'=> $new_version,
				'active'           => $this->plugin_is_active(),
				'package_deleted'  => $delete_package_after,
				'verified'         => true,
				'note'             => 'Refresh MCP ability discovery after a plugin update so newly registered abilities and schemas are visible.',
			);
		} finally {
			$this->release_lock();
		}
	}

	private function inspect_package( int $attachment_id, string $expected_sha256 ): array|\WP_Error {
		if ( $attachment_id < 1 || 'attachment' !== get_post_type( $attachment_id ) ) {
			return new \WP_Error( 'jksh_update_invalid_attachment', 'A valid WordPress media attachment ID is required.' );
		}
		if ( 1 !== preg_match( '/^[a-f0-9]{64}$/', $expected_sha256 ) ) {
			return new \WP_Error( 'jksh_update_invalid_sha256', 'expected_sha256 must be a 64-character lowercase or uppercase hexadecimal SHA-256 value.' );
		}
		if ( 'unavailable' === $this->archive_inspector() ) {
			return new \WP_Error( 'jksh_update_zip_unavailable', 'Neither ZipArchive nor WordPress PclZip is available for safe package inspection.' );
		}

		$file = get_attached_file( $attachment_id, true );
		if ( ! is_string( $file ) || '' === $file || ! is_file( $file ) || ! is_readable( $file ) ) {
			return new \WP_Error( 'jksh_update_package_missing', 'The attached ZIP package is missing or unreadable.' );
		}
		$real_file = realpath( $file );
		$uploads   = wp_get_upload_dir();
		$real_base = ! empty( $uploads['basedir'] ) ? realpath( $uploads['basedir'] ) : false;
		if ( false === $real_file || false === $real_base ) {
			return new \WP_Error( 'jksh_update_package_path', 'Could not validate the media package path.' );
		}
		$normalized_file = wp_normalize_path( $real_file );
		$normalized_base = trailingslashit( wp_normalize_path( $real_base ) );
		if ( 0 !== strpos( $normalized_file, $normalized_base ) ) {
			return new \WP_Error( 'jksh_update_package_outside_uploads', 'Only ZIP packages stored in the WordPress media uploads directory are accepted.' );
		}
		if ( 'zip' !== strtolower( (string) pathinfo( $real_file, PATHINFO_EXTENSION ) ) ) {
			return new \WP_Error( 'jksh_update_package_not_zip', 'The update package must be a .zip file.' );
		}
		$size = filesize( $real_file );
		if ( false === $size || $size < 1 || $size > self::MAX_PACKAGE_BYTES ) {
			return new \WP_Error( 'jksh_update_package_size', 'The package is empty or exceeds the 20 MiB self-update limit.' );
		}

		$actual_sha256 = strtolower( (string) hash_file( 'sha256', $real_file ) );
		if ( ! hash_equals( strtolower( $expected_sha256 ), $actual_sha256 ) ) {
			return new \WP_Error( 'jksh_update_checksum_mismatch', 'Package SHA-256 does not match the expected checksum.' );
		}

		$archive = $this->inspect_archive_contents( $real_file );
		if ( is_wp_error( $archive ) ) {
			return $archive;
		}

		$main = (string) ( $archive['main_file'] ?? '' );
		$headers = $this->parse_plugin_headers( $main );
		if ( self::PLUGIN_NAME !== $headers['plugin_name'] || self::TEXT_DOMAIN !== $headers['text_domain'] ) {
			return new \WP_Error( 'jksh_update_identity_mismatch', 'The ZIP is not a verified JustKalinga Social Hub package.' );
		}
		if ( '' === $headers['version'] || ! preg_match( '/^[0-9A-Za-z.+_-]+$/', $headers['version'] ) ) {
			return new \WP_Error( 'jksh_update_version_invalid', 'The package plugin version is missing or invalid.' );
		}
		if ( '' !== $headers['requires_php'] && version_compare( PHP_VERSION, $headers['requires_php'], '<' ) ) {
			return new \WP_Error( 'jksh_update_php_requirement', 'The package requires a newer PHP version than this server provides.' );
		}
		$wp_version = get_bloginfo( 'version' );
		if ( '' !== $headers['requires_wp'] && version_compare( $wp_version, $headers['requires_wp'], '<' ) ) {
			return new \WP_Error( 'jksh_update_wp_requirement', 'The package requires a newer WordPress version than this site provides.' );
		}

		return array(
			'ok'              => true,
			'attachment_id'   => $attachment_id,
			'package_version' => $headers['version'],
			'plugin_name'     => $headers['plugin_name'],
			'text_domain'     => $headers['text_domain'],
			'requires_php'    => $headers['requires_php'],
			'requires_wp'     => $headers['requires_wp'],
			'sha256'          => $actual_sha256,
			'package_bytes'   => (int) $size,
			'file_count'      => (int) ( $archive['file_count'] ?? 0 ),
			'unpacked_bytes'  => (int) ( $archive['unpacked_bytes'] ?? 0 ),
			'archive_inspector'=> sanitize_key( (string) ( $archive['inspector'] ?? '' ) ),
			'file_path'       => $real_file,
		);
	}

	private function archive_inspector(): string {
		if ( class_exists( '\ZipArchive' ) ) {
			return 'ziparchive';
		}
		$pclzip = ABSPATH . 'wp-admin/includes/class-pclzip.php';
		return is_readable( $pclzip ) ? 'pclzip' : 'unavailable';
	}

	private function inspect_archive_contents( string $file ): array|\WP_Error {
		if ( class_exists( '\ZipArchive' ) ) {
			return $this->inspect_with_ziparchive( $file );
		}
		return $this->inspect_with_pclzip( $file );
	}

	private function inspect_with_ziparchive( string $file ): array|\WP_Error {
		$zip = new \ZipArchive();
		if ( true !== $zip->open( $file, \ZipArchive::CHECKCONS ) ) {
			return new \WP_Error( 'jksh_update_zip_invalid', 'The ZIP package failed its integrity check.' );
		}
		try {
			if ( $zip->numFiles < 1 || $zip->numFiles > self::MAX_FILES ) {
				return new \WP_Error( 'jksh_update_zip_file_count', 'The ZIP contains an invalid number of entries.' );
			}
			$total_unpacked = 0;
			for ( $i = 0; $i < $zip->numFiles; $i++ ) {
				$stat = $zip->statIndex( $i );
				if ( ! is_array( $stat ) || empty( $stat['name'] ) ) {
					return new \WP_Error( 'jksh_update_zip_entry', 'The ZIP contains an unreadable entry.' );
				}
				$name = str_replace( '\\', '/', (string) $stat['name'] );
				$path_error = $this->validate_archive_path( $name );
				if ( is_wp_error( $path_error ) ) {
					return $path_error;
				}
				if ( $this->zip_entry_is_symlink( $zip, $i ) ) {
					return new \WP_Error( 'jksh_update_zip_symlink', 'Symbolic links are not allowed in plugin update packages.' );
				}
				$total_unpacked += (int) ( $stat['size'] ?? 0 );
				if ( $total_unpacked > self::MAX_UNPACKED ) {
					return new \WP_Error( 'jksh_update_zip_unpacked_size', 'The uncompressed package exceeds the 50 MiB safety limit.' );
				}
			}
			$main = $zip->getFromName( self::PLUGIN_BASENAME );
			if ( false === $main || '' === trim( (string) $main ) ) {
				return new \WP_Error( 'jksh_update_main_file_missing', 'The ZIP does not contain jk-social-hub/jk-social-hub.php.' );
			}
			return array(
				'inspector'      => 'ziparchive',
				'file_count'     => (int) $zip->numFiles,
				'unpacked_bytes' => $total_unpacked,
				'main_file'      => (string) $main,
			);
		} finally {
			$zip->close();
		}
	}

	private function inspect_with_pclzip( string $file ): array|\WP_Error {
		require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
		if ( ! class_exists( '\PclZip' ) ) {
			return new \WP_Error( 'jksh_update_pclzip_unavailable', 'WordPress PclZip is unavailable.' );
		}
		$archive = new \PclZip( $file );
		$list = $archive->listContent();
		if ( 0 === $list || ! is_array( $list ) || count( $list ) < 1 || count( $list ) > self::MAX_FILES ) {
			return new \WP_Error( 'jksh_update_zip_invalid', 'The ZIP package could not be safely listed.' );
		}
		$total_unpacked = 0;
		foreach ( $list as $entry ) {
			$name = str_replace( '\\', '/', (string) ( $entry['filename'] ?? '' ) );
			if ( '' === $name ) {
				return new \WP_Error( 'jksh_update_zip_entry', 'The ZIP contains an unreadable entry.' );
			}
			$path_error = $this->validate_archive_path( $name );
			if ( is_wp_error( $path_error ) ) {
				return $path_error;
			}
			$total_unpacked += (int) ( $entry['size'] ?? 0 );
			if ( $total_unpacked > self::MAX_UNPACKED ) {
				return new \WP_Error( 'jksh_update_zip_unpacked_size', 'The uncompressed package exceeds the 50 MiB safety limit.' );
			}
		}
		$main = $archive->extract( PCLZIP_OPT_BY_NAME, self::PLUGIN_BASENAME, PCLZIP_OPT_EXTRACT_AS_STRING );
		if ( 0 === $main || ! is_array( $main ) || empty( $main[0]['content'] ) ) {
			return new \WP_Error( 'jksh_update_main_file_missing', 'The ZIP does not contain jk-social-hub/jk-social-hub.php.' );
		}
		return array(
			'inspector'      => 'pclzip',
			'file_count'     => count( $list ),
			'unpacked_bytes' => $total_unpacked,
			'main_file'      => (string) $main[0]['content'],
		);
	}

	private function validate_archive_path( string $name ): true|\WP_Error {
		if ( str_contains( $name, "\0" ) || str_starts_with( $name, '/' ) || preg_match( '#(^|/)\.\.(/|$)#', $name ) ) {
			return new \WP_Error( 'jksh_update_zip_path_traversal', 'The ZIP contains an unsafe path.' );
		}
		if ( 0 !== strpos( $name, self::PLUGIN_ROOT ) ) {
			return new \WP_Error( 'jksh_update_zip_wrong_root', 'Every ZIP entry must be inside the jk-social-hub/ plugin directory.' );
		}
		return true;
	}

	private function run_upgrader( string $package_file ): bool|\WP_Error {
		$this->load_admin_helpers();
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/class-plugin-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';

		$skin     = new \Automatic_Upgrader_Skin();
		$upgrader = new \Plugin_Upgrader( $skin );
		$result   = $upgrader->install(
			$package_file,
			array(
				'clear_update_cache' => true,
				'overwrite_package'  => true,
			)
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		if ( true !== $result && is_wp_error( $skin->result ?? null ) ) {
			return $skin->result;
		}
		return true === $result;
	}

	private function verify_installed_package( string $expected_version, bool $was_active ): true|\WP_Error {
		$this->load_admin_helpers();
		$main_file = WP_PLUGIN_DIR . '/' . self::PLUGIN_BASENAME;
		if ( ! is_file( $main_file ) || ! is_readable( $main_file ) ) {
			return new \WP_Error( 'jksh_update_verify_missing', 'The plugin main file is missing after replacement.' );
		}
		$data = get_plugin_data( $main_file, false, false );
		if ( self::PLUGIN_NAME !== (string) ( $data['Name'] ?? '' ) || self::TEXT_DOMAIN !== (string) ( $data['TextDomain'] ?? '' ) ) {
			return new \WP_Error( 'jksh_update_verify_identity', 'Installed plugin identity does not match JK Social Hub.' );
		}
		if ( ! hash_equals( $expected_version, (string) ( $data['Version'] ?? '' ) ) ) {
			return new \WP_Error( 'jksh_update_verify_version', 'Installed plugin version does not match the verified package version.' );
		}
		if ( $was_active && ! is_plugin_active( self::PLUGIN_BASENAME ) ) {
			return new \WP_Error( 'jksh_update_verify_inactive', 'The plugin was active before replacement but is no longer active.' );
		}
		return true;
	}

	private function backup_current_plugin(): string|\WP_Error {
		$this->load_admin_helpers();
		if ( ! function_exists( 'WP_Filesystem' ) || ! WP_Filesystem() ) {
			return new \WP_Error( 'jksh_update_filesystem', 'WordPress could not initialize filesystem access for the backup.' );
		}
		$base = trailingslashit( WP_CONTENT_DIR ) . 'upgrade/jksh-self-update-' . wp_generate_uuid4();
		$dest = trailingslashit( $base ) . 'jk-social-hub';
		if ( ! wp_mkdir_p( $dest ) ) {
			return new \WP_Error( 'jksh_update_backup_dir', 'Could not create the temporary rollback directory.' );
		}
		$result = copy_dir( untrailingslashit( JKSH_DIR ), $dest );
		if ( is_wp_error( $result ) ) {
			$this->cleanup_directory( $base );
			return new \WP_Error( 'jksh_update_backup_failed', 'Could not create a rollback copy of the current plugin.' );
		}
		return $base;
	}

	private function restore_backup( string $backup_dir ): string {
		if ( '' === $backup_dir || ! is_dir( $backup_dir ) ) {
			return 'backup_missing';
		}
		$this->load_admin_helpers();
		if ( ! function_exists( 'WP_Filesystem' ) || ! WP_Filesystem() ) {
			return 'filesystem_unavailable';
		}
		global $wp_filesystem;
		$source = trailingslashit( $backup_dir ) . 'jk-social-hub';
		if ( ! is_dir( $source ) ) {
			return 'backup_missing';
		}
		$wp_filesystem->delete( untrailingslashit( JKSH_DIR ), true );
		$result = copy_dir( $source, untrailingslashit( JKSH_DIR ) );
		wp_clean_plugins_cache( true );
		$this->cleanup_directory( $backup_dir );
		return is_wp_error( $result ) ? 'restore_failed' : 'restored';
	}

	private function cleanup_directory( string $dir ): void {
		if ( '' === $dir || ! is_dir( $dir ) ) {
			return;
		}
		$this->load_admin_helpers();
		if ( function_exists( 'WP_Filesystem' ) && WP_Filesystem() ) {
			global $wp_filesystem;
			$wp_filesystem->delete( $dir, true );
		}
	}

	private function acquire_lock(): true|\WP_Error {
		$now = time();
		$existing = get_option( self::LOCK_OPTION, array() );
		if ( is_array( $existing ) && ! empty( $existing['created_at'] ) && (int) $existing['created_at'] < ( $now - self::LOCK_TTL ) ) {
			delete_option( self::LOCK_OPTION );
		}
		$created = add_option(
			self::LOCK_OPTION,
			array( 'created_at' => $now, 'user_id' => get_current_user_id() ),
			'',
			false
		);
		if ( ! $created ) {
			return new \WP_Error( 'jksh_update_locked', 'Another JK Social Hub plugin update is already in progress.' );
		}
		return true;
	}

	private function release_lock(): void {
		delete_option( self::LOCK_OPTION );
	}

	private function plugin_is_active(): bool {
		$this->load_admin_helpers();
		return function_exists( 'is_plugin_active' ) && is_plugin_active( self::PLUGIN_BASENAME );
	}

	private function load_admin_helpers(): void {
		if ( ! function_exists( 'get_plugin_data' ) || ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		if ( ! function_exists( 'WP_Filesystem' ) || ! function_exists( 'copy_dir' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
	}

	private function parse_plugin_headers( string $contents ): array {
		return array(
			'plugin_name'  => $this->header_value( $contents, 'Plugin Name' ),
			'version'      => $this->header_value( $contents, 'Version' ),
			'text_domain'  => $this->header_value( $contents, 'Text Domain' ),
			'requires_php' => $this->header_value( $contents, 'Requires PHP' ),
			'requires_wp'  => $this->header_value( $contents, 'Requires at least' ),
		);
	}

	private function header_value( string $contents, string $header ): string {
		$pattern = '/^[ \t\/*#@]*' . preg_quote( $header, '/' ) . '\s*:\s*(.+)$/mi';
		if ( preg_match( $pattern, $contents, $match ) ) {
			return trim( preg_replace( '/\s*(?:\*\/|\?>).*/', '', (string) $match[1] ) );
		}
		return '';
	}

	private function zip_entry_is_symlink( \ZipArchive $zip, int $index ): bool {
		$opsys = 0;
		$attr  = 0;
		if ( method_exists( $zip, 'getExternalAttributesIndex' ) && $zip->getExternalAttributesIndex( $index, $opsys, $attr ) ) {
			if ( \ZipArchive::OPSYS_UNIX === $opsys ) {
				$mode = ( $attr >> 16 ) & 0xF000;
				return 0xA000 === $mode;
			}
		}
		return false;
	}

	private function normalize_input( mixed $input ): array {
		if ( is_array( $input ) ) {
			return $input;
		}
		if ( is_object( $input ) ) {
			return get_object_vars( $input );
		}
		return array();
	}

	private function audit( string $action, string $result, string $message, array $context = array() ): void {
		try {
			( new LogRepository() )->add(
				array(
					'action'  => $action,
					'result'  => $result,
					'message' => $message,
					'context' => $context,
				)
			);
		} catch ( \Throwable $e ) {
			// Updating the plugin must not fail merely because audit logging is unavailable.
		}
	}
}
