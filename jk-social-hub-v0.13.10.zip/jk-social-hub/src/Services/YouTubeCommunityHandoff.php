<?php
namespace JKSH\Services;

use JKSH\Repositories\AccountRepository;
use JKSH\Repositories\JobRepository;
use JKSH\Repositories\LogRepository;
use JKSH\Repositories\VariantRepository;

final class YouTubeCommunityHandoff {
	public function readiness(): array {
		$client = new LiveWorkerClient();
		$health = $client->health();
		$data = is_array( $health['data'] ?? null ) ? $health['data'] : array();
		$helper = is_array( $data['community_prefill'] ?? null ) ? $data['community_prefill'] : array();
		return array(
			'ok' => ! empty( $health['ok'] ),
			'worker_status' => (int) ( $health['status'] ?? 0 ),
			'worker_message' => sanitize_textarea_field( (string) ( $health['message'] ?? '' ) ),
			'helper_available' => ! empty( $helper['available'] ),
			'helper' => $helper,
			'note' => 'YouTube Community has no public post-creation API. The browser helper fills the native composer and deliberately stops before Post/Schedule.',
		);
	}

	public function payload_for_job( int $job_id ): array|\WP_Error {
		$job = ( new JobRepository() )->get( $job_id );
		if ( ! $job || 'youtube' !== sanitize_key( (string) $job->platform ) || 'community_handoff' !== sanitize_key( (string) $job->job_type ) ) {
			return new \WP_Error( 'jksh_community_job_not_found', 'YouTube Community handoff job was not found.' );
		}
		if ( 'published_manual' === sanitize_key( (string) $job->status ) ) {
			return new \WP_Error( 'jksh_community_already_published', 'This Community handoff is already marked published.' );
		}
		$variant = ( new VariantRepository() )->get( (int) $job->variant_id );
		if ( ! $variant ) {
			return new \WP_Error( 'jksh_community_variant_not_found', 'YouTube Community variant was not found.' );
		}
		$fields = json_decode( (string) $variant->fields_json, true );
		$fields = is_array( $fields ) ? $fields : array();
		$media_ids = json_decode( (string) $variant->media_json, true );
		$media_ids = is_array( $media_ids ) ? array_values( array_filter( array_map( 'absint', $media_ids ) ) ) : array();
		$stored_delivery_urls = array_values( array_filter( array_map( 'esc_url_raw', (array) ( $fields['media_delivery_urls'] ?? array() ) ) ) );
		$delivery_urls = array();
		if ( $media_ids ) {
			foreach ( $media_ids as $index => $media_id ) {
				$url = wp_get_attachment_url( $media_id );
				if ( $url ) {
					$delivery_urls[] = esc_url_raw( $url );
				} elseif ( ! empty( $stored_delivery_urls[ $index ] ) ) {
					$delivery_urls[] = $stored_delivery_urls[ $index ];
				}
			}
		} else {
			$delivery_urls = $stored_delivery_urls;
		}
		if ( ! $delivery_urls ) {
			return new \WP_Error( 'jksh_community_media_missing', 'No original image delivery URLs are available for this Community handoff.' );
		}
		$accounts = ( new AccountRepository() )->connected( 'youtube' );
		$channel_id = $accounts ? sanitize_text_field( (string) $accounts[0]->external_account_id ) : '';
		if ( '' === $channel_id ) {
			return new \WP_Error( 'jksh_community_channel_missing', 'No connected YouTube channel is available.' );
		}
		$community_url = esc_url_raw( (string) ( $fields['youtube_community_url'] ?? '' ) );
		if ( '' === $community_url || str_contains( $community_url, '/post/' ) ) {
			$community_url = 'https://www.youtube.com/channel/' . rawurlencode( $channel_id ) . '/community';
		}
		$caption = trim( (string) ( $variant->caption ?: $variant->description ) );
		if ( '' === $caption ) {
			return new \WP_Error( 'jksh_community_caption_missing', 'The Community handoff caption is empty.' );
		}
		return array(
			'job_id' => $job_id,
			'channel_id' => $channel_id,
			'community_url' => $community_url,
			'title' => sanitize_text_field( (string) $variant->title ),
			'caption' => $caption,
			'media_urls' => $delivery_urls,
			'scheduled_at_ist' => $this->ist_time( (string) $job->scheduled_at ),
			'stop_before_publish' => true,
			'max_images' => 10,
		);
	}

	public function prefill( int $job_id ): array|\WP_Error {
		$payload = $this->payload_for_job( $job_id );
		if ( is_wp_error( $payload ) ) {
			return $payload;
		}
		$result = ( new LiveWorkerClient() )->community_prefill( $payload );
		( new LogRepository() )->add(
			array(
				'job_id' => $job_id,
				'content_id' => 0,
				'variant_id' => 0,
				'action' => 'community_prefill',
				'result' => ! empty( $result['ok'] ) ? 'success' : 'failed',
				'message' => ! empty( $result['ok'] ) ? 'YouTube Community browser prefill requested.' : (string) ( $result['message'] ?? 'Community browser prefill failed.' ),
				'context' => array(
					'worker_status' => (int) ( $result['status'] ?? 0 ),
					'media_count' => count( (array) ( $payload['media_urls'] ?? array() ) ),
					'stop_before_publish' => true,
				),
			)
		);
		return $result;
	}

	private function ist_time( string $utc_mysql ): string {
		if ( '' === trim( $utc_mysql ) ) {
			return '';
		}
		try {
			$utc = new \DateTimeImmutable( $utc_mysql, new \DateTimeZone( 'UTC' ) );
			return $utc->setTimezone( new \DateTimeZone( 'Asia/Kolkata' ) )->format( 'Y-m-d H:i:s' );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
}
