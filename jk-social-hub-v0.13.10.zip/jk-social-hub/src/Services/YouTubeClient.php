<?php
namespace JKSH\Services;

use JKSH\Repositories\AccountRepository;
use JKSH\Security\Crypto;

final class YouTubeClient {
	private AccountRepository $accounts;
	private Crypto $crypto;

	public function __construct() {
		$this->accounts = new AccountRepository();
		$this->crypto   = new Crypto();
	}

	public function channel( object $account ): array {
		return $this->request(
			$account,
			'GET',
			'https://www.googleapis.com/youtube/v3/channels',
			array(
				'part' => 'snippet,contentDetails,statistics,status',
				'mine' => 'true',
			)
		);
	}

	public function request( object $account, string $method, string $url, array $query = array(), array $body = array() ): array {
		$token = $this->access_token( $account );
		if ( ! $token['ok'] ) {
			return $token;
		}
		if ( $query ) {
			$url = add_query_arg( $query, $url );
		}
		$args = array(
			'method'      => strtoupper( $method ),
			'timeout'     => 30,
			'redirection' => 3,
			'headers'     => array(
				'Authorization' => 'Bearer ' . $token['access_token'],
				'Accept'        => 'application/json',
			),
		);
		if ( $body ) {
			$args['headers']['Content-Type'] = 'application/json; charset=UTF-8';
			$args['body'] = wp_json_encode( $body );
		}
		return $this->decode_response( wp_remote_request( $url, $args ) );
	}

	public function upload_video_resumable( object $account, string $file, string $mime, array $metadata, bool $notify_subscribers = false ): array {
		if ( ! is_readable( $file ) ) {
			return array( 'ok' => false, 'status' => 0, 'message' => 'Video file is not readable.', 'data' => array() );
		}
		if ( ! function_exists( 'curl_init' ) ) {
			return array( 'ok' => false, 'status' => 0, 'message' => 'PHP cURL is required for streamed YouTube uploads.', 'data' => array() );
		}
		$token = $this->access_token( $account );
		if ( ! $token['ok'] ) {
			return $token;
		}
		$bytes = (int) filesize( $file );
		$parts = array( 'snippet', 'status' );
		if ( ! empty( $metadata['recordingDetails'] ) ) {
			$parts[] = 'recordingDetails';
		}
		$url = add_query_arg(
			array( 'uploadType' => 'resumable', 'part' => implode( ',', $parts ), 'notifySubscribers' => $notify_subscribers ? 'true' : 'false' ),
			'https://www.googleapis.com/upload/youtube/v3/videos'
		);
		$init = wp_remote_post(
			$url,
			array(
				'timeout' => 30,
				'headers' => array(
					'Authorization'           => 'Bearer ' . $token['access_token'],
					'Accept'                  => 'application/json',
					'Content-Type'            => 'application/json; charset=UTF-8',
					'X-Upload-Content-Length' => (string) $bytes,
					'X-Upload-Content-Type'   => $mime ?: 'application/octet-stream',
				),
				'body' => wp_json_encode( $metadata ),
			)
		);
		$decoded = $this->decode_response( $init );
		if ( empty( $decoded['ok'] ) ) {
			return $decoded;
		}
		$location = (string) wp_remote_retrieve_header( $init, 'location' );
		if ( '' === $location ) {
			return array( 'ok' => false, 'status' => (int) ( $decoded['status'] ?? 0 ), 'message' => 'YouTube did not return a resumable upload session URI.', 'data' => array() );
		}
		return $this->curl_stream_request( 'PUT', $location, (string) $token['access_token'], $file, $mime ?: 'application/octet-stream' );
	}

	public function set_thumbnail( object $account, string $video_id, string $file, string $mime ): array {
		if ( ! is_readable( $file ) ) {
			return array( 'ok' => false, 'status' => 0, 'message' => 'Thumbnail file is not readable.', 'data' => array() );
		}
		$token = $this->access_token( $account );
		if ( ! $token['ok'] ) {
			return $token;
		}
		$raw = file_get_contents( $file );
		if ( false === $raw ) {
			return array( 'ok' => false, 'status' => 0, 'message' => 'Thumbnail file could not be read.', 'data' => array() );
		}
		$url = add_query_arg(
			array( 'videoId' => $video_id, 'uploadType' => 'media' ),
			'https://www.googleapis.com/upload/youtube/v3/thumbnails/set'
		);
		$response = wp_remote_request(
			$url,
			array(
				'method'  => 'POST',
				'timeout' => 60,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token['access_token'],
					'Accept'        => 'application/json',
					'Content-Type'  => $mime ?: 'application/octet-stream',
					'Content-Length'=> (string) strlen( $raw ),
				),
				'body' => $raw,
			)
		);
		return $this->decode_response( $response );
	}

	public function add_to_playlist( object $account, string $playlist_id, string $video_id ): array {
		return $this->request(
			$account,
			'POST',
			'https://www.googleapis.com/youtube/v3/playlistItems',
			array( 'part' => 'snippet' ),
			array(
				'snippet' => array(
					'playlistId' => $playlist_id,
					'resourceId' => array( 'kind' => 'youtube#video', 'videoId' => $video_id ),
				),
			)
		);
	}


	public function list_live_broadcasts( object $account, int $max_results = 1 ): array {
		return $this->request(
			$account,
			'GET',
			'https://www.googleapis.com/youtube/v3/liveBroadcasts',
			array(
				'part' => 'id,snippet,status,contentDetails',
				'mine' => 'true',
				'broadcastType' => 'all',
				'maxResults' => max( 0, min( 50, $max_results ) ),
			)
		);
	}

	public function list_live_streams( object $account, int $max_results = 1 ): array {
		return $this->request(
			$account,
			'GET',
			'https://www.googleapis.com/youtube/v3/liveStreams',
			array(
				'part' => 'id,snippet,cdn,status',
				'mine' => 'true',
				'maxResults' => max( 0, min( 50, $max_results ) ),
			)
		);
	}

	public function create_live_broadcast( object $account, array $body ): array {
		return $this->request(
			$account,
			'POST',
			'https://www.googleapis.com/youtube/v3/liveBroadcasts',
			array( 'part' => 'id,snippet,status,contentDetails' ),
			$body
		);
	}

	public function create_live_stream( object $account, array $body ): array {
		return $this->request(
			$account,
			'POST',
			'https://www.googleapis.com/youtube/v3/liveStreams',
			array( 'part' => 'id,snippet,cdn,status,contentDetails' ),
			$body
		);
	}

	public function bind_live_broadcast( object $account, string $broadcast_id, string $stream_id ): array {
		return $this->request(
			$account,
			'POST',
			'https://www.googleapis.com/youtube/v3/liveBroadcasts/bind',
			array(
				'id' => $broadcast_id,
				'streamId' => $stream_id,
				'part' => 'id,snippet,status,contentDetails',
			)
		);
	}

	public function transition_live_broadcast( object $account, string $broadcast_id, string $status ): array {
		$status = sanitize_key( $status );
		if ( ! in_array( $status, array( 'testing', 'live', 'complete' ), true ) ) {
			return array( 'ok' => false, 'status' => 0, 'message' => 'Unsupported YouTube live transition status.', 'data' => array() );
		}
		return $this->request(
			$account,
			'POST',
			'https://www.googleapis.com/youtube/v3/liveBroadcasts/transition',
			array( 'id' => $broadcast_id, 'broadcastStatus' => $status, 'part' => 'id,status,contentDetails' )
		);
	}

	public function delete_live_broadcast( object $account, string $broadcast_id ): array {
		return $this->request(
			$account,
			'DELETE',
			'https://www.googleapis.com/youtube/v3/liveBroadcasts',
			array( 'id' => $broadcast_id )
		);
	}

	public function delete_live_stream( object $account, string $stream_id ): array {
		return $this->request(
			$account,
			'DELETE',
			'https://www.googleapis.com/youtube/v3/liveStreams',
			array( 'id' => $stream_id )
		);
	}

	private function curl_stream_request( string $method, string $url, string $token, string $file, string $mime ): array {
		$fh = fopen( $file, 'rb' );
		if ( false === $fh ) {
			return array( 'ok' => false, 'status' => 0, 'message' => 'Video file could not be opened for streaming.', 'data' => array() );
		}
		$ch = curl_init( $url );
		curl_setopt_array(
			$ch,
			array(
				CURLOPT_CUSTOMREQUEST  => $method,
				CURLOPT_UPLOAD         => true,
				CURLOPT_INFILE         => $fh,
				CURLOPT_INFILESIZE     => (int) filesize( $file ),
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HEADER         => true,
				CURLOPT_CONNECTTIMEOUT => 30,
				CURLOPT_TIMEOUT        => 0,
				CURLOPT_FOLLOWLOCATION => false,
				CURLOPT_HTTPHEADER     => array(
					'Authorization: Bearer ' . $token,
					'Accept: application/json',
					'Content-Type: ' . $mime,
					'Content-Length: ' . (int) filesize( $file ),
				),
			)
		);
		$raw = curl_exec( $ch );
		$error = curl_error( $ch );
		$status = (int) curl_getinfo( $ch, CURLINFO_RESPONSE_CODE );
		$header_size = (int) curl_getinfo( $ch, CURLINFO_HEADER_SIZE );
		curl_close( $ch );
		fclose( $fh );
		if ( false === $raw ) {
			return array( 'ok' => false, 'status' => $status, 'message' => sanitize_textarea_field( $error ?: 'YouTube streamed upload failed.' ), 'data' => array() );
		}
		$body = substr( (string) $raw, $header_size );
		$data = json_decode( $body, true );
		$data = is_array( $data ) ? $data : array();
		if ( $status >= 200 && $status < 300 ) {
			return array( 'ok' => true, 'status' => $status, 'data' => $data, 'message' => '' );
		}
		$message = (string) ( $data['error']['message'] ?? 'YouTube streamed upload failed.' );
		return array( 'ok' => false, 'status' => $status, 'data' => $data, 'message' => sanitize_textarea_field( $message ) );
	}

	private function access_token( object $account ): array {
		$credentials = $this->accounts->credentials( $account );
		$access      = (string) ( $credentials['access_token'] ?? '' );
		$expires_at  = ! empty( $account->token_expires_at ) ? strtotime( (string) $account->token_expires_at . ' UTC' ) : false;
		if ( '' !== $access && ( false === $expires_at || $expires_at > time() + 120 ) ) {
			return array( 'ok' => true, 'access_token' => $access );
		}

		$refresh = (string) ( $credentials['refresh_token'] ?? '' );
		if ( '' === $refresh ) {
			return array( 'ok' => false, 'message' => 'YouTube refresh token is unavailable. Reconnect YouTube.' );
		}
		$config = wp_parse_args( (array) get_option( YouTubeConnector::OPTION, array() ), ( new YouTubeConnector() )->defaults() );
		$secret = $this->crypto->decrypt( (string) ( $config['client_secret_encrypted'] ?? '' ) );
		if ( '' === (string) ( $config['client_id'] ?? '' ) || '' === $secret ) {
			return array( 'ok' => false, 'message' => 'YouTube OAuth client credentials are not configured.' );
		}

		$response = wp_remote_post(
			'https://oauth2.googleapis.com/token',
			array(
				'timeout' => 30,
				'body'    => array(
					'client_id'     => (string) $config['client_id'],
					'client_secret' => $secret,
					'refresh_token' => $refresh,
					'grant_type'    => 'refresh_token',
				),
			)
		);
		$decoded = $this->decode_response( $response );
		if ( ! $decoded['ok'] || empty( $decoded['data']['access_token'] ) ) {
			return array( 'ok' => false, 'message' => 'YouTube token refresh failed: ' . ( $decoded['message'] ?? 'Unknown error.' ) );
		}

		$credentials['access_token'] = sanitize_text_field( (string) $decoded['data']['access_token'] );
		$credentials['token_type']   = sanitize_text_field( (string) ( $decoded['data']['token_type'] ?? 'Bearer' ) );
		$credentials['scope']        = sanitize_text_field( (string) ( $decoded['data']['scope'] ?? ( $credentials['scope'] ?? '' ) ) );
		$expires_in = max( 0, (int) ( $decoded['data']['expires_in'] ?? 0 ) );
		$expiry = $expires_in ? gmdate( 'Y-m-d H:i:s', time() + $expires_in ) : null;
		$this->accounts->upsert(
			array(
				'platform'            => 'youtube',
				'account_name'        => (string) $account->account_name,
				'external_account_id' => (string) $account->external_account_id,
				'status'              => 'connected',
				'settings'            => $this->accounts->settings( $account ),
				'credentials'         => $credentials,
				'token_expires_at'    => $expiry,
				'last_checked_at'     => (string) ( $account->last_checked_at ?? '' ),
				'last_error'          => '',
			)
		);
		return array( 'ok' => true, 'access_token' => (string) $credentials['access_token'] );
	}

	private function decode_response( $response ): array {
		if ( is_wp_error( $response ) ) {
			return array( 'ok' => false, 'message' => $response->get_error_message(), 'status' => 0, 'data' => array() );
		}
		$status = (int) wp_remote_retrieve_response_code( $response );
		$raw    = (string) wp_remote_retrieve_body( $response );
		$data   = json_decode( $raw, true );
		$data   = is_array( $data ) ? $data : array();
		if ( $status >= 200 && $status < 300 ) {
			return array( 'ok' => true, 'status' => $status, 'data' => $data, 'message' => '' );
		}
		$message = (string) ( $data['error']['message'] ?? $data['error_description'] ?? $data['error'] ?? 'YouTube API request failed.' );
		return array( 'ok' => false, 'status' => $status, 'data' => $data, 'message' => sanitize_textarea_field( $message ) );
	}
}
