<?php
namespace JKSH\Services;

use JKSH\Repositories\LiveStreamRepository;
use JKSH\Repositories\LogRepository;

final class LiveWorker {
	private Settings $settings;
	private LiveStreamRepository $streams;
	private LiveSecretStore $secrets;
	private LiveWorkerClient $client;
	private LiveWorkerSigner $signer;

	public function __construct() {
		$this->settings = new Settings();
		$this->streams  = new LiveStreamRepository();
		$this->secrets  = new LiveSecretStore();
		$this->client   = new LiveWorkerClient();
		$this->signer   = new LiveWorkerSigner();
	}

	public function readiness( bool $probe = false ): array {
		$keys = $this->signer->public_bundle();
		$key_ok = ! empty( $keys['configured'] );
		$health = $probe && $this->client->endpoint_valid() ? $this->client->health() : null;
		$signed_handshake = $probe && $this->client->endpoint_valid() ? $this->client->signed_handshake() : null;
		return array(
			'contract_version' => 'jksh-relay-v1',
			'enabled' => (bool) $this->settings->get( 'live_worker_enabled', 0 ),
			'public_key_b64' => $key_ok ? base64_encode( (string) ( $keys['public_key_pem'] ?? '' ) ) : '',
			'endpoint_configured' => '' !== $this->client->endpoint(),
			'endpoint_valid' => $this->client->endpoint_valid(),
			'ingest_base_configured' => '' !== trim( (string) $this->settings->get( 'live_worker_ingest_base', '' ) ),
			'internal_ingest_base_configured' => '' !== trim( (string) $this->settings->get( 'live_worker_internal_ingest_base', 'rtmp://mediamtx:1935/jksh' ) ),
			'signing_key_configured' => $key_ok,
			'key_id' => $key_ok ? sanitize_text_field( (string) $keys['key_id'] ) : '',
			'health' => $health,
			'signed_handshake' => $signed_handshake,
			'dry_run' => (bool) $this->settings->get( 'dry_run', 1 ),
			'dispatch_possible' => $key_ok && $this->settings->get( 'live_worker_enabled', 0 ) && $this->client->endpoint_valid() && ! $this->settings->get( 'dry_run', 1 ),
			'note' => 'The relay worker runs outside WordPress. Read-only health and signed handshake probes are allowed during Dry Run; stream dispatch remains blocked while global Dry Run is ON.',
		);
	}

	public function pairing(): array|\WP_Error {
		$bundle = $this->signer->ensure();
		if ( is_wp_error( $bundle ) ) {
			return $bundle;
		}
		return array(
			'contract_version' => 'jksh-relay-v1',
			'algorithm' => 'RSA-SHA256',
			'key_id' => sanitize_text_field( (string) $bundle['key_id'] ),
			'public_key_pem' => (string) $bundle['public_key_pem'],
			'public_key_b64' => base64_encode( (string) $bundle['public_key_pem'] ),
			'worker_paths' => array(
				'health' => '/v1/health',
				'start' => '/v1/jobs/start',
				'stop' => '/v1/jobs/stop',
				'status' => '/v1/jobs/status',
				'community_prefill' => '/v1/community/prefill',
				'community_publish' => '/v1/community/publish',
			),
			'note' => 'This is a public verification key, not a credential. The private signing key never leaves WordPress.',
		);
	}

	public function preflight( int $id ): array|\WP_Error {
		$row = $this->streams->get( $id );
		if ( ! $row ) {
			return new \WP_Error( 'jksh_worker_draft', 'Live stream draft not found.' );
		}
		$destinations = json_decode( (string) $row->destinations_json, true );
		$destinations = is_array( $destinations ) ? $destinations : array();
		$metadata = json_decode( (string) $row->metadata_json, true );
		$metadata = is_array( $metadata ) ? $metadata : array();
		$source = $this->source_for( $row );
		$issues = array();
		if ( is_wp_error( $source ) ) {
			$issues[] = $source->get_error_message();
		}
		$outputs = array();
		foreach ( $destinations as $platform ) {
			$platform = sanitize_key( (string) $platform );
			$resolved = $this->destination_for( $id, $platform, $metadata );
			if ( is_wp_error( $resolved ) ) {
				$issues[] = ucfirst( $platform ) . ': ' . $resolved->get_error_message();
				continue;
			}
			$outputs[] = array( 'platform' => $platform, 'protocol' => $this->scheme_of( (string) $resolved ) );
		}
		return array(
			'ok' => empty( $issues ),
			'live_stream_id' => $id,
			'source_type' => sanitize_key( (string) $row->source_type ),
			'source_ready' => ! is_wp_error( $source ),
			'destinations_requested' => array_values( array_map( 'sanitize_key', $destinations ) ),
			'destinations_ready' => $outputs,
			'issues' => array_values( $issues ),
			'worker' => $this->readiness( false ),
			'note' => 'Preflight never returns source URLs, destination URLs, stream names or stream keys.',
		);
	}

	public function dispatch( array $input ): array|\WP_Error {
		$id = absint( $input['live_stream_id'] ?? 0 );
		if ( empty( $input['confirm'] ) ) {
			return new \WP_Error( 'jksh_worker_confirm', 'confirm=true is required before starting the relay worker.' );
		}
		if ( $this->settings->get( 'dry_run', 1 ) ) {
			return new \WP_Error( 'jksh_worker_dry_run', 'Relay-worker dispatch is blocked while global Dry Run is ON.' );
		}
		if ( ! $this->settings->get( 'live_worker_enabled', 0 ) ) {
			return new \WP_Error( 'jksh_worker_switch', 'Live relay-worker master switch is OFF.' );
		}
		$preflight = $this->preflight( $id );
		if ( is_wp_error( $preflight ) ) {
			return $preflight;
		}
		if ( empty( $preflight['ok'] ) ) {
			return new \WP_Error( 'jksh_worker_preflight', 'Relay-worker preflight failed: ' . implode( ' ', (array) $preflight['issues'] ) );
		}
		$row = $this->streams->get( $id );
		$metadata = json_decode( (string) $row->metadata_json, true );
		$metadata = is_array( $metadata ) ? $metadata : array();
		$destinations = json_decode( (string) $row->destinations_json, true );
		$destinations = is_array( $destinations ) ? $destinations : array();
		$source = $this->source_for( $row );
		if ( is_wp_error( $source ) ) {
			return $source;
		}
		$outputs = array();
		foreach ( $destinations as $platform ) {
			$resolved = $this->destination_for( $id, sanitize_key( (string) $platform ), $metadata );
			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}
			$outputs[] = array( 'platform' => sanitize_key( (string) $platform ), 'url' => (string) $resolved );
		}
		$worker_id = 'jksh-live-' . $id . '-' . substr( str_replace( '-', '', (string) $row->uuid ), 0, 12 );
		$response = $this->client->start(
			array(
				'job_id' => $worker_id,
				'live_stream_id' => $id,
				'source_url' => (string) $source,
				'outputs' => $outputs,
				'profile' => array(
					'mode' => sanitize_key( (string) ( $metadata['relay_profile']['mode'] ?? 'copy' ) ),
					'restart_on_failure' => true,
				),
			)
		);
		if ( empty( $response['ok'] ) ) {
			$this->streams->update( $id, array( 'last_error' => (string) ( $response['message'] ?? 'Relay worker rejected the job.' ) ) );
			return new \WP_Error( 'jksh_worker_start', 'Relay worker did not start: ' . sanitize_textarea_field( (string) ( $response['message'] ?? '' ) ) );
		}
		$this->streams->update( $id, array( 'worker_job_id' => $worker_id, 'status' => 'relay_starting', 'started_at' => current_time( 'mysql', true ), 'last_error' => '' ) );
		( new LogRepository() )->add( array(
			'action' => 'live_worker_start',
			'result' => 'success',
			'message' => 'Signed live relay-worker job dispatched.',
			'context' => array( 'live_stream_id' => $id, 'worker_job_id' => $worker_id, 'destinations' => array_values( array_map( 'sanitize_key', $destinations ) ) ),
		) );
		return array( 'ok' => true, 'live_stream_id' => $id, 'worker_job_id' => $worker_id, 'status' => 'relay_starting', 'secrets_returned' => false );
	}

	public function stop( array $input ): array|\WP_Error {
		$id = absint( $input['live_stream_id'] ?? 0 );
		if ( empty( $input['confirm'] ) ) {
			return new \WP_Error( 'jksh_worker_stop_confirm', 'confirm=true is required before stopping the relay worker.' );
		}
		$row = $this->streams->get( $id );
		if ( ! $row || '' === (string) $row->worker_job_id ) {
			return new \WP_Error( 'jksh_worker_job', 'No worker job is recorded for this live stream.' );
		}
		$response = $this->client->stop( (string) $row->worker_job_id );
		if ( empty( $response['ok'] ) ) {
			return new \WP_Error( 'jksh_worker_stop', 'Relay worker stop failed: ' . sanitize_textarea_field( (string) ( $response['message'] ?? '' ) ) );
		}
		$this->streams->update( $id, array( 'status' => 'relay_stopped', 'ended_at' => current_time( 'mysql', true ), 'last_error' => '' ) );
		( new LogRepository() )->add( array( 'action' => 'live_worker_stop', 'result' => 'success', 'message' => 'Live relay-worker job stopped.', 'context' => array( 'live_stream_id' => $id, 'worker_job_id' => (string) $row->worker_job_id ) ) );
		return array( 'ok' => true, 'live_stream_id' => $id, 'worker_job_id' => sanitize_text_field( (string) $row->worker_job_id ), 'status' => 'relay_stopped' );
	}

	private function source_for( object $row ): string|\WP_Error {
		$source_json = json_decode( (string) $row->source_json, true );
		$source_json = is_array( $source_json ) ? $source_json : array();
		$reference = trim( (string) ( $source_json['reference'] ?? '' ) );
		if ( '' !== $reference ) {
			if ( preg_match( '#^(?:rtmps?|srt|https?)://#i', $reference ) ) {
				return $reference;
			}
			return new \WP_Error( 'jksh_worker_source_scheme', 'Source reference must use RTMP, RTMPS, SRT, HTTP or HTTPS.' );
		}
		if ( 'rtmp_input' === (string) $row->source_type ) {
			$base = rtrim( trim( (string) $this->settings->get( 'live_worker_internal_ingest_base', 'rtmp://mediamtx:1935/jksh' ) ), '/' );
			if ( '' === $base || ! preg_match( '#^rtmps?://#i', $base ) ) {
				return new \WP_Error( 'jksh_worker_ingest_base', 'No RTMP/RTMPS worker ingest base is configured.' );
			}
			$secret = $this->secrets->get( (int) $row->id, 'worker_ingest' );
			$key = (string) ( $secret['stream_key'] ?? '' );
			if ( '' === $key ) {
				$key = 'jksh_' . wp_generate_password( 40, false, false );
				$this->secrets->put( (int) $row->id, 'worker_ingest', array( 'stream_key' => $key ) );
			}
			return $base . '/' . rawurlencode( $key );
		}
		return new \WP_Error( 'jksh_worker_source', 'This live draft does not contain a relay-worker source URL.' );
	}

	private function destination_for( int $id, string $platform, array $metadata ): string|\WP_Error {
		if ( 'youtube' === $platform ) {
			$yt = (array) ( $metadata['youtube'] ?? array() );
			$address = (string) ( $yt['rtmps_ingestion_address'] ?? $yt['ingestion_address'] ?? '' );
			$key = (string) ( $this->secrets->get( $id, 'youtube' )['stream_name'] ?? '' );
			if ( '' === $address || '' === $key ) {
				return new \WP_Error( 'jksh_worker_youtube', 'YouTube Live has not been provisioned for this draft.' );
			}
			return rtrim( $address, '/' ) . '/' . rawurlencode( $key );
		}
		$secret = $this->secrets->get( $id, $platform );
		$url = (string) ( $secret['stream_url'] ?? '' );
		if ( '' === $url ) {
			return new \WP_Error( 'jksh_worker_destination', 'No encrypted live ingest URL is stored for this destination.' );
		}
		if ( ! preg_match( '#^rtmps?://#i', $url ) ) {
			return new \WP_Error( 'jksh_worker_destination_scheme', 'Destination ingest URL is not RTMP/RTMPS.' );
		}
		return $url;
	}

	private function scheme_of( string $url ): string {
		$pos = strpos( $url, '://' );
		return false === $pos ? '' : sanitize_key( substr( $url, 0, $pos ) );
	}
}
