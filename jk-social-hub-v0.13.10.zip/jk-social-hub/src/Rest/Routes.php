<?php
namespace JKSH\Rest;

use JKSH\Repositories\AccountRepository;
use JKSH\Repositories\ContentRepository;
use JKSH\Repositories\JobRepository;
use JKSH\Repositories\VariantRepository;
use JKSH\Services\MetaConnector;
use JKSH\Services\Settings;

final class Routes {
	public function register(): void {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
	}

	public function routes(): void {
		register_rest_route(
			'jksh/v1',
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'status' ),
				'permission_callback' => static fn() => current_user_can( 'jksh_view' ),
			)
		);

		register_rest_route(
			'jksh/v1',
			'/accounts',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'accounts' ),
				'permission_callback' => static fn() => current_user_can( 'jksh_manage_accounts' ),
			)
		);

		register_rest_route(
			'jksh/v1',
			'/content',
			array(
				'methods'             => 'GET',
				'callback'            => static fn() => rest_ensure_response( ( new ContentRepository() )->recent( 100 ) ),
				'permission_callback' => static fn() => current_user_can( 'jksh_view' ),
			)
		);

		register_rest_route(
			'jksh/v1',
			'/variants',
			array(
				'methods'             => 'GET',
				'callback'            => static fn() => rest_ensure_response( ( new VariantRepository() )->recent( 150 ) ),
				'permission_callback' => static fn() => current_user_can( 'jksh_view' ),
			)
		);

		register_rest_route(
			'jksh/v1',
			'/jobs',
			array(
				'methods'             => 'GET',
				'callback'            => static fn() => rest_ensure_response( ( new JobRepository() )->recent( 150 ) ),
				'permission_callback' => static fn() => current_user_can( 'jksh_view' ),
			)
		);
	}

	public function accounts(): \WP_REST_Response {
		$rows = array_map(
			static function ( $account ) {
				return array(
					'id'                  => (int) $account->id,
					'platform'            => (string) $account->platform,
					'account_name'        => (string) $account->account_name,
					'external_account_id' => (string) $account->external_account_id,
					'status'              => (string) $account->status,
					'token_expires_at'    => $account->token_expires_at,
					'last_checked_at'     => $account->last_checked_at,
					'last_error'          => (string) $account->last_error,
				);
			},
			( new AccountRepository() )->all()
		);
		return new \WP_REST_Response( $rows, 200 );
	}

	public function status(): \WP_REST_Response {
		global $wpdb;
		$settings = new Settings();
		$data = array(
			'plugin_version'  => JKSH_VERSION,
			'db_version'      => (string) get_option( 'jksh_db_version', '' ),
			'dry_run'         => (bool) $settings->get( 'dry_run', 1 ),
			'timezone'        => (string) $settings->get( 'timezone', 'Asia/Kolkata' ),
			'wordpress_tz'    => wp_timezone_string(),
			'action_scheduler'=> function_exists( 'as_schedule_single_action' ),
			'wp_cron_disabled'=> (bool) ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ),
			'php_version'     => PHP_VERSION,
			'wp_version'      => get_bloginfo( 'version' ),
			'meta_configured' => ( new MetaConnector() )->is_configured(),
			'tables'          => array(),
		);

		foreach ( array( 'accounts','content','variants','media','jobs','publish_logs','analytics','templates','campaigns' ) as $table ) {
			$name = $wpdb->prefix . 'jksh_' . $table;
			$data['tables'][ $table ] = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $name ) );
		}

		return new \WP_REST_Response( $data, 200 );
	}
}
