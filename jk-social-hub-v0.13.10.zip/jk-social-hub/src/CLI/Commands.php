<?php
namespace JKSH\CLI;

use JKSH\Repositories\ContentRepository;
use JKSH\Repositories\JobRepository;
use JKSH\Services\Settings;

final class Commands {
	public static function register(): void {
		\WP_CLI::add_command( 'jksh status', array( self::class, 'status' ) );
		\WP_CLI::add_command( 'jksh queue', array( self::class, 'queue' ) );
	}

	public static function status(): void {
		$settings = new Settings();
		\WP_CLI::success(
			wp_json_encode(
				array(
					'version'          => JKSH_VERSION,
					'db_version'       => get_option( 'jksh_db_version', '' ),
					'dry_run'          => (bool) $settings->get( 'dry_run', 1 ),
					'timezone'         => $settings->get( 'timezone' ),
					'content_records'  => count( ( new ContentRepository() )->recent( 200 ) ),
					'queue_records'    => count( ( new JobRepository() )->recent( 200 ) ),
				),
				JSON_PRETTY_PRINT
			)
		);
	}

	public static function queue(): void {
		$rows = ( new JobRepository() )->recent( 50 );
		\WP_CLI\Utils\format_items( 'table', $rows, array( 'id','platform','job_type','status','attempts','scheduled_at' ) );
	}
}
