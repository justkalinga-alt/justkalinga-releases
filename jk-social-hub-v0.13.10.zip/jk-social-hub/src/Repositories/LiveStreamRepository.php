<?php
namespace JKSH\Repositories;

final class LiveStreamRepository {
	private string $table;
	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'jksh_live_streams';
	}
	public function create( array $data ): int {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->insert(
			$this->table,
			array(
				'uuid' => wp_generate_uuid4(),
				'title' => sanitize_text_field( $data['title'] ?? '' ),
				'description' => sanitize_textarea_field( $data['description'] ?? '' ),
				'source_type' => sanitize_key( $data['source_type'] ?? 'rtmp_input' ),
				'source_json' => wp_json_encode( $data['source'] ?? array() ),
				'destinations_json' => wp_json_encode( $data['destinations'] ?? array() ),
				'metadata_json' => wp_json_encode( $data['metadata'] ?? array() ),
				'status' => sanitize_key( $data['status'] ?? 'draft' ),
				'scheduled_start_at' => empty( $data['scheduled_start_at'] ) ? null : sanitize_text_field( $data['scheduled_start_at'] ),
				'started_at' => null,
				'ended_at' => null,
				'worker_job_id' => '',
				'last_error' => '',
				'author_id' => get_current_user_id(),
				'created_at' => $now,
				'updated_at' => $now,
			)
		);
		return (int) $wpdb->insert_id;
	}
	public function get( int $id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function update( int $id, array $data ): bool {
		global $wpdb;
		$fields = array();
		$formats = array();
		if ( array_key_exists( 'metadata', $data ) ) {
			$fields['metadata_json'] = wp_json_encode( $data['metadata'] );
			$formats[] = '%s';
		}
		if ( array_key_exists( 'status', $data ) ) {
			$fields['status'] = sanitize_key( (string) $data['status'] );
			$formats[] = '%s';
		}
		if ( array_key_exists( 'worker_job_id', $data ) ) {
			$fields['worker_job_id'] = sanitize_text_field( (string) $data['worker_job_id'] );
			$formats[] = '%s';
		}
		if ( array_key_exists( 'last_error', $data ) ) {
			$fields['last_error'] = sanitize_textarea_field( (string) $data['last_error'] );
			$formats[] = '%s';
		}
		if ( array_key_exists( 'started_at', $data ) ) {
			$fields['started_at'] = empty( $data['started_at'] ) ? null : sanitize_text_field( (string) $data['started_at'] );
			$formats[] = '%s';
		}
		if ( array_key_exists( 'ended_at', $data ) ) {
			$fields['ended_at'] = empty( $data['ended_at'] ) ? null : sanitize_text_field( (string) $data['ended_at'] );
			$formats[] = '%s';
		}
		if ( ! $fields ) {
			return true;
		}
		$fields['updated_at'] = current_time( 'mysql', true );
		$formats[] = '%s';
		$result = $wpdb->update( $this->table, $fields, array( 'id' => $id ), $formats, array( '%d' ) );
		return false !== $result;
	}

	public function recent( int $limit = 50 ): array {
		global $wpdb;
		$limit = max( 1, min( 200, $limit ) );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table} ORDER BY id DESC LIMIT %d", $limit ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}
}
