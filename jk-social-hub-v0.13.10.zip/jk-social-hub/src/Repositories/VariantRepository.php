<?php
namespace JKSH\Repositories;

final class VariantRepository {
	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'jksh_variants';
	}

	public function create( array $data ): int {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->insert(
			$this->table,
			array(
				'uuid'             => wp_generate_uuid4(),
				'content_id'       => (int) ( $data['content_id'] ?? 0 ),
				'platform'         => sanitize_key( $data['platform'] ?? '' ),
				'publication_type' => sanitize_key( $data['publication_type'] ?? 'post' ),
				'title'            => sanitize_text_field( $data['title'] ?? '' ),
				'caption'          => sanitize_textarea_field( $data['caption'] ?? '' ),
				'description'      => sanitize_textarea_field( $data['description'] ?? '' ),
				'hashtags'         => sanitize_text_field( $data['hashtags'] ?? '' ),
				'cta'              => sanitize_textarea_field( $data['cta'] ?? '' ),
				'media_json'       => wp_json_encode( $data['media'] ?? array() ),
				'fields_json'      => wp_json_encode( $data['fields'] ?? array() ),
				'publish_at'       => empty( $data['publish_at'] ) ? null : sanitize_text_field( $data['publish_at'] ),
				'status'           => sanitize_key( $data['status'] ?? 'draft' ),
				'external_id'      => '',
				'external_url'     => '',
				'analytics_json'   => wp_json_encode( array() ),
				'created_at'       => $now,
				'updated_at'       => $now,
			),
			array( '%s','%d','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s' )
		);
		return (int) $wpdb->insert_id;
	}

	public function get( int $id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function by_content( int $content_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE content_id = %d ORDER BY id ASC", $content_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function recent( int $limit = 100 ): array {
		global $wpdb;
		$limit = max( 1, min( 300, $limit ) );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table} ORDER BY id DESC LIMIT %d", $limit ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function update_fields( int $id, array $data ): void {
		global $wpdb;
		$allowed = array();
		foreach ( array( 'title', 'caption', 'description', 'hashtags', 'cta', 'media_json', 'fields_json', 'publish_at', 'status' ) as $key ) {
			if ( array_key_exists( $key, $data ) ) {
				$allowed[ $key ] = in_array( $key, array( 'title', 'hashtags', 'publish_at', 'status' ), true ) ? sanitize_text_field( (string) $data[ $key ] ) : ( in_array( $key, array( 'media_json', 'fields_json' ), true ) ? (string) $data[ $key ] : sanitize_textarea_field( (string) $data[ $key ] ) );
			}
		}
		if ( ! $allowed ) {
			return;
		}
		$allowed['updated_at'] = current_time( 'mysql', true );
		$wpdb->update( $this->table, $allowed, array( 'id' => $id ) );
	}

	public function update_status( int $id, string $status, array $extra = array() ): void {
		global $wpdb;
		$data = array_merge(
			array(
				'status'     => sanitize_key( $status ),
				'updated_at' => current_time( 'mysql', true ),
			),
			$extra
		);
		$wpdb->update( $this->table, $data, array( 'id' => $id ) );
	}
}
