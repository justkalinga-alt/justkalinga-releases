<?php
namespace JKSH\Repositories;

final class JobRepository {
	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'jksh_jobs';
	}

	public function create( array $data ): int {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$key = sanitize_text_field( $data['idempotency_key'] ?? '' );
		if ( '' === $key ) {
			$key = hash( 'sha256', implode( '|', array( $data['variant_id'] ?? 0, $data['platform'] ?? '', $data['job_type'] ?? '', $data['scheduled_at'] ?? $now ) ) );
		}

		$wpdb->insert(
			$this->table,
			array(
				'uuid'               => wp_generate_uuid4(),
				'idempotency_key'    => $key,
				'content_id'         => (int) ( $data['content_id'] ?? 0 ),
				'variant_id'         => (int) ( $data['variant_id'] ?? 0 ),
				'platform'           => sanitize_key( $data['platform'] ?? '' ),
				'job_type'           => sanitize_key( $data['job_type'] ?? 'publish' ),
				'status'             => sanitize_key( $data['status'] ?? 'queued' ),
				'attempts'           => 0,
				'max_attempts'       => (int) ( $data['max_attempts'] ?? 3 ),
				'payload_json'       => wp_json_encode( $data['payload'] ?? array() ),
				'last_response_json' => wp_json_encode( array() ),
				'last_error'         => '',
				'scheduled_at'       => sanitize_text_field( $data['scheduled_at'] ?? $now ),
				'started_at'         => null,
				'completed_at'       => null,
				'created_at'         => $now,
				'updated_at'         => $now,
			),
			array( '%s','%s','%d','%d','%s','%s','%s','%d','%d','%s','%s','%s','%s','%s','%s','%s','%s' )
		);

		if ( $wpdb->last_error && str_contains( strtolower( $wpdb->last_error ), 'duplicate' ) ) {
			$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$this->table} WHERE idempotency_key = %s", $key ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			return (int) $existing;
		}
		return (int) $wpdb->insert_id;
	}

	public function get( int $id ): ?object {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( $row ) {
			$payload = json_decode( (string) ( $row->payload_json ?? '{}' ), true );
			$payload = is_array( $payload ) ? $payload : array();
			// publish_mode is intentionally captured inside payload_json, not a DB column.
			// Hydrate it for platform connectors that consume the repository object directly.
			$row->publish_mode = sanitize_key( (string) ( $payload['publish_mode'] ?? ( ! empty( $payload['dry_run'] ) ? 'dry_run' : 'dry_run' ) ) );
		}
		return $row;
	}


	public function by_content( int $content_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE content_id = %d ORDER BY id ASC", $content_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function recent( int $limit = 100 ): array {
		global $wpdb;
		$limit = max( 1, min( 300, $limit ) );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table} ORDER BY id DESC LIMIT %d", $limit ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function update( int $id, array $data ): void {
		global $wpdb;
		$data['updated_at'] = current_time( 'mysql', true );
		$wpdb->update( $this->table, $data, array( 'id' => $id ) );
	}
}
