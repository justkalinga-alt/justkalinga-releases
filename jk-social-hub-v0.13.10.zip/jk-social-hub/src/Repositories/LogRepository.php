<?php
namespace JKSH\Repositories;

final class LogRepository {
	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'jksh_publish_logs';
	}

	public function add( array $data ): int {
		global $wpdb;
		$wpdb->insert(
			$this->table,
			array(
				'job_id'       => (int) ( $data['job_id'] ?? 0 ),
				'content_id'   => (int) ( $data['content_id'] ?? 0 ),
				'variant_id'   => (int) ( $data['variant_id'] ?? 0 ),
				'user_id'      => (int) ( $data['user_id'] ?? get_current_user_id() ),
				'action'       => sanitize_key( $data['action'] ?? 'event' ),
				'result'       => sanitize_key( $data['result'] ?? 'info' ),
				'external_id'  => sanitize_text_field( $data['external_id'] ?? '' ),
				'external_url' => esc_url_raw( $data['external_url'] ?? '' ),
				'message'      => sanitize_textarea_field( $data['message'] ?? '' ),
				'context_json' => wp_json_encode( $data['context'] ?? array() ),
				'created_at'   => current_time( 'mysql', true ),
			)
		);
		return (int) $wpdb->insert_id;
	}

	public function recent( int $limit = 100 ): array {
		global $wpdb;
		$limit = max( 1, min( 500, $limit ) );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table} ORDER BY id DESC LIMIT %d", $limit ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}
	public function recent_by_actions( array $actions, int $limit = 100 ): array {
		global $wpdb;
		$actions = array_values( array_filter( array_map( 'sanitize_key', $actions ) ) );
		$limit   = max( 1, min( 500, $limit ) );
		if ( ! $actions ) {
			return array();
		}

		$placeholders = implode( ', ', array_fill( 0, count( $actions ), '%s' ) );
		$sql = "SELECT * FROM {$this->table} WHERE action IN ({$placeholders}) ORDER BY id DESC LIMIT %d";
		$args = array_merge( $actions, array( $limit ) );
		return $wpdb->get_results( $wpdb->prepare( $sql, ...$args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

}
