<?php
namespace JKSH\Repositories;

use JKSH\Security\Crypto;

final class AccountRepository {
	private string $table;
	private Crypto $crypto;

	public function __construct() {
		global $wpdb;
		$this->table  = $wpdb->prefix . 'jksh_accounts';
		$this->crypto = new Crypto();
	}

	public function all(): array {
		global $wpdb;
		return $wpdb->get_results( "SELECT * FROM {$this->table} ORDER BY platform ASC, account_name ASC, id ASC" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function active(): array {
		global $wpdb;
		return $wpdb->get_results( "SELECT * FROM {$this->table} WHERE status <> 'not_connected' ORDER BY platform ASC, account_name ASC, id ASC" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function connected( string $platform = '' ): array {
		global $wpdb;
		if ( '' !== $platform ) {
			return $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$this->table} WHERE status = 'connected' AND platform = %s ORDER BY account_name ASC, id ASC",
					sanitize_key( $platform )
				)
			); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
		return $wpdb->get_results( "SELECT * FROM {$this->table} WHERE status = 'connected' ORDER BY platform ASC, account_name ASC, id ASC" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function get( int $id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function find( string $platform, string $external_account_id ): ?object {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$this->table} WHERE platform = %s AND external_account_id = %s LIMIT 1",
				sanitize_key( $platform ),
				sanitize_text_field( $external_account_id )
			)
		); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function upsert( array $data ): int {
		global $wpdb;
		$platform = sanitize_key( $data['platform'] ?? '' );
		$external = sanitize_text_field( $data['external_account_id'] ?? '' );
		if ( '' === $platform || '' === $external ) {
			return 0;
		}

		$existing = $this->find( $platform, $external );
		$now      = current_time( 'mysql', true );
		$row      = array(
			'platform'            => $platform,
			'account_name'        => sanitize_text_field( $data['account_name'] ?? '' ),
			'external_account_id' => $external,
			'parent_account_id'   => (int) ( $data['parent_account_id'] ?? 0 ),
			'status'              => sanitize_key( $data['status'] ?? 'connected' ),
			'settings_json'       => wp_json_encode( $data['settings'] ?? array() ),
			'token_expires_at'    => empty( $data['token_expires_at'] ) ? null : sanitize_text_field( $data['token_expires_at'] ),
			'last_checked_at'     => empty( $data['last_checked_at'] ) ? null : sanitize_text_field( $data['last_checked_at'] ),
			'last_error'          => sanitize_textarea_field( $data['last_error'] ?? '' ),
			'updated_at'          => $now,
		);

		if ( array_key_exists( 'credentials', $data ) ) {
			$row['credentials_encrypted'] = $this->crypto->encrypt( wp_json_encode( (array) $data['credentials'] ) );
		}

		if ( $existing ) {
			$wpdb->update( $this->table, $row, array( 'id' => (int) $existing->id ) );
			return (int) $existing->id;
		}

		$row['created_at'] = $now;
		if ( ! isset( $row['credentials_encrypted'] ) ) {
			$row['credentials_encrypted'] = '';
		}
		$wpdb->insert( $this->table, $row );
		return (int) $wpdb->insert_id;
	}

	public function credentials( object $account ): array {
		if ( empty( $account->credentials_encrypted ) ) {
			return array();
		}
		$json = $this->crypto->decrypt( (string) $account->credentials_encrypted );
		$data = json_decode( $json, true );
		return is_array( $data ) ? $data : array();
	}

	public function settings( object $account ): array {
		$data = json_decode( (string) ( $account->settings_json ?? '' ), true );
		return is_array( $data ) ? $data : array();
	}

	public function update_status( int $id, string $status, string $error = '', bool $touch = true ): void {
		global $wpdb;
		$data = array(
			'status'     => sanitize_key( $status ),
			'last_error' => sanitize_textarea_field( $error ),
			'updated_at' => current_time( 'mysql', true ),
		);
		if ( $touch ) {
			$data['last_checked_at'] = current_time( 'mysql', true );
		}
		$wpdb->update( $this->table, $data, array( 'id' => $id ) );
	}

	public function disconnect( int $id ): void {
		global $wpdb;
		$wpdb->update(
			$this->table,
			array(
				'status'                => 'not_connected',
				'credentials_encrypted' => '',
				'token_expires_at'      => null,
				'last_checked_at'       => current_time( 'mysql', true ),
				'last_error'            => '',
				'updated_at'            => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);
	}
}
