<?php
namespace JKSH\Repositories;

final class TemplateRepository {
	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'jksh_templates';
	}

	public function all(): array {
		global $wpdb;
		return $wpdb->get_results( "SELECT * FROM {$this->table} ORDER BY id DESC" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function create( array $data ): int {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->insert(
			$this->table,
			array(
				'name'          => sanitize_text_field( $data['name'] ?? '' ),
				'content_type'  => sanitize_key( $data['content_type'] ?? '' ),
				'platform'      => sanitize_key( $data['platform'] ?? '' ),
				'template_kind' => sanitize_key( $data['template_kind'] ?? 'caption' ),
				'body'          => sanitize_textarea_field( $data['body'] ?? '' ),
				'status'        => 'active',
				'created_at'    => $now,
				'updated_at'    => $now,
			)
		);
		return (int) $wpdb->insert_id;
	}
}
