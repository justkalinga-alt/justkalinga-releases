<?php
namespace JKSH;

use JKSH\Admin\Menu;
use JKSH\Admin\MetaActions;
use JKSH\Admin\YouTubeActions;
use JKSH\Admin\CommunityActions;
use JKSH\DB\Migrator;
use JKSH\Queue\Dispatcher;
use JKSH\Rest\Routes;
use JKSH\Services\Settings;
use JKSH\Services\LiveWorkerSigner;

final class Plugin {
	private static ?Plugin $instance = null;

	private bool $booted = false;

	public static function instance(): Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function boot(): void {
		if ( $this->booted ) {
			return;
		}
		$this->booted = true;

		( new Migrator() )->maybe_migrate();
		( new Settings() )->register();
		// Generate the relay-worker signing key locally once. The private key never leaves WordPress.
		( new LiveWorkerSigner() )->ensure();
		( new Dispatcher() )->register();
		( new Routes() )->register();
		( new MetaActions() )->register();
		( new YouTubeActions() )->register();
		( new CommunityActions() )->register();

		if ( is_admin() ) {
			( new Menu() )->register();
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\JKSH\CLI\Commands::register();
		}
	}
}
