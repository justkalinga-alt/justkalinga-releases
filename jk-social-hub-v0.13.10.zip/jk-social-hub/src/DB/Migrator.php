<?php
namespace JKSH\DB;

final class Migrator {
	public function maybe_migrate(): void {
		$current = (string) get_option( 'jksh_db_version', '' );
		if ( version_compare( $current, JKSH_DB_VERSION, '<' ) ) {
			$this->migrate();
		}
	}

	public function migrate(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$p       = $wpdb->prefix;

		$sql = array();

		$sql[] = "CREATE TABLE {$p}jksh_accounts (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			platform varchar(32) NOT NULL,
			account_name varchar(191) NOT NULL DEFAULT '',
			external_account_id varchar(191) NOT NULL DEFAULT '',
			parent_account_id bigint(20) unsigned NOT NULL DEFAULT 0,
			status varchar(32) NOT NULL DEFAULT 'not_connected',
			credentials_encrypted longtext NULL,
			settings_json longtext NULL,
			token_expires_at datetime NULL,
			last_checked_at datetime NULL,
			last_error text NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY platform_external (platform,external_account_id(150)),
			KEY platform (platform),
			KEY status (status),
			KEY parent_account_id (parent_account_id)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}jksh_content (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			uuid char(36) NOT NULL,
			title varchar(255) NOT NULL,
			content_type varchar(64) NOT NULL,
			body longtext NULL,
			status varchar(32) NOT NULL DEFAULT 'draft',
			media_json longtext NULL,
			meta_json longtext NULL,
			author_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY uuid (uuid),
			KEY content_type (content_type),
			KEY status (status),
			KEY created_at (created_at)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}jksh_variants (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			uuid char(36) NOT NULL,
			content_id bigint(20) unsigned NOT NULL,
			platform varchar(32) NOT NULL,
			publication_type varchar(64) NOT NULL DEFAULT 'post',
			title text NULL,
			caption longtext NULL,
			description longtext NULL,
			hashtags text NULL,
			cta text NULL,
			media_json longtext NULL,
			fields_json longtext NULL,
			publish_at datetime NULL,
			status varchar(32) NOT NULL DEFAULT 'draft',
			external_id varchar(191) NOT NULL DEFAULT '',
			external_url text NULL,
			analytics_json longtext NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY uuid (uuid),
			KEY content_id (content_id),
			KEY platform (platform),
			KEY status (status),
			KEY publish_at (publish_at)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}jksh_media (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			content_id bigint(20) unsigned NOT NULL DEFAULT 0,
			attachment_id bigint(20) unsigned NOT NULL DEFAULT 0,
			source_type varchar(32) NOT NULL DEFAULT 'wordpress',
			source_url text NULL,
			meta_json longtext NULL,
			sort_order int(11) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY content_id (content_id),
			KEY attachment_id (attachment_id)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}jksh_jobs (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			uuid char(36) NOT NULL,
			idempotency_key varchar(191) NOT NULL,
			content_id bigint(20) unsigned NOT NULL DEFAULT 0,
			variant_id bigint(20) unsigned NOT NULL DEFAULT 0,
			platform varchar(32) NOT NULL,
			job_type varchar(64) NOT NULL,
			status varchar(32) NOT NULL DEFAULT 'queued',
			attempts int(11) NOT NULL DEFAULT 0,
			max_attempts int(11) NOT NULL DEFAULT 3,
			payload_json longtext NULL,
			last_response_json longtext NULL,
			last_error text NULL,
			scheduled_at datetime NULL,
			started_at datetime NULL,
			completed_at datetime NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY uuid (uuid),
			UNIQUE KEY idempotency_key (idempotency_key),
			KEY status (status),
			KEY scheduled_at (scheduled_at),
			KEY variant_id (variant_id)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}jksh_publish_logs (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			job_id bigint(20) unsigned NOT NULL DEFAULT 0,
			content_id bigint(20) unsigned NOT NULL DEFAULT 0,
			variant_id bigint(20) unsigned NOT NULL DEFAULT 0,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			action varchar(64) NOT NULL,
			result varchar(32) NOT NULL,
			external_id varchar(191) NOT NULL DEFAULT '',
			external_url text NULL,
			message text NULL,
			context_json longtext NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY job_id (job_id),
			KEY content_id (content_id),
			KEY variant_id (variant_id),
			KEY created_at (created_at)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}jksh_analytics (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			variant_id bigint(20) unsigned NOT NULL DEFAULT 0,
			platform varchar(32) NOT NULL,
			metric_date date NOT NULL,
			metrics_json longtext NULL,
			fetched_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY variant_day (variant_id,metric_date),
			KEY platform (platform),
			KEY metric_date (metric_date)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}jksh_templates (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			name varchar(191) NOT NULL,
			content_type varchar(64) NOT NULL DEFAULT '',
			platform varchar(32) NOT NULL DEFAULT '',
			template_kind varchar(32) NOT NULL DEFAULT 'caption',
			body longtext NOT NULL,
			status varchar(32) NOT NULL DEFAULT 'active',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY platform (platform),
			KEY content_type (content_type)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}jksh_live_streams (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			uuid char(36) NOT NULL,
			title varchar(255) NOT NULL,
			description longtext NULL,
			source_type varchar(32) NOT NULL DEFAULT 'rtmp_input',
			source_json longtext NULL,
			destinations_json longtext NULL,
			metadata_json longtext NULL,
			status varchar(32) NOT NULL DEFAULT 'draft',
			scheduled_start_at datetime NULL,
			started_at datetime NULL,
			ended_at datetime NULL,
			worker_job_id varchar(191) NOT NULL DEFAULT '',
			last_error text NULL,
			author_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY uuid (uuid),
			KEY status (status),
			KEY scheduled_start_at (scheduled_start_at)
		) {$charset};";


		$sql[] = "CREATE TABLE {$p}jksh_campaigns (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			name varchar(191) NOT NULL,
			slug varchar(191) NOT NULL,
			utm_source varchar(100) NOT NULL DEFAULT '',
			utm_medium varchar(100) NOT NULL DEFAULT 'social',
			utm_campaign varchar(191) NOT NULL DEFAULT '',
			start_at datetime NULL,
			end_at datetime NULL,
			status varchar(32) NOT NULL DEFAULT 'active',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY status (status)
		) {$charset};";

		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}

		update_option( 'jksh_db_version', JKSH_DB_VERSION, false );
	}
}
