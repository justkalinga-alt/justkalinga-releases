<?php
namespace JKSH\Queue;

use JKSH\Repositories\JobRepository;
use JKSH\Repositories\LogRepository;
use JKSH\Repositories\VariantRepository;
use JKSH\Services\MetaPublisher;
use JKSH\Services\YouTubePublisher;
use JKSH\Services\ThreadsPublisher;
use JKSH\Services\Settings;

final class Dispatcher {
	public const ACTION = 'jksh_process_job';

	public function register(): void {
		add_action( self::ACTION, array( $this, 'process' ), 10, 1 );
		add_filter( 'cron_schedules', array( $this, 'cron_schedules' ) );
		add_action( 'jksh_queue_sweep', array( $this, 'sweep' ) );
		$this->ensure_sweep();
	}

	public function cron_schedules( array $schedules ): array {
		$schedules['jksh_five_minutes'] = array(
			'interval' => 300,
			'display'  => 'Every 5 minutes (JK Social Hub)',
		);
		return $schedules;
	}

	private function ensure_sweep(): void {
		if ( ! wp_next_scheduled( 'jksh_queue_sweep' ) ) {
			wp_schedule_event( time() + 300, 'jksh_five_minutes', 'jksh_queue_sweep' );
		}
	}

	public function schedule( int $job_id, int $timestamp ): void {
		$timestamp = max( time() + 10, $timestamp );
		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action( $timestamp, self::ACTION, array( $job_id ), 'jk-social-hub', true );
			return;
		}
		if ( ! wp_next_scheduled( self::ACTION, array( $job_id ) ) ) {
			wp_schedule_single_event( $timestamp, self::ACTION, array( $job_id ) );
		}
	}

	public function sweep(): void {
		global $wpdb;
		$table = $wpdb->prefix . 'jksh_jobs';
		$now   = current_time( 'mysql', true );
		$ids   = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE status IN ('queued','retrying') AND scheduled_at <= %s ORDER BY scheduled_at ASC LIMIT 20",
				$now
			)
		); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		foreach ( $ids as $id ) {
			$this->process( (int) $id );
		}
	}

	public function process( int $job_id ): void {
		$jobs      = new JobRepository();
		$variants  = new VariantRepository();
		$logs      = new LogRepository();
		$settings  = new Settings();
		$job       = $jobs->get( $job_id );

		if ( ! $job || in_array( (string) $job->status, array( 'published', 'dry_run_complete', 'cancelled', 'failed', 'blocked' ), true ) ) {
			return;
		}

		$variant = $variants->get( (int) $job->variant_id );
		if ( ! $variant ) {
			$this->fail_job( $jobs, $variants, $logs, $job, 'Variant not found for queued job.', array() );
			return;
		}

		$payload  = json_decode( (string) ( $job->payload_json ?? '{}' ), true );
		$payload  = is_array( $payload ) ? $payload : array();
		$mode    = $this->publish_mode( $payload );
		$is_poll = ( ! empty( $payload['meta_state'] ) && is_array( $payload['meta_state'] ) )
			|| ( ! empty( $payload['threads_state'] ) && is_array( $payload['threads_state'] ) );
		// Polls for Meta-side media processing are not new publish attempts. This keeps
		// max_attempts reserved for actual write failures and avoids premature failure.
		$attempts = $is_poll ? (int) $job->attempts : (int) $job->attempts + 1;

		$jobs->update(
			$job_id,
			array(
				'status'     => 'processing',
				'attempts'   => $attempts,
				'started_at' => current_time( 'mysql', true ),
			)
		);

		if ( 'dry_run' === $mode ) {
			$preflight = array();
			$platform = sanitize_key( (string) $job->platform );
			if ( in_array( $platform, array( 'facebook', 'instagram' ), true ) ) {
				$preflight = ( new MetaPublisher() )->preflight( $variant );
			} elseif ( 'youtube' === $platform ) {
				$preflight = ( new YouTubePublisher() )->preflight( $variant );
			} elseif ( 'threads' === $platform ) {
				$preflight = ( new ThreadsPublisher() )->preflight( $variant );
			} elseif ( 'pinterest' === $platform ) {
				if ( ! class_exists( '\\JKSH_Pinterest_Connector' ) ) {
					$preflight = array( 'ok' => false, 'message' => 'Pinterest connector is not loaded.' );
				} else {
					$pinterest_ready = \JKSH_Pinterest_Connector::instance()->readiness();
					$preflight = ! empty( $pinterest_ready['live_publish_possible'] )
						? array( 'ok' => true )
						: array( 'ok' => false, 'message' => (string) ( $pinterest_ready['message'] ?? $pinterest_ready['note'] ?? 'Pinterest live publishing is not ready.' ) );
				}
			}
			if ( $preflight && empty( $preflight['ok'] ) ) {
				$this->fail_job(
					$jobs,
					$variants,
					$logs,
					$job,
					'Dry Run preflight failed: ' . sanitize_textarea_field( (string) ( $preflight['message'] ?? 'Unknown publishing preflight error.' ) ),
					is_array( $preflight['details'] ?? null ) ? $preflight['details'] : array()
				);
				return;
			}
			$this->complete_dry_run( $jobs, $variants, $logs, $job, $payload, $preflight );
			return;
		}

		if ( 'live' !== $mode ) {
			$this->block_job( $jobs, $variants, $logs, $job, 'This job was not explicitly scheduled for live publishing.' );
			return;
		}

		if ( $settings->get( 'dry_run', 1 ) ) {
			$this->block_job( $jobs, $variants, $logs, $job, 'Dry Run is currently ON. The live job was blocked before any external API write.' );
			return;
		}
		$platform = sanitize_key( (string) $job->platform );
		if ( in_array( $platform, array( 'facebook', 'instagram' ), true ) ) {
			if ( ! $settings->get( 'meta_live_publish_enabled', 0 ) ) {
				$this->block_job( $jobs, $variants, $logs, $job, 'Meta live publishing master switch is OFF. No external platform was modified.' );
				return;
			}
			$result = ( new MetaPublisher() )->publish( $variant, $payload );
		} elseif ( 'youtube' === $platform ) {
			if ( ! $settings->get( 'youtube_live_publish_enabled', 0 ) ) {
				$this->block_job( $jobs, $variants, $logs, $job, 'YouTube live publishing master switch is OFF. No external platform was modified.' );
				return;
			}
			$result = ( new YouTubePublisher() )->publish( $variant, $payload );
		} elseif ( 'threads' === $platform ) {
			if ( ! $settings->get( 'threads_live_publish_enabled', 0 ) ) {
				$this->block_job( $jobs, $variants, $logs, $job, 'Threads live publishing master switch is OFF. No external platform was modified.' );
				return;
			}
			$result = ( new ThreadsPublisher() )->publish( $variant, $payload );
		} elseif ( 'pinterest' === $platform ) {
			if ( ! class_exists( '\\JKSH_Pinterest_Connector' ) ) {
				$this->block_job( $jobs, $variants, $logs, $job, 'Pinterest connector is not loaded. No external platform was modified.' );
				return;
			}
			$pinterest = \JKSH_Pinterest_Connector::instance();
			$pinterest_ready = $pinterest->readiness();
			if ( empty( $pinterest_ready['live_publish_possible'] ) ) {
				$this->block_job( $jobs, $variants, $logs, $job, (string) ( $pinterest_ready['message'] ?? $pinterest_ready['note'] ?? 'Pinterest live publishing is not ready.' ) );
				return;
			}
			// The Pinterest connector owns Pin media processing, API writes and receipts.
			$pinterest->process_job( $job_id );
			return;
		} else {
			$this->block_job( $jobs, $variants, $logs, $job, 'Live publishing for ' . $platform . ' is not enabled in this release.' );
			return;
		}

		if ( ! empty( $result['ok'] ) && ! empty( $result['pending'] ) ) {
			$delay = max( 10, (int) ( $result['delay'] ?? 20 ) );
			$next  = time() + $delay;
			$jobs->update(
				$job_id,
				array(
					'status'             => 'retrying',
					'payload_json'       => wp_json_encode( $result['payload'] ?? $payload ),
					'last_response_json' => wp_json_encode( $result['response'] ?? array() ),
					'last_error'         => '',
					'scheduled_at'       => gmdate( 'Y-m-d H:i:s', $next ),
				)
			);
			$variants->update_status( (int) $job->variant_id, 'processing' );
			$logs->add(
				array(
					'job_id'     => $job_id,
					'content_id' => (int) $job->content_id,
					'variant_id' => (int) $job->variant_id,
					'action'     => 'publish_pending',
					'result'     => 'info',
					'message'    => sanitize_textarea_field( (string) ( $result['message'] ?? 'Platform media is processing.' ) ),
					'context'    => array( 'platform' => (string) $job->platform, 'retry_in_seconds' => $delay ),
				)
			);
			$this->schedule( $job_id, $next );
			return;
		}

		if ( ! empty( $result['ok'] ) ) {
			$external_id  = sanitize_text_field( (string) ( $result['external_id'] ?? '' ) );
			$external_url = esc_url_raw( (string) ( $result['external_url'] ?? '' ) );
			$jobs->update(
				$job_id,
				array(
					'status'             => 'published',
					'payload_json'       => wp_json_encode( $result['payload'] ?? $payload ),
					'last_response_json' => wp_json_encode( $result['response'] ?? array() ),
					'last_error'         => '',
					'completed_at'       => current_time( 'mysql', true ),
				)
			);
			$variants->update_status(
				(int) $job->variant_id,
				'published',
				array(
					'external_id'  => $external_id,
					'external_url' => $external_url,
				)
			);
			$logs->add(
				array(
					'job_id'       => $job_id,
					'content_id'   => (int) $job->content_id,
					'variant_id'   => (int) $job->variant_id,
					'action'       => 'publish',
					'result'       => 'success',
					'external_id'  => $external_id,
					'external_url' => $external_url,
					'message'      => sanitize_textarea_field( (string) ( $result['message'] ?? 'Published successfully.' ) ),
					'context'      => array( 'platform' => (string) $job->platform ),
				)
			);
			if ( 'instagram' === sanitize_key( (string) $job->platform ) ) {
				$this->log_instagram_story_receipt( $logs, $job, $result );
			}
			return;
		}

		$retryable     = ! empty( $result['retryable'] );
		$max           = max( 1, (int) $job->max_attempts );
		$error_attempts = $attempts + ( $is_poll ? 1 : 0 );
		if ( $is_poll ) {
			$jobs->update( $job_id, array( 'attempts' => $error_attempts ) );
		}
		if ( $retryable && $error_attempts < $max ) {
			$delay = min( 900, 60 * ( 2 ** max( 0, $error_attempts - 1 ) ) );
			$next  = time() + $delay;
			$jobs->update(
				$job_id,
				array(
					'status'             => 'retrying',
					'last_error'         => sanitize_textarea_field( (string) ( $result['message'] ?? 'Temporary publishing error.' ) ),
					'last_response_json' => wp_json_encode( $result['response'] ?? array() ),
					'scheduled_at'       => gmdate( 'Y-m-d H:i:s', $next ),
				)
			);
			$variants->update_status( (int) $job->variant_id, 'retrying' );
			$logs->add(
				array(
					'job_id'     => $job_id,
					'content_id' => (int) $job->content_id,
					'variant_id' => (int) $job->variant_id,
					'action'     => 'publish_retry',
					'result'     => 'info',
					'message'    => sanitize_textarea_field( (string) ( $result['message'] ?? 'Temporary publishing error.' ) ),
					'context'    => array( 'platform' => (string) $job->platform, 'retry_in_seconds' => $delay, 'attempt' => $error_attempts ),
				)
			);
			$this->schedule( $job_id, $next );
			return;
		}

		$this->fail_job( $jobs, $variants, $logs, $job, sanitize_textarea_field( (string) ( $result['message'] ?? 'Platform publishing failed.' ) ), $result['response'] ?? array() );
	}

	private function log_instagram_story_receipt( LogRepository $logs, object $job, array $result ): void {
		$response = is_array( $result['response'] ?? null ) ? $result['response'] : array();
		$story = is_array( $response['story'] ?? null ) ? $response['story'] : array();
		if ( ! $story ) {
			return;
		}
		$ok = ! empty( $story['ok'] );
		$story_id = sanitize_text_field( (string) ( $story['id'] ?? '' ) );
		$logs->add(
			array(
				'job_id' => (int) $job->id,
				'content_id' => (int) $job->content_id,
				'variant_id' => (int) $job->variant_id,
				'action' => 'story_publish',
				'result' => $ok ? 'success' : 'failed',
				'external_id' => $story_id,
				'message' => sanitize_textarea_field( (string) ( $story['message'] ?? ( $ok ? 'Instagram Story published.' : 'Instagram Story was not published.' ) ) ),
				'context' => array(
					'platform' => 'instagram',
					'source_type' => sanitize_key( (string) ( $story['source_type'] ?? '' ) ),
					'companion' => isset( $response['feed'] ),
				),
			)
		);
	}

	private function publish_mode( array $payload ): string {
		$mode = sanitize_key( (string) ( $payload['publish_mode'] ?? '' ) );
		if ( in_array( $mode, array( 'dry_run', 'live', 'blocked' ), true ) ) {
			return $mode;
		}
		if ( ! empty( $payload['dry_run'] ) ) {
			return 'dry_run';
		}
		return 'dry_run';
	}

	private function complete_dry_run( JobRepository $jobs, VariantRepository $variants, LogRepository $logs, object $job, array $payload, array $preflight = array() ): void {
		$response = array(
			'mode'      => 'dry_run',
			'platform'  => (string) $job->platform,
			'job_type'  => (string) $job->job_type,
			'validated' => true,
			'preflight' => $preflight,
			'timestamp' => current_time( 'mysql', true ),
		);
		$jobs->update(
			(int) $job->id,
			array(
				'status'             => 'dry_run_complete',
				'payload_json'       => wp_json_encode( $payload ),
				'last_response_json' => wp_json_encode( $response ),
				'completed_at'       => current_time( 'mysql', true ),
			)
		);
		$variants->update_status( (int) $job->variant_id, 'dry_run_complete' );
		$logs->add(
			array(
				'job_id'     => (int) $job->id,
				'content_id' => (int) $job->content_id,
				'variant_id' => (int) $job->variant_id,
				'action'     => 'dry_run_publish',
				'result'     => 'success',
				'message'    => 'Dry Run completed. No external platform was modified.',
				'context'    => $response,
			)
		);
	}

	private function block_job( JobRepository $jobs, VariantRepository $variants, LogRepository $logs, object $job, string $message ): void {
		$jobs->update(
			(int) $job->id,
			array(
				'status'       => 'blocked',
				'last_error'   => sanitize_textarea_field( $message ),
				'completed_at' => current_time( 'mysql', true ),
			)
		);
		$variants->update_status( (int) $job->variant_id, 'blocked' );
		$logs->add(
			array(
				'job_id'     => (int) $job->id,
				'content_id' => (int) $job->content_id,
				'variant_id' => (int) $job->variant_id,
				'action'     => 'publish_blocked',
				'result'     => 'failed',
				'message'    => sanitize_textarea_field( $message ),
			)
		);
	}

	private function fail_job( JobRepository $jobs, VariantRepository $variants, LogRepository $logs, object $job, string $message, array $response ): void {
		$jobs->update(
			(int) $job->id,
			array(
				'status'             => 'failed',
				'last_error'         => sanitize_textarea_field( $message ),
				'last_response_json' => wp_json_encode( $response ),
				'completed_at'       => current_time( 'mysql', true ),
			)
		);
		$variants->update_status( (int) $job->variant_id, 'failed' );
		$logs->add(
			array(
				'job_id'     => (int) $job->id,
				'content_id' => (int) $job->content_id,
				'variant_id' => (int) $job->variant_id,
				'action'     => 'publish',
				'result'     => 'failed',
				'message'    => sanitize_textarea_field( $message ),
				'context'    => array( 'platform' => (string) $job->platform ),
			)
		);
	}
}
