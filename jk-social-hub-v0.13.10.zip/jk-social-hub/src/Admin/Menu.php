<?php
namespace JKSH\Admin;

final class Menu {
	public function register(): void {
		add_action( 'admin_menu', array( $this, 'menus' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
	}

	public function menus(): void {
		$pages = new Pages();
		add_menu_page( 'JK Social Hub', 'JK Social Hub', 'jksh_view', 'jksh-dashboard', array( $pages, 'dashboard' ), 'dashicons-share', 3 );
		add_submenu_page( 'jksh-dashboard', 'Dashboard', 'Dashboard', 'jksh_view', 'jksh-dashboard', array( $pages, 'dashboard' ) );
		add_submenu_page( 'jksh-dashboard', 'Composer', 'Composer', 'jksh_create', 'jksh-composer', array( $pages, 'composer' ) );
		add_submenu_page( 'jksh-social-upload', 'Content Library', 'Content Library', 'jksh_view', 'jksh-content', array( $pages, 'content_library' ) );
		add_submenu_page( 'jksh-dashboard', 'Platform Variants', 'Platform Variants', 'jksh_view', 'jksh-variants', array( $pages, 'variants' ) );
		add_submenu_page( 'jksh-dashboard', 'Calendar', 'Calendar', 'jksh_view', 'jksh-calendar', array( $pages, 'calendar' ) );
		add_submenu_page( 'jksh-dashboard', 'Queue', 'Queue', 'jksh_view', 'jksh-queue', array( $pages, 'queue' ) );
		add_submenu_page( 'jksh-dashboard', 'Templates', 'Templates', 'jksh_edit', 'jksh-templates', array( $pages, 'templates' ) );
		add_submenu_page( 'jksh-dashboard', 'Accounts', 'Accounts', 'jksh_manage_accounts', 'jksh-accounts', array( $pages, 'accounts' ) );
		add_submenu_page( 'jksh-dashboard', 'Analytics', 'Analytics', 'jksh_view_analytics', 'jksh-analytics', array( $pages, 'analytics' ) );
		add_submenu_page( 'jksh-dashboard', 'Logs', 'Logs', 'jksh_view', 'jksh-logs', array( $pages, 'logs' ) );
		add_submenu_page( 'jksh-dashboard', 'Settings', 'Settings', 'jksh_manage_settings', 'jksh-settings', array( $pages, 'settings' ) );
	}

	public function assets( string $hook ): void {
		if ( false === strpos( $hook, 'jksh-' ) && 'toplevel_page_jksh-dashboard' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'jksh-admin', JKSH_URL . 'assets/admin.css', array(), JKSH_VERSION );
		wp_enqueue_script( 'jksh-admin', JKSH_URL . 'assets/admin.js', array(), JKSH_VERSION, true );
		wp_localize_script(
			'jksh-admin',
			'JKSHAdmin',
			array(
				'restUrl' => esc_url_raw( rest_url( 'jksh/v1/' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
			)
		);
	}
}
