<?php
namespace JKSH\Admin;

use JKSH\Repositories\ContentRepository;
use JKSH\Repositories\JobRepository;
use JKSH\Repositories\LogRepository;
use JKSH\Repositories\VariantRepository;
use JKSH\Services\YouTubeCommunityHandoff;

final class CommunityActions {
	public function register(): void {
		add_action( 'admin_post_jksh_community_mark_published', array( $this, 'mark_published' ) );
		add_action( 'admin_post_jksh_community_mark_failed', array( $this, 'mark_failed' ) );
		add_action( 'admin_post_jksh_community_prefill', array( $this, 'prefill' ) );
	}


	public function prefill(): void {
		$this->guard();
		$job_id = absint( $_POST['job_id'] ?? 0 );
		check_admin_referer( 'jksh_community_prefill_' . $job_id );
		$result = ( new YouTubeCommunityHandoff() )->prefill( $job_id );
		if ( is_wp_error( $result ) ) {
			$this->redirect( 'error', $result->get_error_message() );
		}
		if ( empty( $result['ok'] ) ) {
			$data = is_array( $result['data'] ?? null ) ? $result['data'] : array();
			$error = sanitize_textarea_field( (string) ( $data['error'] ?? $result['message'] ?? 'YouTube Community browser prefill failed.' ) );
			if ( 'browser_helper_unavailable' === sanitize_key( $error ) ) {
				$error = 'Windows Community browser helper is not installed or not ready. Update the JK Windows Worker and install playwright-core first.';
			} elseif ( 'youtube_login_required' === sanitize_key( $error ) ) {
				$error = 'The dedicated JK browser opened, but YouTube login is required. Sign in once, then click Prefill again.';
			}
			$this->redirect( 'error', $error );
		}
		$data = is_array( $result['data'] ?? null ) ? $result['data'] : array();
		$message = sanitize_key( (string) ( $data['message'] ?? '' ) );
		if ( 'youtube_login_required' === $message ) {
			$this->redirect( 'error', 'The dedicated JK browser opened. Sign in to YouTube once, then click Prefill again.' );
		}
		$this->redirect( 'success', 'YouTube Community composer opened on the Windows helper with caption and original images prefilled. Review it and click Post or Schedule in YouTube.' );
	}

	public function mark_published(): void {
		$this->guard();
		$job_id = absint( $_POST['job_id'] ?? 0 );
		check_admin_referer( 'jksh_community_mark_' . $job_id );
		$external_url = esc_url_raw( trim( (string) wp_unslash( $_POST['external_url'] ?? '' ) ) );
		if ( ! $this->is_youtube_post_url( $external_url ) ) {
			$this->redirect( 'error', 'Paste the actual public YouTube Community post URL before marking it published.' );
		}
		$job = $this->community_job( $job_id );
		if ( ! $job ) {
			$this->redirect( 'error', 'Community handoff job was not found.' );
		}
		if ( 'published_manual' === (string) $job->status ) {
			$this->redirect( 'success', 'This Community handoff was already marked published.' );
		}
		$now = current_time( 'mysql', true );
		$response = array(
			'publish_mode' => 'manual_handoff',
			'manual_required' => true,
			'external_url' => $external_url,
			'actor_user_id' => get_current_user_id(),
			'completed_at_utc' => $now,
		);
		( new JobRepository() )->update(
			$job_id,
			array(
				'status' => 'published_manual',
				'last_error' => '',
				'last_response_json' => wp_json_encode( $response ),
				'completed_at' => $now,
			)
		);
		( new VariantRepository() )->update_status(
			(int) $job->variant_id,
			'published_manual',
			array( 'external_url' => $external_url )
		);
		( new ContentRepository() )->update_status( (int) $job->content_id, 'published_manual' );
		( new LogRepository() )->add(
			array(
				'job_id' => $job_id,
				'content_id' => (int) $job->content_id,
				'variant_id' => (int) $job->variant_id,
				'action' => 'community_mark_published',
				'result' => 'success',
				'external_url' => $external_url,
				'message' => 'YouTube Community handoff marked as manually published.',
				'context' => array( 'publish_mode' => 'manual_handoff' ),
			)
		);
		$this->redirect( 'success', 'YouTube Community handoff marked published with its public receipt URL.' );
	}

	public function mark_failed(): void {
		$this->guard();
		$job_id = absint( $_POST['job_id'] ?? 0 );
		check_admin_referer( 'jksh_community_mark_' . $job_id );
		$reason = sanitize_textarea_field( (string) wp_unslash( $_POST['reason'] ?? '' ) );
		if ( '' === $reason ) {
			$this->redirect( 'error', 'Add a short failure reason before marking the handoff failed.' );
		}
		$job = $this->community_job( $job_id );
		if ( ! $job ) {
			$this->redirect( 'error', 'Community handoff job was not found.' );
		}
		$now = current_time( 'mysql', true );
		( new JobRepository() )->update(
			$job_id,
			array(
				'status' => 'failed_manual',
				'last_error' => $reason,
				'last_response_json' => wp_json_encode( array( 'publish_mode' => 'manual_handoff', 'manual_required' => true, 'actor_user_id' => get_current_user_id() ) ),
				'completed_at' => $now,
			)
		);
		( new VariantRepository() )->update_status( (int) $job->variant_id, 'failed_manual' );
		( new ContentRepository() )->update_status( (int) $job->content_id, 'failed_manual' );
		( new LogRepository() )->add(
			array(
				'job_id' => $job_id,
				'content_id' => (int) $job->content_id,
				'variant_id' => (int) $job->variant_id,
				'action' => 'community_mark_failed',
				'result' => 'failed',
				'message' => $reason,
				'context' => array( 'publish_mode' => 'manual_handoff' ),
			)
		);
		$this->redirect( 'success', 'YouTube Community handoff marked failed. It was not recorded as API-published.' );
	}

	private function guard(): void {
		if ( ! current_user_can( 'jksh_publish' ) ) {
			wp_die( esc_html__( 'You do not have permission to update Community handoff receipts.', 'jk-social-hub' ) );
		}
	}

	private function community_job( int $job_id ): ?object {
		$job = ( new JobRepository() )->get( $job_id );
		if ( ! $job || 'youtube' !== sanitize_key( (string) $job->platform ) || 'community_handoff' !== sanitize_key( (string) $job->job_type ) ) {
			return null;
		}
		return $job;
	}

	private function is_youtube_post_url( string $url ): bool {
		if ( '' === $url || ! wp_http_validate_url( $url ) ) {
			return false;
		}
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		return in_array( $host, array( 'youtube.com', 'www.youtube.com', 'm.youtube.com' ), true ) && str_starts_with( $path, '/post/' );
	}

	private function redirect( string $type, string $message ): never {
		$url = add_query_arg(
			array(
				'page' => 'jksh-queue',
				'jksh_notice' => sanitize_key( $type ),
				'jksh_msg' => rawurlencode( $message ),
			),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $url );
		exit;
	}
}
