<?php
namespace JKSH\Admin;

use JKSH\Services\YouTubeConnector;

final class YouTubeActions {
	public function register(): void {
		add_action( 'admin_post_jksh_save_youtube_config', array( $this, 'save_config' ) );
		add_action( 'admin_post_jksh_youtube_oauth_callback', array( $this, 'callback' ) );
		add_action( 'admin_post_jksh_youtube_test_account', array( $this, 'test_account' ) );
		add_action( 'admin_post_jksh_youtube_disconnect_account', array( $this, 'disconnect_account' ) );
	}

	public function save_config(): void {
		$this->guard( 'jksh_youtube_config' );
		try {
			( new YouTubeConnector() )->save_config(
				sanitize_text_field( wp_unslash( $_POST['client_id'] ?? '' ) ),
				(string) wp_unslash( $_POST['client_secret'] ?? '' )
			);
			$this->redirect( 'success', 'YouTube OAuth settings saved securely.' );
		} catch ( \Throwable $e ) {
			$this->redirect( 'error', $e->getMessage() );
		}
	}

	public function callback(): void {
		if ( ! current_user_can( 'jksh_manage_accounts' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage social accounts.', 'jk-social-hub' ) );
		}
		if ( ! empty( $_GET['error'] ) ) {
			$message = sanitize_text_field( wp_unslash( $_GET['error_description'] ?? $_GET['error'] ) );
			$this->redirect( 'error', 'YouTube authorization was not completed: ' . $message );
		}
		$code  = sanitize_text_field( wp_unslash( $_GET['code'] ?? '' ) );
		$state = sanitize_text_field( wp_unslash( $_GET['state'] ?? '' ) );
		if ( '' === $code || '' === $state ) {
			$this->redirect( 'error', 'YouTube callback was missing required authorization data.' );
		}
		$result = ( new YouTubeConnector() )->handle_callback( $code, $state );
		$this->redirect( $result['ok'] ? 'success' : 'error', $result['message'] );
	}

	public function test_account(): void {
		$this->guard( 'jksh_youtube_test_account' );
		$result = ( new YouTubeConnector() )->test_account( absint( $_POST['account_id'] ?? 0 ) );
		$this->redirect( $result['ok'] ? 'success' : 'error', $result['message'] );
	}

	public function disconnect_account(): void {
		$this->guard( 'jksh_youtube_disconnect_account' );
		$result = ( new YouTubeConnector() )->disconnect_account( absint( $_POST['account_id'] ?? 0 ) );
		$this->redirect( $result['ok'] ? 'success' : 'error', $result['message'] );
	}

	private function guard( string $action ): void {
		if ( ! current_user_can( 'jksh_manage_accounts' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage social accounts.', 'jk-social-hub' ) );
		}
		check_admin_referer( $action );
	}

	private function redirect( string $type, string $message ): void {
		$url = add_query_arg(
			array( 'page' => 'jksh-accounts', 'jksh_notice' => sanitize_key( $type ), 'jksh_msg' => $message ),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $url );
		exit;
	}
}
