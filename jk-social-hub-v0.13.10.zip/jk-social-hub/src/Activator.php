<?php
namespace JKSH;

use JKSH\DB\Migrator;
use JKSH\Services\Settings;

final class Activator {
	public static function activate(): void {
		( new Migrator() )->migrate();
		( new Settings() )->ensure_defaults();
		self::grant_capabilities();
		flush_rewrite_rules( false );
	}

	private static function grant_capabilities(): void {
		$caps = self::capabilities();
		$role = get_role( 'administrator' );
		if ( $role ) {
			foreach ( $caps as $cap ) {
				$role->add_cap( $cap );
			}
		}
	}

	public static function capabilities(): array {
		return array(
			'jksh_view',
			'jksh_create',
			'jksh_edit',
			'jksh_approve',
			'jksh_publish',
			'jksh_manage_accounts',
			'jksh_view_analytics',
			'jksh_manage_settings',
		);
	}
}
