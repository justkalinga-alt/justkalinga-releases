(() => {
  'use strict';
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.jksh-card').forEach((card) => {
      card.dataset.ready = '1';
    });

    document.querySelectorAll('[data-jksh-copy-target]').forEach((button) => {
      button.addEventListener('click', async () => {
        const id = button.getAttribute('data-jksh-copy-target');
        const source = id ? document.getElementById(id) : null;
        if (!source) return;
        const text = source.value || source.textContent || '';
        try {
          await navigator.clipboard.writeText(text);
        } catch (error) {
          source.focus();
          source.select();
          document.execCommand('copy');
        }
        const original = button.textContent;
        button.textContent = 'Copied';
        window.setTimeout(() => { button.textContent = original; }, 1400);
      });
    });
  });
})();
