<?php
/**
 * Plugin Name: JKSH YouTube Source Inspector
 * Description: Temporary read-only source inspector for YouTubeActions method code.
 * Version: 1.0.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action( 'rest_api_init', function () {
    register_rest_route( 'jksh-youtube-source/v1', '/inspect', array(
        'methods' => 'GET',
        'permission_callback' => function () { return current_user_can( 'manage_options' ); },
        'callback' => function () {
            if ( ! class_exists( '\JKSH\Admin\YouTubeActions' ) ) {
                return new WP_Error( 'missing', 'YouTubeActions class not loaded.', array( 'status' => 404 ) );
            }
            $r = new ReflectionClass( '\JKSH\Admin\YouTubeActions' );
            $file = $r->getFileName();
            $lines = ( $file && is_readable( $file ) ) ? file( $file, FILE_IGNORE_NEW_LINES ) : array();
            $out = array( 'file' => $file ? basename( $file ) : '', 'methods' => array() );
            foreach ( array( 'register', 'save_config', 'callback', 'test_account', 'disconnect_account', 'guard', 'redirect' ) as $name ) {
                if ( ! $r->hasMethod( $name ) ) continue;
                $m = $r->getMethod( $name );
                $start = max( 1, $m->getStartLine() );
                $end = max( $start, $m->getEndLine() );
                $src = array();
                if ( $lines ) {
                    for ( $i = $start; $i <= $end; $i++ ) {
                        $src[] = array( 'line' => $i, 'text' => $lines[ $i - 1 ] ?? '' );
                    }
                }
                $out['methods'][ $name ] = $src;
            }
            return rest_ensure_response( $out );
        },
    ) );
} );
