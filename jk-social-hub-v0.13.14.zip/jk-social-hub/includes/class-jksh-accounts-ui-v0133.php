<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Accounts_UI_V0133 {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) { self::$instance = new self(); }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_footer', [ $this, 'admin_footer' ], 1300 );
    }

    private function on_accounts_page() {
        return is_admin() && 'jksh-accounts' === sanitize_key( (string) ( $_GET['page'] ?? '' ) );
    }

    private function count_connected( $repo, $platform ) {
        return count( $repo->connected( $platform ) );
    }

    public function admin_footer() {
        if ( ! $this->on_accounts_page() ) { return; }

        $repo = new \JKSH\Repositories\AccountRepository();
        $settings = new \JKSH\Services\Settings();

        // Render Pinterest Sandbox from the Accounts renderer itself so the
        // card is guaranteed to exist before the tab shell adopts cards.
        if ( class_exists( 'JKSH_Pinterest_Sandbox_V0138' ) ) {
            JKSH_Pinterest_Sandbox_V0138::instance()->render_card();
        }
        $meta_count = $this->count_connected( $repo, 'facebook' ) + $this->count_connected( $repo, 'instagram' );
        $youtube_count = $this->count_connected( $repo, 'youtube' );
        $threads = class_exists( 'JKSH_Threads_Foundation_V0131' ) ? JKSH_Threads_Foundation_V0131::instance()->readiness() : [];
        $gbp = class_exists( 'JKSH_GBP_Foundation_V0130' ) ? JKSH_GBP_Foundation_V0130::instance()->readiness() : [];
        $threads_verified = (int) ( $threads['verified_accounts'] ?? 0 );
        $gbp_locations = (int) ( $gbp['connected_locations'] ?? 0 );
        $gbp_approved = ! empty( $gbp['api_access_confirmed'] );
        $dry_run = (bool) $settings->get( 'dry_run', 1 );
        $threads_switch = (bool) $settings->get( 'threads_live_publish_enabled', 0 );
        ?>
        <template id="jksh-accounts-overview-v0133">
            <div class="jksh-account-hero">
                <div>
                    <span class="jksh-account-eyebrow">Network control center</span>
                    <h2>Connected publishing infrastructure</h2>
                    <p>Manage credentials, OAuth connections, health checks and platform-specific publishing gates from one clean workspace.</p>
                </div>
                <div class="jksh-account-mode <?php echo $dry_run ? 'is-safe' : 'is-live'; ?>">
                    <span><?php echo $dry_run ? 'Dry Run' : 'Live mode'; ?></span>
                    <strong><?php echo $dry_run ? 'Protected' : 'External writes permitted by platform switches'; ?></strong>
                </div>
            </div>
            <div class="jksh-account-health-grid">
                <button type="button" class="jksh-health-card" data-open-account-tab="meta">
                    <span class="jksh-health-icon">M</span><span><small>Meta</small><strong><?php echo esc_html( (string) $meta_count ); ?> connected</strong><em><?php echo $meta_count >= 2 ? 'Facebook + Instagram ready' : 'Review connection'; ?></em></span>
                </button>
                <button type="button" class="jksh-health-card" data-open-account-tab="youtube">
                    <span class="jksh-health-icon">▶</span><span><small>YouTube</small><strong><?php echo esc_html( (string) $youtube_count ); ?> connected</strong><em>Video and Short publishing</em></span>
                </button>
                <button type="button" class="jksh-health-card" data-open-account-tab="threads">
                    <span class="jksh-health-icon">@</span><span><small>Threads</small><strong><?php echo esc_html( (string) $threads_verified ); ?> verified</strong><em><?php echo $threads_verified ? ( $threads_switch ? 'Native publisher armed' : 'Publisher ready · switch off' ) : 'Connection required'; ?></em></span>
                </button>
                <button type="button" class="jksh-health-card" data-open-account-tab="gbp">
                    <span class="jksh-health-icon">G</span><span><small>Google Business</small><strong><?php echo esc_html( (string) $gbp_locations ); ?> locations</strong><em><?php echo $gbp_approved ? 'API access confirmed' : 'Approval pending'; ?></em></span>
                </button>
            </div>
            <section class="jksh-card jksh-overview-note">
                <div><span class="dashicons dashicons-shield-alt"></span></div>
                <div><h3>Independent publishing safety</h3><p>Each live connector requires Dry Run OFF plus its own master switch. Threads v0.13.3 uses the same durable queue, stateful processing and external verification model as the existing publishers.</p></div>
            </section>
        </template>
        <script>
        (() => {
            const wrap = document.querySelector('.jksh-wrap');
            const template = document.getElementById('jksh-accounts-overview-v0133');
            if (!wrap || !template || document.getElementById('jksh-accounts-shell-v0133')) return;

            const tabs = [
                ['overview', 'Overview', 'dashicons-dashboard'],
                ['meta', 'Meta', 'dashicons-facebook-alt'],
                ['youtube', 'YouTube', 'dashicons-video-alt3'],
                ['threads', 'Threads', 'dashicons-share'],
                ['gbp', 'Google Business', 'dashicons-location-alt'],
                ['pinterest', 'Pinterest', 'dashicons-admin-site-alt3']
            ];

            const shell = document.createElement('div');
            shell.id = 'jksh-accounts-shell-v0133';
            shell.className = 'jksh-accounts-shell';
            shell.innerHTML = `
                <nav class="jksh-account-tabs" role="tablist" aria-label="Social account networks">
                    ${tabs.map(([key,label,icon]) => `<button type="button" class="jksh-account-tab" role="tab" data-account-tab="${key}" aria-selected="false"><span class="dashicons ${icon}"></span><span>${label}</span></button>`).join('')}
                </nav>
                <div class="jksh-account-stage">
                    ${tabs.map(([key,label]) => `<section class="jksh-account-panel" data-account-panel="${key}" role="tabpanel" aria-label="${label}" hidden><div class="jksh-account-panel-grid"></div></section>`).join('')}
                </div>`;

            wrap.appendChild(shell);
            const overviewGrid = shell.querySelector('[data-account-panel="overview"] .jksh-account-panel-grid');
            overviewGrid.appendChild(template.content.cloneNode(true));

            const panelGrid = key => shell.querySelector(`[data-account-panel="${key}"] .jksh-account-panel-grid`);
            const cards = Array.from(wrap.querySelectorAll('.jksh-card')).filter(card => !shell.contains(card));

            const bucketFor = card => {
                const id = card.id || '';
                const heading = (card.querySelector('h2')?.textContent || '').replace(/\s+/g,' ').trim();
                if (id === 'jksh-threads-foundation-v0131' || id === 'jksh-threads-callbacks-v0132' || /^Threads\b/i.test(heading)) return 'threads';
                if (id === 'jksh-gbp-foundation-v0130' || /^Google Business Profile\b/i.test(heading)) return 'gbp';
                if (/^Pinterest\b/i.test(heading)) return 'pinterest';
                if (/^Meta App configuration$/i.test(heading) || /^Meta connection$/i.test(heading) || /^Connected accounts$/i.test(heading)) return 'meta';
                if (/^YouTube OAuth configuration$/i.test(heading) || /^YouTube connection$/i.test(heading) || /^Connected YouTube channel$/i.test(heading)) return 'youtube';
                if (/^Publishing readiness$/i.test(heading)) return 'overview';
                return '';
            };

            cards.forEach(card => {
                const heading = (card.querySelector('h2')?.textContent || '').replace(/\s+/g,' ').trim();
                if (/^Pinterest\s*\/\s*Threads$/i.test(heading)) { card.remove(); return; }
                const bucket = bucketFor(card);
                if (!bucket) return;
                card.classList.add('jksh-account-card');
                if (/^Connected accounts$|^Connected YouTube channel$|^Publishing readiness$/i.test(heading)) card.classList.add('jksh-account-card-wide');
                card.style.display = '';
                panelGrid(bucket).appendChild(card);
            });

            // Pinterest Sandbox is intentionally emitted from admin_footer outside .wrap.
            // Adopt it explicitly into the Pinterest tab so its placement does not depend
            // on footer timing or DOM ancestry.
            const sandboxCard = document.getElementById('jksh-pinterest-sandbox-v0138');
            if (sandboxCard) {
                sandboxCard.classList.add('jksh-account-card','jksh-account-card-wide');
                sandboxCard.style.setProperty('display','block','important');
                sandboxCard.style.setProperty('visibility','visible','important');
                sandboxCard.style.setProperty('opacity','1','important');
                sandboxCard.style.setProperty('width','100%','important');
                sandboxCard.style.setProperty('max-width','100%','important');
                sandboxCard.style.setProperty('min-width','0','important');

                const pinterestGrid = panelGrid('pinterest');
                const pinterestPanel = shell.querySelector('[data-account-panel="pinterest"]');
                const target = pinterestGrid || pinterestPanel || wrap;
                target.appendChild(sandboxCard);
            }

            // Clean legacy grid wrappers left empty after cards are moved into their tabs.
            Array.from(wrap.children).forEach(node => {
                if (node === shell || !node.classList?.contains('jksh-grid')) return;
                if (!node.querySelector('.jksh-card')) node.remove();
            });

            const activate = key => {
                if (!tabs.some(t => t[0] === key)) key = 'overview';
                shell.querySelectorAll('.jksh-account-tab').forEach(btn => {
                    const active = btn.dataset.accountTab === key;
                    btn.classList.toggle('is-active', active);
                    btn.setAttribute('aria-selected', active ? 'true' : 'false');
                    btn.tabIndex = active ? 0 : -1;
                });
                shell.querySelectorAll('.jksh-account-panel').forEach(panel => {
                    const active = panel.dataset.accountPanel === key;
                    panel.hidden = !active;
                    panel.classList.toggle('is-active', active);
                });
                try { localStorage.setItem('jkshAccountsTab', key); } catch(e) {}
                if (history.replaceState) history.replaceState(null, '', `${location.pathname}${location.search}#account-${key}`);
            };

            shell.querySelectorAll('.jksh-account-tab').forEach((btn, index, all) => {
                btn.addEventListener('click', () => activate(btn.dataset.accountTab));
                btn.addEventListener('keydown', event => {
                    if (!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
                    event.preventDefault();
                    let next = index;
                    if (event.key === 'ArrowRight') next = (index + 1) % all.length;
                    if (event.key === 'ArrowLeft') next = (index - 1 + all.length) % all.length;
                    if (event.key === 'Home') next = 0;
                    if (event.key === 'End') next = all.length - 1;
                    all[next].focus();
                    activate(all[next].dataset.accountTab);
                });
            });
            shell.querySelectorAll('[data-open-account-tab]').forEach(btn => btn.addEventListener('click', () => activate(btn.dataset.openAccountTab)));

            let initial = (location.hash.match(/^#account-(overview|meta|youtube|threads|gbp|pinterest)$/) || [])[1];
            if (!initial) { try { initial = localStorage.getItem('jkshAccountsTab'); } catch(e) {} }
            const msg = new URLSearchParams(location.search).get('jksh_msg') || '';
            if (/Threads/i.test(msg)) initial = 'threads';
            activate(initial || 'overview');
        })();
        </script>
        <?php
    }
}

JKSH_Accounts_UI_V0133::instance();
