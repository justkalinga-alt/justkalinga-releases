<?php
/** Plugin Name: JKSH Upload Render Probe
 * Version: 1.0.0
 * Author: JustKalinga
 */
if(!defined('ABSPATH')) exit;
add_action('rest_api_init', function(){
  register_rest_route('jksh-upload-probe/v1','/render',[
    'methods'=>'GET',
    'permission_callback'=>fn()=>current_user_can('manage_options'),
    'callback'=>function(){
      if(!class_exists('JKSSB_Bridge')) return new WP_Error('bridge_missing','JKSSB_Bridge not loaded',['status'=>409]);
      $old=$_GET['view']??null; $_GET['view']='upload';
      ob_start();
      JKSSB_Bridge::instance()->render_upload_page();
      $html=ob_get_clean();
      if(null===$old) unset($_GET['view']); else $_GET['view']=$old;
      return rest_ensure_response([
        'ok'=>true,
        'bytes'=>strlen($html),
        'has_upload_studio'=>false!==strpos($html,'Social Upload Studio'),
        'has_pinterest'=>false!==strpos($html,'value="pinterest"'),
        'pinterest_disabled'=>false!==strpos($html,'value="pinterest" disabled'),
        'sandbox_marker'=>false!==strpos($html,'data-sandbox="1"')
      ]);
    }
  ]);
});
