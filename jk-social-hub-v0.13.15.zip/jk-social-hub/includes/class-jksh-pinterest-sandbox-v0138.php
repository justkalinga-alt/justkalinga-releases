<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Pinterest_Sandbox_V0138 {
    private const PLATFORM = 'pinterest_sandbox';
    private const API_HOST = 'https://api-sandbox.pinterest.com/v5';
    private const BOARD_NAME = 'JustKalinga Sandbox Proof';
    private static $instance = null;
    private $request_active = false;

    public static function instance() {
        if ( ! self::$instance ) { self::$instance = new self(); }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_post_jksh_pinterest_sandbox_save', [ $this, 'save_token' ] );
        add_action( 'admin_post_jksh_pinterest_sandbox_disconnect', [ $this, 'disconnect' ] );
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
        add_filter( 'pre_http_request', [ $this, 'route_request' ], 4, 3 );
        add_action( 'shutdown', [ $this, 'reconcile_recent_published' ], 90 );
    }

    private function repo() {
        return new \JKSH\Repositories\AccountRepository();
    }

    public function can_manage() {
        return current_user_can( 'jksh_manage_accounts' ) || current_user_can( 'manage_options' );
    }

    private function account() {
        $rows = $this->repo()->connected( self::PLATFORM );
        return $rows ? $rows[0] : null;
    }

    private function account_data() {
        $account = $this->account();
        if ( ! $account ) { return [ null, [], [] ]; }
        return [ $account, $this->repo()->settings( $account ), $this->repo()->credentials( $account ) ];
    }

    public function readiness() {
        [ $account, $settings, $credentials ] = $this->account_data();
        $connected = $account && ! empty( $credentials['access_token'] ) && ! empty( $settings['board_id'] );
        return [
            'ok' => true,
            'environment' => 'sandbox',
            'connected' => (bool) $connected,
            'profile' => $account ? (string) $account->account_name : '',
            'external_account_id' => $account ? (string) $account->external_account_id : '',
            'board_id' => (string) ( $settings['board_id'] ?? '' ),
            'board_name' => (string) ( $settings['board_name'] ?? '' ),
            'token_expires_at_utc' => $account ? (string) ( $account->token_expires_at ?? '' ) : '',
            'image_pins_supported' => true,
            'video_pins_supported' => false,
            'publisher_label' => $connected ? 'Sandbox Published' : 'Sandbox not connected',
            'token_present' => ! empty( $credentials['access_token'] ),
        ];
    }

    public function register_routes() {
        register_rest_route( 'jksh/v1', '/pinterest/sandbox/readiness', [
            'methods' => 'GET',
            'callback' => function () { return rest_ensure_response( $this->readiness() ); },
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( 'jksh/v1', '/pinterest/sandbox/boards', [
            'methods' => 'GET',
            'callback' => [ $this, 'rest_boards' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
    }

    public function rest_boards() {
        [ $account, $settings, $credentials ] = $this->account_data();
        if ( ! $account || empty( $credentials['access_token'] ) ) {
            return new WP_Error( 'jksh_pinterest_sandbox_not_connected', 'Pinterest Sandbox is not connected.', [ 'status' => 409 ] );
        }
        $result = $this->api_request( (string) $credentials['access_token'], 'GET', '/boards?page_size=100' );
        if ( ! $result['ok'] ) {
            return new WP_Error( 'jksh_pinterest_sandbox_boards', $result['message'], [ 'status' => 502 ] );
        }
        return rest_ensure_response( [
            'ok' => true,
            'environment' => 'sandbox',
            'items' => is_array( $result['data']['items'] ?? null ) ? $result['data']['items'] : [],
            'selected_board_id' => (string) ( $settings['board_id'] ?? '' ),
        ] );
    }

    public function save_token() {
        if ( ! $this->can_manage() ) { wp_die( 'Not allowed.' ); }
        check_admin_referer( 'jksh_pinterest_sandbox_save' );

        $token = trim( (string) wp_unslash( $_POST['sandbox_token'] ?? '' ) );
        if ( '' === $token ) {
            $this->redirect( 'error', 'Pinterest Sandbox token is required.' );
        }

        $profile = $this->api_request( $token, 'GET', '/user_account' );
        if ( ! $profile['ok'] ) {
            $this->redirect( 'error', 'Pinterest Sandbox token verification failed: ' . $profile['message'] );
        }

        $boards = $this->api_request( $token, 'GET', '/boards?page_size=100' );
        if ( ! $boards['ok'] ) {
            $this->redirect( 'error', 'Pinterest Sandbox board discovery failed: ' . $boards['message'] );
        }

        $items = is_array( $boards['data']['items'] ?? null ) ? $boards['data']['items'] : [];
        $board = null;
        foreach ( $items as $item ) {
            if ( self::BOARD_NAME === (string) ( $item['name'] ?? '' ) ) {
                $board = $item;
                break;
            }
        }

        if ( ! $board ) {
            $created = $this->api_request(
                $token,
                'POST',
                '/boards',
                [
                    'name' => self::BOARD_NAME,
                    'description' => 'Private Pinterest API Sandbox proof board for JustKalinga Standard Access review.',
                    'privacy' => 'PUBLIC',
                ]
            );
            if ( $created['ok'] && ! empty( $created['data']['id'] ) ) {
                $board = $created['data'];
            }
        }

        if ( ! $board && $items ) {
            $board = $items[0];
        }

        if ( ! $board || empty( $board['id'] ) ) {
            $this->redirect( 'error', 'Pinterest Sandbox is connected, but no usable board could be created or discovered.' );
        }

        $username = sanitize_text_field( (string) ( $profile['data']['username'] ?? '' ) );
        $profile_id = sanitize_text_field( (string) ( $profile['data']['id'] ?? $username ?: 'sandbox' ) );
        $account_name = $username ? '@' . $username . ' · Sandbox' : 'Pinterest Sandbox';

        $this->repo()->upsert( [
            'platform' => self::PLATFORM,
            'account_name' => $account_name,
            'external_account_id' => $profile_id,
            'status' => 'connected',
            'settings' => [
                'environment' => 'sandbox',
                'username' => $username,
                'board_id' => sanitize_text_field( (string) $board['id'] ),
                'board_name' => sanitize_text_field( (string) ( $board['name'] ?? self::BOARD_NAME ) ),
                'verified_at_utc' => current_time( 'mysql', true ),
                'proof_mode' => true,
                'image_pins_supported' => true,
                'video_pins_supported' => false,
            ],
            'credentials' => [
                'access_token' => $token,
            ],
            'token_expires_at' => gmdate( 'Y-m-d H:i:s', time() + DAY_IN_SECONDS * 30 ),
            'last_checked_at' => current_time( 'mysql', true ),
            'last_error' => '',
        ] );

        $this->redirect( 'success', 'Pinterest Sandbox connected securely. Image Pins can now publish as Sandbox Published.' );
    }

    public function disconnect() {
        if ( ! $this->can_manage() ) { wp_die( 'Not allowed.' ); }
        check_admin_referer( 'jksh_pinterest_sandbox_disconnect' );
        $account = $this->account();
        if ( $account ) {
            $this->repo()->disconnect( (int) $account->id );
        }
        $this->redirect( 'success', 'Pinterest Sandbox disconnected locally. Production Pinterest was not changed.' );
    }

    private function redirect( $type, $message ) {
        wp_safe_redirect(
            add_query_arg(
                [
                    'page' => 'jksh-accounts',
                    'jksh_notice' => sanitize_key( $type ),
                    'jksh_msg' => $message,
                ],
                admin_url( 'admin.php' )
            ) . '#account-pinterest'
        );
        exit;
    }

    private function api_request( $token, $method, $path, $body = null ) {
        $args = [
            'method' => strtoupper( (string) $method ),
            'timeout' => 30,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ],
        ];
        if ( null !== $body ) {
            $args['body'] = wp_json_encode( $body );
        }
        $response = wp_remote_request( self::API_HOST . $path, $args );
        if ( is_wp_error( $response ) ) {
            return [ 'ok' => false, 'message' => $response->get_error_message(), 'data' => [] ];
        }
        $code = (int) wp_remote_retrieve_response_code( $response );
        $raw = (string) wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );
        $data = is_array( $data ) ? $data : [];
        $message = sanitize_text_field( (string) ( $data['message'] ?? $data['error']['message'] ?? $raw ) );
        return [
            'ok' => $code >= 200 && $code < 300,
            'code' => $code,
            'message' => $message ?: ( $code >= 200 && $code < 300 ? 'OK' : 'Pinterest Sandbox API request failed.' ),
            'data' => $data,
        ];
    }

    private function replace_authorization( array $args, $token ) {
        $headers = is_array( $args['headers'] ?? null ) ? $args['headers'] : [];
        $headers['Authorization'] = 'Bearer ' . $token;
        $headers['Content-Type'] = $headers['Content-Type'] ?? 'application/json';
        $headers['Accept'] = $headers['Accept'] ?? 'application/json';
        $args['headers'] = $headers;
        return $args;
    }

    private function replace_board_in_body( array $args, $board_id ) {
        if ( empty( $args['body'] ) || ! is_string( $args['body'] ) ) {
            return $args;
        }
        $data = json_decode( $args['body'], true );
        if ( is_array( $data ) ) {
            $data['board_id'] = (string) $board_id;
            $args['body'] = wp_json_encode( $data );
        }
        return $args;
    }

    public function route_request( $preempt, array $args, string $url ) {
        if ( false !== $preempt ) { return $preempt; }
        if ( 0 !== strpos( $url, 'https://api.pinterest.com/' ) ) { return $preempt; }

        [ $account, $settings, $credentials ] = $this->account_data();
        if ( ! $account || empty( $credentials['access_token'] ) || empty( $settings['board_id'] ) ) {
            return $preempt;
        }

        $method = strtoupper( (string) ( $args['method'] ?? 'GET' ) );
        $path = wp_parse_url( $url, PHP_URL_PATH );
        $path = is_string( $path ) ? $path : '';

        if ( in_array( $method, [ 'POST', 'PUT', 'PATCH' ], true ) && false !== strpos( $path, '/media' ) ) {
            return new WP_Error(
                'jksh_pinterest_sandbox_video_unsupported',
                'Pinterest Sandbox supports image Pins only. Video Pins require Standard API access.'
            );
        }

        $sandbox_url = preg_replace(
            '#^https://api\.pinterest\.com/#',
            'https://api-sandbox.pinterest.com/',
            $url,
            1
        );
        if ( ! is_string( $sandbox_url ) || $sandbox_url === $url ) {
            return $preempt;
        }

        $args = $this->replace_authorization( $args, (string) $credentials['access_token'] );
        if ( 'POST' === $method && false !== strpos( $path, '/pins' ) ) {
            $args = $this->replace_board_in_body( $args, (string) $settings['board_id'] );
        }

        remove_filter( 'pre_http_request', [ $this, 'route_request' ], 4 );
        try {
            return wp_remote_request( $sandbox_url, $args );
        } finally {
            add_filter( 'pre_http_request', [ $this, 'route_request' ], 4, 3 );
        }
    }

    public function reconcile_recent_published() {
        $ready = $this->readiness();
        if ( empty( $ready['connected'] ) ) { return; }

        global $wpdb;
        $jobs = $wpdb->prefix . 'jksh_jobs';
        $variants = $wpdb->prefix . 'jksh_variants';
        $logs = $wpdb->prefix . 'jksh_publish_logs';
        $since = gmdate( 'Y-m-d H:i:s', time() - HOUR_IN_SECONDS * 12 );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT j.id job_id,j.content_id,j.variant_id,j.last_response_json,j.completed_at,
                        v.status variant_status,v.fields_json,v.external_id,v.external_url
                 FROM {$jobs} j
                 INNER JOIN {$variants} v ON v.id=j.variant_id
                 WHERE j.platform='pinterest' AND j.status='published' AND j.completed_at >= %s
                 ORDER BY j.id DESC LIMIT 30",
                $since
            ),
            ARRAY_A
        );

        foreach ( (array) $rows as $row ) {
            $fields = json_decode( (string) ( $row['fields_json'] ?? '{}' ), true );
            $fields = is_array( $fields ) ? $fields : [];
            if ( ! empty( $fields['sandbox_published'] ) ) { continue; }

            $pin_id = sanitize_text_field( (string) ( $row['external_id'] ?? '' ) );
            $pin_url = esc_url_raw( (string) ( $row['external_url'] ?? '' ) );
            if ( '' === $pin_url && '' !== $pin_id ) {
                $pin_url = 'https://www.pinterest.com/pin/' . rawurlencode( $pin_id ) . '/';
            }

            $fields['jksh_environment'] = 'sandbox';
            $fields['sandbox_published'] = true;
            $fields['sandbox_pin_id'] = $pin_id;
            $fields['sandbox_pin_url'] = $pin_url;
            $fields['sandbox_board_id'] = (string) $ready['board_id'];
            $fields['sandbox_board_name'] = (string) $ready['board_name'];
            $fields['sandbox_published_at_utc'] = (string) ( $row['completed_at'] ?? current_time( 'mysql', true ) );

            $update = [ 'fields_json' => wp_json_encode( $fields ), 'updated_at' => current_time( 'mysql', true ) ];
            if ( $pin_url ) { $update['external_url'] = $pin_url; }
            $wpdb->update( $variants, $update, [ 'id' => (int) $row['variant_id'] ] );

            $response = json_decode( (string) ( $row['last_response_json'] ?? '{}' ), true );
            $response = is_array( $response ) ? $response : [];
            $response['environment'] = 'sandbox';
            $response['sandbox_published'] = true;
            $response['sandbox_pin_id'] = $pin_id;
            $response['sandbox_pin_url'] = $pin_url;
            $wpdb->update(
                $jobs,
                [ 'last_response_json' => wp_json_encode( $response ) ],
                [ 'id' => (int) $row['job_id'] ]
            );

            $exists = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$logs} WHERE job_id=%d AND action='pinterest_sandbox_published'",
                    (int) $row['job_id']
                )
            );
            if ( ! $exists ) {
                $wpdb->insert(
                    $logs,
                    [
                        'job_id' => (int) $row['job_id'],
                        'content_id' => (int) $row['content_id'],
                        'variant_id' => (int) $row['variant_id'],
                        'user_id' => get_current_user_id(),
                        'action' => 'pinterest_sandbox_published',
                        'result' => 'success',
                        'external_id' => $pin_id,
                        'external_url' => $pin_url,
                        'message' => 'Pinterest image Pin published successfully to the API Sandbox environment.',
                        'context_json' => wp_json_encode( [
                            'environment' => 'sandbox',
                            'board_id' => (string) $ready['board_id'],
                            'status_label' => 'Sandbox Published',
                        ] ),
                        'created_at' => current_time( 'mysql', true ),
                    ]
                );
            }
        }
    }

    public function render_card() {
        $ready = $this->readiness();
        ?>
        <div id="jksh-pinterest-sandbox-inline-v01315" class="jksh-pinterest-sandbox-inline" data-jksh-sandbox-ui="0.13.15" style="display:block!important;width:100%!important;max-width:100%!important;min-width:0!important;box-sizing:border-box!important;visibility:visible!important;opacity:1!important;border-top:1px solid #e4e7ec;margin-top:24px;padding-top:20px;">
            <h3 style="margin-top:0;">Pinterest Sandbox <small style="font-size:11px;font-weight:700;color:#667085;margin-left:8px;">Proof Mode</small> <span class="jksh-badge <?php echo ! empty( $ready['connected'] ) ? 'status-connected' : 'status-not_connected'; ?>"><?php echo ! empty( $ready['connected'] ) ? 'Connected' : 'Not connected'; ?></span></h2>
            <p><strong>Standard Access proof mode.</strong> This is a separate encrypted Sandbox credential lane. Your production Pinterest OAuth connection is not modified.</p>
            <p class="description">Sandbox supports image Pins only. Successful image Pins are recorded in Content Library as <strong>Sandbox Published</strong> with their Pin ID and Open link. Video Pins remain blocked until Pinterest grants Standard API access.</p>
            <?php if ( ! empty( $ready['connected'] ) ) : ?>
                <table class="widefat striped">
                    <tbody>
                        <tr><th>Profile</th><td><?php echo esc_html( $ready['profile'] ); ?></td></tr>
                        <tr><th>Environment</th><td><strong>Sandbox</strong></td></tr>
                        <tr><th>Proof board</th><td><?php echo esc_html( $ready['board_name'] ); ?><br><code><?php echo esc_html( $ready['board_id'] ); ?></code></td></tr>
                        <tr><th>Token expiry</th><td><?php echo esc_html( $ready['token_expires_at_utc'] ?: 'Not reported' ); ?> UTC</td></tr>
                    </tbody>
                </table>
                <p><span class="jksh-badge status-connected">Ready for image proof Pins</span></p>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Disconnect only the Pinterest Sandbox token? Production Pinterest will remain untouched.');">
                    <input type="hidden" name="action" value="jksh_pinterest_sandbox_disconnect">
                    <?php wp_nonce_field( 'jksh_pinterest_sandbox_disconnect' ); ?>
                    <button class="button button-link-delete">Disconnect Sandbox</button>
                </form>
            <?php else : ?>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="jksh-form">
                    <input type="hidden" name="action" value="jksh_pinterest_sandbox_save">
                    <?php wp_nonce_field( 'jksh_pinterest_sandbox_save' ); ?>
                    <label>
                        <span>Sandbox access token</span>
                        <input type="password" name="sandbox_token" value="" autocomplete="new-password" required>
                    </label>
                    <p class="description">Paste the token generated from Pinterest → Generate Access Tokens → Sandbox. It is encrypted in the JK Social account vault and is never shown again.</p>
                    <button class="button button-primary">Save & verify Sandbox token</button>
                </form>
            <?php endif; ?>
        </div>
        <style>
        #jksh-pinterest-sandbox-inline-v01315{
            width:100%;
            max-width:100%;
            min-width:0;
            box-sizing:border-box;
            overflow:visible;
        }
        #jksh-pinterest-sandbox-inline-v01315 *{box-sizing:border-box}
        #jksh-pinterest-sandbox-inline-v01315 p,
        #jksh-pinterest-sandbox-inline-v01315 td,
        #jksh-pinterest-sandbox-inline-v01315 th{overflow-wrap:anywhere;word-break:normal}
        #jksh-pinterest-sandbox-inline-v01315 .jksh-form{
            display:grid;
            gap:12px;
            width:100%;
            max-width:760px;
            min-width:0;
        }
        #jksh-pinterest-sandbox-inline-v01315 .jksh-form label{display:grid;gap:6px;min-width:0}
        #jksh-pinterest-sandbox-inline-v01315 input[type=password],
        #jksh-pinterest-sandbox-inline-v01315 input[type=text],
        #jksh-pinterest-sandbox-inline-v01315 select,
        #jksh-pinterest-sandbox-inline-v01315 textarea{
            width:100%;
            max-width:100%;
            min-width:0;
        }
        #jksh-pinterest-sandbox-inline-v01315 table{
            width:100%;
            max-width:100%;
            table-layout:fixed;
        }
        .jksh-account-panel[data-account-panel="pinterest"],
        .jksh-account-panel[data-account-panel="pinterest"] .jksh-account-panel-grid{
            min-width:0;
            width:100%;
            max-width:100%;
        }
        @media(max-width:782px){
            #jksh-pinterest-sandbox-inline-v01315{padding:16px!important}
            #jksh-pinterest-sandbox-inline-v01315 .button{width:100%;justify-content:center}
        }
        </style>
        <?php
    }
}

JKSH_Pinterest_Sandbox_V0138::instance();
