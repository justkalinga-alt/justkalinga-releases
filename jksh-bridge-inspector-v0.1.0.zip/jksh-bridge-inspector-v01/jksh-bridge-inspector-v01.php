<?php
/**
 * Plugin Name: JKSH Active Bridge Inspector
 * Description: Temporary read-only inspector for the active JK Social Supabase Bridge file.
 * Version: 0.1.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action('rest_api_init', function(){
    register_rest_route('jksh-bridge-inspect/v1','/search',[
        'methods'=>'GET',
        'permission_callback'=>function(){ return current_user_can('manage_options'); },
        'callback'=>function(WP_REST_Request $r){
            $q=(string)$r->get_param('q');
            if($q==='') return new WP_Error('missing_q','q is required',['status'=>400]);
            $candidates=[
                WP_PLUGIN_DIR.'/jk-social-supabase-bridge-disabled/jk-social-supabase-bridge.php',
                WP_PLUGIN_DIR.'/jk-social-supabase-bridge/jk-social-supabase-bridge.php',
            ];
            $file=''; foreach($candidates as $f){ if(is_readable($f)){ $file=$f; break; } }
            if(!$file) return new WP_Error('missing_bridge','Active bridge file not found',['status'=>404]);
            $lines=file($file, FILE_IGNORE_NEW_LINES); $matches=[];
            foreach($lines as $i=>$line){
                if(stripos($line,$q)!==false){
                    $from=max(0,$i-5); $to=min(count($lines)-1,$i+8); $excerpt=[];
                    for($j=$from;$j<=$to;$j++) $excerpt[]=['line'=>$j+1,'text'=>$lines[$j]];
                    $matches[]=['line'=>$i+1,'excerpt'=>$excerpt];
                    if(count($matches)>=50) break;
                }
            }
            return ['ok'=>true,'file'=>basename(dirname($file)).'/'.basename($file),'query'=>$q,'count'=>count($matches),'matches'=>$matches];
        }
    ]);
});
