<?php
namespace JKSH\Admin;

use JKSH\Queue\Dispatcher;
use JKSH\Repositories\AccountRepository;
use JKSH\Repositories\ContentRepository;
use JKSH\Repositories\JobRepository;
use JKSH\Repositories\LogRepository;
use JKSH\Repositories\TemplateRepository;
use JKSH\Repositories\VariantRepository;
use JKSH\Services\MetaConnector;
use JKSH\Services\MetaPublisher;
use JKSH\Services\Settings;
use JKSH\Services\VariantBuilder;
use JKSH\Services\YouTubeConnector;

final class Pages {
	private function header( string $title, string $subtitle = '' ): void {
		echo '<div class="wrap jksh-wrap"><div class="jksh-title-row"><div><h1>' . esc_html( $title ) . '</h1>';
		if ( $subtitle ) {
			echo '<p class="description">' . esc_html( $subtitle ) . '</p>';
		}
		echo '</div><span class="jksh-version">v' . esc_html( JKSH_VERSION ) . '</span></div>';
		$this->notice_dry_run();
	}

	private function footer(): void {
		echo '</div>';
	}


	private function ist_time( mixed $utc_value ): string {
		$value = trim( (string) $utc_value );
		if ( '' === $value || '0000-00-00 00:00:00' === $value ) {
			return '';
		}
		try {
			$utc = new \DateTimeImmutable( $value, new \DateTimeZone( 'UTC' ) );
			return $utc->setTimezone( new \DateTimeZone( 'Asia/Kolkata' ) )->format( 'Y-m-d H:i:s' );
		} catch ( \Throwable $e ) {
			return $value;
		}
	}

	private function notice_dry_run(): void {
		$settings = new Settings();
		if ( $settings->get( 'dry_run', 1 ) ) {
			echo '<div class="notice notice-info inline jksh-notice"><p><strong>Dry Run mode is ON.</strong> v0.6.0 contains Meta plus guarded YouTube video/Short publishing, but jobs scheduled while Dry Run is ON remain dry-run only and cannot later turn live automatically.</p></div>';
		} elseif ( ! $settings->get( 'meta_live_publish_enabled', 0 ) ) {
			echo '<div class="notice notice-warning inline jksh-notice"><p><strong>Dry Run is OFF, but Meta live publishing is still locked.</strong> The separate Meta live-publish switch must also be enabled before a newly scheduled Facebook or Instagram job can publish.</p></div>';
		} else {
			echo '<div class="notice notice-error inline jksh-notice"><p><strong>LIVE META PUBLISHING IS ENABLED.</strong> Newly scheduled Facebook and Instagram jobs can modify external social accounts.</p></div>';
		}
	}

	public function dashboard(): void {
		$this->header( 'JK Social Hub', 'JustKalinga Social Media Command Center' );
		$content  = new ContentRepository();
		$jobs     = new JobRepository();
		$logs     = new LogRepository();
		$settings = new Settings();
		$contents = $content->recent( 5 );
		$job_rows = $jobs->recent( 5 );
		$log_rows = $logs->recent( 5 );
		?>
		<div class="jksh-grid jksh-grid-4">
			<?php $this->stat_card( 'Mode', $settings->get( 'dry_run', 1 ) ? 'Dry Run' : ( $settings->get( 'meta_live_publish_enabled', 0 ) ? 'Meta Live' : 'Live Locked' ), 'v0.6.0 captures mode per scheduled job' ); ?>
			<?php $this->stat_card( 'Timezone', 'Asia/Kolkata (IST)', 'Human-facing timezone (fixed to IST)' ); ?>
			<?php $this->stat_card( 'Master Content', (string) count( $content->recent( 200 ) ), 'Recent records loaded' ); ?>
			<?php $this->stat_card( 'Queue Jobs', (string) count( $jobs->recent( 200 ) ), 'Recent jobs loaded' ); ?>
		</div>
		<div class="jksh-grid jksh-grid-2">
			<section class="jksh-card"><h2>Today's workflow</h2><ol class="jksh-steps"><li>Create master content</li><li>Generate platform variants</li><li>Preview and approve</li><li>Schedule</li><li>Queue with captured safety mode</li><li>Verify preflight / logs</li></ol><p><a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=jksh-composer' ) ); ?>">Create test content</a></p></section>
			<section class="jksh-card"><h2>Connector roadmap</h2><div class="jksh-roadmap"><span>Tier 1</span><strong>Instagram · Facebook · YouTube</strong><span>Tier 2</span><strong>Google Business · Pinterest · Threads</strong><span>Future</span><strong>X · LinkedIn · TikTok</strong></div></section>
		</div>
		<div class="jksh-grid jksh-grid-2">
			<section class="jksh-card"><h2>Recent content</h2><?php $this->content_table( $contents ); ?></section>
			<section class="jksh-card"><h2>Recent queue</h2><?php $this->jobs_table( $job_rows ); ?></section>
		</div>
		<section class="jksh-card"><h2>Recent audit log</h2><?php $this->logs_table( $log_rows ); ?></section>
		<?php
		$this->footer();
	}

	public function composer(): void {
		if ( isset( $_POST['jksh_create_content'] ) ) {
			$this->handle_composer();
		}
		$this->header( 'Composer', 'One master content item → platform-specific variants' );
		$types = $this->content_types();
		$composer_settings = new Settings();
		$composer_any_live = ! $composer_settings->get( 'dry_run', 1 ) && ( $composer_settings->get( 'meta_live_publish_enabled', 0 ) || $composer_settings->get( 'youtube_live_publish_enabled', 0 ) );
		?>
		<form method="post" class="jksh-card jksh-form">
			<?php wp_nonce_field( 'jksh_create_content', 'jksh_nonce' ); ?>
			<div class="jksh-form-grid">
				<label><span>Master title</span><input name="title" type="text" required placeholder="Example: Why Jagannath is called Patitapavana"></label>
				<label><span>Content type</span><select name="content_type"><?php foreach ( $types as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
			</div>
			<label><span>Source / master copy</span><textarea name="body" rows="8" placeholder="Paste the content, script, caption or core message here."></textarea></label>
			<label><span>WordPress media attachment IDs (optional, comma-separated)</span><input name="media_ids" type="text" placeholder="123,124,125"></label>
			<div class="jksh-form-grid">
				<label><span>Schedule date/time (IST)</span><input name="publish_at" type="datetime-local" value="<?php echo esc_attr( wp_date( 'Y-m-d\TH:i', time() + HOUR_IN_SECONDS, new \DateTimeZone( 'Asia/Kolkata' ) ) ); ?>"></label>
				<fieldset><legend>Platforms</legend><label class="jksh-check"><input type="checkbox" name="platforms[]" value="instagram" checked> Instagram</label><label class="jksh-check"><input type="checkbox" name="platforms[]" value="facebook" checked> Facebook</label><label class="jksh-check"><input type="checkbox" name="platforms[]" value="youtube" checked> YouTube</label></fieldset>
			</div>
			<p class="description"><strong>YouTube rule:</strong> image/carousel content becomes a YouTube Community Post variant, never a fake Short/slideshow unless explicitly requested later.</p>
			<?php if ( $composer_any_live ) : ?><p class="description jksh-error-text"><strong>Live mode:</strong> each platform is armed independently. Facebook/Instagram require the Meta master switch; YouTube video/Short uploads require the YouTube master switch. Community Posts stay on the worker/manual path.</p><?php endif; ?>
			<p><button class="button button-primary button-hero" name="jksh_create_content" value="1"><?php echo esc_html( $composer_any_live ? 'Create variants & schedule by platform safety switches' : 'Create variants & schedule Dry Run' ); ?></button></p>
		</form>
		<?php
		$this->footer();
	}

	private function handle_composer(): void {
		if ( ! current_user_can( 'jksh_create' ) ) {
			wp_die( esc_html__( 'You do not have permission to create social content.', 'jk-social-hub' ) );
		}
		check_admin_referer( 'jksh_create_content', 'jksh_nonce' );

		$title       = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
		$type        = sanitize_key( wp_unslash( $_POST['content_type'] ?? 'knowledge_reel' ) );
		$body        = sanitize_textarea_field( wp_unslash( $_POST['body'] ?? '' ) );
		$platforms   = array_map( 'sanitize_key', (array) ( $_POST['platforms'] ?? array() ) );
		$media_ids   = array_values( array_filter( array_map( 'absint', preg_split( '/\s*,\s*/', (string) wp_unslash( $_POST['media_ids'] ?? '' ) ) ) ) );
		$local_time  = sanitize_text_field( wp_unslash( $_POST['publish_at'] ?? '' ) );
		$timezone    = new \DateTimeZone( 'Asia/Kolkata' );
		$when        = \DateTimeImmutable::createFromFormat( 'Y-m-d\TH:i', $local_time, $timezone );
		if ( ! $when ) {
			$when = new \DateTimeImmutable( '+1 hour', $timezone );
		}
		$utc = $when->setTimezone( new \DateTimeZone( 'UTC' ) );
		$scheduled_at = $utc->format( 'Y-m-d H:i:s' );

		if ( '' === $title || empty( $platforms ) ) {
			echo '<div class="notice notice-error"><p>Title and at least one platform are required.</p></div>';
			return;
		}

		$settings = new Settings();
		$global_dry_run = (bool) $settings->get( 'dry_run', 1 );
		$any_live = ! $global_dry_run && ( $settings->get( 'meta_live_publish_enabled', 0 ) || $settings->get( 'youtube_live_publish_enabled', 0 ) );
		if ( $any_live && ! current_user_can( 'jksh_publish' ) ) {
			echo '<div class="notice notice-error"><p>You do not have permission to schedule live social publishing.</p></div>';
			return;
		}

		$content_repo = new ContentRepository();
		$variant_repo = new VariantRepository();
		$job_repo     = new JobRepository();
		$log_repo     = new LogRepository();
		$builder      = new VariantBuilder();
		$dispatcher   = new Dispatcher();

		$content_id = $content_repo->create(
			array(
				'title'        => $title,
				'content_type' => $type,
				'body'         => $body,
				'status'       => 'scheduled',
				'media'        => $media_ids,
			)
		);

		foreach ( $platforms as $platform ) {
			if ( ! in_array( $platform, array( 'instagram', 'facebook', 'youtube' ), true ) ) {
				continue;
			}
			if ( $global_dry_run ) {
				$job_publish_mode = 'dry_run';
			} elseif ( in_array( $platform, array( 'facebook', 'instagram' ), true ) ) {
				$job_publish_mode = $settings->get( 'meta_live_publish_enabled', 0 ) ? 'live' : 'blocked';
			} elseif ( 'youtube' === $platform ) {
				$job_publish_mode = $settings->get( 'youtube_live_publish_enabled', 0 ) ? 'live' : 'blocked';
			} else {
				$job_publish_mode = 'blocked';
			}
			$variant = $builder->build(
				$platform,
				array(
					'title'        => $title,
					'content_type' => $type,
					'body'         => $body,
					'media'        => $media_ids,
				)
			);
			$variant['content_id'] = $content_id;
			$variant['publish_at'] = $scheduled_at;
			$variant['status']     = 'scheduled';
			$variant_id = $variant_repo->create( $variant );

			$job_id = $job_repo->create(
				array(
					'content_id'      => $content_id,
					'variant_id'      => $variant_id,
					'platform'        => $platform,
					'job_type'        => 'publish',
					'status'          => 'queued',
					'scheduled_at'    => $scheduled_at,
					'idempotency_key' => hash( 'sha256', 'jksh|' . $variant_id . '|publish|' . $scheduled_at ),
					'payload'         => array( 'variant_id' => $variant_id, 'publish_mode' => $job_publish_mode, 'dry_run' => 'dry_run' === $job_publish_mode ),
				)
			);
			$dispatcher->schedule( $job_id, $utc->getTimestamp() );
			$log_repo->add(
				array(
					'job_id'     => $job_id,
					'content_id' => $content_id,
					'variant_id' => $variant_id,
					'action'     => 'schedule',
					'result'     => 'success',
					'message'    => 'live' === $job_publish_mode ? 'Platform variant scheduled for LIVE publishing.' : ( 'dry_run' === $job_publish_mode ? 'Platform variant scheduled in Dry Run mode.' : 'Platform variant scheduled but live publishing is locked.' ),
					'context'    => array( 'platform' => $platform, 'scheduled_at_utc' => $scheduled_at, 'publish_mode' => $job_publish_mode ),
				)
			);
		}
		echo '<div class="notice notice-success"><p>Master content #' . esc_html( (string) $content_id ) . ' created with platform variants. Each queued job permanently captured its platform safety mode.</p></div>';
	}

	public function content_library(): void {
		$this->header( 'Content Library', 'Master content records' );
		$this->content_table( ( new ContentRepository() )->recent( 100 ) );
		$this->footer();
	}

	public function variants(): void {
		$this->header( 'Platform Variants', 'Each platform keeps its own native format and copy' );
		$rows = ( new VariantRepository() )->recent( 150 );
		echo '<section class="jksh-card"><table class="widefat striped"><thead><tr><th>ID</th><th>Content</th><th>Platform</th><th>Type</th><th>Status</th><th>Publish IST</th><th>External</th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="7">No variants yet.</td></tr>';
		}
		foreach ( $rows as $row ) {
			echo '<tr><td>' . esc_html( (string) $row->id ) . '</td><td>#' . esc_html( (string) $row->content_id ) . '</td><td><strong>' . esc_html( ucfirst( $row->platform ) ) . '</strong></td><td>' . esc_html( str_replace( '_', ' ', $row->publication_type ) ) . '</td><td>' . $this->badge( $row->status ) . '</td><td>' . esc_html( $this->ist_time( $row->publish_at ) ) . '</td><td>' . ( $row->external_url ? '<a href="' . esc_url( $row->external_url ) . '" target="_blank" rel="noopener">Open</a>' : '—' ) . '</td></tr>';
		}
		echo '</tbody></table></section>';
		$this->footer();
	}

	public function calendar(): void {
		$this->header( 'Calendar', 'Foundation calendar view; drag/drop comes in a later release' );
		$rows = ( new VariantRepository() )->recent( 150 );
		$by_date = array();
		foreach ( $rows as $row ) {
			$ist_publish_at = $row->publish_at ? $this->ist_time( $row->publish_at ) : '';
			$date = $ist_publish_at ? substr( $ist_publish_at, 0, 10 ) : 'Unscheduled';
			$by_date[ $date ][] = $row;
		}
		echo '<div class="jksh-calendar">';
		if ( ! $by_date ) {
			echo '<section class="jksh-card">No scheduled variants yet.</section>';
		}
		foreach ( $by_date as $date => $items ) {
			echo '<section class="jksh-card"><h2>' . esc_html( $date ) . '</h2>';
			foreach ( $items as $item ) {
				echo '<div class="jksh-calendar-item"><strong>' . esc_html( ucfirst( $item->platform ) ) . '</strong><span>' . esc_html( str_replace( '_', ' ', $item->publication_type ) ) . '</span>' . $this->badge( $item->status ) . '</div>';
			}
			echo '</section>';
		}
		echo '</div>';
		$this->footer();
	}

	public function queue(): void {
		$this->header( 'Queue', 'Idempotent background jobs with retained errors and retry history' );
		$this->jobs_table( ( new JobRepository() )->recent( 150 ) );
		$this->footer();
	}

	public function templates(): void {
		if ( isset( $_POST['jksh_add_template'] ) ) {
			check_admin_referer( 'jksh_add_template', 'jksh_nonce' );
			if ( current_user_can( 'jksh_edit' ) ) {
				( new TemplateRepository() )->create(
					array(
						'name'          => wp_unslash( $_POST['name'] ?? '' ),
						'content_type'  => wp_unslash( $_POST['content_type'] ?? '' ),
						'platform'      => wp_unslash( $_POST['platform'] ?? '' ),
						'template_kind' => wp_unslash( $_POST['template_kind'] ?? 'caption' ),
						'body'          => wp_unslash( $_POST['body'] ?? '' ),
					)
				);
				echo '<div class="notice notice-success"><p>Template saved.</p></div>';
			}
		}
		$this->header( 'Templates', 'Reusable captions, CTAs, hashtags and platform defaults' );
		?>
		<div class="jksh-grid jksh-grid-2">
		<form method="post" class="jksh-card jksh-form"><?php wp_nonce_field( 'jksh_add_template', 'jksh_nonce' ); ?><h2>Add template</h2><label><span>Name</span><input name="name" required></label><div class="jksh-form-grid"><label><span>Content type</span><input name="content_type" placeholder="knowledge_carousel"></label><label><span>Platform</span><select name="platform"><option value="">Any</option><option>instagram</option><option>facebook</option><option>youtube</option></select></label></div><label><span>Kind</span><select name="template_kind"><option value="caption">Caption</option><option value="cta">CTA</option><option value="hashtags">Hashtags</option><option value="description">Description</option></select></label><label><span>Template</span><textarea name="body" rows="8" placeholder="Use variables like {{website}}, {{coupon}}, {{product_name}}"></textarea></label><p><button class="button button-primary" name="jksh_add_template" value="1">Save template</button></p></form>
		<section class="jksh-card"><h2>Available variables</h2><code>{{product_name}}</code> <code>{{product_url}}</code> <code>{{website}}</code> <code>{{coupon}}</code> <code>{{phone_primary}}</code> <code>{{phone_secondary}}</code> <code>{{whatsapp}}</code> <code>{{today}}</code> <code>{{festival}}</code> <code>{{platform}}</code><hr><h2>Saved templates</h2><?php foreach ( ( new TemplateRepository() )->all() as $t ) : ?><div class="jksh-template"><strong><?php echo esc_html( $t->name ); ?></strong><span><?php echo esc_html( trim( $t->platform . ' · ' . $t->template_kind, ' ·' ) ); ?></span><pre><?php echo esc_html( $t->body ); ?></pre></div><?php endforeach; ?></section>
		</div>
		<?php
		$this->footer();
	}

	public function accounts(): void {
		$this->header( 'Accounts', 'Meta and YouTube connections, health and controlled publishing readiness' );
		$connector = new MetaConnector();
		$config    = $connector->config();
		$account_repo = new AccountRepository();
		$accounts  = array_values( array_filter( $account_repo->active(), static fn( $a ) => in_array( (string) $a->platform, array( 'facebook', 'instagram' ), true ) ) );
		$youtube_connector = new YouTubeConnector();
		$youtube_config = $youtube_connector->config();
		$youtube_accounts = $account_repo->connected( 'youtube' );
		$notice    = sanitize_key( wp_unslash( $_GET['jksh_notice'] ?? '' ) );
		$message   = sanitize_text_field( rawurldecode( (string) wp_unslash( $_GET['jksh_msg'] ?? '' ) ) );
		if ( $notice && $message ) {
			$class = 'success' === $notice ? 'notice-success' : 'notice-error';
			echo '<div class="notice ' . esc_attr( $class ) . ' inline"><p>' . esc_html( $message ) . '</p></div>';
		}
		?>
		<div class="jksh-grid jksh-grid-2">
			<section class="jksh-card">
				<h2>Meta App configuration</h2>
				<p>Use one Meta app for the JustKalinga Facebook Page and its linked Instagram Professional account. App secrets and access tokens are encrypted server-side and never exposed to JavaScript.</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="jksh-form">
					<input type="hidden" name="action" value="jksh_save_meta_config">
					<?php wp_nonce_field( 'jksh_meta_config' ); ?>
					<label><span>Meta App ID</span><input type="text" name="app_id" value="<?php echo esc_attr( $config['app_id'] ); ?>" autocomplete="off"></label>
					<label><span>Meta App Secret</span><input type="password" name="app_secret" value="" autocomplete="new-password" placeholder="<?php echo $connector->has_secret() ? esc_attr__( 'Saved securely — leave blank to keep it', 'jk-social-hub' ) : esc_attr__( 'Enter App Secret', 'jk-social-hub' ); ?>"></label>
					<div class="jksh-form-grid"><label><span>Graph API version</span><input type="text" name="graph_version" value="<?php echo esc_attr( $config['graph_version'] ); ?>"></label><label><span>Facebook Login configuration ID (optional)</span><input type="text" name="login_config_id" value="<?php echo esc_attr( $config['login_config_id'] ); ?>" placeholder="Leave blank unless Meta gives you one"></label></div>
					<label><span>Primary Facebook Page ID</span><input type="text" inputmode="numeric" name="preferred_page_id" value="<?php echo esc_attr( $connector->preferred_page_id() ); ?>" placeholder="Example: 123456789012345"><small>When set, reconnect imports only this Facebook Page and its linked Instagram Professional account. If blank and exactly one Facebook Page is already connected, v0.6.0 auto-locks to that Page.</small></label>
					<p><button class="button button-primary">Save Meta settings</button></p>
				</form>
				<hr>
				<h3>OAuth redirect URI</h3>
				<p class="description">Add this exact URL to your Meta app's valid OAuth redirect URIs. If the site domain changes later, update Meta too.</p>
				<code class="jksh-code-block"><?php echo esc_html( $connector->redirect_uri() ); ?></code>
				<h3>Requested permissions</h3>
				<p><code><?php echo esc_html( implode( ', ', $connector->scopes() ) ); ?></code></p>
				<?php if ( ! empty( $config['login_config_id'] ) ) : ?>
					<p class="description">Facebook Login for Business configuration mode is active. Meta takes permissions from the saved Configuration ID, so the connector intentionally does not send a separate <code>scope</code> query parameter.</p>
				<?php endif; ?>
			</section>
			<section class="jksh-card">
				<h2>Meta connection</h2>
				<?php if ( $connector->is_configured() ) : ?>
					<p>The app credentials are saved. Reconnect is restricted to the Primary Facebook Page when configured or auto-detected, then discovers its linked Instagram Professional account.</p>
					<p><a class="button button-primary button-hero" href="<?php echo esc_url( $connector->auth_url() ); ?>">Connect / Reconnect Meta</a></p>
				<?php else : ?>
					<p><strong>Not ready yet.</strong> Save the Meta App ID and App Secret first.</p>
					<button class="button button-primary" disabled>Connect Meta</button>
				<?php endif; ?>
				<hr>
				<p><strong>Safety:</strong> v0.6.0 contains controlled Facebook, Instagram and YouTube video/Short publishing methods. Dry Run remains the default; Meta and YouTube each have their own additional live-publish switch.</p>
			</section>
		</div>
		<div class="jksh-grid jksh-grid-2">
			<section class="jksh-card">
				<h2>YouTube OAuth configuration</h2>
				<p>Connect the JustKalinga YouTube channel with a Google Cloud OAuth 2.0 Web application. Client secrets and tokens are encrypted server-side.</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="jksh-form">
					<input type="hidden" name="action" value="jksh_save_youtube_config">
					<?php wp_nonce_field( 'jksh_youtube_config' ); ?>
					<label><span>Google OAuth Client ID</span><input type="text" name="client_id" value="<?php echo esc_attr( $youtube_config['client_id'] ); ?>" autocomplete="off"></label>
					<label><span>Google OAuth Client Secret</span><input type="password" name="client_secret" value="" autocomplete="new-password" placeholder="<?php echo $youtube_connector->has_secret() ? esc_attr__( 'Saved securely — leave blank to keep it', 'jk-social-hub' ) : esc_attr__( 'Enter Client Secret', 'jk-social-hub' ); ?>"></label>
					<p><button class="button button-primary">Save YouTube settings</button></p>
				</form>
				<hr><h3>Authorized redirect URI</h3><code class="jksh-code-block"><?php echo esc_html( $youtube_connector->redirect_uri() ); ?></code>
				<h3>Requested OAuth scope</h3><p><code><?php echo esc_html( implode( ' ', $youtube_connector->scopes() ) ); ?></code></p>
			</section>
			<section class="jksh-card">
				<h2>YouTube connection</h2>
				<?php if ( $youtube_connector->is_configured() ) : ?>
					<p><a class="button button-primary button-hero" href="<?php echo esc_url( $youtube_connector->auth_url() ); ?>">Connect / Reconnect YouTube</a></p>
				<?php else : ?>
					<p><strong>Not ready yet.</strong> Save the Google OAuth Client ID and Client Secret first.</p><button class="button button-primary" disabled>Connect YouTube</button>
				<?php endif; ?>
				<hr><p><strong>Stage:</strong> OAuth + channel discovery + encrypted refresh-token storage + guarded video/Short adapter. Live uploads remain locked unless Dry Run is OFF and the separate YouTube publishing switch is ON. YouTube Live provisioning is a later stage.</p>
			</section>
		</div>
		<section class="jksh-card">
			<h2>Connected YouTube channel</h2>
			<table class="widefat striped"><thead><tr><th>Name</th><th>Channel ID</th><th>Status</th><th>Token expiry IST</th><th>Last checked IST</th><th>Actions</th></tr></thead><tbody>
			<?php if ( ! $youtube_accounts ) : ?><tr><td colspan="6">No YouTube channel connected yet.</td></tr><?php endif; ?>
			<?php foreach ( $youtube_accounts as $account ) : ?>
			<tr><td><strong><?php echo esc_html( $account->account_name ); ?></strong></td><td><code><?php echo esc_html( $account->external_account_id ); ?></code></td><td><?php echo $this->badge( $account->status ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td><td><?php echo esc_html( $this->ist_time( $account->token_expires_at ) ); ?></td><td><?php echo esc_html( $this->ist_time( $account->last_checked_at ) ); ?><?php if ( $account->last_error ) : ?><br><small class="jksh-error-text"><?php echo esc_html( $account->last_error ); ?></small><?php endif; ?></td><td><div class="jksh-actions"><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="jksh_youtube_test_account"><input type="hidden" name="account_id" value="<?php echo esc_attr( (string) $account->id ); ?>"><?php wp_nonce_field( 'jksh_youtube_test_account' ); ?><button class="button">Test connection</button></form><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Disconnect this YouTube channel locally from JK Social Hub?');"><input type="hidden" name="action" value="jksh_youtube_disconnect_account"><input type="hidden" name="account_id" value="<?php echo esc_attr( (string) $account->id ); ?>"><?php wp_nonce_field( 'jksh_youtube_disconnect_account' ); ?><button class="button button-link-delete">Disconnect</button></form></div></td></tr>
			<?php endforeach; ?>
			</tbody></table>
		</section>
		<?php $publishing_readiness = ( new MetaPublisher() )->readiness(); ?>
		<section class="jksh-card">
			<h2>Publishing readiness</h2>
			<p><strong>Current state:</strong> <?php echo esc_html( $publishing_readiness['live_publish_possible'] ? 'LIVE publishing is armed' : ( $publishing_readiness['dry_run'] ? 'Dry Run protection is active' : 'Live publishing remains locked' ) ); ?></p>
			<p class="description">Supported in v0.6.0: Facebook text/single/multi-image/Reels; Instagram single-image/carousels/Reels; YouTube video and Short uploads with metadata, custom thumbnail and playlist follow-ups. YouTube Community Posts remain on the worker/manual path.</p>
			<p class="description"><strong>Two-key safety:</strong> live Meta writes require Dry Run OFF plus the Meta live-publish switch ON, and each queued job permanently records whether it was scheduled as dry-run or live.</p>
		</section>
		<section class="jksh-card">
			<h2>Connected accounts</h2><p class="description">Disconnected local records are hidden here. Reconnect is limited to the Primary Facebook Page when configured or auto-detected.</p>
			<table class="widefat striped"><thead><tr><th>Platform</th><th>Name</th><th>External ID</th><th>Status</th><th>Token expiry IST</th><th>Last checked IST</th><th>Actions</th></tr></thead><tbody>
			<?php if ( ! $accounts ) : ?><tr><td colspan="7">No Meta accounts connected yet.</td></tr><?php endif; ?>
			<?php foreach ( $accounts as $account ) : ?>
				<tr>
					<td><strong><?php echo esc_html( ucfirst( $account->platform ) ); ?></strong></td>
					<td><?php echo esc_html( $account->account_name ); ?></td>
					<td><code><?php echo esc_html( $account->external_account_id ); ?></code></td>
					<td><?php echo $this->badge( $account->status ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
					<td><?php echo esc_html( $this->ist_time( $account->token_expires_at ) ); ?></td>
					<td><?php echo esc_html( $this->ist_time( $account->last_checked_at ) ); ?><?php if ( $account->last_error ) : ?><br><small class="jksh-error-text"><?php echo esc_html( $account->last_error ); ?></small><?php endif; ?></td>
					<td><div class="jksh-actions"><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="jksh_meta_test_account"><input type="hidden" name="account_id" value="<?php echo esc_attr( (string) $account->id ); ?>"><?php wp_nonce_field( 'jksh_meta_test_account' ); ?><button class="button">Test connection</button></form><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Disconnect this account locally from JK Social Hub?');"><input type="hidden" name="action" value="jksh_meta_disconnect_account"><input type="hidden" name="account_id" value="<?php echo esc_attr( (string) $account->id ); ?>"><?php wp_nonce_field( 'jksh_meta_disconnect_account' ); ?><button class="button button-link-delete">Disconnect</button></form></div></td>
				</tr>
			<?php endforeach; ?>
			</tbody></table>
		</section>
		<div class="jksh-grid jksh-grid-2">
			<section class="jksh-card"><h2>Google Business Profile</h2><p>Tier 2 · planned after Tier 1 is stable.</p><span class="jksh-badge status-not_connected">Not connected</span></section>
			<section class="jksh-card"><h2>Pinterest / Threads</h2><p>Tier 2 · planned after Tier 1 is stable.</p><span class="jksh-badge status-not_connected">Not connected</span></section>
		</div>
		<?php
		$this->footer();
	}

	public function analytics(): void {
		$this->header( 'Analytics', 'Foundation schema is ready for historical platform metrics' );
		?>
		<div class="jksh-grid jksh-grid-3">
			<section class="jksh-card"><h2>JK Content Score</h2><p>Not calculated yet. We will wait for enough historical data before defining weights.</p></section>
			<section class="jksh-card"><h2>Priority metrics</h2><p>Shares · Saves · Followers gained · Profile visits · Link clicks · Retention · Skip rate · Orders / revenue.</p></section>
			<section class="jksh-card"><h2>Attribution</h2><p>UTM campaign model is reserved for linking social content to sessions and WooCommerce orders later.</p></section>
		</div>
		<?php
		$this->footer();
	}

	public function logs(): void {
		$this->header( 'Audit Logs', 'Who changed, scheduled, published, retried or failed' );
		$this->logs_table( ( new LogRepository() )->recent( 200 ) );
		$this->footer();
	}

	public function settings(): void {
		$this->header( 'Settings', 'Brand variables and safety defaults' );
		$settings = ( new Settings() )->all();
		?>
		<form method="post" action="options.php" class="jksh-card jksh-form">
			<?php settings_fields( 'jksh_settings_group' ); ?>
			<div class="jksh-form-grid"><label><span>Brand name</span><input name="jksh_settings[brand_name]" value="<?php echo esc_attr( $settings['brand_name'] ); ?>"></label><label><span>Operational timezone</span><input value="Asia/Kolkata (IST)" readonly><input type="hidden" name="jksh_settings[timezone]" value="Asia/Kolkata"></label></div>
			<label><span>Main website</span><input name="jksh_settings[website]" type="url" value="<?php echo esc_attr( $settings['website'] ); ?>"></label>
			<div class="jksh-form-grid"><label><span>Primary phone</span><input name="jksh_settings[phone_primary]" value="<?php echo esc_attr( $settings['phone_primary'] ); ?>"></label><label><span>Secondary phone</span><input name="jksh_settings[phone_secondary]" value="<?php echo esc_attr( $settings['phone_secondary'] ); ?>"></label></div>
			<div class="jksh-form-grid"><label><span>WhatsApp</span><input name="jksh_settings[whatsapp]" value="<?php echo esc_attr( $settings['whatsapp'] ); ?>"></label><label><span>Email</span><input type="email" name="jksh_settings[email]" value="<?php echo esc_attr( $settings['email'] ); ?>"></label></div>
			<div class="jksh-form-grid"><label><span>Coupon code</span><input name="jksh_settings[coupon_code]" value="<?php echo esc_attr( $settings['coupon_code'] ); ?>"></label><label><span>Coupon label</span><input name="jksh_settings[coupon_label]" value="<?php echo esc_attr( $settings['coupon_label'] ); ?>"></label></div>
			<label class="jksh-check"><input type="checkbox" name="jksh_settings[dry_run]" value="1" <?php checked( $settings['dry_run'], 1 ); ?>> <strong>Dry Run mode</strong> — keep enabled until publishing preflight is verified</label>
			<label class="jksh-check"><input type="checkbox" name="jksh_settings[meta_live_publish_enabled]" value="1" <?php checked( $settings['meta_live_publish_enabled'], 1 ); ?>> <strong>Enable Meta live publishing master switch</strong> — this alone does nothing while Dry Run remains ON</label>
			<label class="jksh-check"><input type="checkbox" name="jksh_settings[youtube_live_publish_enabled]" value="1" <?php checked( $settings['youtube_live_publish_enabled'], 1 ); ?>> <strong>Enable YouTube video/Short publishing master switch</strong> — controls normal video and Short uploads only</label>
			<label class="jksh-check"><input type="checkbox" name="jksh_settings[youtube_live_stream_enabled]" value="1" <?php checked( $settings['youtube_live_stream_enabled'], 1 ); ?>> <strong>Enable YouTube Live provisioning master switch</strong> — creates YouTube broadcast + RTMP stream resources only when Dry Run is also OFF</label>
			<p class="description">Two-key safety: each platform write requires Dry Run OFF plus its dedicated master switch ON. YouTube Live provisioning uses a separate switch from normal video uploads.</p>
			<label class="jksh-check"><input type="checkbox" name="jksh_settings[utm_enabled]" value="1" <?php checked( $settings['utm_enabled'], 1 ); ?>> Enable clean UTM tracking when connector layer is added</label>
			<hr><h2>External live relay worker</h2>
			<label class="jksh-check"><input type="checkbox" name="jksh_settings[live_worker_enabled]" value="1" <?php checked( $settings['live_worker_enabled'], 1 ); ?>> <strong>Enable live relay-worker dispatch</strong> — still blocked while Dry Run remains ON</label>
			<label><span>Worker HTTPS endpoint</span><input name="jksh_settings[live_worker_endpoint]" type="url" value="<?php echo esc_attr( $settings['live_worker_endpoint'] ); ?>" placeholder="https://relay.example.com"></label>
			<label><span>Worker public RTMP/RTMPS ingest base</span><input name="jksh_settings[live_worker_ingest_base]" value="<?php echo esc_attr( $settings['live_worker_ingest_base'] ); ?>" placeholder="rtmp://relay.example.com:1935/jksh"></label>
			<label><span>Worker internal ingest base</span><input name="jksh_settings[live_worker_internal_ingest_base]" value="<?php echo esc_attr( $settings['live_worker_internal_ingest_base'] ); ?>" placeholder="rtmp://mediamtx:1935/jksh"></label>
			<p class="description">v0.8.0 uses RSA-SHA256 signed worker requests. The worker receives destination ingest URLs only over the configured HTTPS control endpoint. Stream keys are never returned through MCP.</p>
			<?php submit_button(); ?>
		</form>
		<?php
		$this->footer();
	}

	private function content_types(): array {
		return array(
			'mangal_arati'         => 'Mangal Arati',
			'sell_reel'            => 'Sell Reel',
			'knowledge_reel'       => 'Knowledge Reel',
			'knowledge_carousel'   => 'Knowledge Carousel',
			'product_carousel'     => 'Product Carousel',
			'festival'             => 'Festival',
			'ritual'               => 'Ritual',
			'besha'                => 'Besha',
			'murti'                => 'Murti',
			'dress_vastra'         => 'Dress / Vastra',
			'jagannath_knowledge'  => 'Jagannath Knowledge',
			'puri'                 => 'Puri',
			'customer_review'      => 'Customer Review',
			'customer_ugc'         => 'Customer UGC',
			'order_dispatch'       => 'Order / Dispatch',
			'long_knowledge_video' => 'Long Knowledge Video',
			'youtube_community'    => 'YouTube Community',
			'story'                => 'Story',
		);
	}

	private function stat_card( string $label, string $value, string $note ): void {
		echo '<section class="jksh-card jksh-stat"><span>' . esc_html( $label ) . '</span><strong>' . esc_html( $value ) . '</strong><small>' . esc_html( $note ) . '</small></section>';
	}

	private function content_table( array $rows ): void {
		echo '<table class="widefat striped"><thead><tr><th>ID</th><th>Title</th><th>Type</th><th>Status</th><th>Created IST</th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="5">No content yet.</td></tr>';
		}
		foreach ( $rows as $row ) {
			echo '<tr><td>' . esc_html( (string) $row->id ) . '</td><td><strong>' . esc_html( $row->title ) . '</strong></td><td>' . esc_html( str_replace( '_', ' ', $row->content_type ) ) . '</td><td>' . $this->badge( $row->status ) . '</td><td>' . esc_html( $this->ist_time( $row->created_at ) ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private function jobs_table( array $rows ): void {
		echo '<section class="jksh-card"><table class="widefat striped"><thead><tr><th>Job</th><th>Variant</th><th>Platform</th><th>Status</th><th>Attempts</th><th>Scheduled IST</th><th>Error</th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="7">Queue is empty.</td></tr>';
		}
		foreach ( $rows as $row ) {
			echo '<tr><td>#' . esc_html( (string) $row->id ) . '</td><td>#' . esc_html( (string) $row->variant_id ) . '</td><td>' . esc_html( ucfirst( $row->platform ) ) . '</td><td>' . $this->badge( $row->status ) . '</td><td>' . esc_html( $row->attempts . '/' . $row->max_attempts ) . '</td><td>' . esc_html( $this->ist_time( $row->scheduled_at ) ) . '</td><td>' . esc_html( (string) $row->last_error ) . '</td></tr>';
		}
		echo '</tbody></table></section>';
	}

	private function logs_table( array $rows ): void {
		echo '<table class="widefat striped"><thead><tr><th>Time IST</th><th>User</th><th>Action</th><th>Content</th><th>Variant</th><th>Result</th><th>Message</th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="7">No logs yet.</td></tr>';
		}
		foreach ( $rows as $row ) {
			$user = $row->user_id ? get_userdata( (int) $row->user_id ) : null;
			echo '<tr><td>' . esc_html( $this->ist_time( $row->created_at ) ) . '</td><td>' . esc_html( $user ? $user->display_name : 'System' ) . '</td><td>' . esc_html( str_replace( '_', ' ', $row->action ) ) . '</td><td>#' . esc_html( (string) $row->content_id ) . '</td><td>#' . esc_html( (string) $row->variant_id ) . '</td><td>' . $this->badge( $row->result ) . '</td><td>' . esc_html( (string) $row->message ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private function badge( string $status ): string {
		return '<span class="jksh-badge status-' . esc_attr( sanitize_html_class( $status ) ) . '">' . esc_html( str_replace( '_', ' ', ucfirst( $status ) ) ) . '</span>';
	}
}
