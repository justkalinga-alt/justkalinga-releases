<?php
namespace JKSH\Mcp;

use JKSH\Repositories\AccountRepository;
use JKSH\Repositories\LogRepository;
use JKSH\Services\MetaConnector;
use JKSH\Services\MetaPublisher;
use JKSH\Services\PluginPackageUpdater;
use JKSH\Services\ContentOrchestrator;
use JKSH\Services\LiveStreaming;
use JKSH\Services\LiveWorker;
use JKSH\Services\PlatformSchema;
use JKSH\Services\YouTubeConnector;
use JKSH\Services\YouTubePublisher;
use JKSH\Services\YouTubeLive;

final class Abilities {
	private const CATEGORY = 'jk-social';

	public function register(): void {
		// Hook early and let WordPress call us when the Abilities API registries exist.
		// Do not require wp_register_ability() to exist at plugin load time.
		add_action( 'wp_abilities_api_categories_init', array( $this, 'register_category' ) );
		add_action( 'wp_abilities_api_init', array( $this, 'register_abilities' ) );
	}

	public function register_category(): void {
		wp_register_ability_category(
			self::CATEGORY,
			array(
				'label'       => __( 'JK Social Hub', 'jk-social-hub' ),
				'description' => __( 'Diagnostics, publishing readiness, and tightly scoped maintenance abilities for the JustKalinga Social Hub.', 'jk-social-hub' ),
			)
		);
	}

	public function register_abilities(): void {
		$this->register_ability(
			'jk-social/get-connected-accounts',
			__( 'Get connected social accounts', 'jk-social-hub' ),
			__( 'Returns the connected Facebook, Instagram and YouTube accounts in JK Social Hub without exposing access tokens, app secrets, encrypted credentials, refresh tokens or other authentication material.', 'jk-social-hub' ),
			array( $this, 'get_connected_accounts' ),
			'jksh_manage_accounts'
		);

		$this->register_ability(
			'jk-social/get-meta-health',
			__( 'Get Meta connection health', 'jk-social-hub' ),
			__( 'Returns a read-only health summary for the configured Meta connection, including Facebook and Instagram account states, token-expiry timestamps, last checks, and latest stored connection-test results. It does not call Meta or modify account state.', 'jk-social-hub' ),
			array( $this, 'get_meta_health' ),
			'jksh_manage_accounts'
		);

		$this->register_ability(
			'jk-social/get-latest-meta-log',
			__( 'Get latest Meta diagnostics', 'jk-social-hub' ),
			__( 'Returns recent sanitized Meta connection, discovery, test, and disconnect audit events from JK Social Hub. Secrets and token-like values are removed from diagnostic context.', 'jk-social-hub' ),
			array( $this, 'get_latest_meta_log' ),
			'jksh_view'
		);

		$this->register_ability(
			'jk-social/get-youtube-health',
			__( 'Get YouTube connection health', 'jk-social-hub' ),
			__( 'Returns read-only YouTube OAuth/channel health without exposing client secrets, access tokens or refresh tokens.', 'jk-social-hub' ),
			array( $this, 'get_youtube_health' ),
			'jksh_manage_accounts'
		);

		$this->register_ability(
			'jk-social/get-instagram-diagnostics',
			__( 'Get Instagram diagnostics', 'jk-social-hub' ),
			__( 'Returns the connected Instagram account records plus the latest sanitized Instagram discovery diagnostics from the Meta connection flow.', 'jk-social-hub' ),
			array( $this, 'get_instagram_diagnostics' ),
			'jksh_manage_accounts'
		);

		$this->register_ability(
			'jk-social/get-publishing-readiness',
			__( 'Get omnichannel publishing readiness', 'jk-social-hub' ),
			__( 'Returns local Dry Run and platform master switches plus Facebook, Instagram and YouTube publishing readiness. Read-only; it never publishes content.', 'jk-social-hub' ),
			array( $this, 'get_publishing_readiness' ),
			'jksh_publish'
		);

		$this->register_ability(
			'jk-social/get-publish-logs',
			__( 'Get publish logs', 'jk-social-hub' ),
			__( 'Returns recent sanitized publishing, retry, pending, blocked, and dry-run events without exposing access tokens or secrets.', 'jk-social-hub' ),
			array( $this, 'get_publish_logs' ),
			'jksh_view'
		);



		$this->register_ability(
			'jk-social/get-platform-field-schema',
			__( 'Get platform field schema', 'jk-social-hub' ),
			__( 'Returns the omnichannel field catalog used by ChatGPT/MCP to prepare native Instagram, Facebook and YouTube variants, including which fields are API-backed or require a manual fallback.', 'jk-social-hub' ),
			array( $this, 'get_platform_field_schema' ),
			'jksh_view'
		);
		$this->register_ability(
			'jk-social/create-dry-run-content',
			__( 'Create omnichannel Dry Run content', 'jk-social-hub' ),
			__( 'Creates one master content item, native platform variants and queued jobs captured permanently as Dry Run. It cannot create live publishing jobs.', 'jk-social-hub' ),
			array( $this, 'create_dry_run_content' ),
			'jksh_create',
			array(
				'type' => 'object',
				'properties' => array(
					'title' => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 255 ),
					'content_type' => array( 'type' => 'string' ),
					'body' => array( 'type' => 'string' ),
					'media_attachment_ids' => array( 'type' => 'array', 'items' => array( 'type' => 'integer', 'minimum' => 1 ) ),
					'platforms' => array( 'type' => 'array', 'items' => array( 'type' => 'string', 'enum' => array( 'instagram', 'facebook', 'youtube' ) ) ),
					'scheduled_at_ist' => array( 'type' => 'string', 'description' => 'Schedule time in Asia/Kolkata (IST). Accepted formats include YYYY-MM-DD HH:MM:SS and YYYY-MM-DDTHH:MM.' ),
					'location' => array( 'type' => 'object', 'additionalProperties' => true ),
					'products' => array( 'type' => 'array', 'items' => array( 'type' => 'object', 'additionalProperties' => true ) ),
					'platform_fields' => array( 'type' => 'object', 'additionalProperties' => true ),
				),
				'required' => array( 'title', 'platforms' ),
				'additionalProperties' => false,
			),
			array( 'readonly' => false, 'destructive' => false, 'idempotent' => false )
		);
		$this->register_ability(
			'jk-social/get-content-package',
			__( 'Get omnichannel content package', 'jk-social-hub' ),
			__( 'Returns a master content record with its platform-specific variants and platform field packs.', 'jk-social-hub' ),
			array( $this, 'get_content_package' ),
			'jksh_view',
			array( 'type' => 'object', 'properties' => array( 'content_id' => array( 'type' => 'integer', 'minimum' => 1 ) ), 'required' => array( 'content_id' ), 'additionalProperties' => false )
		);
		$this->register_ability(
			'jk-social/process-dry-run-jobs',
			__( 'Process Dry Run jobs now', 'jk-social-hub' ),
			__( 'Processes only explicitly captured Dry Run jobs while the global Dry Run safety switch is ON. Live or ambiguous jobs are refused.', 'jk-social-hub' ),
			array( $this, 'process_dry_run_jobs' ),
			'jksh_publish',
			array( 'type' => 'object', 'properties' => array( 'job_ids' => array( 'type' => 'array', 'minItems' => 1, 'items' => array( 'type' => 'integer', 'minimum' => 1 ) ) ), 'required' => array( 'job_ids' ), 'additionalProperties' => false ),
			array( 'readonly' => false, 'destructive' => false, 'idempotent' => true )
		);

		$this->register_ability(
			'jk-social/get-youtube-live-readiness',
			__( 'Get YouTube Live readiness', 'jk-social-hub' ),
			__( 'Returns local YouTube Live provisioning safety state without creating or changing YouTube resources.', 'jk-social-hub' ),
			array( $this, 'get_youtube_live_readiness' ),
			'jksh_publish'
		);

		$this->register_ability(
			'jk-social/probe-youtube-live-api',
			__( 'Probe YouTube Live API', 'jk-social-hub' ),
			__( 'Performs read-only liveBroadcasts.list and liveStreams.list calls for the connected YouTube channel. It does not create, bind, transition or delete any live resource.', 'jk-social-hub' ),
			array( $this, 'probe_youtube_live_api' ),
			'jksh_publish'
		);

		$this->register_ability(
			'jk-social/preflight-youtube-live-draft',
			__( 'Preflight YouTube Live draft', 'jk-social-hub' ),
			__( 'Validates one local live-stream draft for YouTube provisioning without contacting YouTube.', 'jk-social-hub' ),
			array( $this, 'preflight_youtube_live_draft' ),
			'jksh_publish',
			array(
				'type' => 'object',
				'properties' => array(
					'live_stream_id' => array( 'type' => 'integer', 'minimum' => 1 ),
				),
				'required' => array( 'live_stream_id' ),
				'additionalProperties' => false,
			)
		);

		$this->register_ability(
			'jk-social/provision-youtube-live',
			__( 'Provision YouTube Live broadcast and stream', 'jk-social-hub' ),
			__( 'Creates a YouTube liveBroadcast and RTMP liveStream and binds them for a preflighted local draft. Requires confirm=true, global Dry Run OFF and the dedicated YouTube Live provisioning switch ON. Stream keys are encrypted and never returned.', 'jk-social-hub' ),
			array( $this, 'provision_youtube_live' ),
			'jksh_publish',
			array(
				'type' => 'object',
				'properties' => array(
					'live_stream_id' => array( 'type' => 'integer', 'minimum' => 1 ),
					'confirm' => array( 'type' => 'boolean', 'enum' => array( true ) ),
				),
				'required' => array( 'live_stream_id', 'confirm' ),
				'additionalProperties' => false,
			),
			array( 'readonly' => false, 'destructive' => true, 'idempotent' => false )
		);

		$this->register_ability(
			'jk-social/get-live-worker-readiness',
			__( 'Get live relay-worker readiness', 'jk-social-hub' ),
			__( 'Returns the external relay-worker configuration, signed-transport readiness and optional health state without exposing stream keys or destination URLs.', 'jk-social-hub' ),
			array( $this, 'get_live_worker_readiness' ),
			'jksh_view'
		);
		$this->register_ability(
			'jk-social/get-live-worker-pairing',
			__( 'Get live relay-worker pairing data', 'jk-social-hub' ),
			__( 'Returns the JK Social Hub public verification key and relay-worker API contract. The private signing key never leaves WordPress.', 'jk-social-hub' ),
			array( $this, 'get_live_worker_pairing' ),
			'jksh_manage_settings'
		);
		$this->register_ability(
			'jk-social/probe-live-worker',
			__( 'Probe live relay worker', 'jk-social-hub' ),
			__( 'Performs a read-only HTTPS health check against the configured relay worker. It does not start or stop a stream.', 'jk-social-hub' ),
			array( $this, 'probe_live_worker' ),
			'jksh_publish'
		);
		$this->register_ability(
			'jk-social/preflight-live-worker-draft',
			__( 'Preflight live relay-worker draft', 'jk-social-hub' ),
			__( 'Validates one live draft for external relay-worker dispatch without exposing or transmitting source/destination stream secrets.', 'jk-social-hub' ),
			array( $this, 'preflight_live_worker_draft' ),
			'jksh_publish',
			array(
				'type' => 'object',
				'properties' => array( 'live_stream_id' => array( 'type' => 'integer', 'minimum' => 1 ) ),
				'required' => array( 'live_stream_id' ),
				'additionalProperties' => false,
			)
		);
		$this->register_ability(
			'jk-social/dispatch-live-worker',
			__( 'Start live relay-worker job', 'jk-social-hub' ),
			__( 'Sends a signed relay job to the configured external worker. Requires confirm=true, global Dry Run OFF and the live-worker master switch ON. Stream keys are never returned.', 'jk-social-hub' ),
			array( $this, 'dispatch_live_worker' ),
			'jksh_publish',
			array(
				'type' => 'object',
				'properties' => array(
					'live_stream_id' => array( 'type' => 'integer', 'minimum' => 1 ),
					'confirm' => array( 'type' => 'boolean', 'enum' => array( true ) ),
				),
				'required' => array( 'live_stream_id', 'confirm' ),
				'additionalProperties' => false,
			),
			array( 'readonly' => false, 'destructive' => true, 'idempotent' => false )
		);
		$this->register_ability(
			'jk-social/stop-live-worker',
			__( 'Stop live relay-worker job', 'jk-social-hub' ),
			__( 'Stops the external relay-worker job recorded for a local live stream. Requires confirm=true.', 'jk-social-hub' ),
			array( $this, 'stop_live_worker' ),
			'jksh_publish',
			array(
				'type' => 'object',
				'properties' => array(
					'live_stream_id' => array( 'type' => 'integer', 'minimum' => 1 ),
					'confirm' => array( 'type' => 'boolean', 'enum' => array( true ) ),
				),
				'required' => array( 'live_stream_id', 'confirm' ),
				'additionalProperties' => false,
			),
			array( 'readonly' => false, 'destructive' => true, 'idempotent' => true )
		);

		$this->register_ability(
			'jk-social/get-live-streaming-readiness',
			__( 'Get live streaming readiness', 'jk-social-hub' ),
			__( 'Returns the Facebook, Instagram, YouTube and worker prerequisites for multi-destination live streaming. It does not reveal stream keys or tokens.', 'jk-social-hub' ),
			array( $this, 'get_live_streaming_readiness' ),
			'jksh_view'
		);
		$this->register_ability(
			'jk-social/create-live-stream-draft',
			__( 'Create live stream draft', 'jk-social-hub' ),
			__( 'Creates a control-plane live stream draft with destination metadata. It does not contact Facebook, Instagram, YouTube or a streaming worker.', 'jk-social-hub' ),
			array( $this, 'create_live_stream_draft' ),
			'jksh_create',
			array(
				'type' => 'object',
				'properties' => array(
					'title' => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 255 ),
					'description' => array( 'type' => 'string' ),
					'source_type' => array( 'type' => 'string', 'enum' => array( 'rtmp_input', 'camera', 'prerecorded', 'playlist' ) ),
					'source_reference' => array( 'type' => 'string' ),
					'destinations' => array( 'type' => 'array', 'items' => array( 'type' => 'string', 'enum' => array( 'facebook', 'instagram', 'youtube' ) ) ),
					'scheduled_start_at_utc' => array( 'type' => 'string' ),
					'orientation' => array( 'type' => 'string', 'enum' => array( 'adaptive', 'portrait', 'landscape' ) ),
					'location' => array( 'type' => 'object', 'additionalProperties' => true ),
					'products' => array( 'type' => 'array', 'items' => array( 'type' => 'object', 'additionalProperties' => true ) ),
					'platform_fields' => array( 'type' => 'object', 'additionalProperties' => true ),
				),
				'required' => array( 'title', 'destinations' ),
				'additionalProperties' => false,
			),
			array( 'readonly' => false, 'destructive' => false, 'idempotent' => false )
		);
		$this->register_ability(
			'jk-social/list-live-stream-drafts',
			__( 'List live stream drafts', 'jk-social-hub' ),
			__( 'Returns recent live-stream control-plane records without stream keys or authentication secrets.', 'jk-social-hub' ),
			array( $this, 'list_live_stream_drafts' ),
			'jksh_view'
		);

		$this->register_ability(
			'jk-social/get-plugin-update-readiness',
			__( 'Get JK Social Hub plugin update readiness', 'jk-social-hub' ),
			__( 'Returns read-only self-update readiness for JK Social Hub, including current version, filesystem mode, permissions, and package limits. It cannot install arbitrary plugins.', 'jk-social-hub' ),
			array( $this, 'get_plugin_update_readiness' ),
			'update_plugins'
		);

		$this->register_ability(
			'jk-social/preflight-plugin-package',
			__( 'Preflight JK Social Hub update package', 'jk-social-hub' ),
			__( 'Validates a JK Social Hub ZIP already stored as a WordPress media attachment. Verifies SHA-256, ZIP integrity, safe paths, plugin identity, version and platform requirements without changing installed plugin files.', 'jk-social-hub' ),
			array( $this, 'preflight_plugin_package' ),
			'update_plugins',
			array(
				'type'                 => 'object',
				'properties'           => array(
					'attachment_id' => array( 'type' => 'integer', 'minimum' => 1, 'description' => 'Media attachment ID of the JK Social Hub ZIP package.' ),
					'expected_sha256' => array( 'type' => 'string', 'minLength' => 64, 'maxLength' => 64, 'description' => 'Expected SHA-256 checksum of the exact ZIP bytes.' ),
				),
				'required'             => array( 'attachment_id', 'expected_sha256' ),
				'additionalProperties' => false,
			),
			array( 'readonly' => true, 'destructive' => false, 'idempotent' => true )
		);

		$this->register_ability(
			'jk-social/install-update-plugin-package',
			__( 'Install or update JK Social Hub package', 'jk-social-hub' ),
			__( 'Replaces only the JK Social Hub plugin from a verified media-library ZIP. Requires exact SHA-256, expected installed version and confirm=true. Creates a temporary rollback copy, verifies the installed version after replacement, and restores the previous copy if installation or verification fails. Arbitrary plugin slugs are refused.', 'jk-social-hub' ),
			array( $this, 'install_update_plugin_package' ),
			'update_plugins',
			array(
				'type'                 => 'object',
				'properties'           => array(
					'attachment_id' => array( 'type' => 'integer', 'minimum' => 1, 'description' => 'Media attachment ID of the verified JK Social Hub ZIP package.' ),
					'expected_sha256' => array( 'type' => 'string', 'minLength' => 64, 'maxLength' => 64, 'description' => 'Expected SHA-256 checksum of the exact ZIP bytes.' ),
					'expected_current_version' => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 40, 'description' => 'Installed JK Social Hub version observed immediately before this update.' ),
					'confirm' => array( 'type' => 'boolean', 'enum' => array( true ), 'description' => 'Must be true because this operation replaces active plugin files.' ),
					'allow_reinstall' => array( 'type' => 'boolean', 'description' => 'Allow replacing the plugin with the same version. Defaults false.' ),
					'allow_downgrade' => array( 'type' => 'boolean', 'description' => 'Allow installing an older version. Defaults false.' ),
					'delete_package_after' => array( 'type' => 'boolean', 'description' => 'Delete the media ZIP after successful verification. Defaults true.' ),
				),
				'required'             => array( 'attachment_id', 'expected_sha256', 'expected_current_version', 'confirm' ),
				'additionalProperties' => false,
			),
			array( 'readonly' => false, 'destructive' => true, 'idempotent' => false )
		);
	}

	private function register_ability( string $name, string $label, string $description, callable $callback, string $capability, ?array $input_schema = null, ?array $annotations = null ): void {
		$args = array(
			'label'               => $label,
			'description'         => $description,
			'category'            => self::CATEGORY,
			'execute_callback'    => $callback,
			'permission_callback' => static function () use ( $capability ): bool {
				return current_user_can( $capability );
			},
			'meta'                => array(
				'public'       => true,
				'show_in_rest' => true,
				'annotations' => $annotations ?? array(
					'readonly'    => true,
					'destructive' => false,
					'idempotent'  => true,
				),
			),
		);
		if ( null !== $input_schema ) {
			$args['input_schema'] = $input_schema;
		}
		wp_register_ability( $name, $args );
	}

	public function get_connected_accounts( mixed $input = null ): array {
		$accounts = ( new AccountRepository() )->connected();
		$items    = array();
		foreach ( $accounts as $account ) {
			if ( ! in_array( (string) $account->platform, array( 'facebook', 'instagram', 'youtube' ), true ) ) {
				continue;
			}
			$items[] = $this->safe_account( $account );
		}

		return array(
			'site'     => home_url( '/' ),
			'count'    => count( $items ),
			'accounts' => $items,
		);
	}

	public function get_meta_health( mixed $input = null ): array {
		$repo     = new AccountRepository();
		$accounts = array_values(
			array_filter(
				$repo->active(),
				static fn( $account ): bool => in_array( (string) $account->platform, array( 'facebook', 'instagram' ), true )
			)
		);
		$logs = $this->meta_logs( 100 );

		$tests_by_account = array();
		$last_connect     = null;
		foreach ( $logs as $log ) {
			$context = $this->decode_context( (string) ( $log->context_json ?? '' ) );
			if ( 'account_test' === (string) $log->action ) {
				$account_id = (int) ( $context['account_id'] ?? 0 );
				if ( $account_id > 0 && ! isset( $tests_by_account[ $account_id ] ) ) {
					$tests_by_account[ $account_id ] = $this->safe_log( $log );
				}
			}
			if ( null === $last_connect && 'meta_connect' === (string) $log->action ) {
				$last_connect = $this->safe_log( $log );
			}
		}

		$now     = time();
		$healthy = 0;
		$items   = array();
		foreach ( $accounts as $account ) {
			$item = $this->safe_account( $account );
			$token_expired = false;
			if ( ! empty( $account->token_expires_at ) ) {
				$expiry = strtotime( (string) $account->token_expires_at . ' UTC' );
				$token_expired = false !== $expiry && $expiry <= $now;
			}
			$item['token_expired'] = $token_expired;
			$item['latest_test']    = $tests_by_account[ (int) $account->id ] ?? null;
			$item['healthy']        = 'connected' === (string) $account->status && ! $token_expired && ( null === $item['latest_test'] || 'success' === (string) ( $item['latest_test']['result'] ?? '' ) );
			if ( $item['healthy'] ) {
				$healthy++;
			}
			$items[] = $item;
		}

		$overall = 'not_connected';
		if ( $items ) {
			$overall = $healthy === count( $items ) ? 'healthy' : 'attention';
		}

		$connector = new MetaConnector();
		return array(
			'overall_status'  => $overall,
			'configured'      => $connector->is_configured(),
			'primary_page_id' => $connector->preferred_page_id(),
			'account_count'   => count( $items ),
			'healthy_count'   => $healthy,
			'accounts'        => $items,
			'last_connect'    => $last_connect,
			'note'            => 'Read-only stored health. This ability does not call Meta or refresh tokens.',
		);
	}

	public function get_youtube_health( mixed $input = null ): array {
		$connector = new YouTubeConnector();
		$accounts = ( new AccountRepository() )->connected( 'youtube' );
		$logs = ( new LogRepository() )->recent_by_actions( array( 'youtube_connect', 'youtube_account_test', 'youtube_disconnect' ), 25 );
		$items = array_map( array( $this, 'safe_account' ), $accounts );
		$latest_test = null;
		$last_connect = null;
		foreach ( $logs as $log ) {
			if ( null === $latest_test && 'youtube_account_test' === (string) $log->action ) {
				$latest_test = $this->safe_log( $log );
			}
			if ( null === $last_connect && 'youtube_connect' === (string) $log->action ) {
				$last_connect = $this->safe_log( $log );
			}
		}
		return array(
			'configured' => $connector->is_configured(),
			'redirect_uri' => $connector->redirect_uri(),
			'scopes' => $connector->scopes(),
			'connected' => ! empty( $items ),
			'accounts' => $items,
			'latest_test' => $latest_test,
			'last_connect' => $last_connect,
			'note' => 'Read-only stored YouTube connection health. Tokens and OAuth client secrets are never returned.',
		);
	}

	public function get_latest_meta_log( mixed $input = null ): array {
		$logs = $this->meta_logs( 25 );
		return array(
			'count' => count( $logs ),
			'logs'  => array_map( array( $this, 'safe_log' ), $logs ),
		);
	}

	public function get_publishing_readiness( mixed $input = null ): array {
		$meta = ( new MetaPublisher() )->readiness();
		$meta['youtube'] = ( new YouTubePublisher() )->readiness();
		return $meta;
	}

	public function get_publish_logs( mixed $input = null ): array {
		$logs = ( new LogRepository() )->recent_by_actions(
			array( 'publish', 'publish_pending', 'publish_retry', 'publish_blocked', 'dry_run_publish' ),
			50
		);
		return array(
			'count' => count( $logs ),
			'logs'  => array_map( array( $this, 'safe_log' ), $logs ),
		);
	}


	public function get_platform_field_schema( mixed $input = null ): array {
		return array( 'version' => PlatformSchema::VERSION, 'platforms' => ( new PlatformSchema() )->catalog() );
	}

	public function create_dry_run_content( mixed $input ): array|\WP_Error {
		$input = is_array( $input ) ? $input : array();
		$ist_value = trim( (string) ( $input['scheduled_at_ist'] ?? '' ) );
		if ( '' !== $ist_value ) {
			$ist = new \DateTimeZone( 'Asia/Kolkata' );
			$when = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $ist_value, $ist );
			if ( ! $when ) {
				$when = \DateTimeImmutable::createFromFormat( 'Y-m-d\TH:i', $ist_value, $ist );
			}
			if ( ! $when ) {
				try {
					$when = new \DateTimeImmutable( $ist_value, $ist );
				} catch ( \Throwable $e ) {
					$when = false;
				}
			}
			if ( ! $when ) {
				return new \WP_Error( 'jksh_invalid_schedule_ist', 'scheduled_at_ist must be a valid Asia/Kolkata (IST) date/time.' );
			}
			$input['scheduled_at_utc'] = $when->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
		}
		unset( $input['scheduled_at_ist'] );
		$result = ( new ContentOrchestrator() )->create_dry_run( $input );
		if ( is_array( $result ) && ! empty( $result['scheduled_at_utc'] ) ) {
			try {
				$utc = new \DateTimeImmutable( (string) $result['scheduled_at_utc'], new \DateTimeZone( 'UTC' ) );
				$result['scheduled_at_ist'] = $utc->setTimezone( new \DateTimeZone( 'Asia/Kolkata' ) )->format( 'Y-m-d H:i:s' );
			} catch ( \Throwable $e ) {
				$result['scheduled_at_ist'] = (string) $result['scheduled_at_utc'];
			}
			unset( $result['scheduled_at_utc'] );
		}
		return $result;
	}

	public function get_content_package( mixed $input ): array|\WP_Error {
		$input = is_array( $input ) ? $input : array();
		return ( new ContentOrchestrator() )->package( absint( $input['content_id'] ?? 0 ) );
	}

	public function process_dry_run_jobs( mixed $input ): array|\WP_Error {
		$input = is_array( $input ) ? $input : array();
		return ( new ContentOrchestrator() )->process_dry_run_jobs( (array) ( $input['job_ids'] ?? array() ) );
	}


	public function get_youtube_live_readiness( mixed $input = null ): array {
		return ( new YouTubeLive() )->readiness();
	}

	public function probe_youtube_live_api( mixed $input = null ): array {
		return ( new YouTubeLive() )->probe();
	}

	public function preflight_youtube_live_draft( mixed $input ): array|\WP_Error {
		$input = is_array( $input ) ? $input : array();
		return ( new YouTubeLive() )->preflight( absint( $input['live_stream_id'] ?? 0 ) );
	}

	public function provision_youtube_live( mixed $input ): array|\WP_Error {
		return ( new YouTubeLive() )->provision( is_array( $input ) ? $input : array() );
	}

	public function get_live_worker_readiness( mixed $input = null ): array {
		return ( new LiveWorker() )->readiness( false );
	}

	public function get_live_worker_pairing( mixed $input = null ): array|\WP_Error {
		return ( new LiveWorker() )->pairing();
	}

	public function probe_live_worker( mixed $input = null ): array {
		return ( new LiveWorker() )->readiness( true );
	}

	public function preflight_live_worker_draft( mixed $input ): array|\WP_Error {
		$input = is_array( $input ) ? $input : array();
		return ( new LiveWorker() )->preflight( absint( $input['live_stream_id'] ?? 0 ) );
	}

	public function dispatch_live_worker( mixed $input ): array|\WP_Error {
		return ( new LiveWorker() )->dispatch( is_array( $input ) ? $input : array() );
	}

	public function stop_live_worker( mixed $input ): array|\WP_Error {
		return ( new LiveWorker() )->stop( is_array( $input ) ? $input : array() );
	}

	public function get_live_streaming_readiness( mixed $input = null ): array {
		return ( new LiveStreaming() )->readiness();
	}

	public function create_live_stream_draft( mixed $input ): array|\WP_Error {
		return ( new LiveStreaming() )->create_draft( is_array( $input ) ? $input : array() );
	}

	public function list_live_stream_drafts( mixed $input = null ): array {
		return ( new LiveStreaming() )->recent( 25 );
	}


	public function get_plugin_update_readiness( mixed $input = null ): array {
		return ( new PluginPackageUpdater() )->readiness();
	}

	public function preflight_plugin_package( mixed $input ): array|\WP_Error {
		return ( new PluginPackageUpdater() )->preflight( $input );
	}

	public function install_update_plugin_package( mixed $input ): array|\WP_Error {
		return ( new PluginPackageUpdater() )->install_update( $input );
	}

	public function get_instagram_diagnostics( mixed $input = null ): array {
		$repo = new AccountRepository();
		$instagram_accounts = array_map(
			array( $this, 'safe_account' ),
			$repo->connected( 'instagram' )
		);

		$diagnostics = array();
		foreach ( $this->meta_logs( 100 ) as $log ) {
			if ( ! in_array( (string) $log->action, array( 'instagram_discovery', 'meta_connect', 'account_test' ), true ) ) {
				continue;
			}
			$context = $this->decode_context( (string) ( $log->context_json ?? '' ) );
			$is_instagram_test = 'account_test' === (string) $log->action && 'instagram' === (string) ( $context['platform'] ?? '' );
			if ( 'account_test' === (string) $log->action && ! $is_instagram_test ) {
				continue;
			}
			$diagnostics[] = $this->safe_log( $log );
			if ( count( $diagnostics ) >= 20 ) {
				break;
			}
		}

		return array(
			'connected_instagram_accounts' => $instagram_accounts,
			'diagnostics'                  => $diagnostics,
		);
	}

	private function meta_logs( int $limit ): array {
		return ( new LogRepository() )->recent_by_actions(
			array( 'meta_connect', 'meta_page_discovery', 'instagram_discovery', 'account_test', 'account_disconnect' ),
			$limit
		);
	}

	private function safe_account( object $account ): array {
		$settings = ( new AccountRepository() )->settings( $account );
		return array(
			'id'                  => (int) $account->id,
			'platform'            => sanitize_key( (string) $account->platform ),
			'name'                => sanitize_text_field( (string) $account->account_name ),
			'external_account_id' => sanitize_text_field( (string) $account->external_account_id ),
			'parent_account_id'   => (int) $account->parent_account_id,
			'status'              => sanitize_key( (string) $account->status ),
			'token_expires_at'    => $account->token_expires_at ? sanitize_text_field( (string) $account->token_expires_at ) : null,
			'last_checked_at'     => $account->last_checked_at ? sanitize_text_field( (string) $account->last_checked_at ) : null,
			'last_error'          => sanitize_textarea_field( (string) $account->last_error ),
			'updated_at'          => sanitize_text_field( (string) $account->updated_at ),
			'public_settings'     => $this->sanitize_context( $settings ),
		);
	}

	private function safe_log( object $log ): array {
		return array(
			'id'         => (int) $log->id,
			'action'     => sanitize_key( (string) $log->action ),
			'result'     => sanitize_key( (string) $log->result ),
			'message'    => sanitize_textarea_field( (string) $log->message ),
			'context'    => $this->sanitize_context( $this->decode_context( (string) ( $log->context_json ?? '' ) ) ),
			'created_at' => sanitize_text_field( (string) $log->created_at ),
		);
	}

	private function decode_context( string $json ): array {
		$data = json_decode( $json, true );
		return is_array( $data ) ? $data : array();
	}

	private function sanitize_context( array $context ): array {
		$safe = array();
		foreach ( $context as $key => $value ) {
			$key_string = sanitize_key( (string) $key );
			if ( preg_match( '/token|secret|password|credential|authorization|cookie|nonce|state/i', $key_string ) ) {
				continue;
			}
			if ( is_array( $value ) ) {
				$safe[ $key_string ] = $this->sanitize_context( $value );
			} elseif ( is_bool( $value ) || is_int( $value ) || is_float( $value ) || null === $value ) {
				$safe[ $key_string ] = $value;
			} else {
				$safe[ $key_string ] = sanitize_textarea_field( (string) $value );
			}
		}
		return $safe;
	}
}
