<?php
namespace JKSH\Repositories;

final class ContentRepository {
	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'jksh_content';
	}

	public function create( array $data ): int {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->insert(
			$this->table,
			array(
				'uuid'       => wp_generate_uuid4(),
				'title'      => sanitize_text_field( $data['title'] ?? '' ),
				'content_type'=> sanitize_key( $data['content_type'] ?? 'knowledge' ),
				'body'       => wp_kses_post( $data['body'] ?? '' ),
				'status'     => sanitize_key( $data['status'] ?? 'draft' ),
				'media_json' => wp_json_encode( $data['media'] ?? array() ),
				'meta_json'  => wp_json_encode( $data['meta'] ?? array() ),
				'author_id'  => get_current_user_id(),
				'created_at' => $now,
				'updated_at' => $now,
			),
			array( '%s','%s','%s','%s','%s','%s','%s','%d','%s','%s' )
		);
		return (int) $wpdb->insert_id;
	}

	public function get( int $id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function recent( int $limit = 50 ): array {
		global $wpdb;
		$limit = max( 1, min( 200, $limit ) );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table} ORDER BY id DESC LIMIT %d", $limit ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function count_by_status(): array {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT status, COUNT(*) total FROM {$this->table} GROUP BY status" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$out = array();
		foreach ( $rows as $row ) {
			$out[ $row->status ] = (int) $row->total;
		}
		return $out;
	}
}
