<?php
namespace JKSH\Services;

final class VariantBuilder {
	public function build( string $platform, array $master ): array {
		$type = sanitize_key( $master['content_type'] ?? 'knowledge_reel' );
		$platform = sanitize_key( $platform );
		$title = sanitize_text_field( $master['title'] ?? '' );
		$body  = sanitize_textarea_field( $master['body'] ?? '' );
		$media = $master['media'] ?? array();

		$publication_type = $this->publication_type( $platform, $type, ! empty( $media ) );
		$caption = $body;
		$description = $body;
		$hashtags = $this->default_hashtags( $type );
		$cta = 'Jai Jagannātha 🙏';

		if ( 'youtube' === $platform && 'community_post' === $publication_type ) {
			$description = '';
		}

		return array(
			'platform'         => $platform,
			'publication_type' => $publication_type,
			'title'            => $title,
			'caption'          => $caption,
			'description'      => $description,
			'hashtags'         => $hashtags,
			'cta'              => $cta,
			'media'            => $media,
		);
	}

	private function publication_type( string $platform, string $content_type, bool $has_media ): string {
		$image_types = array( 'knowledge_carousel', 'product_carousel', 'carousel', 'festival', 'ritual', 'besha', 'product' );
		$meta_reel_types = array( 'mangal_arati', 'sell_reel', 'knowledge_reel', 'reel', 'short', 'video', 'long_knowledge_video', 'long_video' );
		$youtube_short_types = array( 'mangal_arati', 'sell_reel', 'knowledge_reel', 'reel', 'short' );
		$youtube_video_types = array( 'long_knowledge_video', 'long_video', 'video' );

		if ( 'youtube' === $platform ) {
			if ( in_array( $content_type, $image_types, true ) ) {
				return 'community_post';
			}
			if ( in_array( $content_type, $youtube_video_types, true ) ) {
				return 'video';
			}
			if ( in_array( $content_type, $youtube_short_types, true ) ) {
				return 'short';
			}
			return 'community_post';
		}

		if ( 'instagram' === $platform ) {
			if ( in_array( $content_type, $meta_reel_types, true ) ) {
				return 'reel';
			}
			if ( in_array( $content_type, $image_types, true ) ) {
				return 'carousel';
			}
			return 'post';
		}

		if ( 'facebook' === $platform ) {
			if ( in_array( $content_type, $meta_reel_types, true ) ) {
				return 'reel';
			}
			return 'post';
		}

		if ( 'pinterest' === $platform ) {
			return 'pin';
		}

		if ( 'google_business' === $platform ) {
			return 'publication';
		}

		return 'post';
	}

	private function default_hashtags( string $content_type ): string {
		$base = '#JaiJagannath #Jagannath #Mahaprabhu #JustKalinga';
		if ( str_contains( $content_type, 'besha' ) || str_contains( $content_type, 'product' ) || str_contains( $content_type, 'sell' ) ) {
			return $base . ' #JagannathBesha';
		}
		if ( str_contains( $content_type, 'festival' ) || str_contains( $content_type, 'ritual' ) ) {
			return $base . ' #PuriDham';
		}
		return $base . ' #PuriJagannath';
	}
}
