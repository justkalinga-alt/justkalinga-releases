<?php
namespace JKSH\Services;

use JKSH\Repositories\AccountRepository;
use JKSH\Repositories\LogRepository;
use JKSH\Security\Crypto;

final class MetaConnector {
	public const OPTION = 'jksh_meta_config';

	private Crypto $crypto;
	private AccountRepository $accounts;
	private LogRepository $logs;

	public function __construct() {
		$this->crypto   = new Crypto();
		$this->accounts = new AccountRepository();
		$this->logs     = new LogRepository();
	}

	public function defaults(): array {
		return array(
			'app_id'               => '',
			'app_secret_encrypted' => '',
			'graph_version'        => 'v25.0',
			'login_config_id'      => '',
			'preferred_page_id'    => '',
		);
	}

	public function config(): array {
		return wp_parse_args( (array) get_option( self::OPTION, array() ), $this->defaults() );
	}

	public function has_secret(): bool {
		$config = $this->config();
		return '' !== (string) ( $config['app_secret_encrypted'] ?? '' );
	}

	public function is_configured(): bool {
		$config = $this->config();
		return '' !== (string) $config['app_id'] && $this->has_secret();
	}

	public function preferred_page_id(): string {
		$config = $this->config();
		$saved  = preg_replace( '/\D+/', '', (string) ( $config['preferred_page_id'] ?? '' ) );
		if ( '' !== $saved ) {
			return $saved;
		}

		$connected = $this->accounts->connected( 'facebook' );
		if ( 1 === count( $connected ) ) {
			return preg_replace( '/\D+/', '', (string) $connected[0]->external_account_id );
		}
		return '';
	}

	public function save_config( string $app_id, string $app_secret, string $graph_version, string $login_config_id = '', string $preferred_page_id = '' ): void {
		$current = $this->config();
		$version = preg_replace( '/[^v0-9.]/', '', $graph_version );
		$next = array(
			'app_id'               => sanitize_text_field( $app_id ),
			'app_secret_encrypted' => (string) $current['app_secret_encrypted'],
			'graph_version'        => $version ?: 'v25.0',
			'login_config_id'      => sanitize_text_field( $login_config_id ),
			'preferred_page_id'    => preg_replace( '/\D+/', '', $preferred_page_id ),
		);
		if ( '' !== trim( $app_secret ) ) {
			$next['app_secret_encrypted'] = $this->crypto->encrypt( trim( $app_secret ) );
		}
		update_option( self::OPTION, $next, false );
	}

	private function persist_preferred_page_id( string $page_id ): void {
		$page_id = preg_replace( '/\D+/', '', $page_id );
		if ( '' === $page_id ) {
			return;
		}
		$config = $this->config();
		if ( $page_id === (string) ( $config['preferred_page_id'] ?? '' ) ) {
			return;
		}
		$config['preferred_page_id'] = $page_id;
		update_option( self::OPTION, $config, false );
	}

	public function redirect_uri(): string {
		return admin_url( 'admin-post.php?action=jksh_meta_oauth_callback' );
	}

	public function scopes(): array {
		return array(
			'pages_show_list',
			'pages_read_engagement',
			'pages_manage_posts',
			'instagram_basic',
			'instagram_content_publish',
			'publish_video',
		);
	}

	public function auth_url(): string {
		if ( ! $this->is_configured() ) {
			return '';
		}
		$config = $this->config();
		$state  = wp_generate_password( 48, false, false );
		set_transient( 'jksh_meta_state_' . get_current_user_id(), hash( 'sha256', $state ), 15 * MINUTE_IN_SECONDS );
		$args = array(
			'client_id'     => $config['app_id'],
			'redirect_uri'  => $this->redirect_uri(),
			'state'         => $state,
			'response_type' => 'code',
			'auth_type'     => 'rerequest',
		);

		// Facebook Login for Business uses the saved configuration as the permission
		// request. Meta rejects some login flows when config_id and a raw scope list
		// are sent together, so never send scope in configuration-ID mode.
		if ( ! empty( $config['login_config_id'] ) ) {
			$args['config_id'] = $config['login_config_id'];
			$args['override_default_response_type'] = 'true';
		} else {
			$args['scope'] = implode( ',', $this->scopes() );
		}
		return add_query_arg( $args, 'https://www.facebook.com/' . rawurlencode( $config['graph_version'] ) . '/dialog/oauth' );
	}

	private function granted_permissions( MetaClient $client, string $user_token ): array {
		$result = $client->get( 'me/permissions', $user_token );
		if ( ! $result['ok'] ) {
			return array();
		}
		$granted = array();
		foreach ( (array) ( $result['data']['data'] ?? array() ) as $row ) {
			if ( 'granted' !== (string) ( $row['status'] ?? '' ) ) {
				continue;
			}
			$permission = sanitize_key( $row['permission'] ?? '' );
			if ( '' !== $permission ) {
				$granted[] = $permission;
			}
		}
		return array_values( array_unique( $granted ) );
	}

	private function page_from_user_token( MetaClient $client, string $page_id, string $user_token ): array {
		return $client->get(
			$page_id,
			$user_token,
			array( 'fields' => 'id,name,username,link,access_token,instagram_business_account' )
		);
	}

	public function handle_callback( string $code, string $state ): array {
		$config = $this->config();
		if ( ! $this->is_configured() ) {
			return array( 'ok' => false, 'message' => 'Meta App credentials are not configured.' );
		}
		$expected = (string) get_transient( 'jksh_meta_state_' . get_current_user_id() );
		delete_transient( 'jksh_meta_state_' . get_current_user_id() );
		if ( '' === $expected || ! hash_equals( $expected, hash( 'sha256', $state ) ) ) {
			return array( 'ok' => false, 'message' => 'Meta OAuth state validation failed. Please start the connection again.' );
		}
		$secret = $this->crypto->decrypt( (string) $config['app_secret_encrypted'] );
		if ( '' === $secret ) {
			return array( 'ok' => false, 'message' => 'Saved Meta App secret could not be decrypted.' );
		}

		$client = new MetaClient( (string) $config['graph_version'] );
		$short  = $client->exchange_code( (string) $config['app_id'], $secret, $this->redirect_uri(), $code );
		if ( ! $short['ok'] || empty( $short['data']['access_token'] ) ) {
			return array( 'ok' => false, 'message' => 'Meta token exchange failed: ' . $short['message'] );
		}
		$token_response = $client->exchange_long_lived( (string) $config['app_id'], $secret, (string) $short['data']['access_token'] );
		if ( $token_response['ok'] && ! empty( $token_response['data']['access_token'] ) ) {
			$user_token = (string) $token_response['data']['access_token'];
			$expires_in = (int) ( $token_response['data']['expires_in'] ?? 0 );
		} else {
			$user_token = (string) $short['data']['access_token'];
			$expires_in = (int) ( $short['data']['expires_in'] ?? 0 );
		}
		$expires_at = $expires_in > 0 ? gmdate( 'Y-m-d H:i:s', time() + $expires_in ) : null;

		$me = $client->get( 'me', $user_token, array( 'fields' => 'id,name' ) );
		if ( ! $me['ok'] ) {
			return array( 'ok' => false, 'message' => 'Meta user lookup failed: ' . $me['message'] );
		}

		$granted = $this->granted_permissions( $client, $user_token );
		$missing = array_values( array_diff( $this->scopes(), $granted ) );

		$pages = $client->get(
			'me/accounts',
			$user_token,
			array(
				'fields' => 'id,name,access_token,tasks,instagram_business_account',
				'limit'  => 100,
			)
		);
		if ( ! $pages['ok'] ) {
			return array( 'ok' => false, 'message' => 'Meta Page discovery failed: ' . $pages['message'] );
		}

		$page_rows = array_values( (array) ( $pages['data']['data'] ?? array() ) );
		$preferred = $this->preferred_page_id();
		if ( '' !== $preferred ) {
			$page_rows = array_values(
				array_filter(
					$page_rows,
					static fn( $page ) => $preferred === sanitize_text_field( $page['id'] ?? '' )
				)
			);

			if ( ! $page_rows ) {
				$direct = $this->page_from_user_token( $client, $preferred, $user_token );
				if ( $direct['ok'] && ! empty( $direct['data']['id'] ) ) {
					$page_rows[] = (array) $direct['data'];
				}
			}
		}

		$count_fb = 0;
		$count_ig = 0;
		$processed_page_ids = array();
		$instagram_errors = array();

		foreach ( $page_rows as $page ) {
			$page_id = sanitize_text_field( $page['id'] ?? '' );
			if ( '' === $page_id ) {
				continue;
			}

			$page_info = $this->page_from_user_token( $client, $page_id, $user_token );
			$page_data = $page_info['ok'] ? (array) $page_info['data'] : (array) $page;
			$page_name = sanitize_text_field( $page_data['name'] ?? $page['name'] ?? '' );
			$page_token = (string) ( $page_data['access_token'] ?? $page['access_token'] ?? '' );
			if ( '' === $page_token ) {
				$this->logs->add(
					array(
						'action'  => 'meta_page_discovery',
						'result'  => 'failed',
						'message' => 'Meta returned the selected Facebook Page without a Page access token.',
						'context' => array( 'facebook_page_id' => $page_id ),
					)
				);
				continue;
			}

			$fb_id = $this->accounts->upsert(
				array(
					'platform'            => 'facebook',
					'account_name'        => $page_name,
					'external_account_id' => $page_id,
					'status'              => 'connected',
					'credentials'         => array(
						'access_token'      => $page_token,
						'user_access_token' => $user_token,
					),
					'token_expires_at'    => $expires_at,
					'last_checked_at'     => current_time( 'mysql', true ),
					'settings'            => array(
						'graph_version'    => $config['graph_version'],
						'facebook_user_id' => sanitize_text_field( $me['data']['id'] ?? '' ),
						'username'         => sanitize_text_field( $page_data['username'] ?? '' ),
						'link'             => esc_url_raw( $page_data['link'] ?? '' ),
						'tasks'            => array_values( array_map( 'sanitize_text_field', (array) ( $page['tasks'] ?? array() ) ) ),
					),
				)
			);
			$count_fb++;
			$processed_page_ids[] = $page_id;

			$ig_ref = array();
			if ( isset( $page['instagram_business_account'] ) && is_array( $page['instagram_business_account'] ) ) {
				$ig_ref = $page['instagram_business_account'];
			} elseif ( isset( $page_data['instagram_business_account'] ) && is_array( $page_data['instagram_business_account'] ) ) {
				$ig_ref = $page_data['instagram_business_account'];
			}
			$ig_id = sanitize_text_field( $ig_ref['id'] ?? '' );

			if ( '' === $ig_id ) {
				$instagram_errors[] = 'Meta did not return instagram_business_account for Facebook Page ' . $page_id . '.';
				continue;
			}

			$ig = $client->get( $ig_id, $page_token, array( 'fields' => 'id,username,name,profile_picture_url,followers_count,media_count' ) );
			if ( ! $ig['ok'] ) {
				$instagram_errors[] = 'Instagram lookup failed for ' . $ig_id . ': ' . $ig['message'];
				$this->logs->add(
					array(
						'action'  => 'instagram_discovery',
						'result'  => 'failed',
						'message' => 'Instagram account discovery failed: ' . $ig['message'],
						'context' => array(
							'facebook_page_id'   => $page_id,
							'instagram_account_id' => $ig_id,
							'error_code'         => (int) $ig['code'],
						),
					)
				);
				continue;
			}

			$ig_data = (array) $ig['data'];
			$this->accounts->upsert(
				array(
					'platform'            => 'instagram',
					'account_name'        => sanitize_text_field( $ig_data['username'] ?? $ig_data['name'] ?? 'Instagram' ),
					'external_account_id' => $ig_id,
					'parent_account_id'   => $fb_id,
					'status'              => 'connected',
					'credentials'         => array( 'access_token' => $page_token ),
					'token_expires_at'    => $expires_at,
					'last_checked_at'     => current_time( 'mysql', true ),
					'settings'            => array(
						'graph_version'       => $config['graph_version'],
						'facebook_page_id'    => $page_id,
						'username'            => sanitize_text_field( $ig_data['username'] ?? '' ),
						'name'                => sanitize_text_field( $ig_data['name'] ?? '' ),
						'profile_picture_url' => esc_url_raw( $ig_data['profile_picture_url'] ?? '' ),
						'followers_count'     => (int) ( $ig_data['followers_count'] ?? 0 ),
						'media_count'         => (int) ( $ig_data['media_count'] ?? 0 ),
					),
				)
			);
			$count_ig++;
		}

		if ( '' !== $preferred && in_array( $preferred, $processed_page_ids, true ) ) {
			$this->persist_preferred_page_id( $preferred );
		}

		$context = array(
			'facebook_pages'        => $count_fb,
			'instagram_accounts'    => $count_ig,
			'preferred_page_id'     => $preferred,
			'granted_permissions'   => $granted,
			'missing_permissions'   => $missing,
			'instagram_diagnostics' => $instagram_errors,
		);

		$this->logs->add(
			array(
				'action'  => 'meta_connect',
				'result'  => ( $count_fb > 0 || $count_ig > 0 ) ? 'success' : 'failed',
				'message' => sprintf( 'Meta account discovery finished: %d Facebook Page(s), %d Instagram account(s).', $count_fb, $count_ig ),
				'context' => $context,
			)
		);

		if ( 0 === $count_fb && 0 === $count_ig ) {
			if ( '' !== $preferred ) {
				return array( 'ok' => false, 'message' => 'Meta login succeeded, but the configured primary Facebook Page was not returned. Confirm the login user manages Page ID ' . $preferred . ' and reconnect.' );
			}
			return array( 'ok' => false, 'message' => 'Meta login succeeded, but no manageable Facebook Pages or linked Instagram professional accounts were discovered.' );
		}

		$message = sprintf( 'Connected %d Facebook Page(s) and %d Instagram professional account(s).', $count_fb, $count_ig );
		if ( $missing ) {
			$message .= ' Meta did not grant: ' . implode( ', ', $missing ) . '. If a Facebook Login for Business Configuration ID is set, edit that Meta configuration to include these permissions, then reconnect.';
		} elseif ( 0 === $count_ig && $instagram_errors ) {
			$message .= ' Instagram was not discovered. Check Audit Logs for the sanitized discovery diagnostic, then reconnect after correcting Meta permissions if needed.';
		}
		return array( 'ok' => true, 'message' => $message );
	}

	public function test_account( int $account_id ): array {
		$account = $this->accounts->get( $account_id );
		if ( ! $account ) {
			return array( 'ok' => false, 'message' => 'Account not found.' );
		}
		$credentials = $this->accounts->credentials( $account );
		$token = (string) ( $credentials['access_token'] ?? '' );
		if ( '' === $token ) {
			$this->accounts->update_status( $account_id, 'needs_reauthorization', 'No saved access token.' );
			return array( 'ok' => false, 'message' => 'No saved access token. Reconnect Meta.' );
		}
		$settings = $this->accounts->settings( $account );
		$client = new MetaClient( (string) ( $settings['graph_version'] ?? $this->config()['graph_version'] ) );
		$fields = 'facebook' === $account->platform ? 'id,name,username,link' : 'id,username,name,profile_picture_url,followers_count,media_count';
		$result = $client->get( (string) $account->external_account_id, $token, array( 'fields' => $fields ) );
		if ( ! $result['ok'] ) {
			$status = 190 === (int) $result['code'] ? 'expired' : 'error';
			$this->accounts->update_status( $account_id, $status, $result['message'] );
			$this->logs->add( array( 'action' => 'account_test', 'result' => 'failed', 'message' => ucfirst( $account->platform ) . ' connection test failed: ' . $result['message'], 'context' => array( 'account_id' => $account_id, 'platform' => $account->platform, 'error_code' => $result['code'] ) ) );
			return array( 'ok' => false, 'message' => $result['message'] );
		}
		$this->accounts->update_status( $account_id, 'connected', '' );
		$this->logs->add( array( 'action' => 'account_test', 'result' => 'success', 'message' => ucfirst( $account->platform ) . ' connection test succeeded.', 'context' => array( 'account_id' => $account_id, 'platform' => $account->platform ) ) );
		return array( 'ok' => true, 'message' => ucfirst( $account->platform ) . ' connection is healthy.' );
	}

	public function disconnect_account( int $account_id ): array {
		$account = $this->accounts->get( $account_id );
		if ( ! $account ) {
			return array( 'ok' => false, 'message' => 'Account not found.' );
		}
		$this->accounts->disconnect( $account_id );
		$this->logs->add( array( 'action' => 'account_disconnect', 'result' => 'success', 'message' => ucfirst( $account->platform ) . ' token removed from JK Social Hub.', 'context' => array( 'account_id' => $account_id, 'platform' => $account->platform ) ) );
		return array( 'ok' => true, 'message' => ucfirst( $account->platform ) . ' disconnected locally. No social content was changed.' );
	}
}
