<?php
namespace JKSH\Services;

final class LiveWorkerClient {
	private Settings $settings;
	private LiveWorkerSigner $signer;

	public function __construct() {
		$this->settings = new Settings();
		$this->signer   = new LiveWorkerSigner();
	}

	public function endpoint(): string {
		return rtrim( (string) $this->settings->get( 'live_worker_endpoint', '' ), '/' );
	}

	public function endpoint_valid(): bool {
		$endpoint = $this->endpoint();
		if ( '' === $endpoint ) {
			return false;
		}
		$parts = wp_parse_url( $endpoint );
		if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return false;
		}
		if ( 'https' === strtolower( (string) $parts['scheme'] ) ) {
			return true;
		}
		$host = strtolower( (string) $parts['host'] );
		return in_array( $host, array( 'localhost', '127.0.0.1', '::1' ), true );
	}

	public function health(): array {
		if ( ! $this->endpoint_valid() ) {
			return array( 'ok' => false, 'status' => 0, 'message' => 'A valid HTTPS worker endpoint is not configured.' );
		}
		$response = wp_remote_get(
			$this->endpoint() . '/v1/health',
			array( 'timeout' => 5, 'redirection' => 0, 'user-agent' => 'JKSH/' . JKSH_VERSION )
		);
		return $this->normalize( $response );
	}

	public function signed_handshake(): array {
		// Compatibility handshake for workers that predate /v1/ping: send a signed
		// status request for a deliberately nonexistent probe job. A 404
		// job_not_found response can only be reached after the worker validates the
		// RSA signature, timestamp, nonce and contract headers.
		$probe_id = 'jksh-probe-' . wp_generate_password( 24, false, false );
		$response = $this->status( $probe_id );
		$error = sanitize_key( (string) ( $response['data']['error'] ?? '' ) );
		if ( 404 === (int) ( $response['status'] ?? 0 ) && 'job_not_found' === $error ) {
			return array(
				'ok' => true,
				'status' => 404,
				'message' => 'signed_handshake_ok',
				'proof' => 'authenticated_job_not_found',
			);
		}
		return $response;
	}

	public function start( array $payload ): array {
		return $this->signed_request( 'POST', '/v1/jobs/start', $payload, 12 );
	}

	public function stop( string $job_id ): array {
		return $this->signed_request( 'POST', '/v1/jobs/stop', array( 'job_id' => sanitize_text_field( $job_id ) ), 8 );
	}

	public function status( string $job_id ): array {
		return $this->signed_request( 'POST', '/v1/jobs/status', array( 'job_id' => sanitize_text_field( $job_id ) ), 8 );
	}

	private function signed_request( string $method, string $path, array $payload, int $timeout ): array {
		if ( ! $this->endpoint_valid() ) {
			return array( 'ok' => false, 'status' => 0, 'message' => 'A valid HTTPS worker endpoint is not configured.' );
		}
		$body = wp_json_encode( $payload, JSON_UNESCAPED_SLASHES );
		if ( ! is_string( $body ) ) {
			return array( 'ok' => false, 'status' => 0, 'message' => 'Unable to encode relay-worker request.' );
		}
		$timestamp = (string) time();
		$nonce = wp_generate_password( 32, false, false );
		$signed = $this->signer->sign( $timestamp, $nonce, $body );
		if ( is_wp_error( $signed ) ) {
			return array( 'ok' => false, 'status' => 0, 'message' => $signed->get_error_message() );
		}
		$response = wp_remote_request(
			$this->endpoint() . $path,
			array(
				'method' => $method,
				'timeout' => $timeout,
				'redirection' => 0,
				'headers' => array(
					'Content-Type' => 'application/json',
					'X-JKSH-Contract' => 'jksh-relay-v1',
					'X-JKSH-Key-Id' => (string) $signed['key_id'],
					'X-JKSH-Timestamp' => $timestamp,
					'X-JKSH-Nonce' => $nonce,
					'X-JKSH-Signature' => (string) $signed['signature'],
				),
				'body' => $body,
				'user-agent' => 'JKSH/' . JKSH_VERSION,
			)
		);
		return $this->normalize( $response );
	}

	private function normalize( $response ): array {
		if ( is_wp_error( $response ) ) {
			return array( 'ok' => false, 'status' => 0, 'message' => sanitize_textarea_field( $response->get_error_message() ) );
		}
		$status = (int) wp_remote_retrieve_response_code( $response );
		$raw = (string) wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );
		$data = is_array( $data ) ? $data : array();
		return array(
			'ok' => $status >= 200 && $status < 300 && empty( $data['error'] ),
			'status' => $status,
			'message' => sanitize_textarea_field( (string) ( $data['message'] ?? ( $status >= 200 && $status < 300 ? '' : 'Worker request failed.' ) ) ),
			'data' => $this->sanitize_nested( $data ),
		);
	}

	private function sanitize_nested( array $data ): array {
		$out = array();
		foreach ( $data as $key => $value ) {
			$key = is_string( $key ) ? sanitize_key( $key ) : $key;
			if ( is_array( $value ) ) {
				$out[ $key ] = $this->sanitize_nested( $value );
			} elseif ( is_bool( $value ) || is_int( $value ) || is_float( $value ) || null === $value ) {
				$out[ $key ] = $value;
			} else {
				$text = (string) $value;
				if ( preg_match( '/(?:rtmps?|srt):\/\//i', $text ) || false !== stripos( (string) $key, 'secret' ) || false !== stripos( (string) $key, 'key' ) ) {
					$out[ $key ] = '[redacted]';
				} else {
					$out[ $key ] = sanitize_textarea_field( $text );
				}
			}
		}
		return $out;
	}
}
