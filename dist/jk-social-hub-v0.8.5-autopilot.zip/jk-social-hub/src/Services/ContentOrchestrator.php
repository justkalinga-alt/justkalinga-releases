<?php
namespace JKSH\Services;

use JKSH\Queue\Dispatcher;
use JKSH\Repositories\ContentRepository;
use JKSH\Repositories\JobRepository;
use JKSH\Repositories\LogRepository;
use JKSH\Repositories\VariantRepository;

final class ContentOrchestrator {
	public function create_dry_run( array $input ): array|\WP_Error {
		$title = sanitize_text_field( (string) ( $input['title'] ?? '' ) );
		if ( '' === $title ) {
			return new \WP_Error( 'jksh_missing_title', 'A master title is required.' );
		}
		$platforms = array_values( array_intersect( array( 'instagram', 'facebook', 'youtube' ), array_map( 'sanitize_key', (array) ( $input['platforms'] ?? array( 'instagram', 'facebook', 'youtube' ) ) ) ) );
		if ( ! $platforms ) {
			return new \WP_Error( 'jksh_missing_platform', 'At least one supported platform is required.' );
		}
		$media = array_values( array_unique( array_filter( array_map( 'absint', (array) ( $input['media_attachment_ids'] ?? array() ) ) ) ) );
		foreach ( $media as $attachment_id ) {
			if ( ! wp_attachment_is_image( $attachment_id ) ) {
				$mime = (string) get_post_mime_type( $attachment_id );
				if ( ! str_starts_with( $mime, 'video/' ) ) {
					return new \WP_Error( 'jksh_bad_media', 'Attachment ' . $attachment_id . ' is not a supported image or video.' );
				}
			}
		}

		$scheduled_at = $this->scheduled_at( (string) ( $input['scheduled_at_utc'] ?? '' ) );
		$content_meta = array(
			'location' => $this->sanitize_nested( (array) ( $input['location'] ?? array() ) ),
			'products' => $this->sanitize_nested( (array) ( $input['products'] ?? array() ) ),
			'source' => 'mcp',
			'workflow' => 'omnichannel_v1',
		);
		$content_repo = new ContentRepository();
		$variant_repo = new VariantRepository();
		$job_repo = new JobRepository();
		$log_repo = new LogRepository();
		$builder = new VariantBuilder();
		$schema = new PlatformSchema();
		$dispatcher = new Dispatcher();
		$content_id = $content_repo->create(
			array(
				'title' => $title,
				'content_type' => sanitize_key( (string) ( $input['content_type'] ?? 'knowledge' ) ),
				'body' => wp_kses_post( (string) ( $input['body'] ?? '' ) ),
				'status' => 'scheduled',
				'media' => $media,
				'meta' => $content_meta,
			)
		);
		$created = array();
		foreach ( $platforms as $platform ) {
			$variant = $builder->build(
				$platform,
				array(
					'title' => $title,
					'content_type' => sanitize_key( (string) ( $input['content_type'] ?? 'knowledge' ) ),
					'body' => (string) ( $input['body'] ?? '' ),
					'media' => $media,
				)
			);
			$fields = $schema->sanitize_fields( $platform, (array) ( $input['platform_fields'][ $platform ] ?? array() ) );
			$this->apply_copy_overrides( $platform, $variant, $fields );
			$variant['fields'] = $fields;
			$variant['content_id'] = $content_id;
			$variant['publish_at'] = $scheduled_at;
			$variant['status'] = 'scheduled';
			$variant_id = $variant_repo->create( $variant );
			$job_id = $job_repo->create(
				array(
					'content_id' => $content_id,
					'variant_id' => $variant_id,
					'platform' => $platform,
					'job_type' => 'publish',
					'status' => 'queued',
					'scheduled_at' => $scheduled_at,
					'idempotency_key' => hash( 'sha256', 'jksh|mcp|' . $variant_id . '|publish|' . $scheduled_at ),
					'payload' => array( 'variant_id' => $variant_id, 'publish_mode' => 'dry_run', 'dry_run' => true, 'source' => 'mcp' ),
				)
			);
			$dispatcher->schedule( $job_id, strtotime( $scheduled_at . ' UTC' ) ?: time() + 10 );
			$log_repo->add(
				array(
					'job_id' => $job_id,
					'content_id' => $content_id,
					'variant_id' => $variant_id,
					'action' => 'schedule',
					'result' => 'success',
					'message' => 'MCP omnichannel variant scheduled in Dry Run mode.',
					'context' => array( 'platform' => $platform, 'scheduled_at_utc' => $scheduled_at, 'publish_mode' => 'dry_run' ),
				)
			);
			$created[] = array( 'platform' => $platform, 'variant_id' => $variant_id, 'job_id' => $job_id, 'fields' => $fields );
		}
		return array( 'content_id' => $content_id, 'publish_mode' => 'dry_run', 'scheduled_at_utc' => $scheduled_at, 'variants' => $created );
	}

	public function package( int $content_id ): array|\WP_Error {
		$content = ( new ContentRepository() )->get( $content_id );
		if ( ! $content ) {
			return new \WP_Error( 'jksh_not_found', 'Master content was not found.' );
		}
		$variants = ( new VariantRepository() )->by_content( $content_id );
		$jobs = ( new JobRepository() )->by_content( $content_id );
		return array(
			'content' => $this->safe_content( $content ),
			'variants' => array_map( array( $this, 'safe_variant' ), $variants ),
			'jobs' => array_map( array( $this, 'safe_job' ), $jobs ),
		);
	}

	public function process_dry_run_jobs( array $job_ids ): array|\WP_Error {
		$settings = new Settings();
		if ( ! $settings->get( 'dry_run', 1 ) ) {
			return new \WP_Error( 'jksh_dry_run_required', 'Dry Run must be ON to execute this MCP ability.' );
		}
		$repo = new JobRepository();
		$dispatcher = new Dispatcher();
		$results = array();
		foreach ( array_values( array_unique( array_filter( array_map( 'absint', $job_ids ) ) ) ) as $job_id ) {
			$job = $repo->get( $job_id );
			if ( ! $job ) {
				$results[] = array( 'job_id' => $job_id, 'status' => 'not_found' );
				continue;
			}
			$payload = json_decode( (string) $job->payload_json, true );
			if ( ! is_array( $payload ) || 'dry_run' !== sanitize_key( (string) ( $payload['publish_mode'] ?? '' ) ) ) {
				$results[] = array( 'job_id' => $job_id, 'status' => 'refused', 'message' => 'Only jobs captured as dry_run can be processed by this ability.' );
				continue;
			}
			$dispatcher->process( $job_id );
			$after = $repo->get( $job_id );
			$results[] = array( 'job_id' => $job_id, 'status' => sanitize_key( (string) ( $after->status ?? 'unknown' ) ), 'last_error' => sanitize_textarea_field( (string) ( $after->last_error ?? '' ) ) );
		}
		return array( 'results' => $results );
	}

	private function scheduled_at( string $value ): string {
		if ( $value ) {
			$ts = strtotime( $value . ( str_contains( $value, 'UTC' ) || str_contains( $value, 'Z' ) ? '' : ' UTC' ) );
			if ( $ts ) {
				return gmdate( 'Y-m-d H:i:s', max( time(), $ts ) );
			}
		}
		return gmdate( 'Y-m-d H:i:s', time() );
	}

	private function apply_copy_overrides( string $platform, array &$variant, array $fields ): void {
		if ( isset( $fields['title'] ) ) {
			$variant['title'] = sanitize_text_field( (string) $fields['title'] );
		}
		if ( 'facebook' === $platform && isset( $fields['message'] ) ) {
			$variant['caption'] = sanitize_textarea_field( (string) $fields['message'] );
		} elseif ( isset( $fields['caption'] ) ) {
			$variant['caption'] = sanitize_textarea_field( (string) $fields['caption'] );
		}
		if ( isset( $fields['description'] ) ) {
			$variant['description'] = sanitize_textarea_field( (string) $fields['description'] );
		}
		if ( isset( $fields['hashtags'] ) ) {
			$variant['hashtags'] = is_array( $fields['hashtags'] ) ? sanitize_text_field( implode( ' ', $fields['hashtags'] ) ) : sanitize_text_field( (string) $fields['hashtags'] );
		}
		if ( isset( $fields['cta'] ) ) {
			$variant['cta'] = sanitize_textarea_field( (string) $fields['cta'] );
		}
	}

	private function sanitize_nested( array $value ): array {
		$out = array();
		foreach ( $value as $key => $item ) {
			$key = is_string( $key ) ? sanitize_key( $key ) : $key;
			$out[ $key ] = is_array( $item ) ? $this->sanitize_nested( $item ) : ( is_bool( $item ) || is_int( $item ) || is_float( $item ) || null === $item ? $item : sanitize_textarea_field( (string) $item ) );
		}
		return $out;
	}

	private function safe_content( object $row ): array {
		return array(
			'id' => (int) $row->id,
			'title' => sanitize_text_field( (string) $row->title ),
			'content_type' => sanitize_key( (string) $row->content_type ),
			'body' => wp_kses_post( (string) $row->body ),
			'status' => sanitize_key( (string) $row->status ),
			'media' => json_decode( (string) $row->media_json, true ) ?: array(),
			'meta' => json_decode( (string) ( $row->meta_json ?? '' ), true ) ?: array(),
		);
	}
	private function safe_variant( object $row ): array {
		return array(
			'id' => (int) $row->id,
			'platform' => sanitize_key( (string) $row->platform ),
			'publication_type' => sanitize_key( (string) $row->publication_type ),
			'title' => sanitize_text_field( (string) $row->title ),
			'caption' => sanitize_textarea_field( (string) $row->caption ),
			'description' => sanitize_textarea_field( (string) $row->description ),
			'hashtags' => sanitize_text_field( (string) $row->hashtags ),
			'cta' => sanitize_textarea_field( (string) $row->cta ),
			'media' => json_decode( (string) $row->media_json, true ) ?: array(),
			'fields' => json_decode( (string) ( $row->fields_json ?? '' ), true ) ?: array(),
			'field_mapping' => ( new PlatformSchema() )->summarize_fields( (string) $row->platform, json_decode( (string) ( $row->fields_json ?? '' ), true ) ?: array() ),
			'publish_at' => sanitize_text_field( (string) $row->publish_at ),
			'status' => sanitize_key( (string) $row->status ),
		);
	}

	private function safe_job( object $row ): array {
		return array(
			'id' => (int) $row->id,
			'variant_id' => (int) $row->variant_id,
			'platform' => sanitize_key( (string) $row->platform ),
			'job_type' => sanitize_key( (string) $row->job_type ),
			'status' => sanitize_key( (string) $row->status ),
			'attempts' => (int) $row->attempts,
			'scheduled_at' => sanitize_text_field( (string) $row->scheduled_at ),
			'last_error' => sanitize_textarea_field( (string) $row->last_error ),
			'publish_mode' => sanitize_key( (string) ( ( json_decode( (string) $row->payload_json, true ) ?: array() )['publish_mode'] ?? '' ) ),
		);
	}

}
