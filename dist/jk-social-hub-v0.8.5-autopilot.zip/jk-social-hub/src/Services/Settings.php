<?php
namespace JKSH\Services;

final class Settings {
	public const OPTION = 'jksh_settings';

	public function register(): void {
		add_action( 'admin_init', array( $this, 'register_setting' ) );
	}

	public function register_setting(): void {
		register_setting(
			'jksh_settings_group',
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize' ),
				'default'           => $this->defaults(),
			)
		);
	}

	public function ensure_defaults(): void {
		$current = get_option( self::OPTION, array() );
		update_option( self::OPTION, wp_parse_args( is_array( $current ) ? $current : array(), $this->defaults() ), false );
	}

	public function defaults(): array {
		return array(
			'dry_run'                   => 1,
			'meta_live_publish_enabled' => 0,
			'youtube_live_publish_enabled' => 0,
			'youtube_live_stream_enabled' => 0,
			'timezone'        => 'Asia/Kolkata',
			'website'         => 'https://justkalinga.com',
			'brand_name'      => 'JustKalinga',
			'phone_primary'   => '',
			'phone_secondary' => '',
			'whatsapp'        => '',
			'email'           => '',
			'coupon_code'     => 'PURIDHAM11',
			'coupon_label'    => '11% off',
			'utm_enabled'     => 1,
			'worker_enabled'  => 0,
			'worker_endpoint' => '',
			'live_worker_enabled' => 0,
			'live_worker_endpoint' => '',
			'live_worker_ingest_base' => '',
			'live_worker_internal_ingest_base' => 'rtmp://mediamtx:1935/jksh',
		);
	}

	public function all(): array {
		return wp_parse_args( (array) get_option( self::OPTION, array() ), $this->defaults() );
	}

	public function get( string $key, $default = null ) {
		$settings = $this->all();
		return $settings[ $key ] ?? $default;
	}

	public function sanitize( $input ): array {
		$input = is_array( $input ) ? $input : array();
		return array(
			'dry_run'                   => empty( $input['dry_run'] ) ? 0 : 1,
			'meta_live_publish_enabled' => empty( $input['meta_live_publish_enabled'] ) ? 0 : 1,
			'youtube_live_publish_enabled' => empty( $input['youtube_live_publish_enabled'] ) ? 0 : 1,
			'youtube_live_stream_enabled' => empty( $input['youtube_live_stream_enabled'] ) ? 0 : 1,
			'timezone'        => 'Asia/Kolkata',
			'website'         => esc_url_raw( $input['website'] ?? '' ),
			'brand_name'      => sanitize_text_field( $input['brand_name'] ?? 'JustKalinga' ),
			'phone_primary'   => sanitize_text_field( $input['phone_primary'] ?? '' ),
			'phone_secondary' => sanitize_text_field( $input['phone_secondary'] ?? '' ),
			'whatsapp'        => sanitize_text_field( $input['whatsapp'] ?? '' ),
			'email'           => sanitize_email( $input['email'] ?? '' ),
			'coupon_code'     => sanitize_text_field( $input['coupon_code'] ?? '' ),
			'coupon_label'    => sanitize_text_field( $input['coupon_label'] ?? '' ),
			'utm_enabled'     => empty( $input['utm_enabled'] ) ? 0 : 1,
			'worker_enabled'  => empty( $input['worker_enabled'] ) ? 0 : 1,
			'worker_endpoint' => esc_url_raw( $input['worker_endpoint'] ?? '' ),
			'live_worker_enabled' => empty( $input['live_worker_enabled'] ) ? 0 : 1,
			'live_worker_endpoint' => esc_url_raw( $input['live_worker_endpoint'] ?? '' ),
			'live_worker_ingest_base' => sanitize_text_field( $input['live_worker_ingest_base'] ?? '' ),
			'live_worker_internal_ingest_base' => sanitize_text_field( $input['live_worker_internal_ingest_base'] ?? 'rtmp://mediamtx:1935/jksh' ),
		);
	}
}
