(() => {
  'use strict';
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.jksh-card').forEach((card) => {
      card.dataset.ready = '1';
    });
  });
})();
