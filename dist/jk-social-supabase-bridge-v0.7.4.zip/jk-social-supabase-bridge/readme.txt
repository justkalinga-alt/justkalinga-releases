JK Social Supabase Bridge v0.7.3
Working-title fields are context-only; YouTube image/carousel requests create explicit Community-ready handoff jobs rather than being omitted or falsely reported as published.
