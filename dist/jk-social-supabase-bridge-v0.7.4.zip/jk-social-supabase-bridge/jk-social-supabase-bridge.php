<?php
/**
 * Plugin Name: JK Social Supabase Bridge
 * Description: Secure media-vault bridge between JK Social Hub and Supabase Storage.
 * Version: 0.7.4
 * Requires at least: 6.9
 * Requires PHP: 8.1
 * Author: JustKalinga
 * Text Domain: jk-social-supabase-bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class JKSSB_Bridge {
    const VERSION  = '0.7.4';
    const CONTRACT = 'jksh-media-v1';
    const ENDPOINT = 'https://jfcovdfemyqzxtkjpcev.supabase.co/functions/v1/jksh-media-vault';
    const OPT_KEY  = 'jkssb_key_material_v1';
    const MAX_BYTES = 524288000;
    const DIRECT_CHUNK_BYTES = 4194304;
    const DELIVERY_BASE = 'https://jfcovdfemyqzxtkjpcev.supabase.co/functions/v1/jksh-media-delivery?asset_id=';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public static function activate() {
        if ( version_compare( PHP_VERSION, '8.1', '<' ) ) {
            deactivate_plugins( plugin_basename( __FILE__ ) );
            wp_die( esc_html__( 'JK Social Supabase Bridge requires PHP 8.1 or newer.', 'jk-social-supabase-bridge' ) );
        }
        self::ensure_keypair();
    }

    private function __construct() {
        add_action( 'wp_abilities_api_categories_init', array( $this, 'register_category' ) );
        add_action( 'wp_abilities_api_init', array( $this, 'register_abilities' ) );
        add_action( 'admin_menu', array( $this, 'register_upload_page' ) );
        add_action( 'wp_ajax_jkssb_ui_begin', array( $this, 'ajax_ui_begin' ) );
        add_action( 'wp_ajax_jkssb_ui_chunk', array( $this, 'ajax_ui_chunk' ) );
        add_action( 'wp_ajax_jkssb_ui_finalize', array( $this, 'ajax_ui_finalize' ) );
        add_action( 'wp_ajax_jkssb_ui_save_bundle', array( $this, 'ajax_ui_save_bundle' ) );
    }

    private static function crypto_key() {
        return hash( 'sha256', wp_salt( 'auth' ) . '|jkssb|' . home_url( '/' ), true );
    }

    private static function encrypt_private_key( $plaintext ) {
        if ( ! function_exists( 'openssl_encrypt' ) ) {
            return new WP_Error( 'jkssb_openssl_missing', 'OpenSSL encryption is unavailable.' );
        }
        $iv  = random_bytes( 12 );
        $tag = '';
        $enc = openssl_encrypt( $plaintext, 'aes-256-gcm', self::crypto_key(), OPENSSL_RAW_DATA, $iv, $tag );
        if ( false === $enc ) {
            return new WP_Error( 'jkssb_encrypt_failed', 'Could not encrypt bridge private key.' );
        }
        return base64_encode( wp_json_encode( array(
            'v'   => 1,
            'iv'  => base64_encode( $iv ),
            'tag' => base64_encode( $tag ),
            'ct'  => base64_encode( $enc ),
        ) ) );
    }

    private static function decrypt_private_key( $stored ) {
        if ( ! $stored || ! function_exists( 'openssl_decrypt' ) ) {
            return new WP_Error( 'jkssb_key_unavailable', 'Bridge private key is unavailable.' );
        }
        $decoded = json_decode( base64_decode( $stored ), true );
        if ( ! is_array( $decoded ) || empty( $decoded['iv'] ) || empty( $decoded['tag'] ) || empty( $decoded['ct'] ) ) {
            return new WP_Error( 'jkssb_key_corrupt', 'Stored bridge key material is invalid.' );
        }
        $plain = openssl_decrypt(
            base64_decode( $decoded['ct'] ),
            'aes-256-gcm',
            self::crypto_key(),
            OPENSSL_RAW_DATA,
            base64_decode( $decoded['iv'] ),
            base64_decode( $decoded['tag'] )
        );
        if ( false === $plain ) {
            return new WP_Error( 'jkssb_decrypt_failed', 'Could not decrypt bridge private key.' );
        }
        return $plain;
    }

    private static function ensure_keypair() {
        $existing = get_option( self::OPT_KEY );
        if ( is_array( $existing ) && ! empty( $existing['private'] ) && ! empty( $existing['public_b64'] ) && ! empty( $existing['key_id'] ) ) {
            return $existing;
        }
        if ( ! function_exists( 'openssl_pkey_new' ) ) {
            return new WP_Error( 'jkssb_openssl_missing', 'OpenSSL key generation is unavailable.' );
        }
        $resource = openssl_pkey_new( array(
            'private_key_bits' => 2048,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
        ) );
        if ( ! $resource ) {
            return new WP_Error( 'jkssb_keygen_failed', 'Could not generate RSA keypair.' );
        }
        $private = '';
        if ( ! openssl_pkey_export( $resource, $private ) ) {
            return new WP_Error( 'jkssb_private_export_failed', 'Could not export RSA private key.' );
        }
        $details = openssl_pkey_get_details( $resource );
        if ( empty( $details['key'] ) ) {
            return new WP_Error( 'jkssb_public_export_failed', 'Could not export RSA public key.' );
        }
        $public = $details['key'];
        $encrypted = self::encrypt_private_key( $private );
        if ( is_wp_error( $encrypted ) ) {
            return $encrypted;
        }
        $data = array(
            'private'    => $encrypted,
            'public_b64' => base64_encode( $public ),
            'key_id'     => substr( hash( 'sha256', $public ), 0, 24 ),
            'created_at' => gmdate( 'c' ),
        );
        update_option( self::OPT_KEY, $data, false );
        return $data;
    }

    private static function key_material() {
        $data = self::ensure_keypair();
        if ( is_wp_error( $data ) ) {
            return $data;
        }
        $private = self::decrypt_private_key( $data['private'] );
        if ( is_wp_error( $private ) ) {
            return $private;
        }
        $data['private_plain'] = $private;
        return $data;
    }

    public function register_category() {
        if ( function_exists( 'wp_register_ability_category' ) ) {
            wp_register_ability_category( 'jk-social-supabase', array(
                'label'       => 'JK Social Supabase',
                'description' => 'Secure Supabase media-vault operations for JK Social Hub.',
            ) );
        }
    }

    public function register_abilities() {
        if ( ! function_exists( 'wp_register_ability' ) ) {
            return;
        }

        $object_output = array( 'type' => 'object', 'additionalProperties' => true );
        $public_meta   = array( 'public' => true );

        wp_register_ability( 'jk-social-supabase/get-readiness', array(
            'label'               => 'Get Supabase Bridge Readiness',
            'description'         => 'Returns read-only JK Social Supabase bridge and endpoint readiness without exposing private keys.',
            'category'            => 'jk-social-supabase',
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_readiness' ),
            'permission_callback' => array( $this, 'can_manage' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'readonly' => true ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/get-public-key', array(
            'label'               => 'Get Supabase Bridge Public Key',
            'description'         => 'Returns only the bridge public verification key and key ID for pairing with the Supabase media vault.',
            'category'            => 'jk-social-supabase',
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_public_key' ),
            'permission_callback' => array( $this, 'can_manage' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'readonly' => true ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/ingest-media', array(
            'label'               => 'Ingest Media To Supabase',
            'description'         => 'Uploads an existing WordPress media attachment once into the private JK Social Supabase vault with SHA-256 deduplication. An explicit metadata.jksh_live_request with confirm_live=true can atomically queue a guarded live JK Social Hub publish after successful ingest.',
            'category'            => 'jk-social-supabase',
            'input_schema'        => array(
                'type' => 'object',
                'properties' => array(
                    'attachment_id' => array( 'type' => 'integer', 'minimum' => 1 ),
                    'alt_text'      => array( 'type' => 'string' ),
                    'ai_generated'  => array( 'type' => 'boolean' ),
                    'product_refs'  => array( 'type' => 'array', 'items' => array( 'type' => 'object', 'additionalProperties' => true ) ),
                    'metadata'      => array( 'type' => 'object', 'additionalProperties' => true ),
                ),
                'required' => array( 'attachment_id' ),
                'additionalProperties' => false,
            ),
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_ingest_media' ),
            'permission_callback' => array( $this, 'can_manage' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'destructive' => false, 'idempotent' => true ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/create-delivery-url', array(
            'label'               => 'Create Supabase Delivery URL',
            'description'         => 'Creates a temporary signed delivery URL for a ready media asset so a social platform can fetch it.',
            'category'            => 'jk-social-supabase',
            'input_schema'        => array(
                'type' => 'object',
                'properties' => array(
                    'attachment_id'     => array( 'type' => 'integer', 'minimum' => 1 ),
                    'asset_id'          => array( 'type' => 'string' ),
                    'expires_in_seconds'=> array( 'type' => 'integer', 'minimum' => 60, 'maximum' => 21600 ),
                ),
                'additionalProperties' => false,
            ),
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_delivery_url' ),
            'permission_callback' => array( $this, 'can_manage' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'readonly' => true ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/inspect-jksh-runtime', array(
            'label'               => 'Inspect JK Social Hub Runtime',
            'description'         => 'Read-only inspection of JK Social Hub database tables, columns, loaded JKSH classes and public methods. No row data or secrets are returned.',
            'category'            => 'jk-social-supabase',
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_inspect_jksh_runtime_with_uploads' ),
            'permission_callback' => array( $this, 'can_manage' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'readonly' => true ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/inspect-jksh-records', array(
            'label'               => 'Inspect JK Social Hub Content Records',
            'description'         => 'Read-only inspection of one JK Social Hub content package at the database-row level, including sanitized variant/job payloads. Account credentials and secrets are never read.',
            'category'            => 'jk-social-supabase',
            'input_schema'        => array(
                'type' => 'object',
                'properties' => array(
                    'content_id' => array( 'type' => 'integer', 'minimum' => 1 ),
                ),
                'required' => array( 'content_id' ),
                'additionalProperties' => false,
            ),
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_inspect_jksh_records' ),
            'permission_callback' => array( $this, 'can_manage' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'readonly' => true ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/ingest-from-url', array(
            'label'               => 'Ingest Media From URL',
            'description'         => 'Downloads an explicitly supplied HTTPS media URL into WordPress, validates it, and ingests the resulting attachment into the private Supabase media vault.',
            'category'            => 'jk-social-supabase',
            'input_schema'        => array(
                'type' => 'object',
                'properties' => array(
                    'url'          => array( 'type' => 'string', 'format' => 'uri' ),
                    'filename'     => array( 'type' => 'string' ),
                    'title'        => array( 'type' => 'string' ),
                    'alt_text'     => array( 'type' => 'string' ),
                    'ai_generated' => array( 'type' => 'boolean' ),
                    'product_refs' => array( 'type' => 'array', 'items' => array( 'type' => 'object', 'additionalProperties' => true ) ),
                    'metadata'     => array( 'type' => 'object', 'additionalProperties' => true ),
                ),
                'required' => array( 'url' ),
                'additionalProperties' => false,
            ),
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_ingest_from_url' ),
            'permission_callback' => array( $this, 'can_manage' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'destructive' => false ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/begin-direct-upload', array(
            'label'               => 'Begin Direct Supabase Upload',
            'description'         => 'Starts a temporary chunked upload session for original media bytes without creating a WordPress Media Library file.',
            'category'            => 'jk-social-supabase',
            'input_schema'        => array(
                'type' => 'object',
                'properties' => array(
                    'filename'      => array( 'type' => 'string' ),
                    'mime_type'     => array( 'type' => 'string' ),
                    'bytes'         => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => self::MAX_BYTES ),
                    'sha256'        => array( 'type' => 'string' ),
                    'width'         => array( 'type' => 'integer', 'minimum' => 1 ),
                    'height'        => array( 'type' => 'integer', 'minimum' => 1 ),
                    'duration_ms'   => array( 'type' => 'integer', 'minimum' => 0 ),
                    'alt_text'      => array( 'type' => 'string' ),
                    'ai_generated'  => array( 'type' => 'boolean' ),
                    'product_refs'  => array( 'type' => 'array', 'items' => array( 'type' => 'object', 'additionalProperties' => true ) ),
                    'metadata'      => array( 'type' => 'object', 'additionalProperties' => true ),
                ),
                'required' => array( 'filename', 'mime_type', 'bytes', 'sha256' ),
                'additionalProperties' => false,
            ),
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_begin_direct_upload' ),
            'permission_callback' => array( $this, 'can_manage' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'destructive' => false ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/append-direct-upload-chunk', array(
            'label'               => 'Append Direct Upload Chunk',
            'description'         => 'Appends one base64 chunk to a temporary direct-upload session. No WordPress media attachment is created.',
            'category'            => 'jk-social-supabase',
            'input_schema'        => array(
                'type' => 'object',
                'properties' => array(
                    'upload_id'    => array( 'type' => 'string' ),
                    'offset'       => array( 'type' => 'integer', 'minimum' => 0 ),
                    'chunk_base64' => array( 'type' => 'string' ),
                ),
                'required' => array( 'upload_id', 'offset', 'chunk_base64' ),
                'additionalProperties' => false,
            ),
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_append_direct_upload_chunk' ),
            'permission_callback' => array( $this, 'can_manage' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'destructive' => false, 'idempotent' => true ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/finalize-direct-upload', array(
            'label'               => 'Finalize Direct Supabase Upload',
            'description'         => 'Verifies the original file, uploads it to the private Supabase vault, creates a link-only attachment shell, and optionally queues guarded live publishing.',
            'category'            => 'jk-social-supabase',
            'input_schema'        => array(
                'type' => 'object',
                'properties' => array( 'upload_id' => array( 'type' => 'string' ) ),
                'required' => array( 'upload_id' ),
                'additionalProperties' => false,
            ),
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_finalize_direct_upload' ),
            'permission_callback' => array( $this, 'can_manage' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'destructive' => false ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/abort-direct-upload', array(
            'label'               => 'Abort Direct Supabase Upload',
            'description'         => 'Deletes a temporary direct-upload buffer and its session metadata.',
            'category'            => 'jk-social-supabase',
            'input_schema'        => array(
                'type' => 'object',
                'properties' => array( 'upload_id' => array( 'type' => 'string' ) ),
                'required' => array( 'upload_id' ),
                'additionalProperties' => false,
            ),
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_abort_direct_upload' ),
            'permission_callback' => array( $this, 'can_manage' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'destructive' => true, 'idempotent' => true ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/list-upload-drafts', array(
            'label' => 'List Social Upload Drafts', 'description' => 'Lists recent media bundles uploaded from the WordPress Social Upload screen.', 'category' => 'jk-social-supabase',
            'output_schema' => $object_output, 'execute_callback' => array( $this, 'ability_list_upload_drafts' ), 'permission_callback' => array( $this, 'can_manage' ),
            'meta' => array_merge( $public_meta, array( 'annotations' => array( 'readonly' => true ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/get-upload-draft', array(
            'label' => 'Get Social Upload Draft', 'description' => 'Returns one uploaded media bundle by bundle_id.', 'category' => 'jk-social-supabase',
            'input_schema' => array( 'type' => 'object', 'properties' => array( 'bundle_id' => array( 'type' => 'string' ) ), 'required' => array( 'bundle_id' ), 'additionalProperties' => false ),
            'output_schema' => $object_output, 'execute_callback' => array( $this, 'ability_get_upload_draft' ), 'permission_callback' => array( $this, 'can_manage' ),
            'meta' => array_merge( $public_meta, array( 'annotations' => array( 'readonly' => true ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/queue-upload-draft', array(
            'label' => 'Queue Social Upload Draft', 'description' => 'Turns one uploaded bundle into guarded live JK Social Hub jobs.', 'category' => 'jk-social-supabase',
            'input_schema' => array( 'type' => 'object', 'properties' => array(
                'bundle_id' => array( 'type' => 'string' ), 'title' => array( 'type' => 'string' ), 'body' => array( 'type' => 'string' ), 'scheduled_at_utc' => array( 'type' => 'string' ),
                'platforms' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ), 'platform_fields' => array( 'type' => 'object', 'additionalProperties' => true ),
                'location' => array( 'type' => 'object', 'additionalProperties' => true ), 'products' => array( 'type' => 'array', 'items' => array( 'type' => 'object', 'additionalProperties' => true ) ),
                'cta' => array( 'type' => 'string' ), 'confirm_live' => array( 'type' => 'boolean' ) ),
                'required' => array( 'bundle_id', 'title', 'scheduled_at_utc', 'platforms', 'confirm_live' ), 'additionalProperties' => false ),
            'output_schema' => $object_output, 'execute_callback' => array( $this, 'ability_queue_upload_draft' ), 'permission_callback' => array( $this, 'can_manage' ),
            'meta' => array_merge( $public_meta, array( 'annotations' => array( 'destructive' => false ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/get-update-readiness', array(
            'label'               => 'Get Bridge Update Readiness',
            'description'         => 'Read-only self-update readiness for JK Social Supabase Bridge.',
            'category'            => 'jk-social-supabase',
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_update_readiness' ),
            'permission_callback' => array( $this, 'can_manage' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'readonly' => true ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/preflight-update-package', array(
            'label'               => 'Preflight Bridge Update Package',
            'description'         => 'Validates an uploaded JK Social Supabase Bridge ZIP by exact SHA-256 and plugin identity without installing it.',
            'category'            => 'jk-social-supabase',
            'input_schema'        => array(
                'type' => 'object',
                'properties' => array(
                    'attachment_id'   => array( 'type' => 'integer', 'minimum' => 1 ),
                    'expected_sha256' => array( 'type' => 'string', 'pattern' => '^[0-9a-fA-F]{64}$' ),
                ),
                'required' => array( 'attachment_id', 'expected_sha256' ),
                'additionalProperties' => false,
            ),
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_preflight_update' ),
            'permission_callback' => array( $this, 'can_update' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'readonly' => true ) ) ),
        ) );

        wp_register_ability( 'jk-social-supabase/install-update-package', array(
            'label'               => 'Install Bridge Update Package',
            'description'         => 'Installs only a verified JK Social Supabase Bridge ZIP. Requires exact SHA-256, current version and confirm=true.',
            'category'            => 'jk-social-supabase',
            'input_schema'        => array(
                'type' => 'object',
                'properties' => array(
                    'attachment_id'            => array( 'type' => 'integer', 'minimum' => 1 ),
                    'expected_sha256'          => array( 'type' => 'string', 'pattern' => '^[0-9a-fA-F]{64}$' ),
                    'expected_current_version' => array( 'type' => 'string' ),
                    'confirm'                  => array( 'type' => 'boolean' ),
                    'delete_package_after'     => array( 'type' => 'boolean' ),
                ),
                'required' => array( 'attachment_id', 'expected_sha256', 'expected_current_version', 'confirm' ),
                'additionalProperties' => false,
            ),
            'output_schema'       => $object_output,
            'execute_callback'    => array( $this, 'ability_install_update' ),
            'permission_callback' => array( $this, 'can_update' ),
            'meta'                => array_merge( $public_meta, array( 'annotations' => array( 'destructive' => true ) ) ),
        ) );
    }

    public function can_manage() {
        return current_user_can( 'manage_options' );
    }

    public function ability_public_key() {
        $keys = self::ensure_keypair();
        if ( is_wp_error( $keys ) ) {
            return $keys;
        }
        return array(
            'ok'             => true,
            'contract'       => self::CONTRACT,
            'key_id'         => $keys['key_id'],
            'public_key_b64' => $keys['public_b64'],
            'created_at'     => $keys['created_at'],
        );
    }

    public function ability_readiness() {
        $keys = self::ensure_keypair();
        $health = wp_remote_get( self::ENDPOINT, array( 'timeout' => 10, 'redirection' => 2 ) );
        $health_data = null;
        if ( ! is_wp_error( $health ) ) {
            $health_data = json_decode( wp_remote_retrieve_body( $health ), true );
        }
        return array(
            'ok'                    => ! is_wp_error( $keys ),
            'version'               => self::VERSION,
            'contract'              => self::CONTRACT,
            'endpoint'              => self::ENDPOINT,
            'key_id'                => is_wp_error( $keys ) ? null : $keys['key_id'],
            'openssl_available'     => function_exists( 'openssl_sign' ),
            'endpoint_health_code'  => is_wp_error( $health ) ? null : wp_remote_retrieve_response_code( $health ),
            'endpoint_health'       => $health_data,
            'max_upload_bytes'      => self::MAX_BYTES,
            'private_key_exposed'   => false,
        );
    }

    private function signed_post( $payload, $timeout = 30 ) {
        $keys = self::key_material();
        if ( is_wp_error( $keys ) ) {
            return $keys;
        }
        $body = wp_json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        if ( false === $body ) {
            return new WP_Error( 'jkssb_json_failed', 'Could not encode vault request.' );
        }
        $timestamp = (string) time();
        $nonce     = bin2hex( random_bytes( 16 ) );
        $canonical = self::CONTRACT . "\n" . $timestamp . "\n" . $nonce . "\n" . hash( 'sha256', $body );
        $signature = '';
        if ( ! openssl_sign( $canonical, $signature, $keys['private_plain'], OPENSSL_ALGO_SHA256 ) ) {
            return new WP_Error( 'jkssb_sign_failed', 'Could not sign Supabase vault request.' );
        }
        $response = wp_remote_post( self::ENDPOINT, array(
            'timeout' => $timeout,
            'headers' => array(
                'Content-Type'       => 'application/json',
                'X-JKSH-Contract'    => self::CONTRACT,
                'X-JKSH-Key-Id'      => $keys['key_id'],
                'X-JKSH-Timestamp'   => $timestamp,
                'X-JKSH-Nonce'       => $nonce,
                'X-JKSH-Signature'   => base64_encode( $signature ),
            ),
            'body'        => $body,
            'data_format' => 'body',
        ) );
        if ( is_wp_error( $response ) ) {
            return $response;
        }
        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( $code < 200 || $code >= 300 || ! is_array( $data ) || empty( $data['ok'] ) ) {
            return new WP_Error( 'jkssb_vault_request_failed', 'Supabase media-vault request failed.', array( 'status' => $code, 'response' => is_array( $data ) ? $data : null ) );
        }
        return $data;
    }

    public function ability_ingest_media( $input ) {
        $attachment_id = isset( $input['attachment_id'] ) ? absint( $input['attachment_id'] ) : 0;
        if ( ! $attachment_id || 'attachment' !== get_post_type( $attachment_id ) ) {
            return new WP_Error( 'jkssb_invalid_attachment', 'A valid WordPress media attachment is required.' );
        }
        $file = get_attached_file( $attachment_id );
        if ( ! $file || ! is_readable( $file ) ) {
            return new WP_Error( 'jkssb_file_unreadable', 'The attachment file cannot be read.' );
        }
        $bytes = filesize( $file );
        if ( false === $bytes || $bytes <= 0 || $bytes > self::MAX_BYTES ) {
            return new WP_Error( 'jkssb_file_size', 'The attachment is empty or exceeds the 50 MB Phase 2 upload limit.' );
        }
        $mime = get_post_mime_type( $attachment_id );
        $allowed = array( 'image/jpeg','image/png','image/webp','image/gif','video/mp4','video/quicktime','video/webm' );
        if ( ! in_array( $mime, $allowed, true ) ) {
            return new WP_Error( 'jkssb_mime_not_allowed', 'This attachment type is not allowed in the JK Social media vault.' );
        }
        $sha = hash_file( 'sha256', $file );
        $meta = wp_get_attachment_metadata( $attachment_id );
        $width = isset( $meta['width'] ) ? absint( $meta['width'] ) : null;
        $height = isset( $meta['height'] ) ? absint( $meta['height'] ) : null;
        $duration_ms = null;
        if ( isset( $meta['length'] ) && is_numeric( $meta['length'] ) ) {
            $duration_ms = (int) round( (float) $meta['length'] * 1000 );
        }
        $alt = isset( $input['alt_text'] ) ? sanitize_text_field( $input['alt_text'] ) : get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
        $prepare = $this->signed_post( array(
            'action'           => 'prepare_upload',
            'filename'         => wp_basename( $file ),
            'mime_type'        => $mime,
            'bytes'            => (int) $bytes,
            'sha256'           => $sha,
            'width'            => $width,
            'height'           => $height,
            'duration_ms'      => $duration_ms,
            'source'           => 'wordpress',
            'source_reference' => 'attachment:' . $attachment_id,
            'alt_text'         => $alt,
            'ai_generated'     => ! empty( $input['ai_generated'] ),
            'product_refs'     => isset( $input['product_refs'] ) && is_array( $input['product_refs'] ) ? $input['product_refs'] : array(),
            'metadata'         => isset( $input['metadata'] ) && is_array( $input['metadata'] ) ? $input['metadata'] : array(),
        ) );
        if ( is_wp_error( $prepare ) ) {
            return $prepare;
        }
        if ( ! empty( $prepare['duplicate'] ) && ! empty( $prepare['asset']['id'] ) ) {
            $this->save_attachment_asset_meta( $attachment_id, $prepare['asset'] );
            return $this->maybe_create_jksh_live_schedule(
                array( 'ok' => true, 'duplicate' => true, 'attachment_id' => $attachment_id, 'asset' => $prepare['asset'] ),
                $input
            );
        }
        if ( empty( $prepare['asset_id'] ) || empty( $prepare['signed_upload_url'] ) ) {
            return new WP_Error( 'jkssb_prepare_incomplete', 'Vault prepare response did not include an upload target.' );
        }
        $binary = file_get_contents( $file );
        if ( false === $binary ) {
            return new WP_Error( 'jkssb_file_read_failed', 'Could not read attachment bytes for upload.' );
        }
        $upload = wp_remote_request( $prepare['signed_upload_url'], array(
            'method'  => 'PUT',
            'timeout' => 180,
            'headers' => array(
                'Content-Type'  => $mime,
                'Cache-Control' => 'max-age=3600',
                'x-upsert'      => 'false',
            ),
            'body'        => $binary,
            'data_format' => 'body',
        ) );
        unset( $binary );
        if ( is_wp_error( $upload ) ) {
            return $upload;
        }
        $upload_code = wp_remote_retrieve_response_code( $upload );
        if ( $upload_code < 200 || $upload_code >= 300 ) {
            return new WP_Error( 'jkssb_storage_upload_failed', 'Supabase Storage signed upload failed.', array( 'status' => $upload_code ) );
        }
        $final = $this->signed_post( array( 'action' => 'finalize_upload', 'asset_id' => $prepare['asset_id'] ) );
        if ( is_wp_error( $final ) ) {
            return $final;
        }
        if ( ! empty( $final['asset'] ) ) {
            $this->save_attachment_asset_meta( $attachment_id, $final['asset'] );
        }
        return $this->maybe_create_jksh_live_schedule(
            array(
                'ok'            => true,
                'duplicate'     => false,
                'attachment_id' => $attachment_id,
                'asset'         => isset( $final['asset'] ) ? $final['asset'] : null,
            ),
            $input
        );
    }

    private function maybe_create_jksh_live_schedule( $ingest_result, $input ) {
        $metadata = isset( $input['metadata'] ) && is_array( $input['metadata'] ) ? $input['metadata'] : array();
        if ( empty( $metadata['jksh_live_request'] ) || ! is_array( $metadata['jksh_live_request'] ) ) {
            return $ingest_result;
        }
        $live = $this->create_jksh_live_content(
            absint( $ingest_result['attachment_id'] ),
            $metadata['jksh_live_request'],
            isset( $ingest_result['asset'] ) && is_array( $ingest_result['asset'] ) ? $ingest_result['asset'] : array()
        );
        if ( is_wp_error( $live ) ) {
            $live->add_data( array_merge( (array) $live->get_error_data(), array(
                'media_ingest_succeeded' => true,
                'attachment_id'          => absint( $ingest_result['attachment_id'] ),
            ) ) );
            return $live;
        }
        $ingest_result['live_schedule'] = $live;
        return $ingest_result;
    }

    private function sanitize_live_value( $value, $key = '' ) {
        if ( preg_match( '/token|secret|credential|authorization|private|access[_-]?key|refresh/i', (string) $key ) ) {
            return '[redacted]';
        }
        if ( is_array( $value ) ) {
            $out = array();
            foreach ( $value as $k => $v ) {
                $out[ is_int( $k ) ? $k : sanitize_key( (string) $k ) ] = $this->sanitize_live_value( $v, (string) $k );
            }
            return $out;
        }
        if ( is_bool( $value ) || is_int( $value ) || is_float( $value ) || null === $value ) {
            return $value;
        }
        return sanitize_textarea_field( (string) $value );
    }

    private function get_jksh_publishing_readiness() {
        if ( ! function_exists( 'wp_get_ability' ) ) {
            return new WP_Error( 'jkssb_abilities_unavailable', 'WordPress Abilities API is unavailable.' );
        }
        $ability = wp_get_ability( 'jk-social/get-publishing-readiness' );
        if ( ! $ability ) {
            return new WP_Error( 'jkssb_readiness_unavailable', 'JK Social Hub publishing readiness ability is unavailable.' );
        }
        $readiness = $ability->execute();
        if ( is_wp_error( $readiness ) ) {
            return $readiness;
        }
        if ( ! is_array( $readiness ) ) {
            return new WP_Error( 'jkssb_readiness_invalid', 'JK Social Hub publishing readiness returned an invalid response.' );
        }
        return $readiness;
    }

    private function validate_jksh_live_media( $attachment_ids, $content_type ) {
        $attachment_ids = array_values( array_unique( array_filter( array_map( 'absint', (array) $attachment_ids ) ) ) );
        if ( empty( $attachment_ids ) || count( $attachment_ids ) > 10 ) {
            return new WP_Error( 'jkssb_live_media_count', 'Live publish requires 1-10 valid media attachments.' );
        }
        $image_mimes = array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif' );
        $video_mimes = array( 'video/mp4', 'video/quicktime', 'video/webm' );
        foreach ( $attachment_ids as $id ) {
            if ( 'attachment' !== get_post_type( $id ) ) {
                return new WP_Error( 'jkssb_live_media_invalid', 'A requested media attachment does not exist.', array( 'attachment_id' => $id ) );
            }
            if ( ! get_post_meta( $id, '_jkssb_asset_id', true ) ) {
                return new WP_Error( 'jkssb_live_media_not_ingested', 'Every live media attachment must be ingested into Supabase first.', array( 'attachment_id' => $id ) );
            }
            $mime = get_post_mime_type( $id );
            if ( in_array( $content_type, array( 'single_image', 'image', 'carousel' ), true ) && ! in_array( $mime, $image_mimes, true ) ) {
                return new WP_Error( 'jkssb_live_media_type', 'Image content may contain image attachments only.', array( 'attachment_id' => $id, 'mime' => $mime ) );
            }
            if ( in_array( $content_type, array( 'reel', 'sell_reel', 'video', 'short' ), true ) && ! in_array( $mime, $video_mimes, true ) ) {
                return new WP_Error( 'jkssb_live_media_type', 'Reel content requires a video attachment.', array( 'attachment_id' => $id, 'mime' => $mime ) );
            }
        }
        if ( in_array( $content_type, array( 'single_image', 'image' ), true ) && 1 !== count( $attachment_ids ) ) {
            return new WP_Error( 'jkssb_live_single_image_count', 'A single image post requires exactly one image.' );
        }
        if ( 'carousel' === $content_type && count( $attachment_ids ) < 2 ) {
            return new WP_Error( 'jkssb_live_carousel_count', 'A carousel requires at least two images.' );
        }
        if ( in_array( $content_type, array( 'reel', 'sell_reel', 'video', 'short' ), true ) && 1 !== count( $attachment_ids ) ) {
            return new WP_Error( 'jkssb_live_reel_count', 'A Reel requires exactly one video.' );
        }
        return $attachment_ids;
    }

    private function create_jksh_live_content( $current_attachment_id, $request, $asset ) {
        global $wpdb;
        if ( empty( $request['confirm_live'] ) || true !== $request['confirm_live'] ) {
            return new WP_Error( 'jkssb_live_confirm_required', 'confirm_live=true is required to create live publishing jobs.' );
        }
        $request_id = isset( $request['request_id'] ) ? sanitize_text_field( (string) $request['request_id'] ) : '';
        if ( ! preg_match( '/^[A-Za-z0-9._:-]{8,100}$/', $request_id ) ) {
            return new WP_Error( 'jkssb_live_request_id', 'request_id must be 8-100 safe characters.' );
        }
        $title = isset( $request['title'] ) ? sanitize_text_field( $request['title'] ) : '';
        if ( '' === $title ) {
            return new WP_Error( 'jkssb_live_title', 'A title is required.' );
        }
        $body = isset( $request['body'] ) ? sanitize_textarea_field( $request['body'] ) : '';
        $content_type = isset( $request['content_type'] ) ? sanitize_key( $request['content_type'] ) : 'single_image';
        if ( ! in_array( $content_type, array( 'single_image', 'image', 'carousel', 'reel', 'sell_reel', 'video', 'short' ), true ) ) {
            return new WP_Error( 'jkssb_live_content_type', 'Supported live content: single_image, image, carousel, reel, sell_reel, video and short.' );
        }
        $platforms = isset( $request['platforms'] ) && is_array( $request['platforms'] ) ? array_values( array_unique( array_map( 'sanitize_key', $request['platforms'] ) ) ) : array();
        if ( empty( $platforms ) ) {
            return new WP_Error( 'jkssb_live_platforms', 'At least one live platform is required.' );
        }
        foreach ( $platforms as $platform ) {
            if ( ! in_array( $platform, array( 'instagram', 'facebook', 'youtube' ), true ) ) { return new WP_Error( 'jkssb_live_platform_unsupported', 'Unsupported live platform.', array( 'platform' => $platform ) ); }
            if ( 'youtube' === $platform && ! in_array( $content_type, array( 'reel', 'sell_reel', 'video', 'short' ), true ) ) { return new WP_Error( 'jkssb_youtube_community_worker', 'YouTube image/community publishing remains on the Community worker/manual path; images are never converted to fake Shorts.' ); }
        }
        $scheduled_at = isset( $request['scheduled_at_utc'] ) ? sanitize_text_field( $request['scheduled_at_utc'] ) : '';
        $dt = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $scheduled_at, new DateTimeZone( 'UTC' ) );
        if ( ! $dt || $dt->format( 'Y-m-d H:i:s' ) !== $scheduled_at ) {
            return new WP_Error( 'jkssb_live_schedule_format', 'scheduled_at_utc must use YYYY-MM-DD HH:MM:SS in UTC.' );
        }
        $scheduled_ts = $dt->getTimestamp();
        if ( $scheduled_ts < time() + 60 || $scheduled_ts > time() + YEAR_IN_SECONDS ) {
            return new WP_Error( 'jkssb_live_schedule_range', 'Live schedule must be at least 60 seconds in the future and no more than one year ahead.' );
        }
        $readiness = $this->get_jksh_publishing_readiness();
        if ( is_wp_error( $readiness ) ) {
            return $readiness;
        }
        if ( ! empty( $readiness['dry_run'] ) ) {
            return new WP_Error( 'jkssb_live_dry_run_on', 'JK Social Hub Dry Run is ON. Live job creation is refused.' );
        }
        if ( empty( $readiness['meta_live_publish_enabled'] ) || empty( $readiness['live_publish_possible'] ) ) {
            return new WP_Error( 'jkssb_live_meta_disabled', 'JK Social Hub Meta live publishing is not ready.' );
        }
        $healthy = array();
        foreach ( isset( $readiness['accounts'] ) && is_array( $readiness['accounts'] ) ? $readiness['accounts'] : array() as $account ) {
            if ( ! empty( $account['platform'] ) && ! empty( $account['connected'] ) && ! empty( $account['healthy'] ) ) {
                $healthy[ sanitize_key( $account['platform'] ) ] = true;
            }
        }
        foreach ( $platforms as $platform ) {
            if ( 'youtube' === $platform ) { if ( empty( $readiness['youtube']['live_publish_possible'] ) || empty( $readiness['youtube']['account']['healthy'] ) ) return new WP_Error( 'jkssb_live_account_unhealthy', 'YouTube is not connected and healthy.', array( 'platform' => 'youtube' ) ); continue; }
            if ( empty( $healthy[ $platform ] ) ) return new WP_Error( 'jkssb_live_account_unhealthy', 'A selected platform account is not connected and healthy.', array( 'platform' => $platform ) );
        }
        $media_ids = isset( $request['media_attachment_ids'] ) && is_array( $request['media_attachment_ids'] ) ? $request['media_attachment_ids'] : array( $current_attachment_id );
        if ( ! in_array( $current_attachment_id, array_map( 'absint', $media_ids ), true ) ) {
            $media_ids[] = $current_attachment_id;
        }
        $media_ids = $this->validate_jksh_live_media( $media_ids, $content_type );
        if ( is_wp_error( $media_ids ) ) {
            return $media_ids;
        }
        $platform_fields = isset( $request['platform_fields'] ) && is_array( $request['platform_fields'] ) ? $request['platform_fields'] : array();
        $location = isset( $request['location'] ) && is_array( $request['location'] ) ? $this->sanitize_live_value( $request['location'] ) : array();
        $products = isset( $request['products'] ) && is_array( $request['products'] ) ? $this->sanitize_live_value( $request['products'] ) : array();
        $cta_default = isset( $request['cta'] ) && '' !== trim( (string) $request['cta'] ) ? sanitize_text_field( $request['cta'] ) : 'Jai Jagannātha 🙏';

        $idempotency_option = 'jkssb_live_req_' . hash( 'sha256', $request_id );
        $existing = get_option( $idempotency_option );
        if ( is_array( $existing ) && ! empty( $existing['content_id'] ) ) {
            $existing['ok'] = true;
            $existing['duplicate'] = true;
            return $existing;
        }
        if ( false === add_option( $idempotency_option, array( 'status' => 'creating', 'created_at' => gmdate( 'c' ) ), '', false ) ) {
            return new WP_Error( 'jkssb_live_request_in_progress', 'This live request_id is already being processed.' );
        }

        $content_table = $wpdb->prefix . 'jksh_content';
        $variant_table = $wpdb->prefix . 'jksh_variants';
        $job_table     = $wpdb->prefix . 'jksh_jobs';
        $now           = gmdate( 'Y-m-d H:i:s' );
        $content_uuid  = wp_generate_uuid4();
        $meta = array(
            'location'        => $location,
            'products'        => $products,
            'source'          => 'supabase_bridge',
            'workflow'        => 'omnichannel_v1',
            'request_id'      => $request_id,
            'ai_generated'    => ! empty( $request['ai_generated'] ),
            'supabase_asset'  => array(
                'id'       => isset( $asset['id'] ) ? sanitize_text_field( $asset['id'] ) : '',
                'asset_key'=> isset( $asset['asset_key'] ) ? sanitize_text_field( $asset['asset_key'] ) : '',
            ),
        );
        $wpdb->query( 'START TRANSACTION' );
        try {
            $inserted = $wpdb->insert( $content_table, array(
                'uuid'         => $content_uuid,
                'title'        => $title,
                'content_type' => $content_type,
                'body'         => $body,
                'status'       => 'scheduled',
                'media_json'   => wp_json_encode( $media_ids ),
                'author_id'    => get_current_user_id(),
                'created_at'   => $now,
                'updated_at'   => $now,
                'meta_json'    => wp_json_encode( $meta, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
            ) );
            if ( false === $inserted ) {
                throw new RuntimeException( 'Could not create JK Social Hub content row: ' . $wpdb->last_error );
            }
            $content_id = (int) $wpdb->insert_id;
            $created_variants = array();
            foreach ( $platforms as $platform ) {
                $raw_fields = isset( $platform_fields[ $platform ] ) && is_array( $platform_fields[ $platform ] ) ? $platform_fields[ $platform ] : array();
                $fields = $this->sanitize_live_value( $raw_fields );
                if ( 'instagram' === $platform ) {
                    $caption = isset( $fields['caption'] ) ? (string) $fields['caption'] : $body; $hashtags = isset( $fields['hashtags'] ) ? (string) $fields['hashtags'] : ''; $description = isset( $fields['description'] ) ? (string) $fields['description'] : $body; if ( ! isset( $fields['caption'] ) ) { $fields['caption'] = $caption; }
                } elseif ( 'youtube' === $platform ) {
                    $caption = $body; $hashtags = ''; $description = isset( $fields['description'] ) ? (string) $fields['description'] : $body; if ( ! isset( $fields['title'] ) ) $fields['title'] = $title; if ( ! isset( $fields['description'] ) ) $fields['description'] = $description; if ( ! isset( $fields['privacy_status'] ) ) $fields['privacy_status'] = 'public'; if ( ! isset( $fields['notify_subscribers'] ) ) $fields['notify_subscribers'] = false;
                } else {
                    $caption = isset( $fields['message'] ) ? (string) $fields['message'] : $body;
                    $hashtags = isset( $fields['hashtags'] ) ? (string) $fields['hashtags'] : '';
                    $description = isset( $fields['description'] ) ? (string) $fields['description'] : $body;
                    if ( ! isset( $fields['message'] ) ) { $fields['message'] = $caption; }
                }
                if ( ! isset( $fields['hashtags'] ) && '' !== $hashtags ) { $fields['hashtags'] = $hashtags; }
                $publication_type = 'post';
                if ( 'youtube' === $platform ) { $publication_type = in_array( $content_type, array( 'reel', 'sell_reel', 'short' ), true ) ? 'short' : 'video'; } elseif ( in_array( $content_type, array( 'reel', 'sell_reel' ), true ) ) { $publication_type = 'reel'; } elseif ( 'carousel' === $content_type && 'instagram' === $platform ) {
                    $publication_type = 'carousel';
                }
                $variant_uuid = wp_generate_uuid4();
                $variant_ok = $wpdb->insert( $variant_table, array(
                    'uuid'             => $variant_uuid,
                    'content_id'       => $content_id,
                    'platform'         => $platform,
                    'publication_type' => $publication_type,
                    'title'            => $title,
                    'caption'          => $caption,
                    'description'      => $description,
                    'hashtags'         => $hashtags,
                    'cta'              => isset( $fields['cta'] ) ? sanitize_text_field( $fields['cta'] ) : $cta_default,
                    'media_json'       => wp_json_encode( $media_ids ),
                    'publish_at'       => $scheduled_at,
                    'status'           => 'scheduled',
                    'external_id'      => '',
                    'external_url'     => null,
                    'analytics_json'   => wp_json_encode( array() ),
                    'created_at'       => $now,
                    'updated_at'       => $now,
                    'fields_json'      => wp_json_encode( $fields, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
                ) );
                if ( false === $variant_ok ) {
                    throw new RuntimeException( 'Could not create JK Social Hub variant row: ' . $wpdb->last_error );
                }
                $variant_id = (int) $wpdb->insert_id;
                $job_uuid = wp_generate_uuid4();
                $idempotency_key = hash( 'sha256', 'jkssb-live-v1|' . $request_id . '|' . $platform . '|' . $variant_uuid . '|' . $scheduled_at );
                $payload = array(
                    'variant_id'   => $variant_id,
                    'publish_mode' => 'live',
                    'dry_run'      => false,
                    'source'       => 'supabase_bridge',
                );
                $job_ok = $wpdb->insert( $job_table, array(
                    'uuid'               => $job_uuid,
                    'idempotency_key'    => $idempotency_key,
                    'content_id'         => $content_id,
                    'variant_id'         => $variant_id,
                    'platform'           => $platform,
                    'job_type'           => 'publish',
                    'status'             => 'queued',
                    'attempts'           => 0,
                    'max_attempts'       => 3,
                    'payload_json'       => wp_json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
                    'last_response_json' => wp_json_encode( array() ),
                    'last_error'         => '',
                    'scheduled_at'       => $scheduled_at,
                    'started_at'         => null,
                    'completed_at'       => null,
                    'created_at'         => $now,
                    'updated_at'         => $now,
                ) );
                if ( false === $job_ok ) {
                    throw new RuntimeException( 'Could not create JK Social Hub live job row: ' . $wpdb->last_error );
                }
                $created_variants[] = array(
                    'platform'         => $platform,
                    'publication_type' => $publication_type,
                    'variant_id'       => $variant_id,
                    'job_id'           => (int) $wpdb->insert_id,
                    'publish_mode'     => 'live',
                );
            }
            $wpdb->query( 'COMMIT' );
        } catch ( Throwable $e ) {
            $wpdb->query( 'ROLLBACK' );
            delete_option( $idempotency_option );
            return new WP_Error( 'jkssb_live_create_failed', 'JK Social Hub live queue creation failed safely; database transaction was rolled back.', array( 'detail' => sanitize_text_field( $e->getMessage() ) ) );
        }
        $result = array(
            'ok'               => true,
            'duplicate'        => false,
            'request_id'       => $request_id,
            'content_id'       => $content_id,
            'scheduled_at_utc' => $scheduled_at,
            'publish_mode'     => 'live',
            'variants'         => $created_variants,
        );
        update_option( $idempotency_option, $result, false );
        return $result;
    }

    private function save_attachment_asset_meta( $attachment_id, $asset ) {
        if ( ! empty( $asset['id'] ) ) {
            update_post_meta( $attachment_id, '_jkssb_asset_id', sanitize_text_field( $asset['id'] ) );
        }
        if ( ! empty( $asset['asset_key'] ) ) {
            update_post_meta( $attachment_id, '_jkssb_asset_key', sanitize_text_field( $asset['asset_key'] ) );
        }
        if ( ! empty( $asset['object_path'] ) ) {
            update_post_meta( $attachment_id, '_jkssb_object_path', sanitize_text_field( $asset['object_path'] ) );
        }
        if ( ! empty( $asset['sha256'] ) ) {
            update_post_meta( $attachment_id, '_jkssb_sha256', sanitize_text_field( $asset['sha256'] ) );
        }
    }

    public function ability_delivery_url( $input ) {
        $asset_id = isset( $input['asset_id'] ) ? sanitize_text_field( $input['asset_id'] ) : '';
        if ( ! $asset_id && ! empty( $input['attachment_id'] ) ) {
            $asset_id = get_post_meta( absint( $input['attachment_id'] ), '_jkssb_asset_id', true );
        }
        if ( ! $asset_id ) {
            return new WP_Error( 'jkssb_asset_missing', 'No Supabase asset is linked to this request.' );
        }
        return $this->signed_post( array(
            'action'             => 'create_delivery_url',
            'asset_id'           => $asset_id,
            'expires_in_seconds' => isset( $input['expires_in_seconds'] ) ? min( 21600, max( 60, absint( $input['expires_in_seconds'] ) ) ) : 3600,
        ) );
    }


    public function can_update() {
        return current_user_can( 'manage_options' ) && current_user_can( 'update_plugins' ) && current_user_can( 'install_plugins' );
    }

    public function ability_inspect_jksh_runtime() {
        global $wpdb;
        $tables = array();
        $prefix = $wpdb->esc_like( $wpdb->prefix . 'jksh_' ) . '%';
        $names = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $prefix ) );
        foreach ( (array) $names as $table ) {
            $cols = $wpdb->get_results( 'DESCRIBE `' . esc_sql( $table ) . '`', ARRAY_A );
            $tables[] = array(
                'table'   => $table,
                'columns' => array_map( function( $row ) {
                    return array(
                        'field' => isset( $row['Field'] ) ? $row['Field'] : '',
                        'type'  => isset( $row['Type'] ) ? $row['Type'] : '',
                        'null'  => isset( $row['Null'] ) ? $row['Null'] : '',
                        'key'   => isset( $row['Key'] ) ? $row['Key'] : '',
                        'default' => isset( $row['Default'] ) ? $row['Default'] : null,
                    );
                }, (array) $cols ),
            );
        }
        $classes = array();
        foreach ( get_declared_classes() as $class ) {
            if ( 0 !== strpos( $class, 'JKSH' ) && 0 !== strpos( $class, 'JK\\Social' ) ) {
                continue;
            }
            try {
                $r = new ReflectionClass( $class );
                $public = array();
                foreach ( $r->getMethods( ReflectionMethod::IS_PUBLIC ) as $m ) {
                    if ( $m->getDeclaringClass()->getName() !== $class ) {
                        continue;
                    }
                    $public[] = $m->getName();
                }
                $classes[] = array( 'class' => $class, 'public_methods' => $public );
            } catch ( Throwable $e ) {
                // Skip unloadable reflection targets.
            }
        }
        sort( $names );
        usort( $classes, function( $a, $b ) { return strcmp( $a['class'], $b['class'] ); } );
        $latest_records = null;
        $content_table = $wpdb->prefix . 'jksh_content';
        $content_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $content_table ) );
        if ( $content_exists === $content_table ) {
            $latest_content_id = absint( $wpdb->get_var( "SELECT id FROM `{$content_table}` ORDER BY id DESC LIMIT 1" ) );
            if ( $latest_content_id ) {
                $inspected = $this->ability_inspect_jksh_records( array( 'content_id' => $latest_content_id ) );
                if ( ! is_wp_error( $inspected ) ) {
                    $latest_records = $inspected;
                }
            }
        }
        return array(
            'ok'       => true,
            'bridge_version' => self::VERSION,
            'tables'   => $tables,
            'classes'  => $classes,
            'latest_content_records' => $latest_records,
            'secrets_exposed' => false,
        );
    }

    private function sanitize_runtime_value( $value, $key = '' ) {
        if ( preg_match( '/(?:token|secret|credential|authorization|password|private[_-]?key|access[_-]?key|refresh[_-]?key)/i', (string) $key ) ) {
            return '[redacted]';
        }
        if ( is_array( $value ) ) {
            $out = array();
            foreach ( $value as $k => $v ) {
                $out[ $k ] = $this->sanitize_runtime_value( $v, (string) $k );
            }
            return $out;
        }
        if ( is_object( $value ) ) {
            return $this->sanitize_runtime_value( get_object_vars( $value ), $key );
        }
        return $value;
    }

    private function decode_sanitized_json_field( $raw ) {
        if ( null === $raw || '' === $raw ) {
            return null;
        }
        $decoded = json_decode( $raw, true );
        if ( JSON_ERROR_NONE !== json_last_error() ) {
            return '[invalid-json]';
        }
        return $this->sanitize_runtime_value( $decoded );
    }

    public function ability_inspect_jksh_records( $input ) {
        global $wpdb;
        $content_id = isset( $input['content_id'] ) ? absint( $input['content_id'] ) : 0;
        if ( ! $content_id ) {
            return new WP_Error( 'jkssb_content_id_required', 'A valid JK Social Hub content_id is required.' );
        }
        $content_table  = $wpdb->prefix . 'jksh_content';
        $variant_table  = $wpdb->prefix . 'jksh_variants';
        $job_table      = $wpdb->prefix . 'jksh_jobs';
        $media_table    = $wpdb->prefix . 'jksh_media';
        foreach ( array( $content_table, $variant_table, $job_table, $media_table ) as $table ) {
            $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
            if ( $exists !== $table ) {
                return new WP_Error( 'jkssb_jksh_table_missing', 'A required JK Social Hub table is missing.', array( 'table' => $table ) );
            }
        }
        $content = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$content_table}` WHERE id=%d", $content_id ), ARRAY_A );
        if ( ! $content ) {
            return new WP_Error( 'jkssb_content_not_found', 'JK Social Hub content record was not found.' );
        }
        foreach ( array( 'media_json', 'meta_json' ) as $field ) {
            if ( array_key_exists( $field, $content ) ) {
                $content[ $field ] = $this->decode_sanitized_json_field( $content[ $field ] );
            }
        }
        $variants = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$variant_table}` WHERE content_id=%d ORDER BY id ASC", $content_id ), ARRAY_A );
        foreach ( $variants as &$variant ) {
            foreach ( array( 'media_json', 'analytics_json', 'fields_json' ) as $field ) {
                if ( array_key_exists( $field, $variant ) ) {
                    $variant[ $field ] = $this->decode_sanitized_json_field( $variant[ $field ] );
                }
            }
        }
        unset( $variant );
        $jobs = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$job_table}` WHERE content_id=%d ORDER BY id ASC", $content_id ), ARRAY_A );
        foreach ( $jobs as &$job ) {
            foreach ( array( 'payload_json', 'last_response_json' ) as $field ) {
                if ( array_key_exists( $field, $job ) ) {
                    $job[ $field ] = $this->decode_sanitized_json_field( $job[ $field ] );
                }
            }
            if ( isset( $job['last_error'] ) && is_string( $job['last_error'] ) && strlen( $job['last_error'] ) > 2000 ) {
                $job['last_error'] = substr( $job['last_error'], 0, 2000 ) . '...';
            }
        }
        unset( $job );
        $media = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$media_table}` WHERE content_id=%d ORDER BY sort_order ASC, id ASC", $content_id ), ARRAY_A );
        foreach ( $media as &$row ) {
            if ( array_key_exists( 'meta_json', $row ) ) {
                $row['meta_json'] = $this->decode_sanitized_json_field( $row['meta_json'] );
            }
        }
        unset( $row );
        return array(
            'ok'        => true,
            'content'   => $content,
            'variants'  => $variants,
            'jobs'      => $jobs,
            'media'     => $media,
            'secrets_exposed' => false,
        );
    }

    private function direct_session_key( $upload_id ) {
        return 'jkssb_direct_' . md5( (string) $upload_id );
    }

    private function get_direct_session( $upload_id ) {
        if ( ! preg_match( '/^[a-f0-9-]{36}$/i', (string) $upload_id ) ) {
            return new WP_Error( 'jkssb_direct_upload_id', 'Invalid direct upload ID.' );
        }
        $session = get_transient( $this->direct_session_key( $upload_id ) );
        if ( ! is_array( $session ) || empty( $session['path'] ) ) {
            return new WP_Error( 'jkssb_direct_session_missing', 'Direct upload session is missing or expired.' );
        }
        return $session;
    }

    public function ability_begin_direct_upload( $input ) {
        $allowed = array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif', 'video/mp4', 'video/quicktime', 'video/webm' );
        $filename = isset( $input['filename'] ) ? sanitize_file_name( $input['filename'] ) : '';
        $mime = isset( $input['mime_type'] ) ? sanitize_mime_type( $input['mime_type'] ) : '';
        $bytes = isset( $input['bytes'] ) ? absint( $input['bytes'] ) : 0;
        $sha256 = isset( $input['sha256'] ) ? strtolower( sanitize_text_field( $input['sha256'] ) ) : '';
        if ( ! $filename || ! in_array( $mime, $allowed, true ) || $bytes < 1 || $bytes > self::MAX_BYTES || ! preg_match( '/^[a-f0-9]{64}$/', $sha256 ) ) {
            return new WP_Error( 'jkssb_direct_invalid', 'Direct upload metadata is invalid.' );
        }
        $upload_id = wp_generate_uuid4();
        $path = wp_tempnam( 'jkssb-' . $upload_id . '-' . $filename );
        if ( ! $path || ! file_exists( $path ) ) {
            return new WP_Error( 'jkssb_direct_temp', 'Could not create the temporary direct-upload buffer.' );
        }
        $session = array(
            'path' => $path, 'filename' => $filename, 'mime_type' => $mime, 'bytes' => $bytes, 'sha256' => $sha256,
            'width' => isset( $input['width'] ) ? absint( $input['width'] ) : null,
            'height' => isset( $input['height'] ) ? absint( $input['height'] ) : null,
            'duration_ms' => isset( $input['duration_ms'] ) ? absint( $input['duration_ms'] ) : null,
            'alt_text' => isset( $input['alt_text'] ) ? sanitize_text_field( $input['alt_text'] ) : '',
            'ai_generated' => ! empty( $input['ai_generated'] ),
            'product_refs' => isset( $input['product_refs'] ) && is_array( $input['product_refs'] ) ? $input['product_refs'] : array(),
            'metadata' => isset( $input['metadata'] ) && is_array( $input['metadata'] ) ? $input['metadata'] : array(),
            'created_at' => time(),
        );
        set_transient( $this->direct_session_key( $upload_id ), $session, HOUR_IN_SECONDS );
        return array( 'ok' => true, 'upload_id' => $upload_id, 'next_offset' => 0, 'max_chunk_bytes' => self::DIRECT_CHUNK_BYTES, 'expires_in_seconds' => HOUR_IN_SECONDS );
    }

    public function ability_append_direct_upload_chunk( $input ) {
        $upload_id = isset( $input['upload_id'] ) ? sanitize_text_field( $input['upload_id'] ) : '';
        $session = $this->get_direct_session( $upload_id );
        if ( is_wp_error( $session ) ) return $session;
        $offset = isset( $input['offset'] ) ? absint( $input['offset'] ) : 0;
        $current = file_exists( $session['path'] ) ? filesize( $session['path'] ) : false;
        if ( false === $current || (int) $current !== (int) $offset ) {
            return new WP_Error( 'jkssb_direct_offset', 'Chunk offset does not match the current upload position.', array( 'next_offset' => false === $current ? null : (int) $current ) );
        }
        $chunk = isset( $input['chunk_base64'] ) ? base64_decode( $input['chunk_base64'], true ) : false;
        if ( false === $chunk || '' === $chunk || strlen( $chunk ) > self::DIRECT_CHUNK_BYTES ) {
            return new WP_Error( 'jkssb_direct_chunk', 'Direct upload chunk is invalid or too large.' );
        }
        if ( $current + strlen( $chunk ) > (int) $session['bytes'] ) {
            return new WP_Error( 'jkssb_direct_overflow', 'Chunk would exceed the declared original file size.' );
        }
        $written = file_put_contents( $session['path'], $chunk, FILE_APPEND | LOCK_EX );
        unset( $chunk );
        if ( false === $written ) return new WP_Error( 'jkssb_direct_write', 'Could not append the direct upload chunk.' );
        set_transient( $this->direct_session_key( $upload_id ), $session, HOUR_IN_SECONDS );
        return array( 'ok' => true, 'upload_id' => $upload_id, 'next_offset' => (int) $current + (int) $written, 'complete' => ( (int) $current + (int) $written ) === (int) $session['bytes'] );
    }

    private function create_external_attachment_shell( $session, $asset ) {
        if ( empty( $asset['id'] ) ) return new WP_Error( 'jkssb_direct_asset', 'Ready Supabase asset ID is missing.' );
        $delivery = self::DELIVERY_BASE . rawurlencode( (string) $asset['id'] );
        $attachment_id = wp_insert_attachment( array(
            'post_title' => sanitize_text_field( pathinfo( $session['filename'], PATHINFO_FILENAME ) ),
            'post_status' => 'inherit',
            'post_mime_type' => sanitize_mime_type( $session['mime_type'] ),
            'guid' => esc_url_raw( $delivery ),
        ), '', 0, true );
        if ( is_wp_error( $attachment_id ) ) return $attachment_id;
        update_post_meta( $attachment_id, '_jkssb_asset_id', sanitize_text_field( $asset['id'] ) );
        if ( ! empty( $asset['asset_key'] ) ) update_post_meta( $attachment_id, '_jkssb_asset_key', sanitize_text_field( $asset['asset_key'] ) );
        if ( ! empty( $asset['object_path'] ) ) update_post_meta( $attachment_id, '_jkssb_object_path', sanitize_text_field( $asset['object_path'] ) );
        update_post_meta( $attachment_id, '_jkssb_sha256', sanitize_text_field( $session['sha256'] ) );
        update_post_meta( $attachment_id, '_jkssb_external_only', '1' );
        update_post_meta( $attachment_id, '_jkssb_delivery_url', esc_url_raw( $delivery ) );
        if ( ! empty( $session['alt_text'] ) ) update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $session['alt_text'] ) );
        return array( 'attachment_id' => (int) $attachment_id, 'delivery_url' => $delivery );
    }

    public function ability_finalize_direct_upload( $input ) {
        $upload_id = isset( $input['upload_id'] ) ? sanitize_text_field( $input['upload_id'] ) : '';
        $session = $this->get_direct_session( $upload_id );
        if ( is_wp_error( $session ) ) return $session;
        $size = file_exists( $session['path'] ) ? filesize( $session['path'] ) : false;
        if ( false === $size || (int) $size !== (int) $session['bytes'] ) {
            return new WP_Error( 'jkssb_direct_incomplete', 'Direct upload is not complete.', array( 'received_bytes' => false === $size ? 0 : (int) $size, 'expected_bytes' => (int) $session['bytes'] ) );
        }
        $actual_sha = hash_file( 'sha256', $session['path'] );
        if ( ! hash_equals( $session['sha256'], $actual_sha ) ) {
            return new WP_Error( 'jkssb_direct_hash', 'Direct upload SHA-256 does not match the declared original.' );
        }
        $prepare = $this->signed_post( array(
            'action' => 'prepare_upload', 'filename' => $session['filename'], 'mime_type' => $session['mime_type'], 'bytes' => (int) $session['bytes'],
            'sha256' => $actual_sha, 'width' => $session['width'], 'height' => $session['height'], 'duration_ms' => $session['duration_ms'],
            'source' => 'chatgpt_direct', 'source_reference' => 'direct:' . $upload_id, 'alt_text' => $session['alt_text'],
            'ai_generated' => ! empty( $session['ai_generated'] ), 'product_refs' => $session['product_refs'], 'metadata' => $session['metadata'],
        ) );
        if ( is_wp_error( $prepare ) ) return $prepare;
        if ( ! empty( $prepare['duplicate'] ) && ! empty( $prepare['asset']['id'] ) ) {
            $asset = $prepare['asset'];
        } else {
            if ( empty( $prepare['asset_id'] ) || empty( $prepare['signed_upload_url'] ) ) return new WP_Error( 'jkssb_direct_prepare', 'Vault did not return a direct upload target.' );
            $code = 0;
            if ( function_exists( 'curl_init' ) ) { $fh = fopen( $session['path'], 'rb' ); if ( ! $fh ) return new WP_Error( 'jkssb_direct_read', 'Could not stream the temporary original.' ); $ch = curl_init( $prepare['signed_upload_url'] ); curl_setopt( $ch, CURLOPT_UPLOAD, true ); curl_setopt( $ch, CURLOPT_INFILE, $fh ); curl_setopt( $ch, CURLOPT_INFILESIZE, (int) $session['bytes'] ); curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Content-Type: ' . $session['mime_type'], 'Cache-Control: max-age=3600', 'x-upsert: false' ) ); curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true ); curl_setopt( $ch, CURLOPT_TIMEOUT, 900 ); curl_exec( $ch ); $code = (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE ); $cerr = curl_error( $ch ); curl_close( $ch ); fclose( $fh ); if ( $cerr ) return new WP_Error( 'jkssb_direct_storage_transport', $cerr ); } else { $binary = file_get_contents( $session['path'] ); if ( false === $binary ) return new WP_Error( 'jkssb_direct_read', 'Could not read the temporary original.' ); $upload = wp_remote_request( $prepare['signed_upload_url'], array( 'method' => 'PUT', 'timeout' => 900, 'headers' => array( 'Content-Type' => $session['mime_type'], 'Cache-Control' => 'max-age=3600', 'x-upsert' => 'false' ), 'body' => $binary, 'data_format' => 'body' ) ); unset( $binary ); if ( is_wp_error( $upload ) ) return $upload; $code = wp_remote_retrieve_response_code( $upload ); }
            if ( $code < 200 || $code >= 300 ) return new WP_Error( 'jkssb_direct_storage', 'Supabase Storage rejected the original media upload.', array( 'status' => $code ) );
            $final = $this->signed_post( array( 'action' => 'finalize_upload', 'asset_id' => sanitize_text_field( $prepare['asset_id'] ) ) );
            if ( is_wp_error( $final ) ) return $final;
            $asset = isset( $final['asset'] ) && is_array( $final['asset'] ) ? $final['asset'] : array();
        }
        $shell = $this->create_external_attachment_shell( $session, $asset );
        if ( is_wp_error( $shell ) ) return $shell;
        @unlink( $session['path'] );
        delete_transient( $this->direct_session_key( $upload_id ) );
        $result = array( 'ok' => true, 'upload_id' => $upload_id, 'original_sha256' => $actual_sha, 'asset' => $asset, 'attachment_id' => $shell['attachment_id'], 'delivery_url' => $shell['delivery_url'], 'wordpress_media_bytes' => false );
        if ( ! empty( $session['metadata']['jksh_live_request'] ) && is_array( $session['metadata']['jksh_live_request'] ) ) {
            $live = $this->create_jksh_live_content( $shell['attachment_id'], $session['metadata']['jksh_live_request'], $asset );
            if ( is_wp_error( $live ) ) {
                $live->add_data( array_merge( (array) $live->get_error_data(), array( 'media_ingest_succeeded' => true, 'attachment_id' => $shell['attachment_id'], 'asset_id' => isset( $asset['id'] ) ? $asset['id'] : '' ) ) );
                return $live;
            }
            $result['live_schedule'] = $live;
        }
        return $result;
    }

    public function ability_abort_direct_upload( $input ) {
        $upload_id = isset( $input['upload_id'] ) ? sanitize_text_field( $input['upload_id'] ) : '';
        $session = $this->get_direct_session( $upload_id );
        if ( is_wp_error( $session ) ) return array( 'ok' => true, 'already_gone' => true );
        if ( ! empty( $session['path'] ) && file_exists( $session['path'] ) ) @unlink( $session['path'] );
        delete_transient( $this->direct_session_key( $upload_id ) );
        return array( 'ok' => true, 'aborted' => true );
    }

    public function ability_ingest_from_url( $input ) {
        $url = isset( $input['url'] ) ? esc_url_raw( $input['url'] ) : '';
        if ( ! $url || 0 !== stripos( $url, 'https://' ) ) {
            return new WP_Error( 'jkssb_https_required', 'A valid HTTPS media URL is required.' );
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $tmp = download_url( $url, 60 );
        if ( is_wp_error( $tmp ) ) {
            return $tmp;
        }
        if ( filesize( $tmp ) > self::MAX_BYTES ) {
            @unlink( $tmp );
            return new WP_Error( 'jkssb_file_size', 'Downloaded media exceeds the 50 MB Phase 2 limit.' );
        }
        $filename = ! empty( $input['filename'] ) ? sanitize_file_name( $input['filename'] ) : sanitize_file_name( wp_basename( wp_parse_url( $url, PHP_URL_PATH ) ) );
        if ( ! $filename ) {
            $filename = 'jk-social-upload-' . gmdate( 'Ymd-His' );
        }
        $file_array = array( 'name' => $filename, 'tmp_name' => $tmp );
        $attachment_id = media_handle_sideload( $file_array, 0, isset( $input['title'] ) ? sanitize_text_field( $input['title'] ) : '' );
        if ( is_wp_error( $attachment_id ) ) {
            @unlink( $tmp );
            return $attachment_id;
        }
        if ( isset( $input['alt_text'] ) ) {
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $input['alt_text'] ) );
        }
        $ingest = $this->ability_ingest_media( array(
            'attachment_id' => $attachment_id,
            'alt_text'      => isset( $input['alt_text'] ) ? $input['alt_text'] : '',
            'ai_generated'  => ! empty( $input['ai_generated'] ),
            'product_refs'  => isset( $input['product_refs'] ) && is_array( $input['product_refs'] ) ? $input['product_refs'] : array(),
            'metadata'      => isset( $input['metadata'] ) && is_array( $input['metadata'] ) ? $input['metadata'] : array(),
        ) );
        if ( is_wp_error( $ingest ) ) {
            return $ingest;
        }
        $ingest['wordpress_attachment_id'] = $attachment_id;
        return $ingest;
    }

    private function bridge_plugin_basename() {
        return plugin_basename( __FILE__ );
    }

    private function inspect_update_package( $attachment_id, $expected_sha256 ) {
        $attachment_id = absint( $attachment_id );
        $expected_sha256 = strtolower( sanitize_text_field( $expected_sha256 ) );
        if ( ! $attachment_id || 'attachment' !== get_post_type( $attachment_id ) ) {
            return new WP_Error( 'jkssb_update_attachment', 'A valid ZIP media attachment is required.' );
        }
        $file = get_attached_file( $attachment_id );
        if ( ! $file || ! is_readable( $file ) || 'zip' !== strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ) ) {
            return new WP_Error( 'jkssb_update_zip', 'Update package must be a readable ZIP.' );
        }
        $actual = strtolower( hash_file( 'sha256', $file ) );
        if ( ! hash_equals( $expected_sha256, $actual ) ) {
            return new WP_Error( 'jkssb_update_checksum', 'Update package SHA-256 does not match.' );
        }
        if ( ! class_exists( 'ZipArchive' ) ) {
            return new WP_Error( 'jkssb_update_ziparchive', 'ZipArchive is required for bridge update preflight.' );
        }
        $zip = new ZipArchive();
        if ( true !== $zip->open( $file ) ) {
            return new WP_Error( 'jkssb_update_open', 'Could not open update ZIP.' );
        }
        $main = 'jk-social-supabase-bridge/jk-social-supabase-bridge.php';
        $idx = $zip->locateName( $main, ZipArchive::FL_NOCASE );
        if ( false === $idx ) {
            $zip->close();
            return new WP_Error( 'jkssb_update_identity', 'ZIP is not a JK Social Supabase Bridge package.' );
        }
        $source = $zip->getFromIndex( $idx );
        $zip->close();
        if ( false === $source || ! preg_match( '/^\s*\*\s*Plugin Name:\s*JK Social Supabase Bridge\s*$/mi', $source ) || ! preg_match( '/^\s*\*\s*Version:\s*([^\r\n]+)/mi', $source, $m ) ) {
            return new WP_Error( 'jkssb_update_header', 'Bridge package headers are invalid.' );
        }
        return array( 'ok' => true, 'attachment_id' => $attachment_id, 'sha256' => $actual, 'package_version' => trim( $m[1] ), 'file' => $file );
    }

    private function upload_bundles() { $v = get_option( 'jkssb_upload_bundles_v1', array() ); return is_array( $v ) ? $v : array(); }
    private function save_upload_bundles( $items ) { update_option( 'jkssb_upload_bundles_v1', array_slice( array_values( $items ), 0, 100 ), false ); }
    public function ability_list_upload_drafts( $input = array() ) { return array( 'ok' => true, 'items' => array_slice( $this->upload_bundles(), 0, 30 ) ); }
    public function ability_get_upload_draft( $input ) { $id = isset( $input['bundle_id'] ) ? sanitize_text_field( $input['bundle_id'] ) : ''; foreach ( $this->upload_bundles() as $b ) if ( isset( $b['bundle_id'] ) && hash_equals( (string) $b['bundle_id'], $id ) ) return array( 'ok' => true, 'item' => $b ); return new WP_Error( 'jkssb_bundle_missing', 'Upload bundle not found.' ); }
    private function create_youtube_community_handoff( $bundle, $input, $content_id = 0 ) {
        global $wpdb;
        $ids = array_values( array_filter( array_map( 'absint', $bundle['attachment_ids'] ?? array() ) ) );
        if ( empty( $ids ) ) return new WP_Error( 'jkssb_yt_community_media', 'YouTube Community handoff requires uploaded media.' );
        $scheduled_at = sanitize_text_field( $input['scheduled_at_utc'] ?? '' );
        $title = sanitize_text_field( $input['title'] ?? 'JustKalinga Community Post' );
        $body = sanitize_textarea_field( $input['body'] ?? '' );
        $cta = sanitize_text_field( $input['cta'] ?? 'Jai Jagannātha 🙏' );
        $yt_fields = isset( $input['platform_fields']['youtube'] ) && is_array( $input['platform_fields']['youtube'] ) ? $this->sanitize_live_value( $input['platform_fields']['youtube'] ) : array();
        $hashtags = isset( $yt_fields['hashtags'] ) ? sanitize_text_field( $yt_fields['hashtags'] ) : '';
        $now = gmdate( 'Y-m-d H:i:s' );
        if ( ! $content_id ) {
            $content_uuid = wp_generate_uuid4();
            $ok = $wpdb->insert( $wpdb->prefix . 'jksh_content', array(
                'uuid' => $content_uuid, 'title' => $title, 'content_type' => 'youtube_community', 'body' => $body, 'status' => 'community_ready',
                'media_json' => wp_json_encode( $ids ), 'author_id' => get_current_user_id(), 'created_at' => $now, 'updated_at' => $now,
                'meta_json' => wp_json_encode( array( 'source' => 'supabase_bridge', 'workflow' => 'youtube_community_handoff_v1', 'bundle_id' => sanitize_text_field( $bundle['bundle_id'] ?? '' ) ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
            ) );
            if ( false === $ok ) return new WP_Error( 'jkssb_yt_community_content', 'Could not create YouTube Community content row.' );
            $content_id = (int) $wpdb->insert_id;
        }
        $delivery_urls = array();
        foreach ( $ids as $id ) { $u = get_post_meta( $id, '_jkssb_delivery_url', true ); if ( $u ) $delivery_urls[] = esc_url_raw( $u ); }
        $variant_uuid = wp_generate_uuid4();
        $fields = array_merge( $yt_fields, array(
            'community_handoff' => true,
            'manual_required' => true,
            'youtube_community_url' => 'https://www.youtube.com/channel/UCkdivvj0X_aO6FCpa394sgQ/community',
            'media_delivery_urls' => $delivery_urls,
            'note' => 'YouTube does not expose an official Community post creation endpoint. This job is prepared for one-click/manual handoff and must not be reported as API-published.',
        ) );
        $ok = $wpdb->insert( $wpdb->prefix . 'jksh_variants', array(
            'uuid' => $variant_uuid, 'content_id' => $content_id, 'platform' => 'youtube', 'publication_type' => 'community_post',
            'title' => $title, 'caption' => $body, 'description' => $body, 'hashtags' => $hashtags, 'cta' => $cta,
            'media_json' => wp_json_encode( $ids ), 'publish_at' => $scheduled_at, 'status' => 'community_ready', 'external_id' => '',
            'external_url' => 'https://www.youtube.com/channel/UCkdivvj0X_aO6FCpa394sgQ/community', 'analytics_json' => wp_json_encode( array() ),
            'created_at' => $now, 'updated_at' => $now, 'fields_json' => wp_json_encode( $fields, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
        ) );
        if ( false === $ok ) return new WP_Error( 'jkssb_yt_community_variant', 'Could not create YouTube Community variant.' );
        $variant_id = (int) $wpdb->insert_id;
        $job_uuid = wp_generate_uuid4();
        $idempotency_key = hash( 'sha256', 'jkssb-community-v1|' . sanitize_text_field( $bundle['bundle_id'] ?? '' ) . '|' . $scheduled_at );
        $payload = array( 'variant_id' => $variant_id, 'publish_mode' => 'manual_handoff', 'manual_required' => true, 'source' => 'upload_bundle', 'media_attachment_ids' => $ids );
        $ok = $wpdb->insert( $wpdb->prefix . 'jksh_jobs', array(
            'uuid' => $job_uuid, 'idempotency_key' => $idempotency_key, 'content_id' => $content_id, 'variant_id' => $variant_id,
            'platform' => 'youtube', 'job_type' => 'community_handoff', 'status' => 'community_ready', 'attempts' => 0, 'max_attempts' => 1,
            'payload_json' => wp_json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ), 'last_response_json' => wp_json_encode( array() ),
            'last_error' => '', 'scheduled_at' => $scheduled_at, 'created_at' => $now, 'updated_at' => $now,
        ) );
        if ( false === $ok ) return new WP_Error( 'jkssb_yt_community_job', 'Could not create YouTube Community handoff job.' );
        return array( 'platform' => 'youtube', 'publication_type' => 'community_post', 'variant_id' => $variant_id, 'job_id' => (int) $wpdb->insert_id, 'publish_mode' => 'manual_handoff', 'status' => 'community_ready' );
    }

    public function ability_queue_upload_draft( $input ) {
        if ( empty( $input['confirm_live'] ) || true !== $input['confirm_live'] ) return new WP_Error( 'jkssb_live_confirm_required', 'confirm_live=true is required.' );
        $got = $this->ability_get_upload_draft( array( 'bundle_id' => $input['bundle_id'] ?? '' ) ); if ( is_wp_error( $got ) ) return $got;
        $b = $got['item'];
        $ids = array_values( array_filter( array_map( 'absint', $b['attachment_ids'] ?? array() ) ) ); if ( empty( $ids ) ) return new WP_Error( 'jkssb_bundle_media', 'Bundle has no finalized media.' );
        $map = array( 'single_post' => 'single_image', 'carousel' => 'carousel', 'reel' => 'reel', 'long_video' => 'video' );
        $ct = $map[ $b['content_type'] ?? '' ] ?? 'single_image';
        $requested = isset( $input['platforms'] ) && is_array( $input['platforms'] ) ? array_values( array_unique( array_map( 'sanitize_key', $input['platforms'] ) ) ) : array();
        $meta_platforms = array_values( array_intersect( $requested, array( 'instagram', 'facebook' ) ) );
        $wants_youtube = in_array( 'youtube', $requested, true );
        $title = sanitize_text_field( $input['title'] ?? '' );
        $body = sanitize_textarea_field( $input['body'] ?? '' );
        if ( '' === $title ) $title = 'JustKalinga Social Post';
        $first_asset = array( 'id' => get_post_meta( $ids[0], '_jkssb_asset_id', true ), 'asset_key' => get_post_meta( $ids[0], '_jkssb_asset_key', true ) );
        $result = array( 'ok' => true, 'bundle_id' => sanitize_text_field( $b['bundle_id'] ?? '' ), 'variants' => array() );
        $content_id = 0;
        if ( ! empty( $meta_platforms ) ) {
            $req = array( 'confirm_live' => true, 'request_id' => 'upload-' . sanitize_key( $b['bundle_id'] ) . '-' . gmdate( 'YmdHis' ), 'title' => $title, 'body' => $body, 'content_type' => $ct, 'platforms' => $meta_platforms, 'scheduled_at_utc' => sanitize_text_field( $input['scheduled_at_utc'] ?? '' ), 'media_attachment_ids' => $ids, 'platform_fields' => is_array( $input['platform_fields'] ?? null ) ? $input['platform_fields'] : array(), 'location' => is_array( $input['location'] ?? null ) ? $input['location'] : array(), 'products' => is_array( $input['products'] ?? null ) ? $input['products'] : array(), 'cta' => sanitize_text_field( $input['cta'] ?? 'Jai Jagannātha 🙏' ) );
            if ( ! empty( $b['add_to_story'] ) ) { $req['platform_fields']['instagram']['story_after_publish'] = true; $req['platform_fields']['instagram']['highlight_name'] = sanitize_text_field( $b['highlight_name'] ?? '' ); }
            $meta = $this->create_jksh_live_content( $ids[0], $req, $first_asset ); if ( is_wp_error( $meta ) ) return $meta;
            $content_id = isset( $meta['content_id'] ) ? absint( $meta['content_id'] ) : 0;
            $result = array_merge( $result, $meta );
        }
        if ( $wants_youtube && in_array( $ct, array( 'single_image', 'image', 'carousel' ), true ) ) {
            $yt = $this->create_youtube_community_handoff( $b, $input, $content_id ); if ( is_wp_error( $yt ) ) return $yt;
            if ( empty( $result['variants'] ) ) $result['variants'] = array();
            $result['variants'][] = $yt;
            $result['youtube_community'] = $yt;
            if ( ! $content_id && isset( $yt['content_id'] ) ) $result['content_id'] = absint( $yt['content_id'] );
        } elseif ( $wants_youtube ) {
            $result['youtube_note'] = 'Video/Short publishing uses the YouTube upload adapter, not the Community handoff path.';
        }
        if ( empty( $meta_platforms ) && ! $wants_youtube ) return new WP_Error( 'jkssb_live_platforms', 'At least one supported platform is required.' );
        return $result;
    }

    public function register_upload_page() { add_menu_page( 'Social Upload', 'Social Upload', 'manage_options', 'jksh-social-upload', array( $this, 'render_upload_page' ), 'dashicons-upload', 3 ); }
    private function ui_check() { if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'Forbidden' ), 403 ); check_ajax_referer( 'jkssb_social_upload', 'nonce' ); }
    public function ajax_ui_begin() { $this->ui_check(); $filename=sanitize_file_name($_POST['filename']??'');$mime=sanitize_mime_type($_POST['mime_type']??'');$bytes=absint($_POST['bytes']??0);$allowed=array('image/jpeg','image/png','image/webp','image/gif','video/mp4','video/quicktime','video/webm');if(!$filename||!in_array($mime,$allowed,true)||$bytes<1||$bytes>self::MAX_BYTES)wp_send_json_error(array('message'=>'Invalid file or over 500 MB.'),422);$id=wp_generate_uuid4();$path=wp_tempnam('jkssb-ui-'.$id.'-'.$filename);if(!$path)wp_send_json_error(array('message'=>'Could not create upload buffer.'),500);$s=array('path'=>$path,'filename'=>$filename,'mime_type'=>$mime,'bytes'=>$bytes,'sha256'=>'','width'=>null,'height'=>null,'duration_ms'=>null,'alt_text'=>'','ai_generated'=>false,'product_refs'=>array(),'metadata'=>array('source'=>'wordpress_social_upload'),'created_at'=>time(),'server_hash'=>true);set_transient($this->direct_session_key($id),$s,6*HOUR_IN_SECONDS);wp_send_json_success(array('upload_id'=>$id,'max_chunk_bytes'=>self::DIRECT_CHUNK_BYTES)); }
    public function ajax_ui_chunk() { $this->ui_check();$id=sanitize_text_field($_POST['upload_id']??'');$offset=absint($_POST['offset']??0);$s=$this->get_direct_session($id);if(is_wp_error($s))wp_send_json_error(array('message'=>$s->get_error_message()),404);if(empty($_FILES['chunk']['tmp_name']))wp_send_json_error(array('message'=>'Missing chunk.'),400);$raw=file_get_contents($_FILES['chunk']['tmp_name']);if(false===$raw||strlen($raw)>self::DIRECT_CHUNK_BYTES)wp_send_json_error(array('message'=>'Invalid chunk.'),400);$current=filesize($s['path']);if((int)$current!==$offset)wp_send_json_error(array('message'=>'Offset mismatch','next_offset'=>(int)$current),409);$written=file_put_contents($s['path'],$raw,FILE_APPEND|LOCK_EX);if(false===$written)wp_send_json_error(array('message'=>'Write failed.'),500);wp_send_json_success(array('next_offset'=>$offset+$written)); }
    public function ajax_ui_finalize() { $this->ui_check();$id=sanitize_text_field($_POST['upload_id']??'');$s=$this->get_direct_session($id);if(is_wp_error($s))wp_send_json_error(array('message'=>$s->get_error_message()),404);$s['sha256']=hash_file('sha256',$s['path']);set_transient($this->direct_session_key($id),$s,6*HOUR_IN_SECONDS);$r=$this->ability_finalize_direct_upload(array('upload_id'=>$id));if(is_wp_error($r))wp_send_json_error(array('message'=>$r->get_error_message(),'data'=>$r->get_error_data()),500);wp_send_json_success($r); }
    public function ajax_ui_save_bundle() { $this->ui_check();$payload=json_decode(wp_unslash($_POST['payload']??''),true);if(!is_array($payload))wp_send_json_error(array('message'=>'Invalid bundle.'),400);$ids=array_values(array_filter(array_map('absint',$payload['attachment_ids']??array())));if(empty($ids))wp_send_json_error(array('message'=>'No uploaded media.'),400);$type=sanitize_key($payload['content_type']??'');if(!in_array($type,array('single_post','carousel','reel','long_video'),true))wp_send_json_error(array('message'=>'Invalid content type.'),400);$bundle=array('bundle_id'=>wp_generate_uuid4(),'content_type'=>$type,'attachment_ids'=>$ids,'asset_ids'=>array_map(function($id){return get_post_meta($id,'_jkssb_asset_id',true);},$ids),'filenames'=>array_map(function($id){return get_the_title($id);},$ids),'instructions'=>sanitize_textarea_field($payload['instructions']??''),'title'=>sanitize_text_field($payload['title']??''),'add_to_story'=>!empty($payload['add_to_story']),'highlight_name'=>sanitize_text_field($payload['highlight_name']??''),'location'=>sanitize_text_field($payload['location']??''),'product_refs'=>array_values(array_filter(array_map('sanitize_text_field',(array)($payload['product_refs']??array())))),'created_at_utc'=>gmdate('c'),'status'=>'uploaded');$items=$this->upload_bundles();array_unshift($items,$bundle);$this->save_upload_bundles($items);wp_send_json_success($bundle); }
    public function render_upload_page() { if(!current_user_can('manage_options'))return;$nonce=wp_create_nonce('jkssb_social_upload'); ?>
    <div class="wrap"><h1>JustKalinga Social Upload</h1><p>Upload originals here. Files go to the private Supabase vault; WordPress keeps only link/reference shells after finalization.</p><div style="max-width:900px;background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:24px"><p><strong>Content type</strong><br><select id="jkssb-type"><option value="single_post">Single Post</option><option value="carousel">Carousel</option><option value="reel">Reel / Short</option><option value="long_video">Long Video</option></select></p><p><strong>Working title / hint (optional)</strong><br><input id="jkssb-title" class="regular-text" placeholder="Hint only. ChatGPT will rewrite this before publishing."><br><small>This is context, not the final social title.</small></p><p><strong>Images / videos</strong> (up to 500 MB each)<br><input id="jkssb-files" type="file" multiple accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/quicktime,video/webm"></p><p><strong>Instructions / context for ChatGPT (optional)</strong><br><textarea id="jkssb-instructions" rows="4" style="width:100%" placeholder="Tell ChatGPT what this media is about. This text will not be published literally unless you explicitly ask."></textarea></p><p><label><input id="jkssb-story" type="checkbox" checked> Also prepare Instagram Story</label> &nbsp; <input id="jkssb-highlight" placeholder="Highlight name"></p><p><input id="jkssb-location" class="regular-text" placeholder="Location, e.g. Puri, Odisha"></p><p><input id="jkssb-products" style="width:100%" placeholder="Product names/SKUs, comma separated"></p><button class="button button-primary" id="jkssb-upload">Upload to Supabase</button><div id="jkssb-status" style="margin-top:18px;white-space:pre-wrap"></div></div><p><strong>After upload:</strong> tell ChatGPT “Post the latest carousel everywhere at 6 PM.”</p></div>
    <script>(()=>{const ajax=ajaxurl,nonce=<?php echo wp_json_encode($nonce); ?>,status=document.getElementById('jkssb-status');const post=async(fd)=>{fd.append('nonce',nonce);const r=await fetch(ajax,{method:'POST',body:fd,credentials:'same-origin'});const j=await r.json();if(!j.success)throw new Error((j.data&&j.data.message)||'Request failed');return j.data;};async function uploadFile(file,index,total){status.textContent='Uploading '+(index+1)+'/'+total+': '+file.name;let fd=new FormData();fd.append('action','jkssb_ui_begin');fd.append('filename',file.name);fd.append('mime_type',file.type);fd.append('bytes',file.size);const b=await post(fd);let off=0,chunk=b.max_chunk_bytes||4194304;while(off<file.size){const blob=file.slice(off,Math.min(file.size,off+chunk));fd=new FormData();fd.append('action','jkssb_ui_chunk');fd.append('upload_id',b.upload_id);fd.append('offset',String(off));fd.append('chunk',blob,file.name+'.part');const x=await post(fd);off=x.next_offset;status.textContent='Uploading '+(index+1)+'/'+total+': '+file.name+' '+Math.round(off/file.size*100)+'%';}fd=new FormData();fd.append('action','jkssb_ui_finalize');fd.append('upload_id',b.upload_id);return await post(fd);}document.getElementById('jkssb-upload').onclick=async(e)=>{e.preventDefault();const files=[...document.getElementById('jkssb-files').files];if(!files.length){status.textContent='Choose at least one file.';return;}try{const ids=[];for(let i=0;i<files.length;i++){const r=await uploadFile(files[i],i,files.length);ids.push(r.attachment_id||r.external_attachment_id||(r.shell&&r.shell.attachment_id));}const p={content_type:document.getElementById('jkssb-type').value,title:document.getElementById('jkssb-title').value,instructions:document.getElementById('jkssb-instructions').value,add_to_story:document.getElementById('jkssb-story').checked,highlight_name:document.getElementById('jkssb-highlight').value,location:document.getElementById('jkssb-location').value,product_refs:document.getElementById('jkssb-products').value.split(',').map(x=>x.trim()).filter(Boolean),attachment_ids:ids};let fd=new FormData();fd.append('action','jkssb_ui_save_bundle');fd.append('payload',JSON.stringify(p));const saved=await post(fd);status.textContent='✅ Uploaded to Supabase\nBundle: '+saved.bundle_id+'\nType: '+saved.content_type+'\nNow tell ChatGPT when and where to publish it.';}catch(err){status.textContent='❌ '+err.message;}};})();</script><?php }

    public function ability_inspect_jksh_runtime_with_uploads( $input = array() ) {
        $out = $this->ability_inspect_jksh_runtime( $input );
        if ( is_wp_error( $out ) ) return $out;
        if ( ! is_array( $out ) ) $out = array( 'ok' => true );
        $out['upload_bundles'] = array_slice( $this->upload_bundles(), 0, 30 );
        return $out;
    }

    public function ability_update_readiness() {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $data = get_plugin_data( __FILE__, false, false );
        return array(
            'ok' => true,
            'plugin' => $this->bridge_plugin_basename(),
            'current_version' => isset( $data['Version'] ) ? $data['Version'] : self::VERSION,
            'active' => is_plugin_active( $this->bridge_plugin_basename() ),
            'zip_supported' => class_exists( 'ZipArchive' ),
            'can_install_plugins' => current_user_can( 'install_plugins' ),
            'can_update_plugins' => current_user_can( 'update_plugins' ),
            'accepted_plugin_identity' => 'jk-social-supabase-bridge/jk-social-supabase-bridge.php',
        );
    }

    public function ability_preflight_update( $input ) {
        return $this->inspect_update_package( $input['attachment_id'], $input['expected_sha256'] );
    }

    public function ability_install_update( $input ) {
        if ( empty( $input['confirm'] ) ) {
            return new WP_Error( 'jkssb_update_confirm', 'confirm=true is required.' );
        }
        $preflight = $this->inspect_update_package( $input['attachment_id'], $input['expected_sha256'] );
        if ( is_wp_error( $preflight ) ) {
            return $preflight;
        }
        $current = $this->ability_update_readiness();
        if ( ! hash_equals( (string) $current['current_version'], (string) $input['expected_current_version'] ) ) {
            return new WP_Error( 'jkssb_update_version_changed', 'Installed bridge version changed since the caller inspected it.' );
        }
        if ( version_compare( $preflight['package_version'], $current['current_version'], '<=' ) ) {
            return new WP_Error( 'jkssb_update_not_newer', 'Bridge package version must be newer than the installed version.' );
        }
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $was_active = is_plugin_active( $this->bridge_plugin_basename() );
        $skin = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader( $skin );
        $result = $upgrader->install( $preflight['file'], array( 'overwrite_package' => true ) );
        if ( is_wp_error( $result ) || false === $result ) {
            return is_wp_error( $result ) ? $result : new WP_Error( 'jkssb_update_failed', 'Bridge update failed.' );
        }
        if ( $was_active && ! is_plugin_active( $this->bridge_plugin_basename() ) ) {
            $activated = activate_plugin( $this->bridge_plugin_basename() );
            if ( is_wp_error( $activated ) ) {
                return $activated;
            }
        }
        $plugin_file = WP_PLUGIN_DIR . '/jk-social-supabase-bridge/jk-social-supabase-bridge.php';
        $installed = file_exists( $plugin_file ) ? get_plugin_data( $plugin_file, false, false ) : array();
        $version = isset( $installed['Version'] ) ? $installed['Version'] : '';
        if ( ! hash_equals( (string) $preflight['package_version'], (string) $version ) ) {
            return new WP_Error( 'jkssb_update_verify_failed', 'Installed bridge version did not match the package after update.' );
        }
        if ( ! empty( $input['delete_package_after'] ) ) {
            wp_delete_attachment( absint( $input['attachment_id'] ), true );
        }
        return array( 'ok' => true, 'version' => $version, 'active' => is_plugin_active( $this->bridge_plugin_basename() ) );
    }

}

register_activation_hook( __FILE__, array( 'JKSSB_Bridge', 'activate' ) );
JKSSB_Bridge::instance();
