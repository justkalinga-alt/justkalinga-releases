JK Social Supabase Bridge 0.8.2

Adds YouTube Community manual handoff queue/receipts and a guarded 5-minute WP-Cron live supervisor for JK Social Hub YouTube Live + relay-worker automation. Preserves hybrid Supabase/WordPress media routing.


= 0.8.1 =
* IST-only user-facing scheduling for Bridge abilities and supervisor/community screens.
* Safe IST rescheduler for queued publish jobs.
* Accepts the live JustKalinga Social Hub plugin identity during maintenance export.

= 0.8.2 =
* Adds [jk_social_upload] shortcode and a secure standalone clean upload portal.
* Enterprise responsive upload UI with drag/drop, platform cards, carousel reordering and progress states.
* Standalone shortcode pages are login/capability protected and noindex.
