<?php
/**
 * Plugin Name: JustKalinga Social Hub
 * Plugin URI:  https://social.justkalinga.com/
 * Description: Internal social-media operating system for JustKalinga. v0.8.4 makes Asia/Kolkata (IST) the only human-facing scheduling and display timezone while preserving UTC internally for platform APIs, queue safety and token storage.
 * Version:     0.8.6
 * Author:      JustKalinga
 * Text Domain: jk-social-hub
 * Requires at least: 6.5
 * Requires PHP: 8.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'JKSH_VERSION', '0.8.6' );
define( 'JKSH_DB_VERSION', '0.4.0' );
define( 'JKSH_FILE', __FILE__ );
define( 'JKSH_DIR', plugin_dir_path( __FILE__ ) );
define( 'JKSH_URL', plugin_dir_url( __FILE__ ) );

spl_autoload_register(
	static function ( $class ) {
		$prefix = 'JKSH\\';
		if ( 0 !== strpos( $class, $prefix ) ) {
			return;
		}

		$relative = substr( $class, strlen( $prefix ) );
		$path     = JKSH_DIR . 'src/' . str_replace( '\\', '/', $relative ) . '.php';
		if ( is_readable( $path ) ) {
			require_once $path;
		}
	}
);

register_activation_hook( __FILE__, array( 'JKSH\\Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'JKSH\Deactivator', 'deactivate' ) );

// Register MCP Ability hooks as early as possible. WordPress requires abilities to be
// registered from wp_abilities_api_* actions; waiting until plugins_loaded can be too late.
( new JKSH\Mcp\Abilities() )->register();

add_action(
	'plugins_loaded',
	static function () {
		JKSH\Plugin::instance()->boot();
	}
);
