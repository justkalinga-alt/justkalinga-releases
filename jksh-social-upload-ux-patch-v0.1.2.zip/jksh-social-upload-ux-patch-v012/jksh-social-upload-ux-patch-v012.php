<?php
/**
 * Plugin Name: JKSH Social Upload UX Patch v0.1.1
 * Description: Safe UX patch for JK Social Hub Social Upload: platform availability, image drag ordering, and one separate video-only drag/drop cover uploader.
 * Version: 0.1.2
 * Author: JustKalinga
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Social_Upload_UX_Patch_V011 {
    const VERSION = '0.1.2';

    public static function init() {
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_admin' ], 99 );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_front' ], 99 );
        add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
    }

    private static function enqueue_assets() {
        $base = plugin_dir_url( __FILE__ );
        wp_enqueue_style( 'jksh-upload-ux-patch', $base . 'assets/upload-ux.css', [], self::VERSION );
        wp_enqueue_script( 'jksh-upload-ux-patch', $base . 'assets/upload-ux.js', [], self::VERSION, true );
        wp_localize_script( 'jksh-upload-ux-patch', 'JKSHUploadUXPatch', [
            'version' => self::VERSION,
            'restBase' => esc_url_raw( rest_url( 'jksh-upload-ux/v1/' ) ),
            'sandboxReadiness' => esc_url_raw( rest_url( 'jksh/v1/pinterest/sandbox/readiness' ) ),
            'productionReadiness' => esc_url_raw( rest_url( 'jksh/v1/pinterest/readiness' ) ),
            'nonce' => wp_create_nonce( 'wp_rest' ),
        ] );
    }

    public static function enqueue_admin( $hook ) {
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( 'jksh-social-upload' !== $page ) { return; }
        self::enqueue_assets();
    }

    public static function enqueue_front() {
        self::enqueue_assets();
    }

    public static function register_routes() {
        register_rest_route( 'jksh-upload-ux/v1', '/status', [
            'methods' => 'GET',
            'permission_callback' => function () { return current_user_can( 'manage_options' ); },
            'callback' => function () {
                return [
                    'ok' => true,
                    'version' => self::VERSION,
                    'main_plugin_exists' => is_dir( WP_PLUGIN_DIR . '/jk-social-hub' ),
                    'note' => 'Content-type detection fixed: YouTube is selectable for Reel/Short and Long video only; image-post YouTube remains manual. Sandbox image Pins supported; Pinterest Sandbox video Pins are not supported by Pinterest.',
                ];
            },
        ] );

        register_rest_route( 'jksh-upload-ux/v1', '/search', [
            'methods' => 'GET',
            'permission_callback' => function () { return current_user_can( 'manage_options' ); },
            'args' => [ 'q' => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ] ],
            'callback' => [ __CLASS__, 'search_source' ],
        ] );
    }

    public static function search_source( WP_REST_Request $request ) {
        $q = trim( (string) $request->get_param( 'q' ) );
        if ( '' === $q ) { return new WP_Error( 'empty_query', 'Query is required.', [ 'status' => 400 ] ); }
        $base = WP_PLUGIN_DIR . '/jk-social-hub';
        if ( ! is_dir( $base ) ) { return new WP_Error( 'missing_plugin', 'JK Social Hub directory not found.', [ 'status' => 404 ] ); }
        $out = [];
        $it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $base, FilesystemIterator::SKIP_DOTS ) );
        foreach ( $it as $file ) {
            if ( count( $out ) >= 30 ) { break; }
            if ( ! $file->isFile() ) { continue; }
            $ext = strtolower( $file->getExtension() );
            if ( ! in_array( $ext, [ 'php', 'js', 'css' ], true ) ) { continue; }
            $lines = @file( $file->getPathname(), FILE_IGNORE_NEW_LINES );
            if ( ! is_array( $lines ) ) { continue; }
            foreach ( $lines as $i => $line ) {
                if ( false === stripos( $line, $q ) ) { continue; }
                $start = max( 0, $i - 3 );
                $end = min( count( $lines ) - 1, $i + 5 );
                $excerpt = [];
                for ( $j = $start; $j <= $end; $j++ ) {
                    $excerpt[] = [ 'line' => $j + 1, 'text' => $lines[ $j ] ];
                }
                $out[] = [
                    'file' => ltrim( str_replace( $base, '', $file->getPathname() ), '/\\' ),
                    'line' => $i + 1,
                    'excerpt' => $excerpt,
                ];
                if ( count( $out ) >= 30 ) { break 2; }
            }
        }
        return [ 'ok' => true, 'query' => $q, 'count' => count( $out ), 'matches' => $out ];
    }
}
JKSH_Social_Upload_UX_Patch_V011::init();
