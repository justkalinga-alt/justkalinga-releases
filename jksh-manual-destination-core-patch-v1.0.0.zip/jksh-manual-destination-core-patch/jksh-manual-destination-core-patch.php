<?php
/**
 * Plugin Name: JKSH Manual Destination Core Patch
 * Description: One-time checksum-guarded patch for Social Upload manual destination mode.
 * Version: 1.0.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Manual_Destination_Core_Patch_V100 {
    const EXPECTED_SHA256 = 'a1dfe2ea27f37dd6c6592a92ad4cadaeba72790a0773c6d48c526d88de51afe0';

    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
    }

    public static function routes() {
        register_rest_route( 'jksh-manual-dest-patch/v1', '/status', array(
            'methods' => 'GET',
            'permission_callback' => function() { return current_user_can( 'manage_options' ); },
            'callback' => array( __CLASS__, 'status' ),
        ) );
        register_rest_route( 'jksh-manual-dest-patch/v1', '/apply', array(
            'methods' => 'POST',
            'permission_callback' => function() { return current_user_can( 'manage_options' ); },
            'callback' => array( __CLASS__, 'apply' ),
        ) );
    }

    private static function path() {
        return WP_PLUGIN_DIR . '/jk-social-supabase-bridge-disabled/jk-social-supabase-bridge.php';
    }

    public static function status() {
        $path = self::path();
        if ( ! is_readable( $path ) ) {
            return new WP_Error( 'missing_bridge', 'Bridge file is not readable.', array( 'status' => 404 ) );
        }
        $src = file_get_contents( $path );
        return rest_ensure_response( array(
            'ok' => true,
            'sha256' => hash( 'sha256', $src ),
            'bytes' => strlen( $src ),
            'platform_error_count' => substr_count( $src, 'Choose at least one platform.' ),
            'manual_js_count' => substr_count( $src, 'const platforms=[];' ),
            'drive_label_count' => substr_count( $src, '>50 MB · Google Drive' ),
        ) );
    }

    public static function apply( WP_REST_Request $request ) {
        $confirm = $request->get_param( 'confirm' );
        if ( true !== $confirm && 'true' !== $confirm && 1 !== $confirm && '1' !== $confirm ) {
            return new WP_Error( 'confirm_required', 'confirm=true required', array( 'status' => 400 ) );
        }

        $path = self::path();
        if ( ! is_readable( $path ) || ! is_writable( $path ) ) {
            return new WP_Error( 'bridge_unavailable', 'Bridge file is not readable/writable.', array( 'status' => 500 ) );
        }

        $src = file_get_contents( $path );
        if ( false === $src ) {
            return new WP_Error( 'read_failed', 'Could not read Bridge file.', array( 'status' => 500 ) );
        }

        $sha = hash( 'sha256', $src );
        if ( self::EXPECTED_SHA256 !== $sha ) {
            return new WP_Error( 'checksum_mismatch', 'Bridge checksum changed; refusing unsafe patch.', array(
                'status' => 409,
                'expected' => self::EXPECTED_SHA256,
                'actual' => $sha,
            ) );
        }

        $server_old = "        if ( empty( \$selected_platforms ) ) wp_send_json_error( array( 'message' => 'Choose at least one platform.' ), 422 );";
        $server_new = "        \$selected_platforms = array(); // JKSH manual destination mode: choose destinations at publish/schedule time.";

        $js_old = "const platforms=[...document.querySelectorAll('.jkssb-platform:checked')].map(x=>x.value);if(!platforms.length){setStatus('Choose at least one platform.','error');return;}";
        $js_new = "const platforms=[];";

        $label_old = "&gt;50 MB · WordPress Media";
        $label_new = "&gt;50 MB · Google Drive";

        $target_old = "const target=b.storage_target==='wordpress_media'?'WordPress Media':'Supabase';";
        $target_new = "const target=b.storage_target==='google_drive'?'Google Drive':(b.storage_target==='wordpress_media'?'WordPress Media':'Supabase');";

        $server_count = substr_count( $src, $server_old );
        $js_count = substr_count( $src, $js_old );
        if ( 1 !== $server_count || 2 !== $js_count ) {
            return new WP_Error( 'signature_mismatch', 'Expected Bridge signatures were not found exactly.', array(
                'status' => 409,
                'server_count' => $server_count,
                'js_count' => $js_count,
            ) );
        }

        $patched = str_replace( $server_old, $server_new, $src, $c1 );
        $patched = str_replace( $js_old, $js_new, $patched, $c2 );
        $patched = str_replace( $label_old, $label_new, $patched, $c3 );
        $patched = str_replace( $target_old, $target_new, $patched, $c4 );

        if ( 1 !== $c1 || 2 !== $c2 ) {
            return new WP_Error( 'replace_failed', 'Required replacements did not complete safely.', array(
                'status' => 500,
                'server_replaced' => $c1,
                'js_replaced' => $c2,
            ) );
        }

        $backup = $path . '.manual-destination-backup-' . gmdate( 'YmdHis' );
        if ( ! copy( $path, $backup ) ) {
            return new WP_Error( 'backup_failed', 'Could not create Bridge backup.', array( 'status' => 500 ) );
        }

        $tmp = $path . '.manual-destination-tmp';
        if ( false === file_put_contents( $tmp, $patched, LOCK_EX ) ) {
            @unlink( $tmp );
            return new WP_Error( 'write_failed', 'Could not write patched Bridge temp file.', array( 'status' => 500 ) );
        }

        // Basic syntax safety: if PHP CLI is available, lint before swap.
        $lint_ok = null;
        $lint_output = '';
        if ( function_exists( 'exec' ) && defined( 'PHP_BINARY' ) && PHP_BINARY ) {
            $cmd = escapeshellarg( PHP_BINARY ) . ' -l ' . escapeshellarg( $tmp ) . ' 2>&1';
            $lines = array();
            $code = 1;
            @exec( $cmd, $lines, $code );
            $lint_output = implode( "\n", $lines );
            $lint_ok = ( 0 === $code );
            if ( ! $lint_ok ) {
                @unlink( $tmp );
                return new WP_Error( 'lint_failed', 'Patched Bridge failed PHP lint.', array(
                    'status' => 500,
                    'lint' => $lint_output,
                ) );
            }
        }

        if ( ! @rename( $tmp, $path ) ) {
            @unlink( $tmp );
            return new WP_Error( 'swap_failed', 'Could not atomically replace Bridge file.', array( 'status' => 500 ) );
        }

        clearstatcache( true, $path );
        $final = file_get_contents( $path );

        return rest_ensure_response( array(
            'ok' => true,
            'before_sha256' => $sha,
            'after_sha256' => hash( 'sha256', $final ),
            'backup_file' => basename( $backup ),
            'server_replaced' => $c1,
            'js_replaced' => $c2,
            'label_replaced' => $c3,
            'target_replaced' => $c4,
            'lint_ok' => $lint_ok,
            'lint_output' => $lint_output,
            'platform_error_count' => substr_count( $final, 'Choose at least one platform.' ),
            'manual_js_count' => substr_count( $final, 'const platforms=[];' ),
            'drive_label_count' => substr_count( $final, '>50 MB · Google Drive' ),
        ) );
    }
}
JKSH_Manual_Destination_Core_Patch_V100::init();
