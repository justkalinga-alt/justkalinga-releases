(function () {
  'use strict';

  const cfg = window.JKSHUploadUXPatch || {};
  const state = { pinterestSandboxConnected: false, currentType: '' };

  function norm(s) { return String(s || '').replace(/\s+/g, ' ').trim().toLowerCase(); }
  function visible(el) { return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length)); }

  async function getJSON(url) {
    try {
      const res = await fetch(url, { credentials: 'same-origin', headers: cfg.nonce ? { 'X-WP-Nonce': cfg.nonce } : {} });
      if (!res.ok) return null;
      return await res.json();
    } catch (e) { return null; }
  }

  function detectType() {
    const checked = Array.from(document.querySelectorAll('input[type="radio"]:checked, input[type="hidden"], select')).find(el => {
      const key = norm((el.name || '') + ' ' + (el.id || ''));
      if (!/(content.?type|post.?type|media.?type|jksh.*type)/.test(key)) return false;
      const v = norm(el.value);
      return /(single|carousel|reel|short|long|video)/.test(v);
    });
    if (checked) {
      const v = norm(checked.value);
      if (v.includes('carousel')) return 'carousel';
      if (v.includes('reel') || v.includes('short')) return 'reel';
      if (v.includes('long')) return 'long_video';
      if (v.includes('single')) return 'single_post';
    }

    const candidates = Array.from(document.querySelectorAll('button, [role="button"], label, .is-active, .active, .selected, [aria-pressed="true"]'));
    for (const el of candidates) {
      const t = norm(el.textContent);
      if (t.startsWith('reel / short') || t.startsWith('reel/short')) return 'reel';
      if (t.startsWith('long video')) return 'long_video';
      if (t.startsWith('carousel')) return 'carousel';
      if (t.startsWith('single post')) return 'single_post';
    }
    return state.currentType || '';
  }

  function platformBox(name) {
    const wanted = norm(name);
    const inputs = Array.from(document.querySelectorAll('input[type="checkbox"]'));
    for (const input of inputs) {
      let box = input.closest('label, button, [role="button"], div');
      for (let i = 0; i < 5 && box; i++, box = box.parentElement) {
        const txt = norm(box.textContent);
        if (txt === wanted || txt.startsWith(wanted + ' ')) return { input, box };
      }
    }
    const textEls = Array.from(document.querySelectorAll('label,button,div,span')).filter(el => norm(el.textContent) === wanted);
    for (const el of textEls) {
      const box = el.closest('label, button, [role="button"], div');
      const input = box && box.querySelector('input[type="checkbox"]');
      if (input) return { input, box };
    }
    return null;
  }

  function setAvailability(item, enabled, reason) {
    if (!item) return;
    const { input, box } = item;
    input.disabled = !enabled;
    if (!enabled && input.checked) {
      input.checked = false;
      input.dispatchEvent(new Event('change', { bubbles: true }));
    }
    [box, box && box.parentElement].filter(Boolean).forEach(el => {
      el.classList.toggle('jksh-ux-disabled', !enabled);
      el.classList.toggle('jksh-ux-enabled', enabled);
      if (!enabled && reason) el.setAttribute('title', reason);
      else if (el.getAttribute('title') === reason || enabled) el.removeAttribute('title');
      el.setAttribute('aria-disabled', enabled ? 'false' : 'true');
    });

    let note = box && box.parentElement ? box.parentElement.querySelector(':scope > .jksh-ux-platform-note') : null;
    if (!enabled && reason && box && box.parentElement) {
      if (!note) {
        note = document.createElement('div');
        note.className = 'jksh-ux-platform-note';
        box.parentElement.appendChild(note);
      }
      note.textContent = reason;
    } else if (note) {
      note.remove();
    }
  }

  function updatePlatforms() {
    const type = detectType();
    if (type) state.currentType = type;
    const isVideo = type === 'reel' || type === 'long_video';
    const isImage = type === 'single_post' || type === 'carousel';

    const youtube = platformBox('YouTube');
    if (youtube) {
      if (isVideo) setAvailability(youtube, true, '');
      else if (isImage) setAvailability(youtube, false, 'YouTube image/community posts are handled manually. Reels and videos remain available.');
    }

    const pinterest = platformBox('Pinterest');
    if (pinterest) {
      if (isImage && state.pinterestSandboxConnected) {
        setAvailability(pinterest, true, '');
        pinterest.box.setAttribute('title', 'Pinterest Sandbox image publishing is available.');
      } else if (isVideo && state.pinterestSandboxConnected) {
        setAvailability(pinterest, false, 'Pinterest Sandbox does not support video Pins. Video publishing becomes available through production after Standard Access.');
      } else {
        setAvailability(pinterest, false, 'Connect Pinterest Sandbox to enable image publishing.');
      }
    }
  }

  function closestMediaRow(el) {
    let node = el;
    for (let i = 0; i < 7 && node && node !== document.body; i++, node = node.parentElement) {
      const txt = norm(node.textContent);
      const hasRemove = Array.from(node.querySelectorAll('button')).some(b => /(^x$|remove|delete|×)/i.test(norm(b.textContent) + ' ' + norm(b.getAttribute('aria-label')) + ' ' + norm(b.title)));
      const hasFile = /\.(png|jpe?g|webp|gif|mp4|mov|webm)\b/i.test(node.textContent || '');
      if (hasRemove && hasFile) return node;
    }
    return null;
  }

  function mediaRows() {
    const rows = [];
    const buttons = Array.from(document.querySelectorAll('button'));
    for (const b of buttons) {
      const txt = norm(b.textContent) + ' ' + norm(b.getAttribute('aria-label')) + ' ' + norm(b.title);
      if (!/(remove|delete|^x$|×)/i.test(txt)) continue;
      const row = closestMediaRow(b);
      if (row && !rows.includes(row) && visible(row)) rows.push(row);
    }
    return rows;
  }

  function findMoveButton(row, dir) {
    const buttons = Array.from(row.querySelectorAll('button'));
    const patterns = dir === 'up' ? /(move.*up|up|↑|arrow.*up)/i : /(move.*down|down|↓|arrow.*down)/i;
    return buttons.find(b => patterns.test((b.textContent || '') + ' ' + (b.getAttribute('aria-label') || '') + ' ' + (b.title || ''))) || null;
  }

  let dragRow = null;
  function enhanceOrdering() {
    const rows = mediaRows();
    if (rows.length < 2) return;
    rows.forEach(row => {
      if (row.dataset.jkshUxSortable === '1') return;
      row.dataset.jkshUxSortable = '1';
      row.draggable = true;
      row.classList.add('jksh-ux-sortable-row');
      const grip = document.createElement('span');
      grip.className = 'jksh-ux-grip';
      grip.title = 'Drag to reorder';
      grip.setAttribute('aria-label', 'Drag to reorder');
      grip.textContent = '⋮⋮';
      row.insertBefore(grip, row.firstChild);
      row.addEventListener('dragstart', e => {
        dragRow = row;
        row.classList.add('jksh-ux-dragging');
        try { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'jksh-reorder'); } catch (_) {}
      });
      row.addEventListener('dragend', () => {
        row.classList.remove('jksh-ux-dragging');
        document.querySelectorAll('.jksh-ux-drop-target').forEach(x => x.classList.remove('jksh-ux-drop-target'));
        dragRow = null;
      });
      row.addEventListener('dragover', e => {
        if (!dragRow || dragRow === row) return;
        e.preventDefault();
        row.classList.add('jksh-ux-drop-target');
      });
      row.addEventListener('dragleave', () => row.classList.remove('jksh-ux-drop-target'));
      row.addEventListener('drop', e => {
        if (!dragRow || dragRow === row) return;
        e.preventDefault();
        row.classList.remove('jksh-ux-drop-target');
        const now = mediaRows();
        const from = now.indexOf(dragRow);
        const to = now.indexOf(row);
        if (from < 0 || to < 0 || from === to) return;
        const dir = from < to ? 'down' : 'up';
        const steps = Math.abs(to - from);
        let moved = 0;
        const step = () => {
          const currentRows = mediaRows();
          const current = currentRows.find(r => r === dragRow || r.dataset.jkshUxDraggingKey === '1') || dragRow;
          const btn = findMoveButton(current, dir);
          if (!btn || btn.disabled) return;
          current.dataset.jkshUxDraggingKey = '1';
          btn.click();
          moved++;
          if (moved < steps) setTimeout(step, 40);
          else setTimeout(() => {
            document.querySelectorAll('[data-jksh-ux-dragging-key]').forEach(x => delete x.dataset.jkshUxDraggingKey);
            enhanceOrdering();
          }, 80);
        };
        step();
      });
    });
  }

  function coverInput() {
    const inputs = Array.from(document.querySelectorAll('input[type="file"]'));
    for (const input of inputs) {
      let p = input.parentElement;
      for (let i = 0; i < 5 && p; i++, p = p.parentElement) {
        if (/cover\s*\/\s*thumbnail|cover|thumbnail/i.test(p.textContent || '')) return { input, box: p };
      }
    }
    return null;
  }

  function enhanceCoverDrop() {
    const found = coverInput();
    if (!found || found.input.dataset.jkshUxDrop === '1') return;
    const { input, box } = found;
    input.dataset.jkshUxDrop = '1';
    input.setAttribute('accept', 'image/*');

    const drop = document.createElement('div');
    drop.className = 'jksh-ux-cover-drop';
    drop.innerHTML = '<div class="jksh-ux-cover-icon">↥</div><strong>Drop cover image here or click to browse</strong><small>PNG, JPG or WebP</small><div class="jksh-ux-cover-preview" aria-live="polite"></div>';
    input.parentElement.insertBefore(drop, input);
    input.classList.add('jksh-ux-native-file');

    function preview(file) {
      const p = drop.querySelector('.jksh-ux-cover-preview');
      if (!p) return;
      p.textContent = file ? file.name : '';
      if (file && file.type && file.type.startsWith('image/')) {
        const img = new Image();
        img.onload = () => URL.revokeObjectURL(img.src);
        img.src = URL.createObjectURL(file);
        img.alt = 'Selected cover preview';
        p.innerHTML = '';
        p.appendChild(img);
        const span = document.createElement('span');
        span.textContent = file.name;
        p.appendChild(span);
      }
    }

    drop.addEventListener('click', () => input.click());
    ['dragenter','dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('is-dragover'); }));
    ['dragleave','drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('is-dragover'); }));
    drop.addEventListener('drop', e => {
      const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (!file || !file.type.startsWith('image/')) return;
      const dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
      preview(file);
    });
    input.addEventListener('change', () => preview(input.files && input.files[0]));
  }

  function bindTypeClicks() {
    document.addEventListener('click', e => {
      const el = e.target.closest('button, [role="button"], label, div');
      if (!el) return;
      const t = norm(el.textContent);
      if (t.startsWith('single post')) state.currentType = 'single_post';
      else if (t.startsWith('carousel')) state.currentType = 'carousel';
      else if (t.startsWith('reel / short') || t.startsWith('reel/short')) state.currentType = 'reel';
      else if (t.startsWith('long video')) state.currentType = 'long_video';
      else return;
      setTimeout(updatePlatforms, 0);
    }, true);
  }

  async function boot() {
    const sr = await getJSON(cfg.sandboxReadiness || '/wp-json/jksh/v1/pinterest/sandbox/readiness');
    state.pinterestSandboxConnected = !!(sr && sr.ok && sr.connected);
    bindTypeClicks();
    updatePlatforms();
    enhanceOrdering();
    enhanceCoverDrop();

    const mo = new MutationObserver(() => {
      clearTimeout(mo._t);
      mo._t = setTimeout(() => {
        updatePlatforms();
        enhanceOrdering();
        enhanceCoverDrop();
      }, 80);
    });
    mo.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class','disabled','checked','aria-pressed'] });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
