<?php
/**
 * Plugin Name: JKSH Native Pinterest Sandbox UI Fix
 * Description: One-time guarded patch: enable Pinterest Sandbox for Single Post in native Social Upload while production remains locked.
 * Version: 1.0.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Native_Pin_UI_V100 {
    private static $instance;
    public static function instance(){ return self::$instance ?: ( self::$instance = new self() ); }
    private function __construct(){ add_action( 'rest_api_init', [ $this, 'routes' ] ); }
    public function can(){ return current_user_can( 'manage_options' ); }
    public function routes(){
        register_rest_route( 'jksh-native-pin-ui/v1', '/status', [
            'methods' => 'GET', 'permission_callback' => [ $this, 'can' ],
            'callback' => fn() => rest_ensure_response( $this->status() ),
        ] );
        register_rest_route( 'jksh-native-pin-ui/v1', '/apply', [
            'methods' => 'POST', 'permission_callback' => [ $this, 'can' ],
            'callback' => function( WP_REST_Request $req ){
                if ( true !== (bool) $req->get_param( 'confirm' ) ) return new WP_Error( 'confirm_required', 'confirm=true is required', [ 'status' => 400 ] );
                return rest_ensure_response( $this->apply() );
            },
        ] );
    }
    private function file(){
        $candidates = [
            WP_PLUGIN_DIR . '/jk-social-supabase-bridge-disabled/jk-social-supabase-bridge.php',
            WP_PLUGIN_DIR . '/jk-social-supabase-bridge/jk-social-supabase-bridge.php',
        ];
        foreach ( $candidates as $f ) if ( is_file( $f ) && is_readable( $f ) && is_writable( $f ) ) return $f;
        return '';
    }
    public function status(){
        $f = $this->file();
        $s = $f ? file_get_contents( $f ) : '';
        return [
            'ok' => (bool) $f,
            'version' => '1.0.0',
            'file' => $f ? basename( dirname( $f ) ) . '/' . basename( $f ) : '',
            'patched_html' => $s && false !== strpos( $s, 'JKSH_NATIVE_PIN_SANDBOX_UI_V100' ),
            'patched_sync' => $s && false !== strpos( $s, 'Sandbox image proof supports Single Post only.' ),
            'sandbox_ready' => class_exists( 'JKSH_Pinterest_Sandbox_V0138' ) ? (bool) ( JKSH_Pinterest_Sandbox_V0138::instance()->readiness()['connected'] ?? false ) : false,
        ];
    }
    public function apply(){
        $f = $this->file();
        if ( ! $f ) return [ 'ok' => false, 'message' => 'Writable Supabase Bridge file not found.' ];
        $src = file_get_contents( $f );
        if ( false === $src ) return [ 'ok' => false, 'message' => 'Could not read bridge source.' ];
        $orig = $src;

        if ( false === strpos( $src, 'JKSH_NATIVE_PIN_SANDBOX_UI_V100' ) ) {
            $old = <<<'OLD'
<label class="jkssb-platform-card"><input class="jkssb-platform" type="checkbox" value="pinterest" <?php $jkpr = class_exists( 'JKSH_Pinterest_Connector' ) ? JKSH_Pinterest_Connector::instance()->readiness() : array(); if ( ! empty( $jkpr['live_publish_possible'] ) ) { echo 'checked data-connected="1"'; } else { echo 'disabled data-connected="0"'; } ?>><span>Pinterest</span></label>
OLD;
            $new = <<<'NEW'
<label class="jkssb-platform-card"><input class="jkssb-platform" type="checkbox" value="pinterest" <?php /* JKSH_NATIVE_PIN_SANDBOX_UI_V100 */ $jkpr = class_exists( 'JKSH_Pinterest_Connector' ) ? JKSH_Pinterest_Connector::instance()->readiness() : array(); $jksr = class_exists( 'JKSH_Pinterest_Sandbox_V0138' ) ? JKSH_Pinterest_Sandbox_V0138::instance()->readiness() : array(); $jkprod = ! empty( $jkpr['live_publish_possible'] ); $jksbox = is_array( $jksr ) && ! empty( $jksr['connected'] ) && ! empty( $jksr['image_pins_supported'] ); if ( $jkprod ) { echo 'checked data-connected="1" data-sandbox="0"'; } elseif ( $jksbox ) { echo 'data-connected="1" data-sandbox="1"'; } else { echo 'disabled data-connected="0" data-sandbox="0"'; } ?>><span>Pinterest</span></label>
NEW;
            if ( false === strpos( $src, $old ) ) return [ 'ok' => false, 'message' => 'Native Pinterest checkbox anchor not found; no file changed.' ];
            $src = str_replace( $old, $new, $src, $count );
            if ( 1 !== $count ) return [ 'ok' => false, 'message' => 'Unexpected Pinterest checkbox replacement count: ' . $count ];
        }

        $oldSync = <<<'OLD'
const pin=document.querySelector('.jkssb-platform[value="pinterest"]');if(pin){const card=pin.closest('.jkssb-platform-card'),unsupported=(v==='carousel'),connected=(pin.dataset.connected==='1');pin.disabled=!connected||unsupported;if(pin.disabled){pin.checked=false;if(card){card.classList.add('is-disabled');card.title=!connected?'Connect, verify and arm Pinterest in Accounts first.':'Pinterest currently supports one image or one video per Pin.';}}else if(card){card.classList.remove('is-disabled');card.removeAttribute('title');}}
OLD;
        $newSync = <<<'NEW'
const pin=document.querySelector('.jkssb-platform[value="pinterest"]');if(pin){const card=pin.closest('.jkssb-platform-card'),connected=(pin.dataset.connected==='1'),sandbox=(pin.dataset.sandbox==='1'),unsupported=(v==='carousel'||(sandbox&&(v==='reel'||v==='long_video')));pin.disabled=!connected||unsupported;if(pin.disabled){pin.checked=false;if(card){card.classList.add('is-disabled');card.title=!connected?'Connect Pinterest first.':(sandbox?'Sandbox image proof supports Single Post only.':'Pinterest carousel is not supported here.');}}else if(card){card.classList.remove('is-disabled');card.title=sandbox?'Pinterest Sandbox image proof lane':'Pinterest production';}}
NEW;
        if ( false !== strpos( $src, $oldSync ) ) {
            $src = str_replace( $oldSync, $newSync, $src, $countSync );
            if ( 1 !== $countSync ) return [ 'ok' => false, 'message' => 'Unexpected syncType replacement count: ' . $countSync ];
        } elseif ( false === strpos( $src, 'Sandbox image proof supports Single Post only.' ) ) {
            return [ 'ok' => false, 'message' => 'Pinterest syncType anchor not found; no file changed.' ];
        }

        if ( $src === $orig ) return array_merge( [ 'ok' => true, 'message' => 'Already patched.' ], $this->status() );
        $backup = $f . '.jkshbak-native-pin-ui-' . gmdate( 'YmdHis' );
        if ( ! copy( $f, $backup ) ) return [ 'ok' => false, 'message' => 'Could not create bridge backup.' ];
        if ( false === file_put_contents( $f, $src, LOCK_EX ) ) return [ 'ok' => false, 'message' => 'Could not write bridge patch.' ];
        clearstatcache( true, $f );
        return array_merge( [ 'ok' => true, 'message' => 'Native Pinterest Sandbox UI patched.', 'backup' => basename( $backup ) ], $this->status() );
    }
}
JKSH_Native_Pin_UI_V100::instance();
