<?php
/**
 * Plugin Name: JKSH Google Drive Storage
 * Description: Google Drive storage backend for JK Social Hub large media. Files over 50 MB upload directly from the browser to Drive; WordPress stores metadata only.
 * Version: 0.1.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JKSH_Google_Drive_Storage_V010 {
    const VERSION = '0.1.0';
    const OPTION = 'jksh_google_drive_storage_v010';
    const PLATFORM = 'google_drive';
    const THRESHOLD = 52428800; // 50 MB.
    const MAX_BYTES = 524288000; // Match current Social Upload 500 MB limit.
    const ROOT_NAME = 'JK Social Hub Media Vault';
    const LARGE_NAME = 'Large Media';
    const DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.file';
    const OAUTH = 'https://accounts.google.com/o/oauth2/v2/auth';
    const TOKEN = 'https://oauth2.googleapis.com/token';
    const DRIVE_API = 'https://www.googleapis.com/drive/v3';
    const DRIVE_UPLOAD = 'https://www.googleapis.com/upload/drive/v3';
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_post_jksh_drive_save_settings', array( $this, 'save_settings' ) );
        add_action( 'admin_post_jksh_drive_oauth_start', array( $this, 'oauth_start' ) );
        add_action( 'admin_post_jksh_drive_oauth_callback', array( $this, 'oauth_callback' ) );
        add_action( 'admin_post_jksh_drive_test_account', array( $this, 'test_account' ) );
        add_action( 'admin_post_jksh_drive_disconnect_account', array( $this, 'disconnect_account' ) );
        add_action( 'admin_footer', array( $this, 'admin_footer' ), 1140 );
        add_action( 'admin_footer', array( $this, 'upload_router_script' ), 4 );
        add_action( 'wp_footer', array( $this, 'upload_router_script' ), 4 );
        add_action( 'wp_ajax_jkssb_ui_begin', array( $this, 'intercept_upload_begin' ), 1 );
        add_action( 'wp_ajax_jkssb_ui_finalize', array( $this, 'intercept_upload_finalize' ), 1 );
        add_action( 'rest_api_init', array( $this, 'rest_routes' ) );
        add_filter( 'wp_get_attachment_url', array( $this, 'virtual_attachment_url' ), 20, 2 );
    }

    private function deps_ready() {
        return class_exists( '\\JKSH\\Repositories\\AccountRepository' ) && class_exists( '\\JKSH\\Security\\Crypto' );
    }
    private function accounts() { return new \JKSH\Repositories\AccountRepository(); }
    private function crypto() { return new \JKSH\Security\Crypto(); }
    public function redirect_uri() { return admin_url( 'admin-post.php?action=jksh_drive_oauth_callback' ); }

    private function config() {
        $raw = get_option( self::OPTION, array() );
        $raw = is_array( $raw ) ? $raw : array();
        $secret = '';
        if ( ! empty( $raw['client_secret_encrypted'] ) && $this->deps_ready() ) {
            try { $secret = (string) $this->crypto()->decrypt( (string) $raw['client_secret_encrypted'] ); } catch ( Throwable $e ) { $secret = ''; }
        }
        return array(
            'client_id' => sanitize_text_field( (string) ( $raw['client_id'] ?? '' ) ),
            'client_secret' => $secret,
            'enabled' => ! array_key_exists( 'enabled', $raw ) || ! empty( $raw['enabled'] ),
        );
    }

    private function save_config( array $in ) {
        $old = get_option( self::OPTION, array() );
        $old = is_array( $old ) ? $old : array();
        $out = $old;
        if ( array_key_exists( 'client_id', $in ) ) $out['client_id'] = sanitize_text_field( (string) $in['client_id'] );
        if ( array_key_exists( 'client_secret', $in ) && '' !== trim( (string) $in['client_secret'] ) ) {
            if ( ! $this->deps_ready() ) return new WP_Error( 'jksh_drive_crypto', 'JK Social encryption service is unavailable.' );
            $out['client_secret_encrypted'] = $this->crypto()->encrypt( trim( (string) $in['client_secret'] ) );
        }
        if ( array_key_exists( 'enabled', $in ) ) $out['enabled'] = ! empty( $in['enabled'] );
        update_option( self::OPTION, $out, false );
        return true;
    }

    private function guard( $action ) {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Not allowed.' );
        check_admin_referer( $action );
    }
    private function redirect( $type, $msg ) {
        wp_safe_redirect( add_query_arg( array( 'page' => 'jksh-accounts', 'jksh_notice' => $type, 'jksh_msg' => $msg ), admin_url( 'admin.php' ) ) . '#account-drive' );
        exit;
    }

    public function save_settings() {
        $this->guard( 'jksh_drive_save_settings' );
        $saved = $this->save_config( array(
            'client_id' => wp_unslash( $_POST['client_id'] ?? '' ),
            'client_secret' => wp_unslash( $_POST['client_secret'] ?? '' ),
            'enabled' => ! empty( $_POST['enabled'] ),
        ) );
        if ( is_wp_error( $saved ) ) $this->redirect( 'error', $saved->get_error_message() );
        $this->redirect( 'success', 'Google Drive settings saved.' );
    }

    private function primary_account() {
        if ( ! $this->deps_ready() ) return null;
        foreach ( $this->accounts()->connected( self::PLATFORM ) as $a ) return $a;
        return null;
    }

    public function readiness() {
        $c = $this->config();
        $a = $this->primary_account();
        $settings = $a ? $this->accounts()->settings( $a ) : array();
        return array(
            'ok' => true,
            'version' => self::VERSION,
            'configured' => ( '' !== $c['client_id'] && '' !== $c['client_secret'] ),
            'enabled' => (bool) $c['enabled'],
            'connected' => (bool) $a,
            'account_id' => $a ? (int) $a->id : 0,
            'account_name' => $a ? (string) $a->account_name : '',
            'token_expires_at' => $a ? (string) $a->token_expires_at : '',
            'root_folder_id' => sanitize_text_field( (string) ( $settings['root_folder_id'] ?? '' ) ),
            'large_folder_id' => sanitize_text_field( (string) ( $settings['large_folder_id'] ?? '' ) ),
            'threshold_bytes' => self::THRESHOLD,
            'max_bytes' => self::MAX_BYTES,
            'scope' => self::DRIVE_SCOPE,
            'redirect_uri' => $this->redirect_uri(),
            'wordpress_media_bytes' => false,
            'message' => $a ? 'Google Drive storage is connected.' : 'Connect Google Drive before uploading media over 50 MB.',
        );
    }

    public function oauth_start() {
        $this->guard( 'jksh_drive_oauth_start' );
        $c = $this->config();
        if ( '' === $c['client_id'] || '' === $c['client_secret'] ) $this->redirect( 'error', 'Save the Google OAuth Client ID and Client Secret first.' );
        $state = wp_generate_password( 48, false, false );
        set_transient( 'jksh_drive_state_' . hash( 'sha256', $state ), array( 'hash' => wp_hash( $state ), 'user_id' => get_current_user_id() ), 10 * MINUTE_IN_SECONDS );
        $url = add_query_arg( array(
            'client_id' => $c['client_id'],
            'redirect_uri' => $this->redirect_uri(),
            'response_type' => 'code',
            'scope' => self::DRIVE_SCOPE,
            'access_type' => 'offline',
            'prompt' => 'consent',
            'include_granted_scopes' => 'true',
            'state' => $state,
        ), self::OAUTH );
        wp_redirect( $url, 302, 'JK Social Google Drive' );
        exit;
    }

    public function oauth_callback() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Not allowed.' );
        $state = sanitize_text_field( (string) ( $_GET['state'] ?? '' ) );
        $key = 'jksh_drive_state_' . hash( 'sha256', $state );
        $expected = get_transient( $key );
        delete_transient( $key );
        $hash = is_array( $expected ) ? (string) ( $expected['hash'] ?? '' ) : '';
        if ( ! $state || ! $hash || ! hash_equals( $hash, wp_hash( $state ) ) || absint( $expected['user_id'] ?? 0 ) !== get_current_user_id() ) {
            $this->redirect( 'error', 'Google Drive OAuth state validation failed.' );
        }
        if ( ! empty( $_GET['error'] ) ) $this->redirect( 'error', 'Google Drive authorization was not completed.' );
        $code = sanitize_text_field( (string) ( $_GET['code'] ?? '' ) );
        if ( ! $code ) $this->redirect( 'error', 'Google did not return an authorization code.' );
        $c = $this->config();
        $r = wp_remote_post( self::TOKEN, array( 'timeout' => 30, 'body' => array(
            'client_id' => $c['client_id'],
            'client_secret' => $c['client_secret'],
            'code' => $code,
            'redirect_uri' => $this->redirect_uri(),
            'grant_type' => 'authorization_code',
        ) ) );
        if ( is_wp_error( $r ) ) $this->redirect( 'error', 'Google Drive token exchange failed: ' . $r->get_error_message() );
        $data = json_decode( (string) wp_remote_retrieve_body( $r ), true );
        if ( wp_remote_retrieve_response_code( $r ) >= 300 || empty( $data['access_token'] ) ) $this->redirect( 'error', 'Google Drive token exchange failed.' );
        $access = sanitize_text_field( (string) $data['access_token'] );
        $folders = $this->ensure_folders_with_token( $access );
        if ( is_wp_error( $folders ) ) $this->redirect( 'error', $folders->get_error_message() );
        $expires = absint( $data['expires_in'] ?? 3600 );
        $credentials = array(
            'access_token' => $access,
            'refresh_token' => sanitize_text_field( (string) ( $data['refresh_token'] ?? '' ) ),
            'token_type' => sanitize_key( (string) ( $data['token_type'] ?? 'Bearer' ) ),
            'scope' => sanitize_text_field( (string) ( $data['scope'] ?? self::DRIVE_SCOPE ) ),
        );
        $settings = array(
            'root_folder_id' => $folders['root_folder_id'],
            'large_folder_id' => $folders['large_folder_id'],
            'root_folder_name' => self::ROOT_NAME,
            'large_folder_name' => self::LARGE_NAME,
            'required_scope' => self::DRIVE_SCOPE,
            'connector_phase' => 'drive-storage-v0.1.0',
            'verified_by_api' => true,
        );
        $id = $this->accounts()->upsert( array(
            'platform' => self::PLATFORM,
            'account_name' => 'Google Drive · ' . self::ROOT_NAME,
            'external_account_id' => $folders['root_folder_id'],
            'status' => 'connected',
            'credentials' => $credentials,
            'settings' => $settings,
            'token_expires_at' => gmdate( 'Y-m-d H:i:s', time() + $expires ),
            'last_checked_at' => current_time( 'mysql', true ),
            'last_error' => '',
        ) );
        if ( ! $id ) $this->redirect( 'error', 'Could not save the Google Drive connection.' );
        $this->redirect( 'success', 'Google Drive connected. Large Media folder is ready.' );
    }

    private function token_for( $account ) {
        $creds = $this->accounts()->credentials( $account );
        $access = (string) ( $creds['access_token'] ?? '' );
        $exp = ! empty( $account->token_expires_at ) ? strtotime( (string) $account->token_expires_at . ' UTC' ) : 0;
        if ( $access && ( ! $exp || $exp > time() + 300 ) ) return $access;
        $refresh = (string) ( $creds['refresh_token'] ?? '' );
        if ( ! $refresh ) return new WP_Error( 'jksh_drive_refresh', 'Google Drive refresh token is missing. Reconnect Drive.' );
        $c = $this->config();
        $r = wp_remote_post( self::TOKEN, array( 'timeout' => 30, 'body' => array(
            'client_id' => $c['client_id'],
            'client_secret' => $c['client_secret'],
            'refresh_token' => $refresh,
            'grant_type' => 'refresh_token',
        ) ) );
        if ( is_wp_error( $r ) ) return $r;
        $d = json_decode( (string) wp_remote_retrieve_body( $r ), true );
        if ( wp_remote_retrieve_response_code( $r ) >= 300 || empty( $d['access_token'] ) ) return new WP_Error( 'jksh_drive_refresh_failed', 'Google Drive token refresh failed.' );
        $settings = $this->accounts()->settings( $account );
        $this->accounts()->upsert( array(
            'platform' => self::PLATFORM,
            'account_name' => (string) $account->account_name,
            'external_account_id' => (string) $account->external_account_id,
            'status' => 'connected',
            'credentials' => array(
                'access_token' => (string) $d['access_token'],
                'refresh_token' => $refresh,
                'token_type' => (string) ( $d['token_type'] ?? 'Bearer' ),
                'scope' => (string) ( $d['scope'] ?? ( $creds['scope'] ?? self::DRIVE_SCOPE ) ),
            ),
            'settings' => $settings,
            'token_expires_at' => gmdate( 'Y-m-d H:i:s', time() + absint( $d['expires_in'] ?? 3600 ) ),
            'last_checked_at' => current_time( 'mysql', true ),
            'last_error' => '',
        ) );
        return (string) $d['access_token'];
    }

    private function drive_request( $method, $url, $token, $body = null, $headers = array() ) {
        $args = array( 'method' => $method, 'timeout' => 60, 'headers' => array_merge( array( 'Authorization' => 'Bearer ' . $token ), $headers ) );
        if ( null !== $body ) $args['body'] = is_string( $body ) ? $body : wp_json_encode( $body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        $r = wp_remote_request( $url, $args );
        if ( is_wp_error( $r ) ) return $r;
        $code = wp_remote_retrieve_response_code( $r );
        $data = json_decode( (string) wp_remote_retrieve_body( $r ), true );
        if ( $code < 200 || $code >= 300 ) return new WP_Error( 'jksh_drive_api', 'Google Drive API error (HTTP ' . $code . ').', array( 'response' => $data ) );
        return array( 'code' => $code, 'data' => is_array( $data ) ? $data : array(), 'headers' => wp_remote_retrieve_headers( $r ) );
    }

    private function create_folder( $token, $name, $parent = '' ) {
        $meta = array( 'name' => $name, 'mimeType' => 'application/vnd.google-apps.folder' );
        if ( $parent ) $meta['parents'] = array( $parent );
        $r = $this->drive_request( 'POST', self::DRIVE_API . '/files?fields=id,name,parents', $token, $meta, array( 'Content-Type' => 'application/json' ) );
        if ( is_wp_error( $r ) ) return $r;
        return sanitize_text_field( (string) ( $r['data']['id'] ?? '' ) );
    }

    private function ensure_folders_with_token( $token ) {
        $root = $this->create_folder( $token, self::ROOT_NAME );
        if ( is_wp_error( $root ) || ! $root ) return is_wp_error( $root ) ? $root : new WP_Error( 'jksh_drive_root', 'Could not create the Drive media vault.' );
        $large = $this->create_folder( $token, self::LARGE_NAME, $root );
        if ( is_wp_error( $large ) || ! $large ) return is_wp_error( $large ) ? $large : new WP_Error( 'jksh_drive_large', 'Could not create the Drive Large Media folder.' );
        return array( 'root_folder_id' => $root, 'large_folder_id' => $large );
    }

    public function test_account() {
        $this->guard( 'jksh_drive_test_account' );
        $a = $this->primary_account();
        if ( ! $a ) $this->redirect( 'error', 'Google Drive is not connected.' );
        $token = $this->token_for( $a );
        if ( is_wp_error( $token ) ) $this->redirect( 'error', $token->get_error_message() );
        $s = $this->accounts()->settings( $a );
        $id = sanitize_text_field( (string) ( $s['large_folder_id'] ?? '' ) );
        $r = $this->drive_request( 'GET', self::DRIVE_API . '/files/' . rawurlencode( $id ) . '?fields=id,name,mimeType,trashed', $token );
        if ( is_wp_error( $r ) ) $this->redirect( 'error', 'Drive test failed: ' . $r->get_error_message() );
        $this->accounts()->update_status( (int) $a->id, 'connected', '' );
        $this->redirect( 'success', 'Google Drive connection verified.' );
    }

    public function disconnect_account() {
        $this->guard( 'jksh_drive_disconnect_account' );
        $a = $this->primary_account();
        if ( $a ) $this->accounts()->disconnect( (int) $a->id );
        $this->redirect( 'success', 'Google Drive disconnected locally.' );
    }

    private function upload_key( $uuid ) { return 'jksh_drive_upload_' . preg_replace( '/[^a-zA-Z0-9-]/', '', $uuid ); }
    private function sign_upload( $uuid ) { return hash_hmac( 'sha256', $uuid, wp_salt( 'auth' ) ); }
    private function make_upload_id( $uuid ) { return 'jkdrive.' . $uuid . '.' . $this->sign_upload( $uuid ); }
    private function parse_upload_id( $id ) {
        if ( ! preg_match( '/^jkdrive\.([a-f0-9-]{36})\.([a-f0-9]{64})$/', (string) $id, $m ) ) return false;
        return hash_equals( $this->sign_upload( $m[1] ), $m[2] ) ? $m[1] : false;
    }

    public function intercept_upload_begin() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $mime = sanitize_mime_type( wp_unslash( $_POST['mime_type'] ?? '' ) );
        $bytes = absint( $_POST['bytes'] ?? 0 );
        if ( $bytes <= self::THRESHOLD ) return;
        check_ajax_referer( 'jkssb_social_upload', 'nonce' );
        if ( 0 !== strpos( $mime, 'video/' ) ) wp_send_json_error( array( 'message' => 'Files over 50 MB currently require a video MIME type for Drive storage.' ), 422 );
        if ( $bytes > self::MAX_BYTES ) wp_send_json_error( array( 'message' => 'This file exceeds the current 500 MB Social Upload limit.' ), 422 );
        $rdy = $this->readiness();
        if ( empty( $rdy['connected'] ) || empty( $rdy['enabled'] ) ) wp_send_json_error( array( 'message' => 'Connect Google Drive under JK Social Hub → Accounts before uploading media over 50 MB.' ), 409 );
        $a = $this->primary_account();
        $token = $this->token_for( $a );
        if ( is_wp_error( $token ) ) wp_send_json_error( array( 'message' => $token->get_error_message() ), 409 );
        $settings = $this->accounts()->settings( $a );
        $folder = sanitize_text_field( (string) ( $settings['large_folder_id'] ?? '' ) );
        if ( ! $folder ) wp_send_json_error( array( 'message' => 'Google Drive Large Media folder is missing. Reconnect Drive.' ), 409 );
        $filename = sanitize_file_name( wp_unslash( $_POST['filename'] ?? '' ) );
        $uuid = wp_generate_uuid4();
        $meta = array(
            'name' => $filename,
            'parents' => array( $folder ),
            'appProperties' => array( 'jksh_upload_uuid' => $uuid, 'jksh_source' => 'social_upload' ),
        );
        $url = self::DRIVE_UPLOAD . '/files?uploadType=resumable&fields=id,name,mimeType,size,md5Checksum,webViewLink,parents';
        $resp = wp_remote_post( $url, array(
            'timeout' => 60,
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json; charset=UTF-8',
                'X-Upload-Content-Type' => $mime,
                'X-Upload-Content-Length' => (string) $bytes,
            ),
            'body' => wp_json_encode( $meta, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
        ) );
        if ( is_wp_error( $resp ) ) wp_send_json_error( array( 'message' => 'Could not start Google Drive resumable upload: ' . $resp->get_error_message() ), 502 );
        $code = wp_remote_retrieve_response_code( $resp );
        $location = wp_remote_retrieve_header( $resp, 'location' );
        if ( $code < 200 || $code >= 300 || ! $location ) wp_send_json_error( array( 'message' => 'Google Drive did not return a resumable upload session.' ), 502 );
        $state = array(
            'uuid' => $uuid,
            'user_id' => get_current_user_id(),
            'filename' => $filename,
            'mime_type' => $mime,
            'bytes' => $bytes,
            'width' => absint( $_POST['width'] ?? 0 ),
            'height' => absint( $_POST['height'] ?? 0 ),
            'duration_ms' => absint( $_POST['duration_ms'] ?? 0 ),
            'folder_id' => $folder,
            'created_at' => time(),
        );
        set_transient( $this->upload_key( $uuid ), $state, 3 * HOUR_IN_SECONDS );
        wp_send_json_success( array(
            'upload_id' => $this->make_upload_id( $uuid ),
            'storage_target' => 'google_drive',
            'max_chunk_bytes' => 8388608,
            'drive_session_url' => esc_url_raw( $location ),
            'expected_bytes' => $bytes,
            'mime_type' => $mime,
            'direct_to_drive' => true,
        ) );
    }

    public function intercept_upload_finalize() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $upload_id = sanitize_text_field( wp_unslash( $_POST['upload_id'] ?? '' ) );
        $uuid = $this->parse_upload_id( $upload_id );
        if ( ! $uuid ) return;
        check_ajax_referer( 'jkssb_social_upload', 'nonce' );
        $state = get_transient( $this->upload_key( $uuid ) );
        if ( ! is_array( $state ) || absint( $state['user_id'] ?? 0 ) !== get_current_user_id() ) wp_send_json_error( array( 'message' => 'Google Drive upload session expired. Please upload again.' ), 409 );
        $file_id = sanitize_text_field( wp_unslash( $_POST['drive_file_id'] ?? '' ) );
        if ( ! $file_id ) wp_send_json_error( array( 'message' => 'Google Drive did not return a final file ID.' ), 409 );
        $a = $this->primary_account();
        $token = $a ? $this->token_for( $a ) : new WP_Error( 'jksh_drive_account', 'Google Drive is not connected.' );
        if ( is_wp_error( $token ) ) wp_send_json_error( array( 'message' => $token->get_error_message() ), 409 );
        $r = $this->drive_request( 'GET', self::DRIVE_API . '/files/' . rawurlencode( $file_id ) . '?fields=id,name,mimeType,size,md5Checksum,webViewLink,parents,trashed', $token );
        if ( is_wp_error( $r ) ) wp_send_json_error( array( 'message' => 'Could not verify the uploaded Drive file.' ), 502 );
        $f = $r['data'];
        $size = absint( $f['size'] ?? 0 );
        $parents = is_array( $f['parents'] ?? null ) ? $f['parents'] : array();
        if ( ! empty( $f['trashed'] ) || $size !== absint( $state['bytes'] ) || ! in_array( (string) $state['folder_id'], array_map( 'strval', $parents ), true ) ) {
            wp_send_json_error( array( 'message' => 'Google Drive upload verification failed.' ), 409 );
        }
        $attachment_id = wp_insert_attachment( array(
            'post_title' => sanitize_text_field( pathinfo( (string) $state['filename'], PATHINFO_FILENAME ) ),
            'post_status' => 'inherit',
            'post_mime_type' => sanitize_mime_type( (string) $state['mime_type'] ),
            'guid' => esc_url_raw( (string) ( $f['webViewLink'] ?? '' ) ),
        ), false, 0, true );
        if ( is_wp_error( $attachment_id ) ) wp_send_json_error( array( 'message' => $attachment_id->get_error_message() ), 500 );
        update_post_meta( $attachment_id, '_jksh_storage_source', 'google_drive' );
        update_post_meta( $attachment_id, '_jksh_drive_file_id', $file_id );
        update_post_meta( $attachment_id, '_jksh_drive_size', $size );
        update_post_meta( $attachment_id, '_jksh_drive_mime_type', sanitize_mime_type( (string) $state['mime_type'] ) );
        update_post_meta( $attachment_id, '_jksh_drive_md5', sanitize_text_field( (string) ( $f['md5Checksum'] ?? '' ) ) );
        update_post_meta( $attachment_id, '_jksh_drive_web_view_link', esc_url_raw( (string) ( $f['webViewLink'] ?? '' ) ) );
        update_post_meta( $attachment_id, '_jkssb_original_filename', sanitize_file_name( (string) $state['filename'] ) );
        update_post_meta( $attachment_id, '_jksh_drive_folder_id', sanitize_text_field( (string) $state['folder_id'] ) );
        update_post_meta( $attachment_id, '_jksh_drive_upload_version', self::VERSION );
        $meta = array( 'filesize' => $size );
        if ( ! empty( $state['width'] ) ) $meta['width'] = absint( $state['width'] );
        if ( ! empty( $state['height'] ) ) $meta['height'] = absint( $state['height'] );
        if ( ! empty( $state['duration_ms'] ) ) {
            $meta['length'] = round( absint( $state['duration_ms'] ) / 1000, 3 );
            $seconds = (int) round( absint( $state['duration_ms'] ) / 1000 );
            $meta['length_formatted'] = sprintf( '%02d:%02d', floor( $seconds / 60 ), $seconds % 60 );
        }
        wp_update_attachment_metadata( $attachment_id, $meta );
        delete_transient( $this->upload_key( $uuid ) );
        wp_send_json_success( array(
            'ok' => true,
            'attachment_id' => (int) $attachment_id,
            'external_attachment_id' => (int) $attachment_id,
            'storage' => 'google_drive',
            'drive_file_id' => $file_id,
            'filename' => sanitize_file_name( (string) $state['filename'] ),
            'bytes' => $size,
            'mime_type' => sanitize_mime_type( (string) $state['mime_type'] ),
            'web_view_link' => esc_url_raw( (string) ( $f['webViewLink'] ?? '' ) ),
            'wordpress_media_bytes' => false,
        ) );
    }

    public function virtual_attachment_url( $url, $post_id ) {
        if ( 'google_drive' !== get_post_meta( $post_id, '_jksh_storage_source', true ) ) return $url;
        $view = get_post_meta( $post_id, '_jksh_drive_web_view_link', true );
        return $view ? esc_url_raw( $view ) : $url;
    }

    public function upload_router_script() {
        $is_admin_upload = is_admin() && 'jksh-social-upload' === sanitize_key( (string) ( $_GET['page'] ?? '' ) );
        $is_front_upload = ! is_admin() && is_user_logged_in() && current_user_can( 'manage_options' );
        if ( ! $is_admin_upload && ! $is_front_upload ) return;
        ?>
        <script id="jksh-drive-upload-router-v010">
        (()=>{
          if(window.__jkshDriveUploadRouterV010)return;
          window.__jkshDriveUploadRouterV010=true;
          const nativeFetch=window.fetch.bind(window), sessions=new Map();
          const getAction=body=>body instanceof FormData?String(body.get('action')||''):'';
          window.fetch=async function(input,init){
            const body=init&&init.body, action=getAction(body);
            if(action==='jkssb_ui_chunk'){
              const uploadId=String(body.get('upload_id')||''), s=sessions.get(uploadId);
              if(s){
                const offset=Number(body.get('offset')||0), blob=body.get('chunk');
                if(!(blob instanceof Blob)) return nativeFetch(input,init);
                const end=offset+blob.size-1, final=end+1>=s.total;
                const rr=await nativeFetch(s.url,{method:'PUT',body:blob,redirect:'manual',headers:{'Content-Type':s.mime,'Content-Range':'bytes '+offset+'-'+end+'/'+s.total}});
                if(rr.status!==308 && rr.status!==200 && rr.status!==201){
                  let t='';try{t=await rr.text();}catch(e){} throw new Error('Google Drive upload failed (HTTP '+rr.status+'). '+t.slice(0,180));
                }
                if(final){
                  let meta={};try{meta=await rr.json();}catch(e){}
                  if(!meta.id) throw new Error('Google Drive completed the upload but did not return a file ID.');
                  s.fileId=meta.id;sessions.set(uploadId,s);
                }
                return new Response(JSON.stringify({success:true,data:{next_offset:end+1,storage:'google_drive'}}),{status:200,headers:{'Content-Type':'application/json'}});
              }
            }
            if(action==='jkssb_ui_finalize'){
              const uploadId=String(body.get('upload_id')||''), s=sessions.get(uploadId);
              if(s&&s.fileId) body.set('drive_file_id',s.fileId);
            }
            const res=await nativeFetch(input,init);
            if(action==='jkssb_ui_begin'){
              try{
                const clone=res.clone(), j=await clone.json();
                if(j&&j.success&&j.data&&j.data.storage_target==='google_drive'&&j.data.drive_session_url){
                  sessions.set(String(j.data.upload_id),{url:String(j.data.drive_session_url),total:Number(j.data.expected_bytes||0),mime:String(j.data.mime_type||'application/octet-stream'),fileId:''});
                }
              }catch(e){}
            }
            return res;
          };
        })();
        </script>
        <?php
    }

    public function rest_routes() {
        register_rest_route( 'jksh-drive/v1', '/status', array(
            'methods' => 'GET',
            'permission_callback' => function () { return current_user_can( 'manage_options' ); },
            'callback' => function () { return rest_ensure_response( $this->readiness() ); },
        ) );
    }

    public function admin_footer() {
        if ( ! is_admin() || 'jksh-accounts' !== sanitize_key( (string) ( $_GET['page'] ?? '' ) ) || ! $this->deps_ready() ) return;
        $c = $this->config();
        $r = $this->readiness();
        ?>
        <section id="jksh-google-drive-storage-v010" class="jksh-card" style="display:block;margin-top:18px;max-width:1100px">
          <h2>Google Drive Storage <span class="jksh-badge status-<?php echo esc_attr( $r['connected'] ? 'connected' : ( $r['configured'] ? 'attention' : 'not_connected' ) ); ?>"><?php echo esc_html( $r['connected'] ? 'Connected' : 'Setup' ); ?></span></h2>
          <p><strong>Large-file storage:</strong> files over 50 MB upload directly from your browser to Google Drive. WordPress stores metadata only, not media bytes.</p>
          <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="jksh-form">
            <input type="hidden" name="action" value="jksh_drive_save_settings"><?php wp_nonce_field( 'jksh_drive_save_settings' ); ?>
            <p><label><strong>Google OAuth Client ID</strong><br><input type="text" name="client_id" value="<?php echo esc_attr( $c['client_id'] ); ?>" style="width:100%"></label></p>
            <p><label><strong>Google OAuth Client Secret</strong><br><input type="password" name="client_secret" placeholder="<?php echo $c['client_secret'] ? 'Saved securely - leave blank to keep it' : 'Enter Client Secret'; ?>" style="width:100%"></label></p>
            <p><label><input type="checkbox" name="enabled" value="1" <?php checked( $c['enabled'] ); ?>> Enable Google Drive storage for files over 50 MB</label></p>
            <p><button class="button button-primary">Save Drive settings</button></p>
          </form>
          <hr>
          <p><strong>OAuth redirect URI</strong><br><code><?php echo esc_html( $this->redirect_uri() ); ?></code></p>
          <p><strong>Required scope</strong><br><code><?php echo esc_html( self::DRIVE_SCOPE ); ?></code></p>
          <?php if ( $r['configured'] ) : ?>
            <form style="display:inline" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="jksh_drive_oauth_start"><?php wp_nonce_field( 'jksh_drive_oauth_start' ); ?><button class="button button-hero">Connect / Reconnect Google Drive</button></form>
          <?php endif; ?>
          <?php if ( $r['connected'] ) : ?>
            <p><strong>Status:</strong> Connected · Large Media folder ready · Token expiry <?php echo esc_html( $r['token_expires_at'] ); ?></p>
            <p><form style="display:inline" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="jksh_drive_test_account"><?php wp_nonce_field( 'jksh_drive_test_account' ); ?><button class="button">Test Drive</button></form>
            <form style="display:inline" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="jksh_drive_disconnect_account"><?php wp_nonce_field( 'jksh_drive_disconnect_account' ); ?><button class="button button-link-delete">Disconnect</button></form></p>
          <?php endif; ?>
        </section>
        <script>(()=>{const card=document.getElementById('jksh-google-drive-storage-v010'),grid=document.querySelector('.jksh-account-health-grid');if(card&&grid){const b=document.createElement('button');b.type='button';b.className='jksh-health-card';b.innerHTML='<span class="jksh-health-icon">D</span><span><small>Google Drive</small><strong><?php echo esc_js( $r['connected'] ? 'Connected' : 'Setup required' ); ?></strong><em><?php echo esc_js( $r['connected'] ? 'Large media vault ready' : 'Connect for >50 MB uploads' ); ?></em></span>';b.onclick=()=>card.scrollIntoView({behavior:'smooth',block:'start'});grid.appendChild(b);}})();</script>
        <?php
    }
}

add_action( 'plugins_loaded', function () { if ( class_exists( '\\JKSH\\Plugin' ) ) JKSH_Google_Drive_Storage_V010::instance(); }, 35 );
