<?php
// JKSH_V0913_EMBED_BOOTSTRAP
$jksh_v0913_sync = __DIR__ . '/class-jksh-content-library-v0913-upload-sync.php';
if ( is_readable( $jksh_v0913_sync ) ) { require_once $jksh_v0913_sync; }

/** Integrated Content Library for JK Social Hub v0.9.1. */
if (!defined('ABSPATH')) { exit; }

final class JKSH_Content_Library_V091 {
    const VERSION = '0.9.1';
    const OPT_OVERRIDES = 'jksh_clm_bundle_overrides';
    const OPT_HIDDEN = 'jksh_clm_hidden_bundles';
    const OPT_ARCHIVED = 'jksh_clm_archived_content';

    private static $instance;
    private $page_slug = '';
    private $parent_slug = '';
    private $capability = 'manage_options';

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', [$this, 'replace_content_library'], 9999);
        add_action('admin_notices', [$this, 'admin_notices']);
        add_action('admin_menu', [$this, 'enforce_exclusive_content_library_hook'], 10000);
        add_action('admin_footer', [$this, 'render_test_qa_delete_controls']);
        add_action('admin_post_jksh_delete_test_qa', [$this, 'handle_test_qa_delete_admin_post']);
        add_action('rest_api_init', [$this, 'register_test_qa_rest_routes']);
    }

    public function replace_content_library() {
        global $submenu;
        $found = false;
        foreach ((array) $submenu as $parent => $items) {
            foreach ((array) $items as $item) {
                $label = isset($item[0]) ? wp_strip_all_tags((string) $item[0]) : '';
                if (stripos($label, 'Content Library') !== false) {
                    $this->parent_slug = (string) $parent;
                    $this->capability = isset($item[1]) ? (string) $item[1] : 'manage_options';
                    $this->page_slug = isset($item[2]) ? (string) $item[2] : 'jksh-content-library';
                    remove_submenu_page($this->parent_slug, $this->page_slug);
                    add_submenu_page(
                        $this->parent_slug,
                        'Content Library',
                        'Content Library',
                        $this->capability,
                        $this->page_slug,
                        [$this, 'render_page']
                    );
                    $found = true;
                    break 2;
                }
            }
        }
        if (!$found) {
            $this->parent_slug = 'jk-social-hub';
            $this->page_slug = 'jksh-content-library';
            add_submenu_page($this->parent_slug, 'Content Library', 'Content Library', 'manage_options', $this->page_slug, [$this, 'render_page']);
        }
    }
    /* JKSH_V091_RUNTIME_SAFE_TEST_UI_PATCH */
    public function enforce_exclusive_content_library_hook() {
        if (!is_admin() || !function_exists('get_plugin_page_hookname')) return;
        $hook = get_plugin_page_hookname($this->page_slug, $this->parent_slug);
        if ($hook) {
            remove_all_actions($hook);
            add_action($hook, [$this, 'render_page']);
        }
    }

    private function jksh_is_test_qa_record($row) {
        if (!$row || !is_array($row)) return false;
        $haystack = implode(' ', [
            (string)($row['title'] ?? ''),
            (string)($row['content_type'] ?? ''),
            (string)($row['body'] ?? ''),
            (string)($row['meta_json'] ?? ''),
        ]);
        return (bool) preg_match('/(^|\\b)(qa|test|specimen)(\\b|$)|do not publish|internal qa|internal test|jk direct mcp|dry[ -]?run test/i', $haystack);
    }

    private function jksh_delete_test_qa_local($content_id) {
        global $wpdb;
        $id = absint($content_id);
        if (!$id) throw new Exception('Missing content ID.');
        $content = $wpdb->prefix . 'jksh_content';
        $variants_t = $wpdb->prefix . 'jksh_variants';
        $jobs_t = $wpdb->prefix . 'jksh_jobs';
        $logs_t = $wpdb->prefix . 'jksh_publish_logs';
        $media_t = $wpdb->prefix . 'jksh_media';
        $analytics_t = $wpdb->prefix . 'jksh_analytics';
        $receipts_t = $wpdb->prefix . 'jksh_queue_bridge_receipts';
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$content} WHERE id=%d", $id), ARRAY_A);
        if (!$row) throw new Exception('Content not found.');
        if (!$this->jksh_is_test_qa_record($row)) throw new Exception('Refused: record is not classified as Test/QA.');
        $variants = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$variants_t} WHERE content_id=%d ORDER BY id", $id), ARRAY_A) ?: [];
        $jobs = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$jobs_t} WHERE content_id=%d ORDER BY id", $id), ARRAY_A) ?: [];
        $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$logs_t} WHERE content_id=%d ORDER BY id", $id), ARRAY_A) ?: [];
        $receipts = [];
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $receipts_t)) === $receipts_t) {
            $receipts = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$receipts_t} WHERE content_id=%d", $id), ARRAY_A) ?: [];
        }
        $external = [];
        foreach ($variants as $v) {
            if (!empty($v['external_id']) || !empty($v['external_url'])) $external[] = [
                'source'=>'variant','variant_id'=>(int)$v['id'],'platform'=>(string)$v['platform'],
                'external_id'=>(string)$v['external_id'],'external_url'=>(string)$v['external_url'],
            ];
        }
        foreach ($logs as $l) {
            if (!empty($l['external_id']) || !empty($l['external_url'])) $external[] = [
                'source'=>'log','log_id'=>(int)$l['id'],'external_id'=>(string)$l['external_id'],'external_url'=>(string)$l['external_url'],
            ];
        }
        $audit = get_option('jksh_v091_test_qa_delete_audit', []);
        if (!is_array($audit)) $audit = [];
        $audit[] = [
            'deleted_at_utc'=>gmdate('c'),'deleted_by'=>get_current_user_id(),'content'=>$row,
            'variants'=>$variants,'jobs'=>$jobs,'receipts'=>$receipts,'external_posts_preserved'=>$external,
        ];
        update_option('jksh_v091_test_qa_delete_audit', array_slice($audit, -200), false);
        $hidden = get_option('jksh_clm_hidden_bundles', []);
        if (!is_array($hidden)) $hidden = [];
        foreach ($receipts as $r) if (!empty($r['bundle_id']) && !in_array($r['bundle_id'], $hidden, true)) $hidden[] = $r['bundle_id'];
        update_option('jksh_clm_hidden_bundles', array_values(array_unique($hidden)), false);
        $variant_ids = array_values(array_filter(array_map('absint', wp_list_pluck($variants, 'id'))));
        $wpdb->query('START TRANSACTION');
        try {
            if ($variant_ids && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $analytics_t)) === $analytics_t) {
                $marks = implode(',', array_fill(0, count($variant_ids), '%d'));
                $wpdb->query($wpdb->prepare("DELETE FROM {$analytics_t} WHERE variant_id IN ({$marks})", ...$variant_ids));
            }
            $wpdb->delete($logs_t, ['content_id'=>$id]);
            $wpdb->delete($jobs_t, ['content_id'=>$id]);
            $wpdb->delete($media_t, ['content_id'=>$id]);
            $wpdb->delete($variants_t, ['content_id'=>$id]);
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $receipts_t)) === $receipts_t) $wpdb->delete($receipts_t, ['content_id'=>$id]);
            $wpdb->delete($content, ['id'=>$id]);
            $wpdb->query('COMMIT');
        } catch (Throwable $e) {
            $wpdb->query('ROLLBACK');
            throw $e;
        }
        $archived = get_option('jksh_clm_archived_content', []);
        if (is_array($archived)) update_option('jksh_clm_archived_content', array_values(array_filter($archived, fn($v)=>(int)$v !== $id)), false);
        return ['content_id'=>$id,'external_posts_preserved'=>$external];
    }

    public function register_test_qa_rest_routes() {
        register_rest_route('jksh/v1', '/test-qa-cleanup', [
            'methods'=>'POST',
            'permission_callback'=>function(){ return current_user_can('manage_options'); },
            'callback'=>function(WP_REST_Request $request){
                if (!$request->get_param('confirm')) return new WP_Error('confirmation_required','Set confirm=true.',['status'=>400]);
                $ids = array_values(array_unique(array_filter(array_map('absint',(array)$request->get_param('content_ids')))));
                if (!$ids) return new WP_Error('missing_ids','No content IDs supplied.',['status'=>400]);
                $deleted=[];$skipped=[];
                foreach ($ids as $id) {
                    try { $deleted[]=$this->jksh_delete_test_qa_local($id); }
                    catch (Throwable $e) { $skipped[]=['content_id'=>$id,'reason'=>$e->getMessage()]; }
                }
                return rest_ensure_response(['ok'=>true,'deleted'=>$deleted,'skipped'=>$skipped]);
            },
        ]);
    }

    public function handle_test_qa_delete_admin_post() {
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions.');
        check_admin_referer('jksh_test_qa_delete','jksh_test_qa_nonce');
        $id = absint($_POST['content_id'] ?? 0);
        $msg = 'Test/QA record deleted locally.';
        try {
            $r = $this->jksh_delete_test_qa_local($id);
            if (!empty($r['external_posts_preserved'])) $msg .= ' External platform posts were preserved.';
        } catch (Throwable $e) { $msg = 'Delete refused: ' . $e->getMessage(); }
        wp_safe_redirect(add_query_arg('jkshclm_notice', rawurlencode($msg), admin_url('admin.php?page=' . rawurlencode($this->page_slug))));
        exit;
    }

    public function render_test_qa_delete_controls() {
        if (!is_admin() || (string)($_GET['page'] ?? '') !== (string)$this->page_slug) return;
        $nonce = wp_create_nonce('jksh_test_qa_delete');
        $action = admin_url('admin-post.php');
        ?>
        <style>
        .jksh-test-delete-form{display:inline-flex;margin:0 0 0 8px;vertical-align:middle}.jksh-test-delete{border-color:#fda29b!important;background:#fff5f5!important;color:#b42318!important;font-weight:700!important}.jksh-test-delete:hover{background:#fee4e2!important;border-color:#f97066!important;color:#912018!important}
        </style>
        <script>
        document.addEventListener('DOMContentLoaded',function(){
          const qa=/(^|\\b)(qa|test|specimen)(\\b|$)|do not publish|internal qa|internal test|jk direct mcp|dry[ -]?run test/i;
          document.querySelectorAll('.jksh-content-table tbody tr').forEach(function(row){
            if(!qa.test(row.textContent||'')) return;
            const open=Array.from(row.querySelectorAll('a')).find(a=>(a.textContent||'').trim()==='Open'); if(!open) return;
            let u; try{u=new URL(open.href,window.location.origin);}catch(e){return;}
            const id=u.searchParams.get('edit_content')||u.searchParams.get('content_id'); if(!id) return;
            const cell=open.closest('td')||open.parentElement; if(!cell||cell.querySelector('.jksh-test-delete-form')) return;
            const form=document.createElement('form');form.method='post';form.action=<?php echo wp_json_encode($action); ?>;form.className='jksh-test-delete-form';
            [['action','jksh_delete_test_qa'],['jksh_test_qa_nonce',<?php echo wp_json_encode($nonce); ?>],['content_id',id]].forEach(function(kv){const i=document.createElement('input');i.type='hidden';i.name=kv[0];i.value=kv[1];form.appendChild(i);});
            const b=document.createElement('button');b.type='submit';b.className='button jksh-test-delete';b.textContent='Delete Test';form.appendChild(b);
            form.addEventListener('submit',function(e){if(!window.confirm('Delete this local Test/QA record? External social posts and media files will stay untouched.'))e.preventDefault();});
            cell.appendChild(form);
          });
        });
        </script><?php
    }

    public function admin_notices() {
        if (!empty($_GET['jkshclm_notice'])) {
            $kind = sanitize_key($_GET['jkshclm_kind'] ?? 'success');
            $class = $kind === 'error' ? 'notice-error' : ($kind === 'warning' ? 'notice-warning' : 'notice-success');
            echo '<div class="notice '.esc_attr($class).' is-dismissible"><p>'.esc_html(wp_unslash($_GET['jkshclm_notice'])).'</p></div>';
        }
    }

    private function tables() {
        global $wpdb;
        return [
            'content' => $wpdb->prefix.'jksh_content',
            'variants' => $wpdb->prefix.'jksh_variants',
            'jobs' => $wpdb->prefix.'jksh_jobs',
            'media' => $wpdb->prefix.'jksh_media',
            'logs' => $wpdb->prefix.'jksh_publish_logs',
            'receipts' => $wpdb->prefix.'jksh_queue_bridge_receipts',
        ];
    }

    private function ability_execute($name, $input = []) {
        if (!function_exists('wp_get_ability')) return new WP_Error('abilities_missing', 'WordPress Abilities API is unavailable.');
        try {
            $ability = wp_get_ability($name);
            if (!$ability) return new WP_Error('ability_missing', 'Ability unavailable: '.$name);
            return $ability->execute($input);
        } catch (Throwable $e) {
            return new WP_Error('ability_error', $e->getMessage());
        }
    }

    private function upload_drafts() {
        $res = $this->ability_execute('jk-social-supabase/list-upload-drafts', []);
        if (is_wp_error($res)) return [];
        if (is_array($res) && isset($res['items']) && is_array($res['items'])) return $res['items'];
        return [];
    }

    private function json_decode_array($value) {
        if (is_array($value)) return $value;
        if (!is_string($value) || $value === '') return [];
        $d = json_decode($value, true);
        return is_array($d) ? $d : [];
    }

    private function overrides() { $v = get_option(self::OPT_OVERRIDES, []); return is_array($v) ? $v : []; }
    private function hidden() { $v = get_option(self::OPT_HIDDEN, []); return is_array($v) ? $v : []; }
    private function archived() { $v = get_option(self::OPT_ARCHIVED, []); return is_array($v) ? $v : []; }

    private function merge_bundle_override($bundle) {
        $all = $this->overrides();
        $id = (string)($bundle['bundle_id'] ?? '');
        if ($id && !empty($all[$id]) && is_array($all[$id])) {
            $bundle = array_replace_recursive($bundle, $all[$id]);
            $bundle['_library_override'] = true;
        }
        return $bundle;
    }

    private function get_receipt_map() {
        global $wpdb;
        $t = $this->tables()['receipts'];
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) !== $t) return [];
        $rows = $wpdb->get_results("SELECT bundle_id, content_id, scheduled_at_ist, status, updated_at FROM {$t} WHERE bundle_id <> '' ORDER BY id DESC", ARRAY_A);
        $map = [];
        foreach ((array)$rows as $r) if (!isset($map[$r['bundle_id']])) $map[$r['bundle_id']] = $r;
        return $map;
    }

    private function load_content_map() {
        global $wpdb;
        $t = $this->tables();
        $rows = $wpdb->get_results("SELECT * FROM {$t['content']} ORDER BY id DESC", ARRAY_A);
        $map = [];
        foreach ((array)$rows as $r) $map[(int)$r['id']] = $r;
        return $map;
    }

    private function variants_for($content_id) {
        global $wpdb; $t = $this->tables();
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['variants']} WHERE content_id=%d ORDER BY id ASC", $content_id), ARRAY_A) ?: [];
    }

    private function jobs_for($content_id) {
        global $wpdb; $t = $this->tables();
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['jobs']} WHERE content_id=%d ORDER BY id ASC", $content_id), ARRAY_A) ?: [];
    }

    private function logs_for($content_id) {
        global $wpdb; $t = $this->tables();
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['logs']} WHERE content_id=%d ORDER BY id DESC LIMIT 100", $content_id), ARRAY_A) ?: [];
    }

    private function content_media_for($content_id) {
        global $wpdb; $t = $this->tables();
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['media']} WHERE content_id=%d ORDER BY sort_order ASC, id ASC", $content_id), ARRAY_A) ?: [];
    }

    private function build_items() {
        $drafts = $this->upload_drafts();
        $receipts = $this->get_receipt_map();
        $contents = $this->load_content_map();
        $hidden = $this->hidden();
        $archived = $this->archived();
        $tombstones = get_option('jksh_clm_row_tombstones', []);
        if(!is_array($tombstones)) $tombstones=[];
        $tomb_bundle_ids=array_keys((array)($tombstones['bundles']??[]));
        $tomb_content_ids=array_map('strval',array_keys((array)($tombstones['contents']??[])));
        $used_content = [];
        $items = [];

        foreach ($drafts as $bundle) {
            $bundle = $this->merge_bundle_override($bundle);
            $bid = (string)($bundle['bundle_id'] ?? '');
            if (!$bid || in_array($bid, $hidden, true) || in_array($bid,$tomb_bundle_ids,true)) continue;
            $receipt = $receipts[$bid] ?? null;
            $cid = $receipt ? (int)$receipt['content_id'] : 0;
            $content = ($cid && isset($contents[$cid])) ? $contents[$cid] : null;
            if ($cid) $used_content[$cid] = true;
            $variants = $cid ? $this->variants_for($cid) : [];
            $jobs = $cid ? $this->jobs_for($cid) : [];
            $items[] = $this->normalize_item($bundle, $content, $variants, $jobs, $receipt);
        }
        foreach ($contents as $cid => $content) {
            $content_meta = $this->json_decode_array($content['meta_json'] ?? '');
            $content_bundle_ids = array_values(array_unique(array_filter(array_map('strval', [
                $content_meta['bundle_id'] ?? '',
                $content_meta['upload_snapshot']['bundle_id'] ?? '',
            ]))));
            $content_bundle_tombstoned = false;
            foreach ($content_bundle_ids as $content_bundle_id) {
                if (in_array($content_bundle_id, $tomb_bundle_ids, true) || in_array($content_bundle_id, $hidden, true)) {
                    $content_bundle_tombstoned = true;
                    break;
                }
            }
            if (isset($used_content[$cid]) || in_array((string)$cid, array_map('strval',$archived), true) || in_array((string)$cid,$tomb_content_ids,true) || $content_bundle_tombstoned) continue;
            $items[] = $this->normalize_item(null, $content, $this->variants_for($cid), $this->jobs_for($cid), null);
        }
        usort($items, function($a,$b){ return strcmp($b['created_sort'], $a['created_sort']); });
        return $items;
    }

    private function normalize_item($bundle, $content, $variants, $jobs, $receipt) {
        $platforms = [];
        if ($bundle && !empty($bundle['selected_platforms'])) $platforms = array_values((array)$bundle['selected_platforms']);
        if ($content) { $cm=$this->json_decode_array($content['meta_json']??''); $snap=isset($cm['upload_snapshot'])&&is_array($cm['upload_snapshot'])?$cm['upload_snapshot']:[]; foreach((array)($snap['selected_platforms']??[]) as $p) if($p)$platforms[]=$p; }
        foreach ($variants as $v) if (!empty($v['platform'])) $platforms[] = $v['platform'];
        $platforms = array_values(array_unique(array_filter($platforms)));
        $title = $content['title'] ?? ($bundle['title'] ?? '(Untitled upload)');
        $type = $content['content_type'] ?? ($bundle['content_type'] ?? 'upload');
        $created = $content['created_at'] ?? ($bundle['created_at_utc'] ?? '');
        $state = 'Uploaded';
        $published = false; $sandbox_published = false; $sandbox_pin_id = ''; $sandbox_pin_url = ''; $sandbox_board_name = ''; $queued = false; $failed = false; $cancelled = false; $community = false;
        foreach ($variants as $v) {
            $s = strtolower((string)$v['status']);
            if ($s === 'published') $published = true;
            $vf = json_decode((string)($v['fields_json'] ?? '{}'), true);
            if ($s === 'published' && is_array($vf) && !empty($vf['sandbox_published'])) {
                $sandbox_published = true;
                if (!$sandbox_pin_id) $sandbox_pin_id = sanitize_text_field((string)($vf['sandbox_pin_id'] ?? $v['external_id'] ?? ''));
                if (!$sandbox_pin_url) $sandbox_pin_url = esc_url_raw((string)($vf['sandbox_pin_url'] ?? $v['external_url'] ?? ''));
                if (!$sandbox_board_name) $sandbox_board_name = sanitize_text_field((string)($vf['sandbox_board_name'] ?? ''));
            }
            if (in_array($s,['scheduled','queued','processing'],true)) $queued = true;
            if (in_array($s,['failed','blocked','needs_attention'],true)) $failed = true;
            if ($s === 'cancelled') $cancelled = true;
            if ($s === 'community_ready') $community = true;
        }
        foreach ($jobs as $j) {
            $s = strtolower((string)$j['status']);
            if ($s === 'published') $published = true;
            $jr = json_decode((string)($j['last_response_json'] ?? '{}'), true);
            if ($s === 'published' && is_array($jr) && !empty($jr['sandbox_published'])) {
                $sandbox_published = true;
                if (!$sandbox_pin_id) $sandbox_pin_id = sanitize_text_field((string)($jr['sandbox_pin_id'] ?? $jr['id'] ?? ''));
                if (!$sandbox_pin_url) $sandbox_pin_url = esc_url_raw((string)($jr['sandbox_pin_url'] ?? ''));
            }
            if (in_array($s,['scheduled','queued','processing'],true)) $queued = true;
            if (in_array($s,['failed','blocked','needs_attention'],true)) $failed = true;
            if ($s === 'cancelled') $cancelled = true;
            if ($s === 'community_ready') $community = true;
        }
        if ($failed) $state = 'Needs attention';
        elseif ($published && $queued) $state = 'Part published';
        elseif ($sandbox_published) $state = 'Sandbox Published';
        elseif ($published) $state = 'Published';
        elseif ($community) $state = 'Community ready';
        elseif ($queued) $state = 'Scheduled';
        elseif ($cancelled) $state = 'Cancelled';
        elseif ($content) $state = ucfirst((string)$content['status']);

        $next = '';
        foreach ($jobs as $j) {
            if (!empty($j['scheduled_at']) && in_array($j['status'], ['queued','scheduled'], true)) {
                if (!$next || $j['scheduled_at'] < $next) $next = $j['scheduled_at'];
            }
        }
        return [
            'bundle_id' => $bundle['bundle_id'] ?? '', 'content_id' => (int)($content['id'] ?? 0),
            'title' => $title, 'type' => $type, 'state' => $state, 'platforms' => $platforms,
            'media_count' => $bundle ? count(array_filter(array_map('absint',(array)($bundle['attachment_ids'] ?? [])),fn($id)=>$id && get_post_type($id)==='attachment')) : count(array_filter($this->json_decode_array($content['media_json'] ?? ''),fn($id)=>absint($id) && get_post_type(absint($id))==='attachment')),
            'created_sort' => $created, 'next_schedule' => $next, 'bundle' => $bundle, 'content' => $content,
            'sandbox_pin_id' => $sandbox_pin_id, 'sandbox_pin_url' => $sandbox_pin_url, 'sandbox_board_name' => $sandbox_board_name,
            'variants' => $variants, 'jobs' => $jobs, 'receipt' => $receipt,
        ];
    }

    private function can_destructive_delete($content_id) {
        if (!$content_id) return true;
        $variants = $this->variants_for($content_id); $jobs = $this->jobs_for($content_id);
        foreach ($variants as $v) if (!empty($v['external_id']) || in_array($v['status'],['published','processing'],true)) return false;
        foreach ($jobs as $j) if ((int)$j['attempts'] > 0 || in_array($j['status'],['published','processing'],true)) return false;
        return true;
    }

    private function handle_actions() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['jkshclm_action'])) return;
        if (!current_user_can($this->capability)) wp_die('Insufficient permissions.');
        check_admin_referer('jkshclm_action', 'jkshclm_nonce');
        $action = sanitize_key($_POST['jkshclm_action']);
        try {
            if ($action === 'save_bundle') $this->save_bundle();
            elseif ($action === 'hide_bundle') $this->hide_bundle();
            elseif ($action === 'save_content') $this->save_content();
            elseif ($action === 'archive_content') $this->archive_content();
            elseif ($action === 'delete_content') $this->delete_content();
            elseif ($action === 'save_variant') $this->save_variant();
            elseif ($action === 'cancel_job') $this->cancel_job();
        } catch (Throwable $e) {
            $this->redirect_notice('Error: '.$e->getMessage(), 'error');
        }
    }

    private function save_bundle() {
        $bid = sanitize_text_field(wp_unslash($_POST['bundle_id'] ?? ''));
        if (!$bid) throw new Exception('Missing bundle ID.');
        $ov = $this->overrides();
        $platforms = array_values(array_intersect(['instagram','facebook','youtube'], array_map('sanitize_key', (array)($_POST['selected_platforms'] ?? []))));
        $refs = preg_split('/\r\n|\r|\n/', (string)wp_unslash($_POST['product_refs'] ?? ''));
        $refs = array_values(array_filter(array_map('esc_url_raw', $refs)));
        $ov[$bid] = [
            'title' => sanitize_text_field(wp_unslash($_POST['title'] ?? '')),
            'content_type' => sanitize_key($_POST['content_type'] ?? 'upload'),
            'instructions' => wp_kses_post(wp_unslash($_POST['instructions'] ?? '')),
            'selected_platforms' => $platforms,
            'add_to_story' => !empty($_POST['add_to_story']),
            'highlight_name' => sanitize_text_field(wp_unslash($_POST['highlight_name'] ?? '')),
            'location' => sanitize_text_field(wp_unslash($_POST['location'] ?? '')),
            'product_url' => esc_url_raw(wp_unslash($_POST['product_url'] ?? '')),
            'product_refs' => $refs,
            'music_suggestion' => sanitize_text_field(wp_unslash($_POST['music_suggestion'] ?? '')),
            'autopilot_native_fields' => !empty($_POST['autopilot_native_fields']),
            '_library_ai_notes' => wp_kses_post(wp_unslash($_POST['ai_notes'] ?? '')),
            '_library_notes' => wp_kses_post(wp_unslash($_POST['library_notes'] ?? '')),
        ];
        update_option(self::OPT_OVERRIDES, $ov, false);
        $this->redirect_notice('Upload bundle saved in Content Library.');
    }

    private function hide_bundle() {
        $bid = sanitize_text_field(wp_unslash($_POST['bundle_id'] ?? ''));
        if (!$bid) throw new Exception('Missing bundle ID.');
        $hidden = $this->hidden(); if (!in_array($bid,$hidden,true)) $hidden[]=$bid;
        update_option(self::OPT_HIDDEN, array_values(array_unique($hidden)), false);
        $this->redirect_notice('Upload removed from Content Library. Media files were kept safe.');
    }

    private function save_content() {
        global $wpdb; $t=$this->tables();
        $id=absint($_POST['content_id']??0); if(!$id) throw new Exception('Missing content ID.');
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['content']} WHERE id=%d",$id),ARRAY_A); if(!$row) throw new Exception('Content not found.');
        $meta=$this->json_decode_array($row['meta_json']??'');
        $meta['library_notes']=wp_kses_post(wp_unslash($_POST['library_notes']??''));
        $meta['ai_notes']=wp_kses_post(wp_unslash($_POST['ai_notes']??''));
        $data=[
            'title'=>sanitize_text_field(wp_unslash($_POST['title']??$row['title'])),
            'body'=>wp_kses_post(wp_unslash($_POST['body']??$row['body'])),
            'meta_json'=>wp_json_encode($meta,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
            'updated_at'=>current_time('mysql',true),
        ];
        if($this->can_destructive_delete($id)) $data['content_type']=sanitize_key($_POST['content_type']??$row['content_type']);
        $wpdb->update($t['content'],$data,['id'=>$id]);
        $this->redirect_notice('Master content saved.');
    }

    private function archive_content() {
        $id=absint($_POST['content_id']??0); if(!$id) throw new Exception('Missing content ID.');
        $a=$this->archived(); if(!in_array((string)$id,array_map('strval',$a),true))$a[]=$id;
        update_option(self::OPT_ARCHIVED,array_values(array_unique($a)),false);
        $this->redirect_notice('Content archived from this library view. External posts were not touched.');
    }

    private function delete_content() {
        global $wpdb; $t=$this->tables(); $id=absint($_POST['content_id']??0); if(!$id) throw new Exception('Missing content ID.');
        if(!$this->can_destructive_delete($id)) throw new Exception('This content has started/published external work. Archive it instead of deleting database history.');
        $wpdb->query('START TRANSACTION');
        try {
            $wpdb->delete($t['logs'],['content_id'=>$id]);
            $wpdb->delete($t['jobs'],['content_id'=>$id]);
            $wpdb->delete($t['variants'],['content_id'=>$id]);
            $wpdb->delete($t['media'],['content_id'=>$id]);
            $wpdb->delete($t['content'],['id'=>$id]);
            $wpdb->query('COMMIT');
        } catch(Throwable $e){ $wpdb->query('ROLLBACK'); throw $e; }
        $this->redirect_notice('Unpublished content record deleted safely.');
    }

    private function save_variant() {
        global $wpdb; $t=$this->tables();
        $cid=absint($_POST['content_id']??0); $vid=absint($_POST['variant_id']??0); if(!$cid||!$vid) throw new Exception('Missing variant.');
        $v=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['variants']} WHERE id=%d AND content_id=%d",$vid,$cid),ARRAY_A); if(!$v) throw new Exception('Variant not found.');
        $fields_raw=wp_unslash($_POST['fields_json']??'{}'); $fields=json_decode($fields_raw,true); if(!is_array($fields)) throw new Exception('Platform fields JSON is invalid.');
        $hashtags=(string)wp_unslash($_POST['hashtags']??'');
        $input=[
            'content_id'=>$cid,'variant_id'=>$vid,
            'title'=>sanitize_text_field(wp_unslash($_POST['variant_title']??'')),
            'caption'=>wp_kses_post(wp_unslash($_POST['caption']??'')),
            'description'=>wp_kses_post(wp_unslash($_POST['description']??'')),
            'hashtags'=>$hashtags,'cta'=>wp_kses_post(wp_unslash($_POST['cta']??'')),
            'fields'=>$fields,'confirm'=>true,
        ];
        $publish_ist=sanitize_text_field(wp_unslash($_POST['publish_at_ist']??'')); if($publish_ist!=='')$input['publish_at_ist']=$publish_ist;
        $res=$this->ability_execute('jk-social/update-scheduled-variant',$input);
        if(is_wp_error($res)) throw new Exception($res->get_error_message());
        $this->redirect_notice(ucfirst($v['platform']).' variant updated in place.');
    }

    private function cancel_job() {
        $job=absint($_POST['job_id']??0); if(!$job) throw new Exception('Missing job ID.');
        $res=$this->ability_execute('jk-social/cancel-queued-job',['job_id'=>$job,'confirm'=>true]);
        if(is_wp_error($res)) throw new Exception($res->get_error_message());
        $this->redirect_notice('Queued job cancelled.');
    }

    private function redirect_notice($message,$kind='success') {
        $url=remove_query_arg(['jkshclm_notice','jkshclm_kind']);
        $url=add_query_arg(['jkshclm_notice'=>$message,'jkshclm_kind'=>$kind],$url);
        wp_safe_redirect($url); exit;
    }

    public function render_page() {
        if (!current_user_can($this->capability)) wp_die('Insufficient permissions.');
        $this->handle_actions();
        $edit_bundle=sanitize_text_field(wp_unslash($_GET['edit_bundle']??''));
        $edit_content=absint($_GET['edit_content']??0);
        if($edit_bundle || $edit_content){ $this->render_editor($edit_bundle,$edit_content); return; }
        $this->render_list();
    }

    private function render_list() {
        $all_items=$this->build_items();
        $stats=['Total'=>count($all_items),'Uploaded'=>0,'Scheduled'=>0,'Published'=>0,'Attention'=>0];
        foreach($all_items as $it){
            if(strtolower($it['state'])==='uploaded')$stats['Uploaded']++;
            if(in_array(strtolower($it['state']),['scheduled','part published'],true))$stats['Scheduled']++;
            if(strtolower($it['state'])==='published')$stats['Published']++;
            if(strtolower($it['state'])==='needs attention')$stats['Attention']++;
        }
        $items=$all_items;
        $q=strtolower(sanitize_text_field(wp_unslash($_GET['s']??'')));
        $status=sanitize_text_field(wp_unslash($_GET['status_filter']??''));
        $type=sanitize_text_field(wp_unslash($_GET['type_filter']??''));
        $platform=sanitize_text_field(wp_unslash($_GET['platform_filter']??''));
        $date_from=sanitize_text_field(wp_unslash($_GET['date_from']??''));
        $date_to=sanitize_text_field(wp_unslash($_GET['date_to']??''));
        if($date_from && !preg_match('/^\d{4}-\d{2}-\d{2}$/',$date_from))$date_from='';
        if($date_to && !preg_match('/^\d{4}-\d{2}-\d{2}$/',$date_to))$date_to='';
        $jksh_date_keys_present=array_key_exists('date_from',$_GET)||array_key_exists('date_to',$_GET);
        if(!$jksh_date_keys_present){
            $jksh_today_ist=wp_date('Y-m-d',time(),new DateTimeZone('Asia/Kolkata'));
            $date_from=$jksh_today_ist;
            $date_to=$jksh_today_ist;
        }
        if($date_from && $date_to && $date_from>$date_to){$swap=$date_from;$date_from=$date_to;$date_to=$swap;}
        $items=array_values(array_filter($items,function($i)use($q,$status,$type,$platform,$date_from,$date_to){
            if($q && strpos(strtolower($i['title'].' '.$i['bundle_id'].' '.$i['content_id']),$q)===false)return false;
            if($status && strtolower($i['state'])!==strtolower($status))return false;
            if($type && $i['type']!==$type)return false;
            if($platform && !in_array($platform,$i['platforms'],true))return false;
            if($date_from || $date_to){
                $item_date='';
                if(!empty($i['created_sort'])){
                    try{
                        $dt=new DateTime((string)$i['created_sort'],new DateTimeZone('UTC'));
                        $dt->setTimezone(new DateTimeZone('Asia/Kolkata'));
                        $item_date=$dt->format('Y-m-d');
                    }catch(Throwable $e){
                        $item_date=substr((string)$i['created_sort'],0,10);
                    }
                }
                if($date_from && (!$item_date || $item_date<$date_from))return false;
                if($date_to && (!$item_date || $item_date>$date_to))return false;
            }
            return true;
        }));
        $base=admin_url('admin.php?page='.rawurlencode($this->page_slug));
        echo '<div class="wrap jkshclm jksh-enterprise">'.$this->styles();
        echo '<header class="jksh-hero"><div><div class="jksh-eyebrow">JK SOCIAL HUB · UNIFIED</div><h1>Content Library <span class="jkshclm-version">v'.esc_html(self::VERSION).'</span></h1><p>One workspace for uploads, platform variants, schedules, publishing history, AI notes and safe cleanup.</p></div><div class="jksh-hero-actions"><button type="button" id="jksh-delete-published-media" class="button button-primary">Delete Media</button></div></header>';
        echo '<div class="jksh-stat-grid">';
        foreach($stats as $label=>$value){$cls=strtolower(str_replace(' ','-',$label));echo '<div class="jksh-stat '.$cls.'"><span>'.esc_html($label).'</span><strong>'.esc_html($value).'</strong></div>';}
        echo '</div>';
        echo '<style>
        .jksh-date-range{display:flex;align-items:flex-end;gap:7px}
        .jksh-date-range label{display:flex;flex-direction:column;gap:3px;font-size:9px;line-height:1;font-weight:800;letter-spacing:.04em;text-transform:uppercase;color:#667085}
        .jksh-date-range input[type=date]{height:42px;min-width:132px;max-width:145px;padding:0 9px;border:1px solid #d0d5dd;border-radius:10px;background:#fff;color:#101828;box-sizing:border-box}
        @media(max-width:1180px){.jksh-toolbar{flex-wrap:wrap}.jksh-date-range{order:5}}
        @media(max-width:782px){.jksh-date-range{width:100%;order:5}.jksh-date-range label{flex:1}.jksh-date-range input[type=date]{width:100%;max-width:none;min-width:0}}
        </style>';
        echo '<form method="get" class="jkshclm-filters jksh-toolbar"><input type="hidden" name="page" value="'.esc_attr($this->page_slug).'">';
        echo '<div class="jksh-search"><span class="dashicons dashicons-search"></span><input type="search" name="s" value="'.esc_attr($_GET['s']??'').'" placeholder="Search content, bundle or ID"></div>';
        echo '<select name="status_filter"><option value="">All states</option>'; foreach(['Uploaded','Scheduled','Published','Sandbox Published','Part published','Community ready','Needs attention','Cancelled','Draft'] as $x)echo '<option '.selected($_GET['status_filter']??'',$x,false).'>'.esc_html($x).'</option>'; echo '</select>';
        echo '<select name="platform_filter"><option value="">All platforms</option>'; foreach(['instagram'=>'Instagram','facebook'=>'Facebook','youtube'=>'YouTube','threads'=>'Threads','pinterest'=>'Pinterest'] as $k=>$v)echo '<option value="'.$k.'" '.selected($_GET['platform_filter']??'',$k,false).'>'.$v.'</option>'; echo '</select>';
        echo '<div class="jksh-date-range"><label><span>From</span><input type="date" name="date_from" value="'.esc_attr($date_from).'"></label><label><span>To</span><input type="date" name="date_to" value="'.esc_attr($date_to).'"></label></div>';
        echo '<button class="button button-primary">Apply</button><a class="button" href="'.esc_url($base).'">Reset</a></form>';
        echo '<div class="jksh-table-wrap"><table class="jksh-content-table"><thead><tr><th>Content</th><th>Workflow</th><th>Platforms</th><th>Media</th><th>Created</th><th></th></tr></thead><tbody>';
        foreach($items as $i){
            $edit=$i['bundle_id']?add_query_arg('edit_bundle',$i['bundle_id'],$base):add_query_arg('edit_content',$i['content_id'],$base);
            $statecls=sanitize_html_class(strtolower(str_replace(' ','-',$i['state'])));
            $idline=$i['bundle_id']?'Bundle '.substr($i['bundle_id'],0,8).'…':'Content #'.$i['content_id'];
            $platforms=$i['platforms']?implode(' · ',array_map('ucfirst',$i['platforms'])):'—';
            echo '<tr><td data-label="Content"><div class="jksh-title-cell"><div class="jksh-type-icon">'.esc_html(strtoupper(substr((string)$i['type'],0,1))).'</div><div><strong>'.esc_html($i['title']).'</strong><small>'.esc_html($idline).' · '.esc_html($i['type']).'</small></div></div></td>';
            $workflow='<span class="badge state-'.$statecls.'">'.esc_html($i['state']).'</span>';
            if(!empty($i['sandbox_pin_id'])){
                $workflow.='<small style="display:block;margin-top:6px;font-weight:600;">Pin ID: '.esc_html($i['sandbox_pin_id']).'</small>';
                if(!empty($i['sandbox_pin_url'])) $workflow.='<small style="display:block;margin-top:3px;"><a target="_blank" rel="noopener" href="'.esc_url($i['sandbox_pin_url']).'">Open Pin ↗</a></small>';
                if(!empty($i['sandbox_board_name'])) $workflow.='<small style="display:block;margin-top:3px;color:#667085;">'.esc_html($i['sandbox_board_name']).'</small>';
            }
            echo '<td data-label="Workflow">'.$workflow.'</td>';
            echo '<td data-label="Platforms"><span class="jksh-platforms">'.esc_html($platforms).'</span></td>';
            echo '<td data-label="Media"><span class="jksh-num">'.esc_html($i['media_count']).'</span></td>';
            echo '<td data-label="Created"><span class="muted">'.esc_html($this->fmt_dt($i['created_sort'])).'</span></td>';
            echo '<td class="jksh-row-action"><a class="button button-primary" href="'.esc_url($edit).'">Open</a></td></tr>';
        }
        if(!$items)echo '<tr><td colspan="6"><div class="jksh-empty"><span class="dashicons dashicons-search"></span><strong>No content found</strong><p>Try a different search or filter.</p></div></td></tr>';
        echo '</tbody></table></div></div>';
    }

    private function render_editor($bundle_id,$content_id) {
        $items=$this->build_items(); $item=null;
        foreach($items as $i){if(($bundle_id&&$i['bundle_id']===$bundle_id)||($content_id&&$i['content_id']===$content_id)){$item=$i;break;}}
        if(!$item){echo '<div class="wrap"><h1>Content not found</h1></div>';return;}
        $base=admin_url('admin.php?page='.rawurlencode($this->page_slug));
        $statecls=sanitize_html_class(strtolower(str_replace(' ','-',$item['state'])));
        echo '<div class="wrap jkshclm jksh-enterprise jksh-editor-shell">'.$this->styles();
        echo '<header class="jksh-editor-head"><div><a class="jksh-back" href="'.esc_url($base).'">← Content Library</a><div class="jksh-eyebrow">UNIFIED CONTENT WORKSPACE</div><h1>'.esc_html($item['title']).'</h1><div class="jksh-head-meta"><span class="badge state-'.$statecls.'">'.esc_html($item['state']).'</span><span>'.esc_html($item['type']).'</span><span>'.esc_html($item['platforms']?implode(' · ',array_map('ucfirst',$item['platforms'])):'No platforms selected').'</span></div></div><div class="jksh-head-actions"><span class="jksh-version-pill">Social Hub v'.esc_html(self::VERSION).'</span><a class="button" href="#jksh-media">Media</a><a class="button button-primary" href="#jksh-platforms">Platform fields</a></div></header>';
        echo '<div class="jksh-editor-summary"><div><span>Content ID</span><strong>'.esc_html($item['content_id']?:'—').'</strong></div><div><span>Bundle</span><strong>'.esc_html($item['bundle_id']?substr($item['bundle_id'],0,12).'…':'—').'</strong></div><div><span>Media</span><strong>'.esc_html($item['media_count']).'</strong></div><div><span>Next schedule</span><strong>'.esc_html($item['next_schedule']?$this->fmt_utc_to_ist($item['next_schedule']).' IST':'—').'</strong></div></div>';
        echo '<nav class="jksh-section-nav"><a href="#jksh-overview">Overview</a><a href="#jksh-media">Media</a><a href="#jksh-platforms">Platforms & Jobs</a></nav>';
        echo '<main class="jkshclm-editor" id="jksh-overview">';
        if($item['bundle'])$this->render_bundle_editor($item);
        if($item['content'])$this->render_content_editor($item);
        echo '<div id="jksh-media">';$this->render_media($item);echo '</div>';
        if($item['content']){echo '<div id="jksh-platforms">';$this->render_variants_jobs($item);echo '</div>';}
        echo '</main></div>';
    }

    private function render_bundle_editor($item) {
        $b=$item['bundle'];
        echo '<section class="jksh-panel"><div class="jksh-panel-head"><div><span class="jksh-panel-kicker">UPLOAD SOURCE</span><h2>Upload details</h2><p>Original upload metadata, AI guidance and publishing intent.</p></div></div><form method="post">'; wp_nonce_field('jkshclm_action','jkshclm_nonce');
        echo '<input type="hidden" name="jkshclm_action" value="save_bundle"><input type="hidden" name="bundle_id" value="'.esc_attr($b['bundle_id']).'">';
        $this->field('Title','title',$b['title']??''); $this->field('Content type','content_type',$b['content_type']??'');
        $this->textarea('AI / Upload instructions','instructions',$b['instructions']??'',10);
        $this->textarea('Internal notes for AI','ai_notes',$b['_library_ai_notes']??'',4);
        $this->textarea('Internal team notes','library_notes',$b['_library_notes']??'',4);
        echo '<div class="two">'; $this->field('Location','location',$b['location']??''); $this->field('Highlight name','highlight_name',$b['highlight_name']??''); echo '</div>';
        $this->field('Product URL','product_url',$b['product_url']??''); $this->textarea('Product references (one URL per line)','product_refs',implode("\n",(array)($b['product_refs']??[])),3);
        $this->field('Music suggestion','music_suggestion',$b['music_suggestion']??'');
        echo '<div class="checks"><b>Platforms:</b> '; foreach(['instagram'=>'Instagram','facebook'=>'Facebook','youtube'=>'YouTube'] as $k=>$v)echo '<label><input type="checkbox" name="selected_platforms[]" value="'.$k.'" '.checked(in_array($k,(array)($b['selected_platforms']??[]),true),true,false).'> '.$v.'</label> '; echo '</div>';
        echo '<div class="checks"><label><input type="checkbox" name="add_to_story" '.checked(!empty($b['add_to_story']),true,false).'> Add companion Story</label> <label><input type="checkbox" name="autopilot_native_fields" '.checked(!empty($b['autopilot_native_fields']),true,false).'> Autopilot native fields</label></div>';
        submit_button('Save upload fields'); echo '</form>';
        echo '<form method="post" onsubmit="return confirm(\'Remove this upload from Content Library? Media files will be kept.\')">'; wp_nonce_field('jkshclm_action','jkshclm_nonce'); echo '<input type="hidden" name="jkshclm_action" value="hide_bundle"><input type="hidden" name="bundle_id" value="'.esc_attr($b['bundle_id']).'">'; submit_button('Remove upload from library','delete','',false); echo '</form></section>';
    }

    private function render_content_editor($item) {
        $c=$item['content']; $meta=$this->json_decode_array($c['meta_json']??'');
        echo '<section class="jksh-panel"><div class="jksh-panel-head"><div><span class="jksh-panel-kicker">MASTER RECORD #'.esc_html($c['id']).'</span><h2>Core content</h2><p>Canonical title, body and internal knowledge for this content item.</p></div></div><form method="post">'; wp_nonce_field('jkshclm_action','jkshclm_nonce');
        echo '<input type="hidden" name="jkshclm_action" value="save_content"><input type="hidden" name="content_id" value="'.esc_attr($c['id']).'">';
        $this->field('Master title','title',$c['title']); $this->field('Content type','content_type',$c['content_type']); $this->textarea('Master body','body',$c['body']??'',8);
        $this->textarea('Notes for AI','ai_notes',$meta['ai_notes']??'',4); $this->textarea('Internal notes','library_notes',$meta['library_notes']??'',4);
        echo '<p><b>Status:</b> '.esc_html($c['status']).' &nbsp; <b>Created:</b> '.esc_html($this->fmt_dt($c['created_at'])).' &nbsp; <b>Updated:</b> '.esc_html($this->fmt_dt($c['updated_at'])).'</p>';
        submit_button('Save master content'); echo '</form><div class="danger-zone"><h3>Library actions</h3>';
        echo '<form method="post" style="display:inline">'; wp_nonce_field('jkshclm_action','jkshclm_nonce'); echo '<input type="hidden" name="jkshclm_action" value="archive_content"><input type="hidden" name="content_id" value="'.esc_attr($c['id']).'">'; submit_button('Archive from library','secondary','',false); echo '</form> ';
        if($this->can_destructive_delete((int)$c['id'])){ echo '<form method="post" style="display:inline" onsubmit="return confirm(\'Permanently delete this unpublished Social Hub record and its local variants/jobs?\')">'; wp_nonce_field('jkshclm_action','jkshclm_nonce'); echo '<input type="hidden" name="jkshclm_action" value="delete_content"><input type="hidden" name="content_id" value="'.esc_attr($c['id']).'">'; submit_button('Delete unpublished record','delete','',false); echo '</form>'; }
        else echo '<p class="muted">Permanent delete is locked because publishing has started or an external post exists. Archive locally instead.</p>';
        echo '</div></section>';
    }

    private function render_media($item) {
        $media=[]; $snapshot=[];
        if($item['bundle']){
            foreach((array)($item['bundle']['media_meta']??[]) as $m)$media[]=$m;
            $snapshot=$item['bundle'];
        } elseif($item['content']){
            foreach($this->content_media_for((int)$item['content']['id']) as $m)$media[]=$m;
            $meta=$this->json_decode_array($item['content']['meta_json']??'');
            $snapshot=isset($meta['upload_snapshot'])&&is_array($meta['upload_snapshot'])?$meta['upload_snapshot']:[];
        }

        $visible=[];
        foreach($media as $m){
            $aid=absint($m['attachment_id']??0);
            $url=$aid?wp_get_attachment_url($aid):($m['source_url']??'');
            if(!$url)continue;
            $m['_url']=$url;$visible[]=$m;
        }

        $cover_id=absint($snapshot['cover_attachment_id']??0);
        $cover_url=$cover_id?wp_get_attachment_url($cover_id):'';
        $cover_meta=isset($snapshot['cover_meta'])&&is_array($snapshot['cover_meta'])?$snapshot['cover_meta']:[];
        $count=count($visible)+($cover_url?1:0);
        $cid=absint($item['content_id']??0);

        echo '<section class="jksh-panel"><div class="jksh-panel-head"><div><span class="jksh-panel-kicker">ASSETS</span><h2>Media <span class="count">'.esc_html($count).'</span></h2><p>Source media and publishing cover with WordPress / Supabase references.</p></div>';
        if($cid)echo '<div><button type="button" class="button jksh-task-media-delete" data-content-id="'.esc_attr($cid).'">Delete task media</button></div>';
        echo '</div><div class="media-grid">';

        foreach($visible as $m){
            $aid=absint($m['attachment_id']??0);$url=$m['_url'];$mime=$m['mime_type']??get_post_mime_type($aid);
            echo '<div class="media-card"><small><b>SOURCE</b></small>';
            if($url&&strpos((string)$mime,'image/')===0)echo '<img src="'.esc_url($url).'" alt="">';
            elseif($url&&strpos((string)$mime,'video/')===0)echo '<video src="'.esc_url($url).'" controls preload="metadata"></video>';
            echo '<b>#'.esc_html($aid?:'—').'</b><small>'.esc_html($m['filename']??basename(parse_url((string)$url,PHP_URL_PATH)?:'')).'</small><small>'.esc_html($mime?:'').'</small>';
            if(!empty($m['width']))echo '<small>'.esc_html($m['width'].'×'.$m['height']).'</small>';
            echo '</div>';
        }

        if($cover_url){
            $mime=$cover_meta['mime_type']??get_post_mime_type($cover_id);
            echo '<div class="media-card"><small><b>COVER</b></small><img src="'.esc_url($cover_url).'" alt=""><b>#'.esc_html($cover_id).'</b>';
            echo '<small>'.esc_html($snapshot['cover_filename']??($cover_meta['filename']??'Cover image')).'</small><small>'.esc_html($mime?:'image').'</small>';
            if(!empty($cover_meta['width']))echo '<small>'.esc_html($cover_meta['width'].'×'.$cover_meta['height']).'</small>';
            if(!empty($snapshot['cover_asset_id']))echo '<small>Supabase '.esc_html(substr((string)$snapshot['cover_asset_id'],0,12)).'…</small>';
            echo '</div>';
        }

        if(!$count)echo '<div class="jksh-empty"><strong>No local media remains</strong><p>The media may already have been cleaned up after publishing.</p></div>';
        echo '</div></section>';
    }

    private function render_variants_jobs($item) {
        $cid=(int)$item['content']['id']; $jobsByVariant=[]; foreach($item['jobs'] as $j)$jobsByVariant[(int)$j['variant_id']][]=$j;
        echo '<section class="jksh-panel"><div class="jksh-panel-head"><div><span class="jksh-panel-kicker">NATIVE PUBLISHING</span><h2>Platform variants & jobs</h2><p>Edit untouched schedules in place. Published or attempted records remain protected history.</p></div></div>';
        foreach($item['variants'] as $v){$readonly=in_array($v['status'],['published','processing','failed','cancelled'],true)||!empty($v['external_id']);$fields=$this->json_decode_array($v['fields_json']??''); echo '<details class="variant" open><summary><b>'.esc_html(ucfirst($v['platform'])).'</b> · '.esc_html($v['publication_type']).' · <span class="badge">'.esc_html($v['status']).'</span></summary>';
            if($readonly)echo '<p class="muted">External/past state is protected. Fields below are read-only history.</p>';
            echo '<form method="post">'; wp_nonce_field('jkshclm_action','jkshclm_nonce'); echo '<input type="hidden" name="jkshclm_action" value="save_variant"><input type="hidden" name="content_id" value="'.$cid.'"><input type="hidden" name="variant_id" value="'.esc_attr($v['id']).'">';
            $dis=$readonly?' disabled':''; $this->field('Platform title','variant_title',$v['title']??'',$dis); $this->textarea('Caption / message','caption',$v['caption']??'',6,$dis); $this->textarea('Description','description',$v['description']??'',5,$dis); $this->textarea('Hashtags','hashtags',$v['hashtags']??'',3,$dis); $this->textarea('CTA','cta',$v['cta']??'',3,$dis); $this->field('Publish at IST','publish_at_ist',$this->fmt_utc_to_ist_input($v['publish_at']??''),$dis); $this->textarea('All native platform fields (JSON)','fields_json',wp_json_encode($fields,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),14,$dis);
            if(!$readonly)submit_button('Save '.ucfirst($v['platform']).' variant'); echo '</form>';
            if(!empty($v['external_id'])||!empty($v['external_url']))echo '<p><b>External:</b> '.esc_html($v['external_id']).' '.($v['external_url']?'<a target="_blank" rel="noopener" href="'.esc_url($v['external_url']).'">Open published post ↗</a>':'').'</p>';
            echo '<div class="jobs"><h4>Jobs</h4>'; foreach((array)($jobsByVariant[(int)$v['id']]??[]) as $j){echo '<div class="job"><b>#'.esc_html($j['id']).' '.esc_html($j['job_type']).'</b> <span class="badge">'.esc_html($j['status']).'</span> <span>attempts '.esc_html($j['attempts']).'/'.esc_html($j['max_attempts']).'</span> <span>'.esc_html($this->fmt_utc_to_ist($j['scheduled_at']??'')).'</span>'; if(!empty($j['last_error']))echo '<div class="error">'.esc_html($j['last_error']).'</div>'; if($j['status']==='queued'&&(int)$j['attempts']===0){echo '<form method="post" style="display:inline">';wp_nonce_field('jkshclm_action','jkshclm_nonce');echo '<input type="hidden" name="jkshclm_action" value="cancel_job"><input type="hidden" name="job_id" value="'.esc_attr($j['id']).'">';submit_button('Cancel','small','',false);echo '</form>';} echo '</div>'; } echo '</div></details>'; }
        echo '<details><summary><b>Publish log history</b></summary><table class="widefat striped"><thead><tr><th>Time</th><th>Action</th><th>Result</th><th>Message</th><th>External</th></tr></thead><tbody>'; foreach($this->logs_for($cid) as $l)echo '<tr><td>'.esc_html($this->fmt_utc_to_ist($l['created_at'])).'</td><td>'.esc_html($l['action']).'</td><td>'.esc_html($l['result']).'</td><td>'.esc_html($l['message']).'</td><td>'.($l['external_url']?'<a target="_blank" href="'.esc_url($l['external_url']).'">Open</a>':esc_html($l['external_id'])).'</td></tr>'; echo '</tbody></table></details></section>';
    }

    private function field($label,$name,$value,$extra='') { echo '<label class="field"><span>'.esc_html($label).'</span><input type="text" name="'.esc_attr($name).'" value="'.esc_attr($value).'"'.$extra.'></label>'; }
    private function textarea($label,$name,$value,$rows=5,$extra='') { echo '<label class="field"><span>'.esc_html($label).'</span><textarea name="'.esc_attr($name).'" rows="'.absint($rows).'"'.$extra.'>'.esc_textarea($value).'</textarea></label>'; }
    private function fmt_dt($v){if(!$v)return'—';return esc_html((string)$v);}
    private function fmt_utc_to_ist($v){if(!$v)return'—';try{$d=new DateTime($v,new DateTimeZone('UTC'));$d->setTimezone(new DateTimeZone('Asia/Kolkata'));return $d->format('Y-m-d H:i:s');}catch(Throwable $e){return $v;}}
    private function fmt_utc_to_ist_input($v){if(!$v)return'';try{$d=new DateTime($v,new DateTimeZone('UTC'));$d->setTimezone(new DateTimeZone('Asia/Kolkata'));return $d->format('Y-m-d H:i:s');}catch(Throwable $e){return $v;}}
    private function styles(){return '<style>
    :root{--jk-navy:#0b1220;--jk-ink:#152033;--jk-muted:#667085;--jk-line:#e7eaf0;--jk-soft:#f7f9fc;--jk-blue:#2563eb;--jk-blue2:#1d4ed8;--jk-green:#08783e;--jk-amber:#9a6700;--jk-red:#b42318;--jk-purple:#6941c6}
    .jksh-enterprise{max-width:1540px;margin-top:22px;color:var(--jk-ink)}
    .jksh-hero,.jksh-editor-head{display:flex;justify-content:space-between;gap:24px;align-items:flex-start;background:linear-gradient(135deg,#0b1220 0%,#172554 65%,#1d4ed8 140%);color:#fff;border-radius:18px;padding:26px 28px;margin:0 0 18px;box-shadow:0 12px 28px rgba(15,23,42,.16)}
    .jksh-hero h1,.jksh-editor-head h1{color:#fff;margin:5px 0 8px;font-size:30px;line-height:1.15}.jksh-hero p{margin:0;color:#dbeafe;max-width:760px;font-size:14px}.jksh-eyebrow,.jksh-panel-kicker{font-size:10px;font-weight:800;letter-spacing:.12em;text-transform:uppercase}.jksh-eyebrow{color:#93c5fd}.jkshclm-version,.jksh-version-pill{display:inline-flex;align-items:center;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.11);color:#fff;border-radius:999px;padding:5px 9px;font-size:11px;font-weight:700}.jksh-hero-actions,.jksh-head-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.jksh-hero .button,.jksh-editor-head .button{border-color:rgba(255,255,255,.24);background:rgba(255,255,255,.08);color:#fff}.jksh-hero .button:hover,.jksh-editor-head .button:hover{background:rgba(255,255,255,.16);color:#fff}.jksh-hero .button-primary,.jksh-editor-head .button-primary{background:#fff;border-color:#fff;color:#0f172a}.jksh-hero .button-primary:hover,.jksh-editor-head .button-primary:hover{background:#eff6ff;color:#0f172a}
    .jksh-stat-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin:0 0 16px}.jksh-stat{background:#fff;border:1px solid var(--jk-line);border-radius:14px;padding:16px 18px;box-shadow:0 1px 2px rgba(15,23,42,.03)}.jksh-stat span{display:block;color:var(--jk-muted);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em}.jksh-stat strong{display:block;font-size:25px;margin-top:3px;color:var(--jk-ink)}.jksh-stat.attention strong{color:var(--jk-red)}
    .jksh-toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;background:#fff;border:1px solid var(--jk-line);border-radius:14px;padding:12px;margin-bottom:14px;box-shadow:0 1px 2px rgba(15,23,42,.03)}.jksh-search{position:relative;flex:1;min-width:280px}.jksh-search .dashicons{position:absolute;left:11px;top:9px;color:#98a2b3}.jksh-search input{width:100%;padding-left:38px!important}.jksh-toolbar input,.jksh-toolbar select{min-height:38px;border-color:#d0d5dd;border-radius:8px}
    .jksh-table-wrap{background:#fff;border:1px solid var(--jk-line);border-radius:16px;overflow:hidden;box-shadow:0 4px 14px rgba(15,23,42,.05)}.jksh-content-table{width:100%;border-collapse:collapse}.jksh-content-table th{background:#f8fafc;color:#667085;font-size:11px;text-transform:uppercase;letter-spacing:.04em;text-align:left;padding:12px 14px;border-bottom:1px solid var(--jk-line)}.jksh-content-table td{padding:14px;border-bottom:1px solid #eef1f5;vertical-align:middle}.jksh-content-table tbody tr:hover{background:#fbfdff}.jksh-content-table tbody tr:last-child td{border-bottom:0}.jksh-title-cell{display:flex;gap:11px;align-items:center;min-width:260px}.jksh-title-cell strong{display:block;font-size:14px;color:#101828}.jksh-title-cell small{display:block;margin-top:3px;color:#98a2b3}.jksh-type-icon{width:36px;height:36px;border-radius:10px;background:#eef4ff;color:#3157c8;display:grid;place-items:center;font-weight:800}.jksh-num{font-weight:700}.jksh-row-action{text-align:right}.jksh-platforms{font-size:12px;color:#475467}.schedule{font-size:12px;color:#7a4e00;white-space:nowrap}.muted{color:#98a2b3;font-size:12px}
    .badge{display:inline-flex;align-items:center;border-radius:999px;padding:5px 9px;font-size:11px;font-weight:700;background:#f2f4f7;color:#344054;white-space:nowrap}.state-published,.state-sandbox-published{background:#dcfae6;color:#067647}.state-scheduled,.state-part-published{background:#fef0c7;color:#93370d}.state-needs-attention{background:#fee4e2;color:#b42318}.state-uploaded{background:#dbeafe;color:#1d4ed8}.state-community-ready{background:#ede9fe;color:#6941c6}.state-cancelled{background:#f2f4f7;color:#667085}
    .jksh-empty{text-align:center;padding:40px;color:#667085}.jksh-empty .dashicons{font-size:30px;width:30px;height:30px}.jksh-empty strong{display:block;color:#344054;margin-top:6px;font-size:15px}.jksh-empty p{margin:4px 0 0}
    .jksh-editor-shell{padding-bottom:50px}.jksh-editor-head{align-items:center;margin-bottom:12px}.jksh-editor-head h1{font-size:25px;max-width:920px}.jksh-back{display:inline-block;color:#bfdbfe;text-decoration:none;margin-bottom:10px}.jksh-back:hover{color:#fff}.jksh-head-meta{display:flex;gap:8px;align-items:center;flex-wrap:wrap;color:#dbeafe;font-size:12px}.jksh-editor-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:0 0 10px}.jksh-editor-summary>div{background:#fff;border:1px solid var(--jk-line);border-radius:12px;padding:12px 14px}.jksh-editor-summary span{display:block;color:#98a2b3;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.05em}.jksh-editor-summary strong{display:block;margin-top:3px;color:#344054;font-size:13px;overflow:hidden;text-overflow:ellipsis}.jksh-section-nav{position:sticky;top:32px;z-index:20;background:rgba(246,247,247,.94);backdrop-filter:blur(10px);border-bottom:1px solid var(--jk-line);display:flex;gap:8px;padding:8px 0;margin-bottom:12px}.jksh-section-nav a{text-decoration:none;background:#fff;border:1px solid var(--jk-line);border-radius:999px;padding:6px 11px;color:#344054;font-size:12px;font-weight:600}.jksh-section-nav a:hover{border-color:#98a2b3;color:#101828}
    .jkshclm-editor{display:grid;gap:14px}.jksh-panel,.jkshclm section{background:#fff;border:1px solid var(--jk-line);border-radius:16px;padding:20px 22px;box-shadow:0 2px 10px rgba(15,23,42,.035);scroll-margin-top:90px}.jksh-panel-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;border-bottom:1px solid #eef1f5;padding-bottom:13px;margin-bottom:16px}.jksh-panel-head h2{margin:3px 0 3px;font-size:18px;color:#101828}.jksh-panel-head p{margin:0;color:#98a2b3;font-size:12px}.jksh-panel-kicker{color:#667085}.field{display:block;margin:12px 0}.field span{display:block;font-weight:650;color:#344054;margin-bottom:6px;font-size:12px}.field input[type=text],.field textarea{width:100%;max-width:100%;border:1px solid #d0d5dd;border-radius:9px;padding:9px 11px;box-shadow:0 1px 2px rgba(16,24,40,.03)}.field input[type=text]:focus,.field textarea:focus{border-color:#84adff;box-shadow:0 0 0 3px #eff4ff;outline:0}.field input[disabled],.field textarea[disabled]{background:#f8fafc;color:#667085}.two{display:grid;grid-template-columns:1fr 1fr;gap:12px}.checks{display:flex;gap:16px;flex-wrap:wrap;margin:14px 0;background:#f8fafc;border-radius:10px;padding:10px 12px}.checks label{margin:0}.media-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(155px,1fr));gap:12px}.media-card{border:1px solid var(--jk-line);border-radius:12px;padding:8px;overflow:hidden;background:#fbfcfe}.media-card img,.media-card video{display:block;width:100%;aspect-ratio:1/1;object-fit:cover;border-radius:9px;margin-bottom:8px;background:#111}.media-card b{color:#344054}.media-card small{display:block;color:#98a2b3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.count{font-size:11px;background:#eef2ff;color:#3730a3;border-radius:999px;padding:3px 7px;vertical-align:middle}
    .variant{border:1px solid var(--jk-line);border-radius:12px;margin:10px 0;padding:0;background:#fff;overflow:hidden}.variant summary{cursor:pointer;font-size:14px;padding:13px 15px;background:#f8fafc}.variant form,.variant>p,.variant>.jobs{margin-left:15px;margin-right:15px}.jobs{background:#f8fafc;border-radius:10px;padding:10px 12px;margin-bottom:15px}.job{padding:8px 0;border-bottom:1px solid #e5e7eb;display:flex;gap:10px;align-items:center;flex-wrap:wrap;font-size:12px}.job:last-child{border-bottom:0}.error{color:var(--jk-red);width:100%;font-weight:600}.danger-zone{border-top:1px solid var(--jk-line);margin-top:16px;padding-top:16px}.widefat{border:1px solid var(--jk-line)!important;border-radius:10px;overflow:hidden}.button{border-radius:7px!important}.button-primary{background:var(--jk-blue)!important;border-color:var(--jk-blue)!important}.button-primary:hover{background:var(--jk-blue2)!important;border-color:var(--jk-blue2)!important}
    @media(max-width:1100px){.jksh-stat-grid{grid-template-columns:repeat(3,1fr)}.jksh-content-table th,.jksh-content-table td{padding-left:8px;padding-right:8px}.jksh-editor-summary{grid-template-columns:repeat(2,1fr)}}
    @media(max-width:782px){.jksh-hero,.jksh-editor-head{flex-direction:column}.jksh-stat-grid{grid-template-columns:repeat(2,1fr)}.jksh-toolbar>*{width:100%;min-width:0!important}.jksh-search{min-width:0}.jksh-content-table thead{display:none}.jksh-content-table,.jksh-content-table tbody,.jksh-content-table tr,.jksh-content-table td{display:block;width:100%}.jksh-content-table tr{border-bottom:1px solid var(--jk-line);padding:10px 0}.jksh-content-table td{border:0;padding:7px 12px}.jksh-content-table td:before{content:attr(data-label);display:block;color:#98a2b3;font-size:10px;font-weight:700;text-transform:uppercase;margin-bottom:3px}.jksh-row-action{text-align:left}.two,.jksh-editor-summary{grid-template-columns:1fr}.jksh-section-nav{top:0;overflow:auto;white-space:nowrap}.jkshclm section{padding:16px}}
    </style>';}

}

JKSH_Content_Library_V091::instance();

/* JKSH_V0911_SAFE_APPEND */
/**
 * JK Social Hub v0.9.1.1 Content Library safety patch.
 *
 * Keeps the native v0.9.1 unified renderer as the single owner of the
 * Content Library admin page and adds guarded local Test/QA cleanup.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class JKSH_Content_Library_V0911_Safety {
    private const PAGE_SLUG = 'jksh-content';
    private const REST_NS   = 'jksh/v1';
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu', [ $this, 'take_over_content_library' ], PHP_INT_MAX );
        add_action( 'admin_init', [ $this, 'handle_admin_action' ], 20 );
        add_action( 'admin_footer', [ $this, 'inject_delete_buttons' ], PHP_INT_MAX );
        add_action( 'rest_api_init', [ $this, 'register_rest_routes' ] );
    }

    public function take_over_content_library() {
        if ( ! class_exists( 'JKSH_Content_Library_V091' ) || ! method_exists( 'JKSH_Content_Library_V091', 'instance' ) ) {
            return;
        }

        global $submenu;
        $parent_slug = '';
        if ( is_array( $submenu ) ) {
            foreach ( $submenu as $parent => $items ) {
                if ( ! is_array( $items ) ) {
                    continue;
                }
                foreach ( $items as $item ) {
                    if ( isset( $item[2] ) && self::PAGE_SLUG === (string) $item[2] ) {
                        $parent_slug = (string) $parent;
                        break 2;
                    }
                }
            }
        }

        if ( '' === $parent_slug ) {
            return;
        }

        // Remove duplicate menu rows for the same page slug before adding one canonical row.
        foreach ( $submenu[ $parent_slug ] as $index => $item ) {
            if ( isset( $item[2] ) && self::PAGE_SLUG === (string) $item[2] ) {
                unset( $submenu[ $parent_slug ][ $index ] );
            }
        }
        $submenu[ $parent_slug ] = array_values( $submenu[ $parent_slug ] );

        $renderer = [ JKSH_Content_Library_V091::instance(), 'render_page' ];
        $hook = add_submenu_page(
            $parent_slug,
            'Content Library',
            'Content Library',
            'manage_options',
            self::PAGE_SLUG,
            $renderer
        );

        if ( $hook ) {
            // WordPress admin pages execute every callback attached to the page hook.
            // Keeping one callback prevents the old table and unified table rendering together.
            remove_all_actions( $hook );
            add_action( $hook, $renderer, 10 );
            update_option(
                'jksh_v0911_content_library_owner',
                [
                    'hook'       => $hook,
                    'parent'     => $parent_slug,
                    'updated_at' => gmdate( 'c' ),
                ],
                false
            );
        }
    }

    public function handle_admin_action() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $action = isset( $_POST['jksh_v0911_action'] ) ? sanitize_key( wp_unslash( $_POST['jksh_v0911_action'] ) ) : '';
        if ( 'delete_test_qa' !== $action ) {
            return;
        }

        $id = isset( $_POST['content_id'] ) ? absint( $_POST['content_id'] ) : 0;
        if ( ! $id ) {
            wp_die( esc_html__( 'Missing content ID.', 'jk-social-hub' ) );
        }

        check_admin_referer( 'jksh_v0911_delete_test_' . $id );

        try {
            $items = $this->test_items();
            if ( ! isset( $items[ $id ] ) ) {
                throw new RuntimeException( 'This record is not classified as Test/QA.' );
            }
            $result = $this->delete_local_test_item( $id, 'manual_button', true );
            $notice = sprintf( 'Deleted local Test/QA record #%d. External social posts were not deleted.', $id );
            if ( ! empty( $result['external_records'] ) ) {
                $notice .= ' External IDs were preserved in the cleanup audit.';
            }
        } catch ( Throwable $e ) {
            $notice = 'Delete failed: ' . $e->getMessage();
        }

        wp_safe_redirect(
            add_query_arg(
                [
                    'page'          => self::PAGE_SLUG,
                    'jksh_v0911_msg'=> rawurlencode( $notice ),
                ],
                admin_url( 'admin.php' )
            )
        );
        exit;
    }

    public function inject_delete_buttons() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        if ( empty( $_GET['page'] ) || self::PAGE_SLUG !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
            return;
        }

        $items = $this->test_items();
        $client = [];
        foreach ( $items as $id => $item ) {
            $client[ (string) $id ] = [
                'title' => $item['title'],
                'nonce' => wp_create_nonce( 'jksh_v0911_delete_test_' . $id ),
            ];
        }

        if ( isset( $_GET['jksh_v0911_msg'] ) ) {
            $msg = sanitize_text_field( wp_unslash( $_GET['jksh_v0911_msg'] ) );
            echo '<div class="notice notice-info is-dismissible" style="margin:14px 20px 0 0"><p>' . esc_html( $msg ) . '</p></div>';
        }
        ?>
        <style>
            .jksh-v0911-delete-test{margin-left:8px!important;border-color:#fecaca!important;background:#fff1f2!important;color:#be123c!important;font-weight:700!important}
            .jksh-v0911-delete-test:hover{border-color:#f87171!important;background:#ffe4e6!important;color:#9f1239!important}
        </style>
        <script>
        (() => {
            const records = <?php echo wp_json_encode( $client ); ?>;
            if (!records || !Object.keys(records).length) return;
            document.querySelectorAll('a[href*="edit_content="]').forEach((openLink) => {
                let url;
                try { url = new URL(openLink.href, window.location.href); } catch (e) { return; }
                const id = url.searchParams.get('edit_content');
                if (!id || !records[id]) return;
                const cell = openLink.closest('td') || openLink.parentElement;
                if (!cell || cell.querySelector('.jksh-v0911-delete-test')) return;

                const form = document.createElement('form');
                form.method = 'post';
                form.style.display = 'inline-block';
                form.style.margin = '0';
                form.addEventListener('submit', (event) => {
                    const ok = window.confirm('Delete this local Test/QA record? Any external Instagram, Facebook or YouTube post will remain untouched.');
                    if (!ok) event.preventDefault();
                });
                const fields = {
                    jksh_v0911_action: 'delete_test_qa',
                    content_id: id,
                    _wpnonce: records[id].nonce
                };
                Object.entries(fields).forEach(([name, value]) => {
                    const input = document.createElement('input');
                    input.type = 'hidden'; input.name = name; input.value = value;
                    form.appendChild(input);
                });
                const button = document.createElement('button');
                button.type = 'submit';
                button.className = 'button jksh-v0911-delete-test';
                button.textContent = 'Delete Test';
                form.appendChild(button);
                cell.appendChild(form);
            });
        })();
        </script>
        <?php
    }

    public function register_rest_routes() {
        register_rest_route(
            self::REST_NS,
            '/maintenance/test-qa',
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [ $this, 'rest_preview_test_qa' ],
                    'permission_callback' => [ $this, 'can_manage' ],
                ],
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [ $this, 'rest_clear_test_qa' ],
                    'permission_callback' => [ $this, 'can_manage' ],
                    'args'                => [
                        'confirm' => [
                            'type'     => 'boolean',
                            'required' => true,
                        ],
                    ],
                ],
            ]
        );

        register_rest_route(
            self::REST_NS,
            '/maintenance/content-library-ui',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'rest_ui_status' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ]
        );
    }

    public function can_manage() {
        return current_user_can( 'manage_options' );
    }

    public function rest_preview_test_qa() {
        $items = $this->test_items();
        return rest_ensure_response(
            [
                'ok'    => true,
                'count' => count( $items ),
                'items' => array_values( $items ),
                'note'  => 'Preview only. External social posts are never deleted by this maintenance endpoint.',
            ]
        );
    }

    public function rest_clear_test_qa( WP_REST_Request $request ) {
        if ( true !== (bool) $request->get_param( 'confirm' ) ) {
            return new WP_Error( 'jksh_confirm_required', 'confirm=true is required.', [ 'status' => 400 ] );
        }

        global $wpdb;
        $items = $this->test_items();
        if ( empty( $items ) ) {
            return rest_ensure_response( [ 'ok' => true, 'deleted' => [], 'count' => 0 ] );
        }

        $deleted = [];
        $external = [];
        $wpdb->query( 'START TRANSACTION' );
        try {
            foreach ( array_keys( $items ) as $id ) {
                $result = $this->delete_local_test_item( (int) $id, 'bulk_cleanup', false );
                $deleted[] = (int) $id;
                if ( ! empty( $result['external_records'] ) ) {
                    $external = array_merge( $external, $result['external_records'] );
                }
            }
            $wpdb->query( 'COMMIT' );
        } catch ( Throwable $e ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'jksh_cleanup_failed', $e->getMessage(), [ 'status' => 500 ] );
        }

        update_option(
            'jksh_v0911_last_bulk_cleanup',
            [
                'deleted_ids'                => $deleted,
                'external_records_preserved' => $external,
                'completed_at_utc'            => gmdate( 'c' ),
            ],
            false
        );

        return rest_ensure_response(
            [
                'ok'                         => true,
                'count'                      => count( $deleted ),
                'deleted_ids'                => $deleted,
                'external_records_preserved' => $external,
                'external_posts_deleted'     => false,
            ]
        );
    }

    public function rest_ui_status() {
        return rest_ensure_response(
            [
                'ok'          => true,
                'patch'       => '0.9.1.1',
                'renderer'    => class_exists( 'JKSH_Content_Library_V091' ),
                'owner_state' => get_option( 'jksh_v0911_content_library_owner', [] ),
                'test_count'  => count( $this->test_items() ),
            ]
        );
    }

    private function tables() {
        global $wpdb;
        return [
            'content'  => $wpdb->prefix . 'jksh_content',
            'variants' => $wpdb->prefix . 'jksh_variants',
            'jobs'     => $wpdb->prefix . 'jksh_jobs',
            'media'    => $wpdb->prefix . 'jksh_media',
            'logs'     => $wpdb->prefix . 'jksh_publish_logs',
            'analytics'=> $wpdb->prefix . 'jksh_analytics',
            'receipts' => $wpdb->prefix . 'jksh_queue_bridge_receipts',
        ];
    }

    private function table_exists( $table ) {
        global $wpdb;
        return $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
    }

    private function direct_test_match( array $row ) {
        $haystack = implode(
            ' ',
            [
                (string) ( $row['title'] ?? '' ),
                (string) ( $row['content_type'] ?? '' ),
                (string) ( $row['body'] ?? '' ),
                (string) ( $row['meta_json'] ?? '' ),
            ]
        );
        return (bool) preg_match( '/(^|\\b)(qa|test|specimen)(\\b|$)|do not publish|never publish|internal\\s+(?:qa|test|dry[- ]?run)|jk direct mcp|dry[- ]?run\\s+test/i', $haystack );
    }

    private function bundle_ids_from_row( array $row ) {
        $out = [];
        $meta = json_decode( (string) ( $row['meta_json'] ?? '' ), true );
        if ( ! is_array( $meta ) ) {
            return $out;
        }

        if ( ! empty( $meta['bundle_id'] ) && is_string( $meta['bundle_id'] ) ) {
            $out[] = sanitize_text_field( $meta['bundle_id'] );
        }
        if ( ! empty( $meta['request_id'] ) && is_string( $meta['request_id'] ) ) {
            if ( preg_match( '/upload-([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})-/i', $meta['request_id'], $m ) ) {
                $out[] = strtolower( $m[1] );
            }
        }
        return array_values( array_unique( array_filter( $out ) ) );
    }

    private function test_items() {
        global $wpdb;
        $t = $this->tables();
        $rows = $wpdb->get_results(
            "SELECT id,title,content_type,body,status,meta_json FROM {$t['content']} ORDER BY id DESC",
            ARRAY_A
        );
        if ( ! is_array( $rows ) ) {
            return [];
        }

        $test_bundles = [];
        foreach ( $rows as $row ) {
            if ( $this->direct_test_match( $row ) ) {
                foreach ( $this->bundle_ids_from_row( $row ) as $bundle_id ) {
                    $test_bundles[ strtolower( $bundle_id ) ] = true;
                }
            }
        }

        $items = [];
        foreach ( $rows as $row ) {
            $direct = $this->direct_test_match( $row );
            $companion = false;
            foreach ( $this->bundle_ids_from_row( $row ) as $bundle_id ) {
                if ( isset( $test_bundles[ strtolower( $bundle_id ) ] ) ) {
                    $companion = true;
                    break;
                }
            }
            if ( ! $direct && ! $companion ) {
                continue;
            }

            $id = (int) $row['id'];
            $external_records = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id,platform,status,external_id,external_url FROM {$t['variants']} WHERE content_id=%d AND (external_id<>'' OR external_url IS NOT NULL AND external_url<>'')",
                    $id
                ),
                ARRAY_A
            );
            $items[ $id ] = [
                'id'               => $id,
                'title'            => (string) $row['title'],
                'content_type'     => (string) $row['content_type'],
                'status'           => (string) $row['status'],
                'classification'   => $direct ? 'direct_test_qa' : 'companion_of_test_bundle',
                'external_records' => is_array( $external_records ) ? $external_records : [],
            ];
        }
        return $items;
    }

    private function delete_local_test_item( $id, $reason, $manage_transaction ) {
        global $wpdb;
        $id = absint( $id );
        if ( ! $id ) {
            throw new RuntimeException( 'Invalid content ID.' );
        }

        $items = $this->test_items();
        if ( ! isset( $items[ $id ] ) ) {
            throw new RuntimeException( 'Record is not classified as Test/QA.' );
        }

        $t = $this->tables();
        $content = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['content']} WHERE id=%d", $id ), ARRAY_A );
        if ( ! $content ) {
            throw new RuntimeException( 'Content record not found.' );
        }
        $variants = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t['variants']} WHERE content_id=%d", $id ), ARRAY_A );
        $jobs     = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t['jobs']} WHERE content_id=%d", $id ), ARRAY_A );
        $media    = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t['media']} WHERE content_id=%d", $id ), ARRAY_A );
        $logs     = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t['logs']} WHERE content_id=%d", $id ), ARRAY_A );

        $external_records = [];
        foreach ( (array) $variants as $variant ) {
            if ( ! empty( $variant['external_id'] ) || ! empty( $variant['external_url'] ) ) {
                $external_records[] = [
                    'platform'     => (string) ( $variant['platform'] ?? '' ),
                    'status'       => (string) ( $variant['status'] ?? '' ),
                    'external_id'  => (string) ( $variant['external_id'] ?? '' ),
                    'external_url' => (string) ( $variant['external_url'] ?? '' ),
                ];
            }
        }
        foreach ( (array) $logs as $log ) {
            if ( ! empty( $log['external_id'] ) || ! empty( $log['external_url'] ) ) {
                $external_records[] = [
                    'platform'     => '',
                    'status'       => (string) ( $log['result'] ?? '' ),
                    'external_id'  => (string) ( $log['external_id'] ?? '' ),
                    'external_url' => (string) ( $log['external_url'] ?? '' ),
                ];
            }
        }

        $audit = get_option( 'jksh_v0911_test_cleanup_audit', [] );
        if ( ! is_array( $audit ) ) {
            $audit = [];
        }
        $audit[] = [
            'deleted_at_utc'            => gmdate( 'c' ),
            'reason'                    => sanitize_key( $reason ),
            'content'                   => $content,
            'variants'                  => $variants,
            'jobs'                      => $jobs,
            'media_links'               => $media,
            'publish_logs'              => $logs,
            'external_posts_not_deleted'=> true,
        ];
        $audit = array_slice( $audit, -100 );
        update_option( 'jksh_v0911_test_cleanup_audit', $audit, false );

        $variant_ids = array_values( array_filter( array_map( 'absint', wp_list_pluck( (array) $variants, 'id' ) ) ) );

        if ( $manage_transaction ) {
            $wpdb->query( 'START TRANSACTION' );
        }
        try {
            if ( ! empty( $variant_ids ) && $this->table_exists( $t['analytics'] ) ) {
                $placeholders = implode( ',', array_fill( 0, count( $variant_ids ), '%d' ) );
                $wpdb->query( $wpdb->prepare( "DELETE FROM {$t['analytics']} WHERE variant_id IN ($placeholders)", ...$variant_ids ) );
            }
            if ( $this->table_exists( $t['logs'] ) ) {
                $wpdb->delete( $t['logs'], [ 'content_id' => $id ], [ '%d' ] );
            }
            if ( $this->table_exists( $t['jobs'] ) ) {
                $wpdb->delete( $t['jobs'], [ 'content_id' => $id ], [ '%d' ] );
            }
            if ( $this->table_exists( $t['media'] ) ) {
                $wpdb->delete( $t['media'], [ 'content_id' => $id ], [ '%d' ] );
            }
            if ( $this->table_exists( $t['variants'] ) ) {
                $wpdb->delete( $t['variants'], [ 'content_id' => $id ], [ '%d' ] );
            }
            if ( $this->table_exists( $t['receipts'] ) ) {
                $wpdb->delete( $t['receipts'], [ 'content_id' => $id ], [ '%d' ] );
            }
            $deleted = $wpdb->delete( $t['content'], [ 'id' => $id ], [ '%d' ] );
            if ( false === $deleted ) {
                throw new RuntimeException( 'Failed deleting content record.' );
            }
            if ( $manage_transaction ) {
                $wpdb->query( 'COMMIT' );
            }
        } catch ( Throwable $e ) {
            if ( $manage_transaction ) {
                $wpdb->query( 'ROLLBACK' );
            }
            throw $e;
        }

        return [
            'id'               => $id,
            'external_records' => $external_records,
        ];
    }
}

JKSH_Content_Library_V0911_Safety::instance();

