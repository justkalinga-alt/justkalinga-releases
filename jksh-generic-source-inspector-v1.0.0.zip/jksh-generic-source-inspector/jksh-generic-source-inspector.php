<?php
/**
 * Plugin Name: JKSH Generic Source Inspector
 * Description: Temporary read-only inspector for a strict allowlist of JKSH classes.
 * Version: 1.0.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action( 'rest_api_init', function () {
    register_rest_route( 'jksh-generic-source/v1', '/inspect', array(
        'methods' => 'GET',
        'permission_callback' => function () { return current_user_can( 'manage_options' ); },
        'callback' => function ( WP_REST_Request $request ) {
            $key = sanitize_key( (string) $request->get_param( 'key' ) );
            $map = array(
                'youtube_publisher' => '\JKSH\Services\YouTubePublisher',
                'youtube_client' => '\JKSH\Services\YouTubeClient',
                'variant_repo' => '\JKSH\Repositories\VariantRepository',
                'job_repo' => '\JKSH\Repositories\JobRepository',
                'log_repo' => '\JKSH\Repositories\LogRepository',
            );
            if ( empty( $map[ $key ] ) ) return new WP_Error( 'invalid_key', 'Class key is not allowed.', array( 'status' => 400 ) );
            $class = $map[ $key ];
            if ( ! class_exists( $class ) ) return new WP_Error( 'missing', 'Class could not be autoloaded.', array( 'status' => 404 ) );
            $r = new ReflectionClass( $class );
            $file = $r->getFileName();
            $lines = ( $file && is_readable( $file ) ) ? file( $file, FILE_IGNORE_NEW_LINES ) : array();
            $out = array( 'class' => $class, 'file' => $file ? basename( $file ) : '', 'methods' => array(), 'source' => array() );
            foreach ( $r->getMethods() as $m ) $out['methods'][] = array( 'name' => $m->getName(), 'public' => $m->isPublic(), 'static' => $m->isStatic() );
            if ( $lines ) {
                $max = min( 500, count( $lines ) );
                for ( $i = 1; $i <= $max; $i++ ) $out['source'][] = array( 'line' => $i, 'text' => $lines[ $i - 1 ] );
            }
            return rest_ensure_response( $out );
        },
    ) );
} );
