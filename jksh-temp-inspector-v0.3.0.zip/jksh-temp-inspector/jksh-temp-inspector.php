<?php
/**
 * Plugin Name: JKSH Temporary Bridge Inspector
 * Description: Temporary maintenance helper for safe inspection/patching of JK Social Supabase Bridge.
 * Version: 0.3.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
function jksh_temp_bridge_root(){ return WP_PLUGIN_DIR . '/jk-social-supabase-bridge'; }
function jksh_temp_bridge_main(){ return jksh_temp_bridge_root() . '/jk-social-supabase-bridge.php'; }
add_action('rest_api_init',function(){
 register_rest_route('jksh-temp/v1','/bridge-search',[
  'methods'=>'GET','permission_callback'=>fn()=>current_user_can('manage_options'),
  'callback'=>function(WP_REST_Request $r){
   $q=(string)$r->get_param('q'); if(''===$q)return new WP_Error('q_required','q required',['status'=>400]);
   $path=jksh_temp_bridge_main(); if(!is_file($path))return new WP_Error('missing','Bridge file missing',['status'=>404]);
   $lines=file($path,FILE_IGNORE_NEW_LINES); $hits=[]; $ctx=max(0,min(8,(int)$r->get_param('context')));
   foreach($lines as $i=>$line){ if(false===stripos($line,$q))continue; $a=max(0,$i-$ctx); $b=min(count($lines)-1,$i+$ctx); $chunk=[]; for($j=$a;$j<=$b;$j++)$chunk[]=['line'=>$j+1,'text'=>$lines[$j]]; $hits[]=['line'=>$i+1,'context'=>$chunk]; if(count($hits)>=20)break; }
   return rest_ensure_response(['ok'=>true,'query'=>$q,'hits'=>$hits,'sha256'=>hash_file('sha256',$path)]);
  }
 ]);
 register_rest_route('jksh-temp/v1','/bridge-range',[
  'methods'=>'GET','permission_callback'=>fn()=>current_user_can('manage_options'),
  'callback'=>function(WP_REST_Request $r){
   $start=max(1,(int)$r->get_param('start')); $count=max(1,min(160,(int)$r->get_param('count')));
   $path=jksh_temp_bridge_main(); $lines=file($path,FILE_IGNORE_NEW_LINES); $out=[];
   for($i=$start-1;$i<min(count($lines),$start-1+$count);$i++)$out[]=['line'=>$i+1,'text'=>$lines[$i]];
   return rest_ensure_response(['ok'=>true,'start'=>$start,'count'=>count($out),'lines'=>$out,'sha256'=>hash_file('sha256',$path)]);
  }
 ]);
 register_rest_route('jksh-temp/v1','/bridge-replace',[
  'methods'=>'POST','permission_callback'=>fn()=>current_user_can('manage_options'),
  'callback'=>function(WP_REST_Request $r){
   if(true!==rest_sanitize_boolean($r->get_param('confirm')))return new WP_Error('confirm','confirm=true required',['status'=>400]);
   $path=jksh_temp_bridge_main(); $expected=strtolower((string)$r->get_param('expected_sha256')); $current=hash_file('sha256',$path);
   if($expected!==$current)return new WP_Error('sha_mismatch','Bridge changed since inspection',['status'=>409,'current_sha256'=>$current]);
   $old=(string)$r->get_param('old'); $new=(string)$r->get_param('new'); if(''===$old)return new WP_Error('old_required','old required',['status'=>400]);
   $src=file_get_contents($path); $n=substr_count($src,$old); if(1!==$n)return new WP_Error('match_count','Exact old text must occur exactly once',['status'=>409,'matches'=>$n]);
   $backup=$path.'.jkshbak-'.gmdate('YmdHis'); if(!copy($path,$backup))return new WP_Error('backup_failed','Backup failed',['status'=>500]);
   $patched=str_replace($old,$new,$src,$count); if(1!==$count||false===file_put_contents($path,$patched,LOCK_EX)){ @copy($backup,$path); return new WP_Error('write_failed','Patch failed; backup restored',['status'=>500]); }
   return rest_ensure_response(['ok'=>true,'backup'=>basename($backup),'previous_sha256'=>$current,'new_sha256'=>hash_file('sha256',$path)]);
  }
 ]);
});
