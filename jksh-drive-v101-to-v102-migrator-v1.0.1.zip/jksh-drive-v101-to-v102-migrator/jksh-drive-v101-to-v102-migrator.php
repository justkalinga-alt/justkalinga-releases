<?php
/**
 * Plugin Name: JKSH Drive v1.0.1 to v1.0.2 Migrator
 * Description: One-time guarded migration of the existing encrypted Drive connection into JKSH AccountRepository for Drive Storage v1.0.2.
 * Version: 1.0.0
 * Author: JustKalinga
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'rest_api_init', function () {
    register_rest_route( 'jksh-drive-migrate/v1', '/status', array(
        'methods' => 'GET',
        'permission_callback' => function(){ return current_user_can('manage_options'); },
        'callback' => function(){
            $old = get_option( 'jksh_drive_storage_v101', array() );
            $repo_ready = class_exists('\\JKSH\\Repositories\\AccountRepository');
            $crypto_ready = class_exists('\\JKSH\\Security\\Crypto');
            $new_connected = false;
            if ( $repo_ready ) {
                $repo = new \JKSH\Repositories\AccountRepository();
                $rows = $repo->connected('google_drive');
                $new_connected = ! empty($rows);
            }
            return rest_ensure_response(array(
                'ok'=>true,
                'old_present'=>is_array($old) && !empty($old),
                'old_connected'=>is_array($old) && !empty($old['connected']),
                'old_has_access'=>is_array($old) && !empty($old['access']),
                'old_has_refresh'=>is_array($old) && !empty($old['refresh']),
                'old_has_root'=>is_array($old) && !empty($old['root']),
                'old_has_large'=>is_array($old) && !empty($old['large']),
                'repo_ready'=>$repo_ready,
                'crypto_ready'=>$crypto_ready,
                'new_connected'=>$new_connected,
            ));
        }
    ));
    register_rest_route( 'jksh-drive-migrate/v1', '/run', array(
        'methods' => 'POST',
        'permission_callback' => function(){ return current_user_can('manage_options'); },
        'callback' => function(WP_REST_Request $req){
            if ( true !== rest_sanitize_boolean( $req->get_param('confirm') ) ) return new WP_Error('confirm_required','confirm=true is required.',array('status'=>400));
            if ( ! class_exists('\\JKSH\\Repositories\\AccountRepository') || ! class_exists('\\JKSH\\Security\\Crypto') ) return new WP_Error('deps','JKSH repository/crypto dependencies are unavailable.',array('status'=>500));
            $old = get_option( 'jksh_drive_storage_v101', array() );
            if ( ! is_array($old) || empty($old['connected']) || empty($old['refresh']) ) return new WP_Error('old_missing','The existing v1.0.1 Drive connection is incomplete.',array('status'=>409));
            $crypto = new \JKSH\Security\Crypto();
            try {
                $access = !empty($old['access']) ? (string)$crypto->decrypt((string)$old['access']) : '';
                $refresh = (string)$crypto->decrypt((string)$old['refresh']);
            } catch ( Throwable $e ) {
                return new WP_Error('decrypt_failed','Could not decrypt the existing Drive credentials.',array('status'=>500));
            }
            if ( '' === $refresh ) return new WP_Error('refresh_missing','Existing Drive refresh token could not be recovered.',array('status'=>409));
            $settings = array(
                'vault_folder_id' => sanitize_text_field((string)($old['root'] ?? '')),
                'large_media_folder_id' => sanitize_text_field((string)($old['large'] ?? '')),
                'large_media_folder_name' => 'Large Media',
                'migrated_from' => 'jksh_drive_storage_v101',
            );
            $credentials = array(
                'access_token' => $access,
                'refresh_token' => $refresh,
                'token_type' => 'Bearer',
                'scope' => sanitize_text_field((string)($old['scope'] ?? 'https://www.googleapis.com/auth/drive.file')),
            );
            $repo = new \JKSH\Repositories\AccountRepository();
            $id = $repo->upsert(array(
                'platform' => 'google_drive',
                'account_name' => 'Google Drive',
                'external_account_id' => 'jksh-primary-drive',
                'status' => 'connected',
                'settings' => $settings,
                'credentials' => $credentials,
                'token_expires_at' => !empty($old['expires']) ? sanitize_text_field((string)$old['expires']) : null,
                'last_checked_at' => current_time('mysql', true),
                'last_error' => '',
            ));
            if ( $id < 1 ) return new WP_Error('upsert_failed','Could not create the v1.0.2 Drive account record.',array('status'=>500));
            return rest_ensure_response(array(
                'ok'=>true,
                'account_id'=>$id,
                'platform'=>'google_drive',
                'folder_migrated'=>!empty($settings['large_media_folder_id']),
                'refresh_token_migrated'=>true,
                'old_option_preserved'=>true,
            ));
        }
    ));
});
