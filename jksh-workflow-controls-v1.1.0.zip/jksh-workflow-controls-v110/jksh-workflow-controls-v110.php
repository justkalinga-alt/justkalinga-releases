<?php
/**
 * Plugin Name: JKSH Workflow Controls
 * Description: Native YouTube video-selection repair plus Content Library Publish/Schedule controls for JK Social Hub.
 * Version: 1.1.0
 * Author: JustKalinga
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class JKSH_Workflow_Controls_V110 {
    const VERSION = '1.1.0';
    const BRIDGE_MARKER = 'JKSH_YT_NATIVE_ADMIN_FIX_V220';
    const PATCH_OPTION = 'jksh_workflow_controls_v110_patch_status';

    public static function init() : void {
        add_action( 'plugins_loaded', array( __CLASS__, 'patch_second_upload_renderer' ), 40 );
        add_action( 'rest_api_init', array( __CLASS__, 'rest_routes' ) );
        add_action( 'admin_footer', array( __CLASS__, 'inject_library_ui' ), 9999 );
        add_action( 'wp_footer', array( __CLASS__, 'inject_library_ui' ), 9999 );
    }

    private static function bridge_file() : string {
        $candidates = array(
            WP_PLUGIN_DIR . '/jk-social-supabase-bridge-disabled/jk-social-supabase-bridge.php',
            WP_PLUGIN_DIR . '/jk-social-supabase-bridge/jk-social-supabase-bridge.php',
        );
        foreach ( $candidates as $file ) {
            if ( is_file( $file ) && is_readable( $file ) && is_writable( $file ) ) {
                return $file;
            }
        }
        return '';
    }

    public static function patch_second_upload_renderer() : void {
        $file = self::bridge_file();
        if ( ! $file ) {
            update_option( self::PATCH_OPTION, array(
                'ok' => false,
                'message' => 'Writable JK Social Supabase Bridge file not found.',
                'checked_at' => current_time( 'mysql', true ),
            ), false );
            return;
        }

        $src = file_get_contents( $file );
        if ( false === $src ) {
            update_option( self::PATCH_OPTION, array(
                'ok' => false,
                'message' => 'Could not read bridge file.',
                'checked_at' => current_time( 'mysql', true ),
            ), false );
            return;
        }

        if ( false !== strpos( $src, self::BRIDGE_MARKER ) ) {
            update_option( self::PATCH_OPTION, array(
                'ok' => true,
                'patched' => true,
                'already_patched' => true,
                'sha256' => hash_file( 'sha256', $file ),
                'checked_at' => current_time( 'mysql', true ),
            ), false );
            return;
        }

        $old = <<<'JS'
document.querySelectorAll('.jkssb-type-btn').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.jkssb-type-btn').forEach(x=>x.classList.remove('is-active'));btn.classList.add('is-active');typeEl.value=btn.dataset.type;syncType();renderOrder();}));
JS;

        $new = <<<'JS'
document.querySelectorAll('.jkssb-type-btn').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.jkssb-type-btn').forEach(x=>x.classList.remove('is-active'));btn.classList.add('is-active');typeEl.value=btn.dataset.type;syncType();renderOrder();const yt=document.querySelector('.jkssb-platform[value="youtube"]');if(yt&&(btn.dataset.type==='reel'||btn.dataset.type==='long_video')){yt.disabled=false;yt.checked=true;const card=yt.closest('.jkssb-platform-card');if(card){card.classList.remove('is-disabled');card.style.pointerEvents='auto';card.style.opacity='1';card.removeAttribute('title');}}}));/* JKSH_YT_NATIVE_ADMIN_FIX_V220 */
JS;

        $count = substr_count( $src, $old );
        if ( 1 !== $count ) {
            update_option( self::PATCH_OPTION, array(
                'ok' => false,
                'message' => 'Expected one secondary Social Upload type handler; found ' . $count . '.',
                'sha256' => hash_file( 'sha256', $file ),
                'checked_at' => current_time( 'mysql', true ),
            ), false );
            return;
        }

        $backup = $file . '.jkshbak-workflow-controls-' . gmdate( 'YmdHis' );
        if ( ! copy( $file, $backup ) ) {
            update_option( self::PATCH_OPTION, array(
                'ok' => false,
                'message' => 'Could not create bridge backup.',
                'sha256' => hash_file( 'sha256', $file ),
                'checked_at' => current_time( 'mysql', true ),
            ), false );
            return;
        }

        $patched = str_replace( $old, $new, $src, $replaced );
        if ( 1 !== $replaced || false === file_put_contents( $file, $patched, LOCK_EX ) ) {
            @copy( $backup, $file );
            update_option( self::PATCH_OPTION, array(
                'ok' => false,
                'message' => 'Bridge patch failed; original file restored.',
                'backup' => basename( $backup ),
                'checked_at' => current_time( 'mysql', true ),
            ), false );
            return;
        }

        clearstatcache( true, $file );
        update_option( self::PATCH_OPTION, array(
            'ok' => true,
            'patched' => true,
            'backup' => basename( $backup ),
            'sha256' => hash_file( 'sha256', $file ),
            'checked_at' => current_time( 'mysql', true ),
        ), false );
    }

    public static function rest_routes() : void {
        register_rest_route( 'jksh-workflow-controls/v1', '/status', array(
            'methods' => 'GET',
            'permission_callback' => function() {
                return current_user_can( 'manage_options' );
            },
            'callback' => function() {
                $file = self::bridge_file();
                $src = $file ? (string) file_get_contents( $file ) : '';
                return rest_ensure_response( array(
                    'ok' => true,
                    'version' => self::VERSION,
                    'publish_ui' => true,
                    'bridge_file' => $file ? str_replace( WP_PLUGIN_DIR . '/', '', $file ) : '',
                    'youtube_secondary_renderer_patched' => false !== strpos( $src, self::BRIDGE_MARKER ),
                    'patch_status' => get_option( self::PATCH_OPTION, array() ),
                    'stable_queue_ability' => function_exists( 'wp_get_ability' ) && (bool) wp_get_ability( 'jk-social/queue-content-id' ),
                    'reschedule_ability' => function_exists( 'wp_get_ability' ) && (bool) wp_get_ability( 'jk-social-supabase/reschedule-publish-job-ist' ),
                ) );
            },
        ) );

        register_rest_route( 'jksh/v1', '/content/(?P<id>\d+)/manual-publish', array(
            'methods' => 'POST',
            'permission_callback' => function() {
                return current_user_can( 'manage_options' );
            },
            'callback' => array( __CLASS__, 'manual_publish' ),
            'args' => array(
                'id' => array(
                    'validate_callback' => function( $value ) {
                        return absint( $value ) > 0;
                    },
                ),
            ),
        ) );
    }

    private static function normalize_ist( string $value ) {
        $value = trim( $value );
        if ( '' === $value ) {
            return new WP_Error( 'jksh_manual_publish_time', 'Choose a date and time.', array( 'status' => 400 ) );
        }

        try {
            $tz = new DateTimeZone( 'Asia/Kolkata' );
            $dt = new DateTimeImmutable( $value, $tz );
        } catch ( Throwable $e ) {
            return new WP_Error( 'jksh_manual_publish_time', 'The selected date/time is invalid.', array( 'status' => 400 ) );
        }

        $now = new DateTimeImmutable( 'now', new DateTimeZone( 'Asia/Kolkata' ) );
        if ( $dt < $now->modify( '-30 seconds' ) ) {
            return new WP_Error( 'jksh_manual_publish_past', 'Choose a current or future IST date/time.', array( 'status' => 400 ) );
        }

        return $dt->format( 'Y-m-d H:i:s' );
    }

    public static function manual_publish( WP_REST_Request $request ) {
        if ( true !== (bool) $request->get_param( 'confirm' ) ) {
            return new WP_Error( 'jksh_manual_publish_confirm', 'confirm=true is required.', array( 'status' => 400 ) );
        }

        $content_id = absint( $request['id'] );
        $when = self::normalize_ist( (string) $request->get_param( 'scheduled_at_ist' ) );
        if ( is_wp_error( $when ) ) {
            return $when;
        }

        global $wpdb;
        $content_table = $wpdb->prefix . 'jksh_content';
        $jobs_table = $wpdb->prefix . 'jksh_publish_jobs';

        $row = $wpdb->get_row(
            $wpdb->prepare( "SELECT id,status,title,meta_json FROM {$content_table} WHERE id=%d", $content_id ),
            ARRAY_A
        );
        if ( ! $row ) {
            return new WP_Error( 'jksh_manual_publish_missing', 'Content Library item not found.', array( 'status' => 404 ) );
        }

        if ( ! function_exists( 'wp_get_ability' ) ) {
            return new WP_Error( 'jksh_manual_publish_abilities', 'WordPress Abilities API is unavailable.', array( 'status' => 500 ) );
        }

        $status = sanitize_key( (string) $row['status'] );

        if ( in_array( $status, array( 'uploaded', 'draft' ), true ) ) {
            $ability = wp_get_ability( 'jk-social/queue-content-id' );
            if ( ! $ability ) {
                return new WP_Error( 'jksh_manual_publish_queue_missing', 'Stable Content Library scheduler is unavailable.', array( 'status' => 503 ) );
            }
            $result = $ability->execute( array(
                'content_id' => $content_id,
                'scheduled_at_ist' => $when,
                'confirm_live' => true,
            ) );
            if ( is_wp_error( $result ) ) {
                return $result;
            }
            return rest_ensure_response( array(
                'ok' => true,
                'mode' => 'queued',
                'content_id' => $content_id,
                'scheduled_at_ist' => $when,
                'result' => $result,
            ) );
        }

        $queued = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id,attempts,status FROM {$jobs_table} WHERE content_id=%d AND job_type='publish' AND status='queued' AND attempts=0 ORDER BY id ASC",
                $content_id
            ),
            ARRAY_A
        );

        if ( $queued ) {
            $ability = wp_get_ability( 'jk-social-supabase/reschedule-publish-job-ist' );
            if ( ! $ability ) {
                return new WP_Error( 'jksh_manual_publish_reschedule_missing', 'In-place job rescheduler is unavailable.', array( 'status' => 503 ) );
            }

            $done = array();
            foreach ( $queued as $job ) {
                $result = $ability->execute( array(
                    'job_id' => absint( $job['id'] ),
                    'scheduled_at_ist' => $when,
                    'confirm' => true,
                ) );
                if ( is_wp_error( $result ) ) {
                    return new WP_Error(
                        'jksh_manual_publish_reschedule_failed',
                        'Job #' . absint( $job['id'] ) . ': ' . $result->get_error_message(),
                        array( 'status' => 409, 'rescheduled_job_ids' => $done )
                    );
                }
                $done[] = absint( $job['id'] );
            }

            return rest_ensure_response( array(
                'ok' => true,
                'mode' => 'rescheduled',
                'content_id' => $content_id,
                'job_ids' => $done,
                'scheduled_at_ist' => $when,
            ) );
        }

        $failed = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id,variant_id,attempts,max_attempts,status FROM {$jobs_table} WHERE content_id=%d AND job_type='publish' AND status='failed' AND attempts < max_attempts ORDER BY id ASC",
                $content_id
            ),
            ARRAY_A
        );

        if ( $failed ) {
            $variant_table = $wpdb->prefix . 'jksh_platform_variants';
            $tz_ist = new DateTimeZone( 'Asia/Kolkata' );
            $tz_utc = new DateTimeZone( 'UTC' );
            $dt_ist = new DateTimeImmutable( $when, $tz_ist );
            $dt_utc = $dt_ist->setTimezone( $tz_utc );
            $scheduled_utc = $dt_utc->format( 'Y-m-d H:i:s' );
            $timestamp = max( time() + 5, $dt_utc->getTimestamp() );
            $now_utc = current_time( 'mysql', true );
            $retried = array();

            foreach ( $failed as $job ) {
                $job_id = absint( $job['id'] );
                $variant_id = absint( $job['variant_id'] );
                if ( ! $job_id || ! $variant_id ) {
                    continue;
                }

                $updated = $wpdb->update(
                    $jobs_table,
                    array(
                        'status' => 'queued',
                        'scheduled_at' => $scheduled_utc,
                        'started_at' => null,
                        'completed_at' => null,
                        'last_error' => '',
                        'updated_at' => $now_utc,
                    ),
                    array( 'id' => $job_id, 'status' => 'failed' ),
                    array( '%s', '%s', '%s', '%s', '%s', '%s' ),
                    array( '%d', '%s' )
                );
                if ( false === $updated || 0 === $updated ) {
                    continue;
                }

                $wpdb->update(
                    $variant_table,
                    array(
                        'status' => 'scheduled',
                        'publish_at' => $scheduled_utc,
                        'updated_at' => $now_utc,
                    ),
                    array( 'id' => $variant_id ),
                    array( '%s', '%s', '%s' ),
                    array( '%d' )
                );

                wp_clear_scheduled_hook( 'jksh_process_job', array( $job_id ) );
                wp_schedule_single_event( $timestamp, 'jksh_process_job', array( $job_id ) );
                $retried[] = $job_id;
            }

            if ( $retried ) {
                $wpdb->update(
                    $content_table,
                    array( 'status' => 'scheduled', 'updated_at' => $now_utc ),
                    array( 'id' => $content_id ),
                    array( '%s', '%s' ),
                    array( '%d' )
                );

                return rest_ensure_response( array(
                    'ok' => true,
                    'mode' => 'retry_failed',
                    'content_id' => $content_id,
                    'job_ids' => $retried,
                    'scheduled_at_ist' => $when,
                ) );
            }
        }

        return new WP_Error(
            'jksh_manual_publish_not_schedulable',
            'This row has no new upload, untouched queued job, or retryable failed publish job.',
            array( 'status' => 409 )
        );
    }

    public static function inject_library_ui() : void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $nonce = wp_create_nonce( 'wp_rest' );
        $tz = new DateTimeZone( 'Asia/Kolkata' );
        $default = ( new DateTimeImmutable( 'now', $tz ) )->modify( '+5 minutes' );
        $default_date = $default->format( 'Y-m-d' );
        $default_time = $default->format( 'H:i' );
        ?>
        <style id="jksh-workflow-controls-v110-css">
        .jksh-manual-publish{background:#0f766e!important;border-color:#0f766e!important;color:#fff!important}
        .jksh-manual-publish:hover{background:#115e59!important;border-color:#115e59!important;color:#fff!important}
        #jksh-manual-publish-modal[hidden]{display:none!important}
        #jksh-manual-publish-modal{position:fixed;inset:0;z-index:100000;background:rgba(15,23,42,.52);display:grid;place-items:center;padding:18px}
        #jksh-manual-publish-card{width:min(440px,100%);background:#fff;border-radius:18px;box-shadow:0 24px 70px rgba(15,23,42,.28);padding:20px;box-sizing:border-box}
        #jksh-manual-publish-card h2{margin:0 0 6px;font-size:20px;color:#101828}
        #jksh-manual-publish-card p{margin:0 0 16px;color:#667085;font-size:12px;line-height:1.5}
        .jksh-manual-publish-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
        .jksh-manual-publish-grid label{font-size:11px;font-weight:750;color:#344054}
        .jksh-manual-publish-grid input{display:block;width:100%;height:44px;margin-top:6px;padding:0 10px;border:1px solid #d0d5dd;border-radius:10px;box-sizing:border-box}
        .jksh-manual-publish-actions{display:flex;gap:9px;justify-content:flex-end;margin-top:18px}
        .jksh-manual-publish-actions button{min-height:42px;border-radius:10px;padding:0 16px;font-weight:750;cursor:pointer}
        #jksh-manual-publish-cancel{background:#fff;border:1px solid #d0d5dd;color:#344054}
        #jksh-manual-publish-confirm{background:#0f766e;border:1px solid #0f766e;color:#fff}
        #jksh-manual-publish-status{min-height:18px;margin-top:10px;font-size:11px;color:#475467}
        @media(max-width:560px){.jksh-manual-publish-grid{grid-template-columns:1fr}.jksh-manual-publish-actions{display:grid;grid-template-columns:1fr 1fr}.jksh-manual-publish-actions button{width:100%}}
        </style>
        <div id="jksh-manual-publish-modal" hidden>
          <div id="jksh-manual-publish-card" role="dialog" aria-modal="true" aria-labelledby="jksh-manual-publish-title">
            <h2 id="jksh-manual-publish-title">Publish content</h2>
            <p id="jksh-manual-publish-copy">Choose the IST date and time. Uploaded content uses its existing Content ID. Scheduled jobs are rescheduled in place. Needs-attention rows retry only failed platform jobs, reusing the same job IDs.</p>
            <div class="jksh-manual-publish-grid">
              <label>Date <input id="jksh-manual-publish-date" type="date" value="<?php echo esc_attr( $default_date ); ?>"></label>
              <label>Time <input id="jksh-manual-publish-time" type="time" value="<?php echo esc_attr( $default_time ); ?>"></label>
            </div>
            <div id="jksh-manual-publish-status"></div>
            <div class="jksh-manual-publish-actions">
              <button type="button" id="jksh-manual-publish-cancel">Cancel</button>
              <button type="button" id="jksh-manual-publish-confirm">Publish / Schedule</button>
            </div>
          </div>
        </div>
        <script id="jksh-workflow-controls-v110-js">
        (() => {
          const nonce = <?php echo wp_json_encode( $nonce ); ?>;
          const modal = document.getElementById('jksh-manual-publish-modal');
          if (!modal || modal.dataset.wired === '1') return;
          modal.dataset.wired = '1';

          const title = document.getElementById('jksh-manual-publish-title');
          const date = document.getElementById('jksh-manual-publish-date');
          const time = document.getElementById('jksh-manual-publish-time');
          const status = document.getElementById('jksh-manual-publish-status');
          const cancel = document.getElementById('jksh-manual-publish-cancel');
          const confirmBtn = document.getElementById('jksh-manual-publish-confirm');
          let activeId = 0;

          const contentIdFromRow = row => {
            const text = row.innerText || '';
            const m = text.match(/Content\s*#?\s*(\d+)/i) || text.match(/Content\s*ID\s*#?\s*(\d+)/i);
            return m ? Number(m[1]) : 0;
          };

          const workflowFromRow = row => {
            const cells = [...row.querySelectorAll('td')];
            return (cells[1]?.innerText || '').trim();
          };

          const open = (id, workflow) => {
            activeId = id;
            title.textContent = (/scheduled/i.test(workflow) ? 'Reschedule' : (/needs attention/i.test(workflow) ? 'Retry / Publish' : 'Publish')) + ' Content #' + id;
            status.textContent = '';
            modal.hidden = false;
            setTimeout(() => date.focus(), 20);
          };

          const close = () => {
            modal.hidden = true;
            activeId = 0;
            status.textContent = '';
          };

          cancel.addEventListener('click', close);
          modal.addEventListener('click', e => { if (e.target === modal) close(); });
          document.addEventListener('keydown', e => { if (e.key === 'Escape' && !modal.hidden) close(); });

          confirmBtn.addEventListener('click', async () => {
            if (!activeId) return;
            if (!date.value || !time.value) {
              status.textContent = 'Choose both date and time.';
              return;
            }
            confirmBtn.disabled = true;
            confirmBtn.textContent = 'Scheduling…';
            status.textContent = 'Saving schedule…';
            try {
              const r = await fetch('/wp-json/jksh/v1/content/' + activeId + '/manual-publish', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                  'Content-Type': 'application/json',
                  'X-WP-Nonce': nonce
                },
                body: JSON.stringify({
                  scheduled_at_ist: date.value + ' ' + time.value + ':00',
                  confirm: true
                })
              });
              const d = await r.json();
              if (!r.ok || !d.ok) throw new Error(d?.message || 'Publish scheduling failed.');
              status.textContent = d.mode === 'rescheduled' ? 'Rescheduled ✓' : 'Scheduled ✓';
              setTimeout(() => location.reload(), 500);
            } catch (e) {
              status.textContent = e.message || 'Publish scheduling failed.';
            } finally {
              confirmBtn.disabled = false;
              confirmBtn.textContent = 'Publish / Schedule';
            }
          });

          const enhance = () => {
            document.querySelectorAll('table.jksh-content-table tbody tr').forEach(row => {
              if (row.dataset.jkshPublishEnhanced === '1') return;
              const id = contentIdFromRow(row);
              if (!id) return;
              const workflow = workflowFromRow(row);
              if (!/^(Uploaded|Scheduled|Needs attention)\b/i.test(workflow)) {
                row.dataset.jkshPublishEnhanced = '1';
                return;
              }
              const cells = [...row.querySelectorAll('td')];
              const action = cells[cells.length - 1];
              if (!action) return;
              const btn = document.createElement('button');
              btn.type = 'button';
              btn.className = 'button jksh-manual-publish';
              btn.textContent = 'Publish';
              btn.dataset.contentId = String(id);
              btn.addEventListener('click', () => open(id, workflow));
              action.appendChild(btn);
              row.dataset.jkshPublishEnhanced = '1';
            });
          };

          enhance();
          new MutationObserver(enhance).observe(document.body, {childList:true, subtree:true});
        })();
        </script>
        <?php
    }
}

JKSH_Workflow_Controls_V110::init();
